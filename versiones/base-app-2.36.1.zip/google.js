// Base — conexión con Google (Calendar y Gmail) desde el proceso principal.
// Inicio de sesión en el navegador del sistema (OAuth 2.0 para apps de escritorio, con PKCE).
// Las credenciales quedan cifradas con el sistema de Windows (safeStorage / DPAPI).
const { app, shell, safeStorage, net } = require('electron');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SCOPES = [
  'openid',
  'email',
  'https://www.googleapis.com/auth/calendar.events',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.modify', // para marcar como leído
  'https://www.googleapis.com/auth/drive.file' // sólo los archivos que crea Base (las copias)
];
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
const MODIFY = 'https://www.googleapis.com/auth/gmail.modify';
const MODES = new Set(['casa', 'trabajo']);

const dir = () => app.getPath('userData');
const cfgFile = () => path.join(dir(), 'google-app.bin');
const tokFile = (mode) => path.join(dir(), `google-${mode}.bin`);

function writeSecret(file, obj) {
  const text = JSON.stringify(obj);
  const data = safeStorage.isEncryptionAvailable()
    ? Buffer.concat([Buffer.from('ENC1'), safeStorage.encryptString(text)])
    : Buffer.from('RAW1' + text, 'utf8');
  fs.mkdirSync(dir(), { recursive: true });
  fs.writeFileSync(file, data);
}
function readSecret(file) {
  try {
    const buf = fs.readFileSync(file);
    const tag = buf.subarray(0, 4).toString();
    if (tag === 'ENC1') return JSON.parse(safeStorage.decryptString(buf.subarray(4)));
    if (tag === 'RAW1') return JSON.parse(buf.subarray(4).toString('utf8'));
  } catch { /* no existe o no se puede leer */ }
  return null;
}

// Si Base trae incorporadas las claves de la app (google-default.json junto al programa), conectar es un clic.
function defaultConfig() {
  try { const j = JSON.parse(fs.readFileSync(path.join(__dirname, 'google-default.json'), 'utf8')); if (j && /\.apps\.googleusercontent\.com$/.test(j.clientId || '')) return { clientId: j.clientId, clientSecret: j.clientSecret || '' }; } catch {}
  return null;
}
const getConfig = () => readSecret(cfgFile()) || defaultConfig();
function setConfig(clientId, clientSecret) {
  clientId = String(clientId || '').trim();
  clientSecret = String(clientSecret || '').trim();
  if (!/\.apps\.googleusercontent\.com$/.test(clientId)) throw new Error('El ID de cliente tiene que terminar en .apps.googleusercontent.com');
  if (clientSecret.length < 10) throw new Error('Falta el secreto del cliente');
  writeSecret(cfgFile(), { clientId, clientSecret });
}

const tokens = {};
function getTokens(mode) {
  if (!tokens[mode]) tokens[mode] = readSecret(tokFile(mode));
  return tokens[mode];
}
function saveTokens(mode, t) {
  tokens[mode] = t;
  writeSecret(tokFile(mode), t);
}

function status() {
  const out = { configured: !!getConfig(), accounts: {} };
  for (const m of MODES) {
    const t = getTokens(m);
    out.accounts[m] = t ? { email: t.email, needsRelink: !!t.needsRelink, canModify: String(t.scope || '').includes(MODIFY), canDrive: String(t.scope || '').includes(DRIVE_SCOPE) } : null;
  }
  return out;
}

async function postForm(url, params) {
  const r = await net.fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString()
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const e = new Error(j.error_description || j.error || 'HTTP ' + r.status);
    e.code = j.error;
    throw e;
  }
  return j;
}

function decodeJwt(idToken) {
  try { return JSON.parse(Buffer.from(idToken.split('.')[1], 'base64url').toString('utf8')); } catch { return {}; }
}

const PAGE = (title, text) => `<!doctype html><meta charset="utf-8"><title>Base</title>
<body style="font-family:Segoe UI,system-ui,sans-serif;display:grid;place-items:center;height:100vh;margin:0;background:#eef0f3;color:#18202a">
<div style="text-align:center;max-width:420px"><h1 style="font-size:24px;margin:0 0 8px">${title}</h1><p style="color:#586372;margin:0">${text}</p></div>`;

let pendingAuth = null;
function link(mode) {
  if (!MODES.has(mode)) return Promise.reject(new Error('Modo inválido'));
  const cfg = getConfig();
  if (!cfg) return Promise.reject(new Error('Primero configurá la conexión con Google'));
  if (pendingAuth) pendingAuth.cancel('Se empezó otra vinculación');

  return new Promise((resolve, reject) => {
    const verifier = crypto.randomBytes(48).toString('base64url');
    const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
    const state = crypto.randomBytes(16).toString('hex');
    let redirect = '';
    let done = false;

    const server = http.createServer(async (req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1');
      if (u.pathname !== '/') { res.writeHead(404); return res.end(); }
      const finish = (ok, title, text) => {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(PAGE(title, text));
      };
      if (u.searchParams.get('state') !== state) return finish(false, 'Algo no coincide', 'Volvé a Base y probá vincular de nuevo.');
      const err = u.searchParams.get('error');
      if (err) { finish(false, 'No se vinculó', 'Cancelaste o Google no dio permiso. Podés cerrar esta pestaña.'); return end(new Error(err === 'access_denied' ? 'Cancelaste el permiso en Google' : err)); }
      const code = u.searchParams.get('code');
      try {
        const t = await postForm('https://oauth2.googleapis.com/token', {
          code, client_id: cfg.clientId, client_secret: cfg.clientSecret,
          redirect_uri: redirect, grant_type: 'authorization_code', code_verifier: verifier
        });
        if (!t.refresh_token) throw new Error('Google no devolvió acceso permanente. Probá de nuevo.');
        const granted = String(t.scope || '');
        const missing = [];
        if (!granted.includes('calendar.events')) missing.push('Calendar');
        if (!granted.includes('gmail.readonly') && !granted.includes('gmail.modify')) missing.push('Gmail');
        if (!granted.includes('drive.file')) missing.push('Drive');
        const email = decodeJwt(t.id_token).email || '';
        saveTokens(mode, {
          email, refresh: t.refresh_token, access: t.access_token,
          exp: Date.now() + (t.expires_in - 60) * 1000, scope: granted
        });
        finish(true, 'Listo, cuenta vinculada', `${email} quedó conectada al modo ${mode === 'casa' ? 'Casa' : 'Trabajo'}. Ya podés cerrar esta pestaña y volver a Base.`);
        end(null, { email, missing });
      } catch (e) {
        finish(false, 'No se pudo vincular', e.message);
        end(e);
      }
    });

    const timer = setTimeout(() => end(new Error('Se terminó el tiempo para vincular. Probá de nuevo.')), 5 * 60000);
    function end(e, val) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      pendingAuth = null;
      setTimeout(() => server.close(), 500);
      e ? reject(e) : resolve(val);
    }
    pendingAuth = { cancel: (msg) => end(new Error(msg)) };

    server.listen(0, '127.0.0.1', () => {
      redirect = `http://127.0.0.1:${server.address().port}/`;
      const auth = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      auth.search = new URLSearchParams({
        client_id: cfg.clientId, redirect_uri: redirect, response_type: 'code',
        scope: SCOPES.join(' '), access_type: 'offline', prompt: 'consent select_account',
        include_granted_scopes: 'true', state, code_challenge: challenge, code_challenge_method: 'S256'
      }).toString();
      shell.openExternal(auth.href);
    });
    server.on('error', (e) => end(e));
  });
}

async function unlink(mode) {
  const t = getTokens(mode);
  if (t && t.refresh) {
    try { await postForm('https://oauth2.googleapis.com/revoke', { token: t.refresh }); } catch { /* ya no era válido */ }
  }
  tokens[mode] = null;
  try { fs.unlinkSync(tokFile(mode)); } catch {}
}

async function accessToken(mode) {
  const t = getTokens(mode);
  if (!t) throw Object.assign(new Error('Cuenta no vinculada'), { code: 'not_linked' });
  if (t.needsRelink) throw Object.assign(new Error('Hay que volver a vincular la cuenta'), { code: 'relink' });
  if (t.access && Date.now() < t.exp) return t.access;
  const cfg = getConfig();
  try {
    const r = await postForm('https://oauth2.googleapis.com/token', {
      client_id: cfg.clientId, client_secret: cfg.clientSecret, refresh_token: t.refresh, grant_type: 'refresh_token'
    });
    t.access = r.access_token;
    t.exp = Date.now() + (r.expires_in - 60) * 1000;
    saveTokens(mode, t);
    return t.access;
  } catch (e) {
    if (e.code === 'invalid_grant') {
      t.needsRelink = true;
      saveTokens(mode, t);
      throw Object.assign(new Error('Google pidió volver a vincular la cuenta'), { code: 'relink' });
    }
    throw e;
  }
}

async function gapi(mode, url, opts = {}, retry = true) {
  const token = await accessToken(mode);
  const r = await net.fetch(url, {
    method: opts.method || 'GET',
    headers: { Authorization: 'Bearer ' + token, ...(opts.body ? { 'Content-Type': 'application/json' } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  if (r.status === 401 && retry) {
    getTokens(mode).exp = 0;
    return gapi(mode, url, opts, false);
  }
  if (r.status === 204) return null;
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = (j.error && (j.error.message || j.error.status)) || 'HTTP ' + r.status;
    const e = new Error(/has not been used|is disabled/i.test(msg)
      ? 'Falta activar la API en Google Cloud (paso 2 del asistente)'
      : msg);
    e.code = r.status === 403 ? 'forbidden' : 'http';
    throw e;
  }
  return j;
}

// ----- Calendar -----
async function events(mode, timeMin, timeMax) {
  const u = new URL('https://www.googleapis.com/calendar/v3/calendars/primary/events');
  u.search = new URLSearchParams({
    timeMin, timeMax, singleEvents: 'true', orderBy: 'startTime', maxResults: '250',
    fields: 'items(id,summary,start,end,htmlLink,location,status)'
  }).toString();
  const j = await gapi(mode, u.href);
  return (j.items || []).filter(e => e.status !== 'cancelled').map(e => ({
    id: e.id, title: e.summary || '(Sin título)', link: e.htmlLink, location: e.location || '',
    allDay: !!(e.start && e.start.date),
    start: e.start.dateTime || e.start.date,
    end: e.end ? (e.end.dateTime || e.end.date) : null
  }));
}

async function createEvent(mode, ev) {
  const body = { summary: ev.title };
  if (ev.time) {
    const start = new Date(`${ev.date}T${ev.time}:00`);
    const end = new Date(start.getTime() + 60 * 60000);
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    body.start = { dateTime: start.toISOString(), timeZone: tz };
    body.end = { dateTime: end.toISOString(), timeZone: tz };
  } else {
    const d = new Date(`${ev.date}T12:00:00`);
    d.setDate(d.getDate() + 1);
    const next = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    body.start = { date: ev.date };
    body.end = { date: next };
  }
  if (ev.notify !== '' && ev.notify != null) {
    body.reminders = { useDefault: false, overrides: [{ method: 'popup', minutes: Number(ev.notify) }] };
  }
  const j = await gapi(mode, 'https://www.googleapis.com/calendar/v3/calendars/primary/events', { method: 'POST', body });
  return { id: j.id, link: j.htmlLink };
}

async function deleteEvent(mode, id) {
  await gapi(mode, `https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

// ----- Gmail -----
async function mail(mode) {
  const base = 'https://gmail.googleapis.com/gmail/v1/users/me';
  const [label, list] = await Promise.all([
    gapi(mode, `${base}/labels/INBOX`),
    gapi(mode, `${base}/messages?q=${encodeURIComponent('is:unread in:inbox')}&maxResults=15`)
  ]);
  const ids = ((list && list.messages) || []).map(m => m.id);
  const msgs = await Promise.all(ids.map(id =>
    gapi(mode, `${base}/messages/${id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&fields=id,threadId,snippet,internalDate,payload/headers`)
      .catch(() => null)));
  const header = (m, n) => {
    const h = (m.payload && m.payload.headers || []).find(x => x.name.toLowerCase() === n);
    return h ? h.value : '';
  };
  const t = getTokens(mode);
  return {
    email: t && t.email,
    unread: (label && label.messagesUnread) || 0,
    messages: msgs.filter(Boolean).map(m => {
      const from = header(m, 'from');
      const name = (/^"?([^"<]+?)"?\s*</.exec(from) || [])[1] || from.replace(/<.*>/, '').trim() || from;
      const addr = ((/<([^>]+)>/.exec(from) || [])[1] || (/[^\s<>"]+@[^\s<>"]+/.exec(from) || [''])[0]).toLowerCase();
      return {
        id: m.id, thread: m.threadId, from: name, addr, subject: header(m, 'subject') || '(Sin asunto)',
        snippet: (m.snippet || '').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'),
        date: Number(m.internalDate) || 0
      };
    })
  };
}

// ----- Gmail: leer un mail completo y marcar como leído -----
function decodePart(part) {
  if (!part || !part.body || !part.body.data) return '';
  const buf = Buffer.from(part.body.data, 'base64url');
  const ct = ((part.headers || []).find(h => h.name.toLowerCase() === 'content-type') || {}).value || '';
  const cs = (/charset="?([\w-]+)"?/i.exec(ct) || [])[1] || 'utf-8';
  try { return new TextDecoder(cs.toLowerCase()).decode(buf); } catch { return buf.toString('utf8'); }
}
function walk(part, out) {
  if (!part) return;
  const mt = (part.mimeType || '').toLowerCase();
  if (part.filename) out.attachments.push(part.filename);
  else if (mt === 'text/html' && !out.html) out.html = decodePart(part);
  else if (mt === 'text/plain' && !out.text) out.text = decodePart(part);
  for (const p of part.parts || []) walk(p, out);
}
async function message(mode, id) {
  if (!/^[\w-]{1,40}$/.test(String(id))) throw new Error('Mail inválido');
  const m = await gapi(mode, `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=full`);
  const hs = (m.payload && m.payload.headers) || [];
  const h = (n) => ((hs.find(x => x.name.toLowerCase() === n) || {}).value || '');
  const out = { html: '', text: '', attachments: [] };
  walk(m.payload, out);
  const t = getTokens(mode);
  return {
    id: m.id, thread: m.threadId, subject: h('subject') || '(Sin asunto)', from: h('from'), to: h('to'), date: Number(m.internalDate) || 0,
    unread: (m.labelIds || []).includes('UNREAD'), html: out.html, text: out.text, attachments: out.attachments,
    email: t && t.email, canModify: !!(t && String(t.scope || '').includes(MODIFY))
  };
}
async function markRead(mode, ids) {
  ids = (Array.isArray(ids) ? ids : [ids]).map(String).filter(x => /^[\w-]{1,40}$/.test(x)).slice(0, 500);
  if (!ids.length) return;
  const t = getTokens(mode);
  if (!t || !String(t.scope || '').includes(MODIFY)) throw Object.assign(new Error('Falta el permiso para modificar el correo'), { code: 'need_modify' });
  await gapi(mode, 'https://gmail.googleapis.com/gmail/v1/users/me/messages/batchModify', { method: 'POST', body: { ids, removeLabelIds: ['UNREAD'] } });
}

// ----- Gmail: avisos de consumo de las tarjetas (para sumar lo gastado) -----
function htmlToText(h) {
  return String(h || '').replace(/<(script|style|head)[\s\S]*?<\/\1>/gi, ' ').replace(/<br\s*\/?>|<\/(p|div|tr|li|h\d|table)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&aacute;/gi, 'á').replace(/&eacute;/gi, 'é').replace(/&iacute;/gi, 'í').replace(/&oacute;/gi, 'ó')
    .replace(/&uacute;/gi, 'ú').replace(/&ntilde;/gi, 'ñ').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}
// dos búsquedas aparte (Gmail se confunde con muchos paréntesis): los avisos de los bancos y los de Mercado Pago / Mercado Libre
const CC_QUERIES = [
  '(visa OR amex OR "american express" OR mastercard) (consumo OR compra OR transacción OR autorizamos OR realizaste OR cargo)',
  'from:(mercadopago OR mercadolibre) (pagaste OR compraste)'
];
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function cardMails(mode, q, skip, days) {
  const base = 'https://gmail.googleapis.com/gmail/v1/users/me';
  const d = Math.max(7, Math.min(400, Number(days) || 70));
  const queries = String(q || '').trim() ? [String(q).slice(0, 400)] : CC_QUERIES;
  const known = new Set((Array.isArray(skip) ? skip : []).map(String));
  let ids = [];
  for (const one of queries) {
    let token = '';
    for (let page = 0; page < 3; page++) {
      const j = await gapi(mode, `${base}/messages?q=${encodeURIComponent(`newer_than:${d}d ${one}`)}&maxResults=100&fields=messages/id,nextPageToken${token ? '&pageToken=' + token : ''}`);
      ids.push(...((j && j.messages) || []).map(m => m.id));
      token = j && j.nextPageToken; if (!token) break;
    }
  }
  ids = [...new Set(ids)];
  const all = ids.slice();
  const todo = ids.filter(id => !known.has(id));
  ids = todo.slice(0, 25);
  const out = [], failed = [];
  // de a poquito para no pasarnos del límite por minuto de Gmail
  for (let i = 0; i < ids.length; i += 5) {
    if (i) await sleep(400);
    const part = await Promise.all(ids.slice(i, i + 5).map(id => gapi(mode, `${base}/messages/${id}?format=full&fields=id,internalDate,payload`).catch((e) => { failed.push(id); if (/quota|rate limit/i.test(e.message)) throw Object.assign(new Error('quota'), { code: 'quota' }); return null; })));
    for (const m of part) {
      if (!m) continue;
      const hs = (m.payload && m.payload.headers) || [];
      const h = (n) => ((hs.find(x => x.name.toLowerCase() === n) || {}).value || '');
      const o = { html: '', text: '', attachments: [] };
      walk(m.payload, o);
      const text = (o.text && o.text.trim().length > 40 ? o.text : htmlToText(o.html)).replace(/[ \t ]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();
      out.push({ id: m.id, date: Number(m.internalDate) || 0, from: h('from'), subject: h('subject'), text: text.slice(0, 2500) });
    }
  }
  return { ids: all, items: out, failed, more: todo.length > ids.length };
}

// ----- Drive (sólo archivos creados por Base: permiso drive.file) -----
const DAPI = 'https://www.googleapis.com/drive/v3/files';
const UAPI = 'https://www.googleapis.com/upload/drive/v3/files';
function hasDrive(mode) { const t = getTokens(mode); return !!(t && !t.needsRelink && String(t.scope || '').includes(DRIVE_SCOPE)); }
async function dfetch(mode, url, opts = {}, retry = true) {
  const token = await accessToken(mode);
  const r = await net.fetch(url, { method: opts.method || 'GET', headers: { Authorization: 'Bearer ' + token, ...(opts.headers || {}) }, body: opts.body });
  if (r.status === 401 && retry) { getTokens(mode).exp = 0; return dfetch(mode, url, opts, false); }
  return r;
}
async function djson(mode, url, opts = {}) {
  const r = await dfetch(mode, url, opts);
  if (r.status === 204) return null;
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = (j.error && (j.error.message || j.error.status)) || 'HTTP ' + r.status;
    throw Object.assign(new Error(/has not been used|is disabled/i.test(msg) ? 'Falta activar la API de Google Drive en Google Cloud' : /insufficient|scope/i.test(msg) ? 'Falta el permiso de Drive: volvé a vincular la cuenta' : /storageQuotaExceeded|quota/i.test(msg) ? 'Tu Google Drive está lleno' : msg), { code: r.status === 404 ? 'notfound' : r.status === 403 ? 'forbidden' : 'http', status: r.status });
  }
  return j;
}
async function driveQuota(mode) {
  const j = await djson(mode, 'https://www.googleapis.com/drive/v3/about?fields=storageQuota');
  const q = (j && j.storageQuota) || {};
  return { limit: q.limit ? Number(q.limit) : null, usage: Number(q.usage || 0) };
}
async function driveAlive(mode, id) {
  try { const j = await djson(mode, `${DAPI}/${encodeURIComponent(id)}?fields=id,trashed`); return !!(j && j.id && !j.trashed); }
  catch (e) { if (e.code === 'notfound') return false; throw e; }
}
async function driveFolder(mode, name, parent) {
  const j = await djson(mode, `${DAPI}?fields=id`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, mimeType: 'application/vnd.google-apps.folder', ...(parent ? { parents: [parent] } : {}) }) });
  return j.id;
}
async function driveChildren(mode, parent) {
  const out = []; let page = '';
  do {
    const u = new URL(DAPI); u.search = new URLSearchParams({ q: `'${parent}' in parents and trashed=false`, fields: 'nextPageToken,files(id,name,createdTime)', pageSize: '1000', ...(page ? { pageToken: page } : {}) }).toString();
    const j = await djson(mode, u.href); out.push(...(j.files || [])); page = j.nextPageToken || '';
  } while (page);
  return out;
}
async function driveTrash(mode, id) { await djson(mode, `${DAPI}/${encodeURIComponent(id)}?fields=id`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ trashed: true }) }); }
// sube un archivo de la compu; si se pasa id, lo reemplaza (Drive guarda la versión anterior)
async function driveUpload(mode, file, { name, parent, id }) {
  const st = await fs.promises.stat(file);
  const meta = id ? {} : { name, parents: [parent] };
  const base = id ? `${UAPI}/${encodeURIComponent(id)}` : UAPI, method = id ? 'PATCH' : 'POST';
  if (st.size <= 5 * 1024 * 1024) {
    const data = await fs.promises.readFile(file), b = 'base' + crypto.randomBytes(8).toString('hex');
    const body = Buffer.concat([Buffer.from(`--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${b}\r\nContent-Type: application/octet-stream\r\n\r\n`), data, Buffer.from(`\r\n--${b}--`)]);
    const j = await djson(mode, `${base}?uploadType=multipart&fields=id`, { method, headers: { 'Content-Type': 'multipart/related; boundary=' + b }, body });
    return j.id;
  }
  // archivos grandes: subida en partes de 8 MB
  const r0 = await dfetch(mode, `${base}?uploadType=resumable&fields=id`, { method, headers: { 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Length': String(st.size) }, body: JSON.stringify(meta) });
  if (!r0.ok) { const j = await r0.json().catch(() => ({})); throw Object.assign(new Error((j.error && j.error.message) || 'HTTP ' + r0.status), { code: r0.status === 404 ? 'notfound' : 'http' }); }
  const loc = r0.headers.get('location'); if (!loc) throw new Error('Drive no aceptó la subida');
  const CH = 8 * 1024 * 1024, fh = await fs.promises.open(file, 'r');
  try {
    let pos = 0;
    while (pos < st.size) {
      const n = Math.min(CH, st.size - pos), buf = Buffer.alloc(n);
      await fh.read(buf, 0, n, pos);
      let r, tries = 0;
      for (;;) {
        try { r = await net.fetch(loc, { method: 'PUT', headers: { 'Content-Range': `bytes ${pos}-${pos + n - 1}/${st.size}` }, body: buf }); }
        catch (e) { if (++tries > 3) throw e; await new Promise(z => setTimeout(z, 2000 * tries)); continue; }
        if (r.status >= 500 && ++tries <= 3) { await new Promise(z => setTimeout(z, 2000 * tries)); continue; }
        break;
      }
      if (r.status === 308) { const rg = r.headers.get('range'); pos = rg ? Number(rg.split('-')[1]) + 1 : pos + n; continue; }
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error((j.error && j.error.message) || 'HTTP ' + r.status);
      return j.id;
    }
  } finally { await fh.close(); }
  throw new Error('La subida quedó incompleta');
}

module.exports = { hasDrive, driveQuota, driveAlive, driveFolder, driveChildren, driveTrash, driveUpload, cardMails, message, markRead, status, getConfig, setConfig, link, unlink, events, createEvent, deleteEvent, mail, MODES };
