// Base — escritorio personal (proceso principal)
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const {
  app, BrowserWindow, ipcMain, shell, dialog, Tray, Menu,
  globalShortcut, nativeImage, Notification, screen, net, powerMonitor
} = require('electron');

// Menú de clic derecho (cortar, copiar, pegar...) en campos de texto y texto seleccionado, en todas las ventanas
app.on('web-contents-created', (_e, wc) => {
  wc.on('context-menu', (_ev, p) => {
    const f = p.editFlags || {};
    const items = [];
    if (p.misspelledWord && p.dictionarySuggestions && p.dictionarySuggestions.length) {
      for (const sug of p.dictionarySuggestions.slice(0, 4)) items.push({ label: sug, click: () => wc.replaceMisspelling(sug) });
      items.push({ type: 'separator' });
    }
    if (p.isEditable) {
      items.push(
        { label: 'Deshacer', role: 'undo', accelerator: 'CmdOrCtrl+Z', enabled: f.canUndo !== false },
        { label: 'Rehacer', role: 'redo', accelerator: 'CmdOrCtrl+Y', enabled: f.canRedo !== false },
        { type: 'separator' },
        { label: 'Cortar', role: 'cut', accelerator: 'CmdOrCtrl+X', enabled: !!f.canCut },
        { label: 'Copiar', role: 'copy', accelerator: 'CmdOrCtrl+C', enabled: !!f.canCopy },
        { label: 'Pegar', role: 'paste', accelerator: 'CmdOrCtrl+V', enabled: f.canPaste !== false },
        { label: 'Pegar como texto', role: 'pasteAndMatchStyle', accelerator: 'CmdOrCtrl+Shift+V', visible: !!p.isEditable && p.inputFieldType === 'none' },
        { label: 'Borrar', role: 'delete', enabled: !!f.canDelete },
        { type: 'separator' },
        { label: 'Seleccionar todo', role: 'selectAll', accelerator: 'CmdOrCtrl+A' }
      );
    } else if (p.selectionText && p.selectionText.trim()) {
      items.push({ label: 'Copiar', role: 'copy', accelerator: 'CmdOrCtrl+C' });
    }
    if (p.linkURL && /^https?:/i.test(p.linkURL)) {
      if (items.length) items.push({ type: 'separator' });
      items.push({ label: 'Copiar dirección del enlace', click: () => require('electron').clipboard.writeText(p.linkURL) });
    }
    if (!items.length) return;
    try { Menu.buildFromTemplate(items).popup({ window: BrowserWindow.fromWebContents(wc) || undefined }); } catch {}
  });
});

try { require('electron').crashReporter.start({ uploadToServer: false }); } catch {}
const APP_ID = 'com.base.escritorio';
// edición: "completa" (Casa y Trabajo) o "compartir" (solo Casa)
let EDITION = { edicion: 'completa' };
try { EDITION = Object.assign(EDITION, JSON.parse(fs.readFileSync(path.join(__dirname, 'edicion.json'), 'utf8'))); } catch {}
const SINGLE = EDITION.edicion === 'compartir';
app.setAppUserModelId(APP_ID);

// Una sola instancia: si se abre de nuevo, mostramos la que ya está.
if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

let win = null;
let tray = null;
let quitting = false;

const userDir = () => app.getPath('userData');
const dataFile = () => path.join(userDir(), 'datos.json');
const bgDir = () => path.join(userDir(), 'fondos');

// ---------- Datos ----------
let memData = null;
function readData() {
  try {
    memData = JSON.parse(fs.readFileSync(dataFile(), 'utf8'));
    return memData;
  } catch {
    return null; // primera vez: el renderer crea los datos iniciales
  }
}

let writeTimer = null;
let pending = null;
function writeData(data) {
  pending = data;
  clearTimeout(writeTimer);
  writeTimer = setTimeout(flushData, 250);
}
function flushData() {
  if (!pending) return;
  const tmp = dataFile() + '.tmp';
  try {
    fs.mkdirSync(userDir(), { recursive: true });
    fs.writeFileSync(tmp, JSON.stringify(pending), 'utf8'); // sin sangría: el archivo pesa casi un tercio menos y se guarda más rápido
    // copia de respaldo del archivo anterior
    if (fs.existsSync(dataFile())) fs.copyFileSync(dataFile(), dataFile() + '.bak');
    fs.renameSync(tmp, dataFile());
    pending = null;
  } catch (e) {
    console.error('No se pudieron guardar los datos', e);
  }
}

function settings() {
  const d = pending || memData || readData();
  return (d && d.settings) || {};
}

// ---------- Registro de errores ----------
const logFile = () => path.join(userDir(), 'registro.txt');
const logLines = [];
function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  logLines.push(line);
  console.log(line);
  try {
    fs.mkdirSync(userDir(), { recursive: true });
    fs.appendFileSync(logFile(), line + '\r\n', 'utf8');
  } catch { /* nada */ }
}
let rendererReady = false;
let readyTimer = null;
let problemShown = false;
function showProblem() {
  if (problemShown) return;
  problemShown = true;
  const detail = logLines.length ? logLines.slice(-12).join('\n') : 'No se registró ningún error. La interfaz no avisó que terminó de arrancar.';
  log('Base no terminó de arrancar');
  dialog.showMessageBox(win, {
    type: 'error',
    title: 'Base',
    message: 'Base no pudo arrancar del todo',
    detail: `Sacale una captura a este mensaje y pasásela a Claude.\n\nElectron ${process.versions.electron} · Windows ${require('os').release()}\n\n${detail}\n\nRegistro completo: ${logFile()}`,
    buttons: ['Copiar y cerrar', 'Cerrar']
  }).then(({ response }) => {
    if (response === 0) require('electron').clipboard.writeText(`Electron ${process.versions.electron}\n${logLines.join('\n')}`);
  });
}
process.on('uncaughtException', (e) => log('ERROR main: ' + (e && e.stack || e)));
process.on('unhandledRejection', (e) => log('ERROR promesa: ' + (e && e.stack || e)));
app.on('child-process-gone', (_e, d) => log('ERROR proceso ' + JSON.stringify(d)));
// cada tanto anotamos cuánta memoria usa Base (para encontrar cierres por falta de memoria)
setInterval(() => { try { const m = process.memoryUsage(); if (m.rss > 600 * 1048576) log(`Memoria alta: ${Math.round(m.rss / 1048576)} MB`); } catch {} }, 60000);
ipcMain.on('app:ready', () => { rendererReady = true; clearTimeout(readyTimer); log('Interfaz lista'); });
ipcMain.on('app:error', (_e, msg) => log('ERROR interfaz: ' + msg));

// ---------- Ventana ----------
// ---------- En qué pantalla va Base (con dos monitores, siempre en una sola) ----------
let displayPref = null;
function targetDisplay() {
  const all = screen.getAllDisplays();
  const want = displayPref != null ? displayPref : settings().display;
  return (want && all.find(d => String(d.id) === String(want))) || screen.getPrimaryDisplay();
}
function placeWin(force) {
  if (!win || win.isDestroyed()) return;
  const d = targetDisplay();
  const cur = screen.getDisplayMatching(win.getBounds());
  if (WA.on) { waApply(); return; }
  if (!force && cur && cur.id === d.id) return;
  const fs2 = win.isFullScreen();
  if (fs2) win.setFullScreen(false);
  if (win.isMaximized()) win.unmaximize();
  win.setBounds(d.workArea);
  win.maximize();
  if (fs2) setTimeout(() => { try { win.setFullScreen(true); } catch {} }, 150);
}
ipcMain.handle('displays:list', () => {
  const prim = screen.getPrimaryDisplay().id;
  const cur = win ? screen.getDisplayMatching(win.getBounds()).id : prim;
  return screen.getAllDisplays().map((d, i) => ({ id: String(d.id), n: i + 1, w: Math.round(d.size.width * d.scaleFactor), h: Math.round(d.size.height * d.scaleFactor), scale: d.scaleFactor, primary: d.id === prim, current: d.id === cur, internal: !!d.internal }));
});
ipcMain.handle('displays:set', (_e, id) => { displayPref = id ? String(id) : ''; placeWin(true); return true; });

function createWindow() {
  const { workArea } = targetDisplay();
  const s = settings();
  win = new BrowserWindow({
    x: workArea.x, y: workArea.y,
    width: workArea.width, height: workArea.height,
    minWidth: 960, minHeight: 640,
    frame: false,
    show: false,
    backgroundColor: '#141a21',
    title: 'Base',
    icon: path.join(__dirname, 'build', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    fullscreen: !!s.fullscreen,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: true,
      webviewTag: false
    }
  });
  win.maximize();
  // si se conecta o desconecta un monitor, Base vuelve a su pantalla
  const replace = () => setTimeout(() => { placeWin(false); screen2Sync(); }, 600);
  screen.on('display-added', replace); screen.on('display-removed', replace); screen.on('display-metrics-changed', replace);
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  win.once('ready-to-show', () => {
    const startHidden = process.argv.includes('--oculto') && !settings().deskMode;
    if (!startHidden) win.show();
    // recién instalado: que Base aparezca adelante de todo (no detrás del instalador)
    if (process.argv.includes('--crear-accesos')) {
      try { win.setAlwaysOnTop(true); win.focus(); setTimeout(() => { try { win.setAlwaysOnTop(false); } catch {} }, 1500); } catch {}
    }
  });

  // ----- Diagnóstico: todo lo que falle queda anotado y se muestra -----
  const wc = win.webContents;
  wc.on('preload-error', (_e, p, err) => log('ERROR preload ' + p + ': ' + (err && err.stack || err)));
  wc.on('console-message', (...args) => {
    // compatible con la firma vieja (event, level, message, line, source) y la nueva (event con datos)
    const ev = args[0] || {};
    const level = ev.level !== undefined ? ev.level : args[1];
    const message = ev.message !== undefined ? ev.message : args[2];
    const line = ev.lineNumber !== undefined ? ev.lineNumber : args[3];
    const source = ev.sourceId !== undefined ? ev.sourceId : args[4];
    // las imágenes que bloqueamos a propósito dentro de los mails no son errores
    if (/ResizeObserver loop/i.test(String(message || ''))) return;
    if (/about:srcdoc/.test(String(source || '')) || /Content Security Policy/.test(String(message || '')) && /srcdoc|cid:/.test(String(message || '') + String(source || ''))) return;
    if (level === 'error' || level === 'warning' || level === 3 || level === 2) {
      log(`CONSOLA ${level}: ${message} (${path.basename(String(source || ''))}:${line})`);
    }
  });
  wc.on('did-fail-load', (_e, code, desc, url) => log(`ERROR carga ${code} ${desc} ${url}`));
  wc.on('render-process-gone', (_e, d) => { log('ERROR renderer: ' + JSON.stringify(d)); if (d && d.reason !== 'clean-exit' && !quitting) setTimeout(() => { try { if (!win.isDestroyed()) win.reload(); } catch {} }, 1500); });
  wc.on('did-finish-load', () => {
    clearTimeout(readyTimer);
    readyTimer = setTimeout(() => {
      if (!rendererReady) showProblem();
    }, 6000);
  });
  // F12 o Ctrl+Shift+I abren las herramientas de desarrollo
  wc.on('before-input-event', (_e, input) => {
    if (input.type === 'keyDown' && (input.key === 'F12' || (input.control && input.shift && input.key.toLowerCase() === 'i'))) {
      wc.toggleDevTools();
    }
  });

  // Cerrar = esconder en la bandeja (para que esté siempre a mano)
  win.on('close', (e) => {
    if (!quitting) {
      e.preventDefault();
      win.hide();
    }
  });
  dockHookWindow();
  deskHookWindow();

  // Links externos se abren en el navegador, nunca dentro de la app
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  // Redes: cada mini ventana corre aislada, sin acceso a Base ni a la compu
  win.webContents.on('will-attach-webview', (e, prefs, params) => {
    delete prefs.preload;
    prefs.nodeIntegration = false;
    prefs.nodeIntegrationInSubFrames = false;
    prefs.contextIsolation = true;
    prefs.sandbox = true;
    prefs.webSecurity = true;
    let ok = false;
    try { ok = new URL(params.src).protocol === 'https:'; } catch {}
    if (!ok || params.partition !== 'persist:redes') e.preventDefault();
  });
  win.webContents.on('did-attach-webview', (_e, wc) => {
    // links que abren ventanas nuevas: al navegador de siempre
    wc.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//i.test(url)) shell.openExternal(url);
      return { action: 'deny' };
    });
    wc.on('will-navigate', (ev, url) => { if (!/^https:\/\//i.test(url)) ev.preventDefault(); });
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) {
      e.preventDefault();
      if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    }
  });
  win.on('maximize', () => win.webContents.send('win:state', 'max'));
  win.on('unmaximize', () => win.webContents.send('win:state', 'normal'));
}

function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  placeWin(false);
  win.show();
  win.focus();
}

function toggleWindow() {
  if (!win) return;
  if (win.isVisible() && win.isFocused() && !win.isMinimized()) { if (DESK.on) deskPeek(); else win.minimize(); }
  else showWindow();
}

// ---------- Bandeja ----------
function buildTray() {
  const file = process.platform === 'win32' ? 'tray.ico' : 'tray.png';
  const icon = nativeImage.createFromPath(path.join(__dirname, 'build', file));
  tray = new Tray(icon.isEmpty() ? nativeImage.createEmpty() : icon);
  tray.setToolTip('Base');
  refreshTrayMenu();
  tray.on('click', showWindow);
}

function refreshTrayMenu(activeMode) {
  if (!tray) return;
  const d = readData() || pending || {};
  const mode = activeMode || d.activeMode || 'casa';
  const list = [['casa', 'Casa'], ...(SINGLE ? [] : [['trabajo', 'Trabajo']]),
    ...(Array.isArray(d.boards) ? d.boards.filter(b => b && b.id && d.modes && d.modes[b.id]).map(b => [b.id, String(b.name || 'Tablero')]) : [])];
  const modes = list.length < 2 ? [] : [{ type: 'separator' },
    ...list.map(([id, name]) => ({ label: id === 'casa' || id === 'trabajo' ? 'Modo ' + name : name, type: 'radio', checked: mode === id, click: () => { showWindow(); win.webContents.send('mode:set', id); } }))];
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Mostrar Base', click: showWindow },
    { label: 'Ver el escritorio de Windows', click: deskPeek },
    ...modes,
    { type: 'separator' },
    { label: 'Salir', click: () => { quitting = true; app.quit(); } }
  ]));
}

// ---------- Atajo global ----------
const DEFAULT_HOTKEY = 'Control+Alt+Space';
let currentHotkey = null;
function registerHotkey(accel) {
  if (currentHotkey) globalShortcut.unregister(currentHotkey);
  currentHotkey = null;
  if (!accel) return true;
  try {
    const ok = globalShortcut.register(accel, toggleWindow);
    if (ok) currentHotkey = accel;
    return ok;
  } catch {
    return false;
  }
}

// atajo del buscador: muestra Base y abre la búsqueda
const DEFAULT_SEARCH_HOTKEY = 'Control+Shift+Space';
let currentSearchHotkey = null;
function registerSearchHotkey(accel) {
  if (currentSearchHotkey) globalShortcut.unregister(currentSearchHotkey);
  currentSearchHotkey = null;
  if (!accel || accel === currentHotkey) return !accel;
  try {
    const ok = globalShortcut.register(accel, () => { showWindow(); win.webContents.send('search:open'); });
    if (ok) currentSearchHotkey = accel;
    return ok;
  } catch { return false; }
}

// ---------- IPC ----------
ipcMain.handle('data:load', () => readData());
ipcMain.on('data:save', (_e, data) => {
  memData = data;
  writeData(data);
  refreshTrayMenu(data.activeMode);
});

ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:hide', () => win && win.hide());
ipcMain.on('win:fullscreen', (_e, on) => win && win.setFullScreen(!!on));
ipcMain.on('app:quit', () => { quitting = true; app.quit(); });

ipcMain.handle('shortcut:pick', async (_e, kind) => {
  const opts = kind === 'folder'
    ? { title: 'Elegí una carpeta', properties: ['openDirectory'] }
    : {
        title: 'Elegí un programa o archivo',
        properties: ['openFile'],
        filters: [
          { name: 'Programas y accesos directos', extensions: ['exe', 'lnk', 'url', 'bat', 'cmd', 'msc', 'appref-ms'] },
          { name: 'Todos los archivos', extensions: ['*'] }
        ]
      };
  const r = await dialog.showOpenDialog(win, opts);
  if (r.canceled || !r.filePaths.length) return null;
  return r.filePaths[0];
});

ipcMain.handle('shortcut:icon', async (_e, target) => {
  try {
    let p = target;
    // Para accesos directos .lnk usamos el icono del programa al que apuntan
    if (process.platform === 'win32' && /\.lnk$/i.test(p)) {
      try {
        const info = shell.readShortcutLink(p);
        if (info.icon && fs.existsSync(info.icon)) p = info.icon;
        else if (info.target && fs.existsSync(info.target)) p = info.target;
      } catch { /* seguimos con el .lnk */ }
    }
    const img = await app.getFileIcon(p, { size: 'large' });
    return img.isEmpty() ? null : img.toDataURL();
  } catch {
    return null;
  }
});

ipcMain.handle('shortcut:open', async (_e, item) => openItem(item));
async function openItem(item) {
  if (!item || !item.target) return 'Sin destino';
  if (item.type === 'web') {
    let url = item.target.trim();
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    try { new URL(url); } catch { return 'La dirección no es válida'; }
    await shell.openExternal(url);
    return '';
  }
  if (!fs.existsSync(item.target)) return 'No se encontró: ' + item.target;
  return shell.openPath(item.target); // '' si salió bien, texto si falló
}

ipcMain.handle('bg:pick', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Elegí una imagen de fondo',
    properties: ['openFile'],
    filters: [{ name: 'Imágenes', extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'] }]
  });
  if (r.canceled || !r.filePaths.length) return null;
  const src = r.filePaths[0];
  fs.mkdirSync(bgDir(), { recursive: true });
  const dest = path.join(bgDir(), Date.now() + path.extname(src).toLowerCase());
  fs.copyFileSync(src, dest);
  return 'file:///' + encodeURI(dest.replace(/\\/g, '/').replace(/^\//, ''));
});

ipcMain.handle('settings:apply', (_e, s) => {
  const result = {};
  if (app.isPackaged) {
    app.setLoginItemSettings({ openAtLogin: !!s.startWithWindows, path: process.execPath, args: ['--oculto'], name: 'Base' });
  }
  deskApply(s);
  panelApply(s);
  screen2Sync();
  result.hotkeyOk = registerHotkey(s.hotkey === undefined ? DEFAULT_HOTKEY : s.hotkey);
  result.searchHotkeyOk = registerSearchHotkey(s.searchHotkey === undefined ? DEFAULT_SEARCH_HOTKEY : s.searchHotkey);
  if (win && typeof s.fullscreen === 'boolean' && win.isFullScreen() !== s.fullscreen) {
    win.setFullScreen(s.fullscreen);
  }
  return result;
});

// Datos de internet (clima, F1, noticias). Solo se permiten estas fuentes.
const CHROME_UA = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${process.versions.chrome} Safari/537.36`;
const ALLOWED_HOSTS = new Set([
  'api.open-meteo.com',
  'geocoding-api.open-meteo.com',
  'api.jolpi.ca',
  'news.google.com',
  'www.bing.com',
  'en.wikipedia.org',
  'site.api.espn.com',
  'ipwho.is',
  'nominatim.openstreetmap.org',
  'itunes.apple.com',
  'dolarapi.com',
  'es.wikipedia.org',
  'store.steampowered.com',
  'api.argentinadatos.com',
  'api.coingecko.com',
  'store-site-backend-static.epicgames.com',
  'www.youtube.com',
  'open.spotify.com'
]);
ipcMain.handle('net:get', async (_e, url) => {
  let u;
  try { u = new URL(url); } catch { return { ok: false, error: 'URL inválida' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.has(u.hostname)) return { ok: false, error: 'Fuente no permitida' };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    // las tiendas de juegos rechazan pedidos que no parecen de un navegador
    const browserLike = /epicgames\.com$|steampowered\.com$/.test(u.hostname);
    const headers = browserLike
      ? { 'User-Agent': CHROME_UA, 'Accept': 'application/json, text/plain, */*', 'Accept-Language': 'es-AR,es;q=0.9,en;q=0.8' }
      : { 'User-Agent': 'Base/1.1 (escritorio personal)' };
    const r = await net.fetch(u.href, { signal: ctrl.signal, headers });
    if (!r.ok) log(`Internet: ${u.hostname} respondió ${r.status}`);
    if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
    return { ok: true, text: await r.text() };
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'Tardó demasiado' : 'Sin conexión' };
  } finally {
    clearTimeout(t);
  }
});

// ----- Vista previa de noticias: baja la nota y deja solo el texto (nunca se ejecuta nada de la página) -----
const PRIVATE_HOST = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.|\[|::1$)|\.local$|\.internal$/i;
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', laquo: '«', raquo: '»', ndash: '–', mdash: '—', hellip: '…', iexcl: '¡', iquest: '¿', ldquo: '“', rdquo: '”', lsquo: '‘', rsquo: '’', aacute: 'á', eacute: 'é', iacute: 'í', oacute: 'ó', uacute: 'ú', ntilde: 'ñ', Aacute: 'Á', Eacute: 'É', Iacute: 'Í', Oacute: 'Ó', Uacute: 'Ú', Ntilde: 'Ñ', uuml: 'ü', deg: '°', ordm: 'º', ordf: 'ª', euro: '€', copy: '©' };
function decodeEnt(s) {
  return s.replace(/&(#x[\da-f]+|#\d+|\w+);/gi, (m, e) => {
    if (e[0] === '#') { const n = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); try { return String.fromCodePoint(n); } catch { return ''; } }
    return ENT[e] != null ? ENT[e] : m;
  });
}
const plain = (h) => decodeEnt(h.replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
function metaOf(html, names) {
  for (const n of names) {
    const re1 = new RegExp(`<meta[^>]+(?:property|name)=["']${n}["'][^>]*content=["']([^"']*)["']`, 'i');
    const re2 = new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${n}["']`, 'i');
    const m = re1.exec(html) || re2.exec(html);
    if (m && m[1].trim()) return decodeEnt(m[1]).trim();
  }
  return '';
}
const JUNK = /suscrib|cookie|newsletter|registrate|iniciá sesión|inicia sesión|todos los derechos|©|publicidad|seguinos|síguenos|compartir en|whatsapp|copyright|recibí las|descargá la app|también te puede interesar|lee también|leé también|mirá también/i;
ipcMain.handle('news:article', async (_e, url) => {
  let u;
  try { u = new URL(String(url)); } catch { return { ok: false, error: 'Dirección inválida' }; }
  if (!/^https?:$/.test(u.protocol) || PRIVATE_HOST.test(u.hostname)) return { ok: false, error: 'Dirección no permitida' };
  if (u.protocol === 'http:') u.protocol = 'https:';
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 12000);
  try {
    const r = await net.fetch(u.href, { signal: ctrl.signal, headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + process.versions.chrome + ' Safari/537.36', 'Accept-Language': 'es-AR,es;q=0.9' } });
    if (!r.ok) return { ok: false, error: `El sitio respondió ${r.status}` };
    const type = r.headers.get('content-type') || '';
    if (type && !/html/i.test(type)) return { ok: false, error: 'No es una página de noticias' };
    const buf = Buffer.from(await r.arrayBuffer()).subarray(0, 3 * 1024 * 1024);
    let cs = (/charset=([\w-]+)/i.exec(type) || [])[1] || (/<meta[^>]+charset=["']?([\w-]+)/i.exec(buf.toString('latin1', 0, 4000)) || [])[1] || 'utf-8';
    let html;
    try { html = new TextDecoder(cs.toLowerCase()).decode(buf); } catch { html = buf.toString('utf8'); }
    const out = {
      url: r.url || u.href,
      title: metaOf(html, ['og:title', 'twitter:title']) || plain((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html) || [])[1] || ''),
      desc: metaOf(html, ['og:description', 'description', 'twitter:description']),
      image: metaOf(html, ['og:image', 'og:image:url', 'twitter:image']),
      site: metaOf(html, ['og:site_name', 'application-name']),
      author: metaOf(html, ['author', 'article:author']).replace(/^https?:\/\/\S+$/, '')
    };
    if (out.image) { try { out.image = new URL(out.image, out.url).href.replace(/^http:/, 'https:'); } catch { out.image = ''; } }
    let body = html.replace(/<(script|style|noscript|svg|form|nav|footer|aside|iframe|button|figure|template)[\s\S]*?<\/\1>/gi, ' ');
    const art = /<article[\s>][\s\S]*<\/article>/i.exec(body);
    if (art && art[0].length > 1500) body = art[0];
    const paras = [], seen = new Set();
    let total = 0;
    const re = /<p[\s>][\s\S]*?<\/p>/gi; let m;
    while ((m = re.exec(body)) && paras.length < 40 && total < 14000) {
      const p = plain(m[0]);
      if (p.length < 60 || JUNK.test(p) || seen.has(p) || p === out.desc) continue;
      seen.add(p); paras.push(p); total += p.length;
    }
    out.paras = paras;
    return { ok: true, data: out };
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'El sitio tardó demasiado' : 'No se pudo abrir la nota' };
  } finally { clearTimeout(t); }
});

// ----- Mini reproductor de YouTube: YouTube exige saber desde qué sitio se ve el video -----
const YT_REF = 'https://www.youtube-nocookie.com/';
app.whenReady().then(() => {
  session.defaultSession.webRequest.onBeforeSendHeaders(
    { urls: ['https://www.youtube-nocookie.com/*', 'https://www.youtube.com/embed/*'] },
    (d, cb) => { if (!d.requestHeaders.Referer) d.requestHeaders.Referer = YT_REF; cb({ requestHeaders: d.requestHeaders }); });
});
// ----- Juegos gratis de Epic: probamos varias formas, porque Epic a veces rechaza pedidos -----
async function fetchText(url, ms = 12000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const r = await net.fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': CHROME_UA, 'Accept': 'application/json, text/plain, */*', 'Accept-Language': 'es-AR,es;q=0.9,en;q=0.8' } });
    return { ok: r.ok, status: r.status, text: r.ok ? await r.text() : '' };
  } catch (e) { return { ok: false, status: 0, text: '' }; } finally { clearTimeout(t); }
}
async function fetchViaWindow(url) {
  const w = new BrowserWindow({ show: false, width: 800, height: 600, webPreferences: { sandbox: true, contextIsolation: true, partition: 'persist:fetch' } });
  try {
    w.webContents.setUserAgent(CHROME_UA);
    await Promise.race([w.loadURL(url), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 20000))]);
    return await w.webContents.executeJavaScript('document.body ? document.body.innerText : ""');
  } finally { if (!w.isDestroyed()) w.destroy(); }
}
ipcMain.handle('deals:epic', async () => {
  const url = 'https://store-site-backend-static.epicgames.com/freeGamesPromotions?locale=es-ES&country=AR&allowCountries=AR';
  const r = await fetchText(url);
  if (r.ok && r.text.trim().startsWith('{')) return { ok: true, kind: 'epic', text: r.text };
  log(`Epic gratis: respuesta ${r.status}, probamos de otra forma`);
  try {
    const t = await fetchViaWindow(url);
    if (t && t.trim().startsWith('{')) return { ok: true, kind: 'epic', text: t };
  } catch (e) { log('Epic gratis (ventana): ' + e.message); }
  const g = await fetchText('https://www.gamerpower.com/api/giveaways?platform=epic-games-store&type=game');
  if (g.ok && g.text.trim().startsWith('[')) return { ok: true, kind: 'gp', text: g.text };
  log(`Epic gratis: GamerPower respondió ${g.status}`);
  return { ok: false };
});

// ----- WhatsApp adentro de Base (tablero Redes) -----
let waView = null;
let waZoom = 1;
function ensureWa() {
  if (waView && !waView.webContents.isDestroyed()) return waView;
  const { WebContentsView } = require('electron');
  waView = new WebContentsView({ webPreferences: { partition: 'persist:whatsapp', contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true } });
  const wc = waView.webContents;
  wc.setUserAgent(CHROME_UA);
  wc.session.setPermissionRequestHandler((_w, perm, cb) => cb(['notifications', 'clipboard-sanitized-write', 'media', 'fullscreen'].includes(perm)));
  wc.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  wc.on('will-navigate', (ev, url) => { if (!/^https:\/\/web\.whatsapp\.com\//.test(url)) { ev.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); } });
  win.contentView.addChildView(waView);
  waView.setBounds({ x: 0, y: 0, width: 0, height: 0 });
  wc.on('did-finish-load', () => { try { wc.setZoomFactor(waZoom); } catch {} });
  wc.loadURL('https://web.whatsapp.com/').catch(() => {});
  return waView;
}
ipcMain.handle('wa:bounds', async (_e, r) => {
  if (!win) return false;
  if (!r || !r.show) { if (waView && !waView.webContents.isDestroyed()) { waView.setBounds({ x: 0, y: 0, width: 0, height: 0 }); if (waView.setVisible) waView.setVisible(false); } return true; }
  const v = ensureWa();
  const b = { x: Math.round(r.x), y: Math.round(r.y), width: Math.max(0, Math.round(r.w)), height: Math.max(0, Math.round(r.h)) };
  v.setBounds(b);
  if (v.setVisible) v.setVisible(true);
  // WhatsApp Web está pensado para ~1000 px de ancho: lo achicamos lo justo para que entre sin barras
  const adj = Math.max(0.6, Math.min(1.5, Number(r.adj) || 1));
  const z = Math.max(0.5, Math.min(1.25, Math.min(1, b.width / 1000, b.height / 620) * adj));
  waZoom = Math.round(z * 100) / 100;
  try { if (Math.abs(v.webContents.getZoomFactor() - waZoom) > 0.01) v.webContents.setZoomFactor(waZoom); } catch {}
  return true;
});
ipcMain.handle('wa:reload', async () => { if (waView && !waView.webContents.isDestroyed()) waView.webContents.reload(); return true; });

let floatPlayer = null;
const FLOAT_SITES = {
  youtube: { url: 'https://www.youtube.com/', title: 'YouTube' },
  ytmusic: { url: 'https://music.youtube.com/', title: 'YouTube Music' },
  twitch: { url: 'https://www.twitch.tv/', title: 'Twitch' }
};
const FLOAT_OK = /^https:\/\/([\w-]+\.)*(youtube\.com|youtu\.be|google\.com|google\.com\.ar|gstatic\.com|googleusercontent\.com|twitch\.tv|ytimg\.com)(\/|$)/;
// navegadores de la compu (con tu sesión iniciada) para la ventanita flotante
const PF = process.env.ProgramFiles || 'C:\\Program Files', PF86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', LAD = process.env.LOCALAPPDATA || '';
const BROWSERS = {
  opera: { app: false, rx: /opera/i, paths: [path.join(LAD, 'Programs', 'Opera', 'opera.exe'), path.join(PF, 'Opera', 'opera.exe'), path.join(LAD, 'Programs', 'Opera', 'launcher.exe')] },
  operagx: { app: false, rx: /opera/i, paths: [path.join(LAD, 'Programs', 'Opera GX', 'opera.exe'), path.join(LAD, 'Programs', 'Opera GX', 'launcher.exe')] },
  chrome: { app: true, rx: /chrome/i, paths: [path.join(PF, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(PF86, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(LAD, 'Google', 'Chrome', 'Application', 'chrome.exe')] },
  brave: { app: true, rx: /brave/i, paths: [path.join(PF, 'BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe'), path.join(LAD, 'BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe')] },
  edge: { app: true, rx: /msedge/i, paths: [path.join(PF86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'), path.join(PF, 'Microsoft', 'Edge', 'Application', 'msedge.exe')] }
};
const exists = (p) => { try { return !!p && fs.existsSync(p); } catch { return false; } };
function findBrowser(pref) {
  const order = pref && BROWSERS[pref] ? [pref, 'chrome', 'brave', 'edge', 'opera', 'operagx'] : ['chrome', 'brave', 'edge', 'opera', 'operagx'];
  for (const k of order) { const exe = BROWSERS[k].paths.find(exists); if (exe) return { key: k, exe, ...BROWSERS[k] }; }
  return null;
}
ipcMain.handle('browsers:list', async () => Object.keys(BROWSERS).filter(k => BROWSERS[k].paths.some(exists)));
async function floatInBrowser(s, pref) {
  const br = findBrowser(pref);
  if (!br || process.platform !== 'win32') return false;
  const before = await winHelper.send('list', '0');
  const known = new Set(((before.ok && before.data) || []).map(w => String(w.h)));
  const td = targetDisplay();
  const wa = td.workArea;
  const sf = td.scaleFactor || 1;
  const w = 560, h = 360, x = wa.x + wa.width - w - 20, y = wa.y + wa.height - h - 170;
  const args = br.app
    ? [`--app=${s.url}`, `--window-size=${Math.round(w * sf)},${Math.round(h * sf)}`, `--window-position=${Math.round(x * sf)},${Math.round(y * sf)}`]
    : ['--new-window', s.url]; // Opera no tiene modo "app": abrimos una ventana nueva y la achicamos
  spawn(br.exe, args, { detached: true, stdio: 'ignore' }).unref();
  // buscamos la ventanita nueva, la acomodamos en la esquina y la dejamos arriba de todo
  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 500));
    const r = await winHelper.send('list', '0');
    const nw = ((r.ok && r.data) || []).find(wd => !known.has(String(wd.h)) && br.rx.test(wd.exe || ''));
    if (nw) {
      await new Promise(r2 => setTimeout(r2, 400));
      await winHelper.send('place', `${nw.h}|${Math.round(x * sf)}|${Math.round(y * sf)}|${Math.round(w * sf)}|${Math.round((h + (br.app ? 0 : 70)) * sf)}`);
      return true;
    }
  }
  return true;
}
ipcMain.handle('player:float', async (_e, site, pref) => {
  const s = FLOAT_SITES[String(site || '')];
  if (!s) return 'Sitio no disponible';
  try { if (await floatInBrowser(s, String(pref || ''))) return ''; } catch (e) { log('Ventana flotante: ' + e.message); }
  if (!floatPlayer || floatPlayer.isDestroyed()) {
    const wa = targetDisplay().workArea;
    floatPlayer = new BrowserWindow({
      width: 560, height: 360, x: wa.x + wa.width - 580, y: wa.y + wa.height - 520, minWidth: 320, minHeight: 200,
      alwaysOnTop: true, autoHideMenuBar: true, title: 'Base · ' + s.title, backgroundColor: '#0f0f0f',
      icon: path.join(__dirname, 'build', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, partition: 'persist:player' }
    });
    floatPlayer.setAlwaysOnTop(true, 'floating');
    floatPlayer.webContents.setUserAgent(CHROME_UA);
    const ses = floatPlayer.webContents.session;
    ses.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'fullscreen' || perm === 'media'));
    floatPlayer.webContents.setWindowOpenHandler(({ url: u }) => {
      if (FLOAT_OK.test(u)) { floatPlayer.loadURL(u); return { action: 'deny' }; }
      if (/^https:\/\//.test(u)) shell.openExternal(u);
      return { action: 'deny' };
    });
    floatPlayer.webContents.on('will-navigate', (ev, u) => { if (!FLOAT_OK.test(u)) { ev.preventDefault(); if (/^https:\/\//.test(u)) shell.openExternal(u); } });
    floatPlayer.on('page-title-updated', (ev, t) => { ev.preventDefault(); floatPlayer.setTitle('Base · ' + t); });
    floatPlayer.on('closed', () => { floatPlayer = null; });
  }
  floatPlayer.loadURL(s.url).catch(() => {});
  floatPlayer.show();
  return '';
});
ipcMain.handle('player:top', async (_e, on) => { if (floatPlayer && !floatPlayer.isDestroyed()) floatPlayer.setAlwaysOnTop(!!on, 'floating'); return true; });

// ----- Redes: sesión propia, con formato de celular para que entre en el panel -----
const { session } = require('electron');
app.whenReady().then(() => {
  const ses = session.fromPartition('persist:redes');
  ses.setUserAgent('Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + process.versions.chrome + ' Mobile Safari/537.36');
  // no se permite nada (ni notificaciones, cámara, micrófono ni ubicación), salvo copiar al portapapeles
  ses.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'notifications' ? false : perm === 'clipboard-sanitized-write'));
});
ipcMain.handle('redes:clear', async () => {
  await session.fromPartition('persist:redes').clearStorageData();
  return true;
});

// ----- Archivos recientes de Windows (para el buscador) -----
ipcMain.handle('files:recent', async () => {
  if (process.platform !== 'win32') return [];
  const dir = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Recent');
  let files = [];
  try { files = fs.readdirSync(dir).filter(f => /\.lnk$/i.test(f)); } catch { return []; }
  const items = [];
  for (const f of files) {
    try {
      const full = path.join(dir, f);
      const st = fs.statSync(full);
      let target = '';
      try { target = shell.readShortcutLink(full).target || ''; } catch {}
      if (!target) continue;
      const isDir = (() => { try { return fs.statSync(target).isDirectory(); } catch { return null; } })();
      if (isDir === null) continue; // ya no existe
      items.push({ name: f.replace(/\.lnk$/i, ''), target, folder: isDir, at: st.mtimeMs });
    } catch {}
  }
  items.sort((a, b) => b.at - a.at);
  const top = items.slice(0, 150);
  for (const it of top.slice(0, 40)) it.icon = await iconOf(it.target, 'normal');
  return top;
});
ipcMain.handle('icon:for', async (_e, p) => (typeof p === 'string' && p.length < 600 ? iconOf(p, 'normal') : null));

// ----- Rendimiento de la compu -----
const os = require('os');
let lastCpu = null;
function cpuSample() {
  const c = os.cpus();
  let idle = 0, total = 0;
  for (const x of c) { for (const k in x.times) total += x.times[k]; idle += x.times.idle; }
  return { idle, total };
}
let lastCores = null, lastNet = null, drivesCache = { at: 0, data: null }, procsCache = { at: 0, data: null };
async function driveList() {
  if (Date.now() - drivesCache.at < 6000 && drivesCache.data) return drivesCache.data;
  let list = null;
  if (process.platform === 'win32') {
    const r = await winHelper.send('drives');
    if (r.ok && Array.isArray(r.data)) list = r.data.map(d => ({ name: d.n.replace(/\\$/, ''), label: d.l, type: d.t, fs: d.f, total: d.size, free: d.free }));
    if (!list) { // plan B: preguntamos letra por letra
      list = [];
      for (const L of 'CDEFGHIJKLMNOPQRSTUVWXYZ') {
        try { const st = await fs.promises.statfs(L + ':\\'); list.push({ name: L + ':', label: '', type: L === 'C' ? 'Fixed' : '', fs: '', total: st.blocks * st.bsize, free: st.bavail * st.bsize }); } catch {}
      }
    }
  } else {
    try { const st = await fs.promises.statfs('/'); list = [{ name: '/', label: '', type: 'Fixed', fs: '', total: st.blocks * st.bsize, free: st.bavail * st.bsize }]; } catch { list = []; }
  }
  list = list.filter(d => d.total > 0);
  drivesCache = { at: Date.now(), data: list };
  return list;
}
ipcMain.handle('sys:stats', async (_e, detail) => {
  const cpus = os.cpus();
  const now = cpuSample();
  let cpu = null;
  if (lastCpu) {
    const dt = now.total - lastCpu.total, di = now.idle - lastCpu.idle;
    cpu = dt > 0 ? Math.max(0, Math.min(100, Math.round(100 * (1 - di / dt)))) : null;
  }
  lastCpu = now;
  // uso de cada núcleo
  const coreNow = cpus.map(c => { let t = 0; for (const k in c.times) t += c.times[k]; return { t, i: c.times.idle }; });
  let cores = null;
  if (lastCores && lastCores.length === coreNow.length) {
    cores = coreNow.map((c, i) => { const dt = c.t - lastCores[i].t; return dt > 0 ? Math.max(0, Math.min(100, Math.round(100 * (1 - (c.i - lastCores[i].i) / dt)))) : 0; });
  }
  lastCores = coreNow;
  const mem = { total: os.totalmem(), free: os.freemem() };
  const drives = await driveList();
  const sys = drives.find(d => d.name.toUpperCase() === String(process.env.SystemDrive || 'C:').toUpperCase()) || drives[0] || null;
  // red: velocidad a partir de la diferencia de bytes
  let net = null;
  if (process.platform === 'win32') {
    const r = await winHelper.send('net');
    if (r.ok && r.data) {
      const t = Date.now();
      net = { name: r.data.name, kind: r.data.kind, link: r.data.speed, down: null, up: null };
      if (lastNet && t > lastNet.t && r.data.rx >= lastNet.rx) {
        const sec = (t - lastNet.t) / 1000;
        net.down = (r.data.rx - lastNet.rx) / sec; net.up = (r.data.tx - lastNet.tx) / sec;
      }
      lastNet = { t, rx: r.data.rx, tx: r.data.tx };
    }
  }
  let procs = null;
  if (detail && process.platform === 'win32') {
    if (Date.now() - procsCache.at > 5000) {
      const r = await winHelper.send('procs');
      if (r.ok && r.data) procsCache = { at: Date.now(), data: r.data };
    }
    procs = procsCache.data;
  }
  let ip = '';
  try {
    for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal && !ip) ip = a.address;
  } catch {}
  return {
    cpu, cores, cpuName: (cpus[0] || {}).model || '', coreCount: cpus.length, mhz: (cpus[0] || {}).speed || 0,
    mem, disk: sys ? { name: sys.name, total: sys.total, free: sys.free } : null, drives, net, procs,
    uptime: os.uptime(), osName: os.version ? os.version() : os.type(), osRelease: os.release(), arch: os.arch(), ip
  };
});
ipcMain.handle('sys:openDrive', async (_e, name) => {
  if (!/^[A-Z]:$/i.test(String(name))) return 'Unidad inválida';
  return shell.openPath(name + '\\');
});

// ----- Copia de seguridad: exportar todo e importarlo en otra compu -----
const pendingFile = () => path.join(userDir(), 'importar.base');
let loadedPack = null;
function packSummary(pack, file) {
  const d = pack.data || {};
  const m = d.modes || {};
  const count = (k) => ['casa', 'trabajo'].reduce((n, x) => n + (((m[x] || {})[k]) || []).length, 0);
  return {
    file: file ? path.basename(file) : '', at: pack.at || 0, from: pack.from || '', app: pack.app || '',
    modes: ['casa', 'trabajo'].filter(x => m[x]), google: !!pack.google,
    tasks: count('tasks'), notes: count('notes'), events: count('events'), shortcuts: count('shortcuts'),
    images: Object.keys(pack.files || {}).length
  };
}
function readPack(file) {
  const txt = fs.readFileSync(file, 'utf8');
  if (txt.length > 80 * 1024 * 1024) throw new Error('El archivo es demasiado grande');
  const pack = JSON.parse(txt);
  if (!pack || pack.base !== 'copia' || !pack.data || !pack.data.modes) throw new Error('No es una copia de Base');
  return pack;
}
function buildPack(data, opts = {}) {
    const copy = JSON.parse(JSON.stringify(data));
    copy.cache = {}; // lo que se baja de internet se vuelve a bajar solo
    const files = {};
    for (const m of Object.values(copy.modes)) {
      const bg = m && m.theme && m.theme.bg;
      if (bg && bg.kind === 'image' && /^file:/i.test(bg.value || '')) {
        try {
          const p = require('url').fileURLToPath(bg.value);
          const st = fs.statSync(p);
          if (st.size < 25 * 1024 * 1024) {
            const key = path.basename(p);
            files[key] = fs.readFileSync(p).toString('base64');
            bg.value = 'base-file:' + key;
          }
        } catch {}
      }
    }
    let gcfg = null;
    if (opts.google) { try { gcfg = google.getConfig(); } catch {} }
    return { base: 'copia', version: 1, app: app.getVersion(), at: Date.now(), from: os.hostname(), data: copy, files, google: gcfg || null };
}
ipcMain.handle('backup:export', async (_e, data, opts = {}) => {
  try {
    if (!data || !data.modes) return { ok: false, error: 'No hay datos para exportar' };
    const pack = buildPack(data, opts);
    const stamp = new Date().toISOString().slice(0, 10);
    const r = await dialog.showSaveDialog(win, {
      title: 'Guardar copia de Base',
      defaultPath: path.join(app.getPath('desktop'), `Base-copia-${stamp}.base`),
      filters: [{ name: 'Copia de Base', extensions: ['base'] }]
    });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    fs.writeFileSync(r.filePath, JSON.stringify(pack), 'utf8');
    log('Copia exportada: ' + r.filePath);
    return { ok: true, file: r.filePath, summary: packSummary(pack, r.filePath) };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('backup:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Elegí la copia de Base', properties: ['openFile'], filters: [{ name: 'Copia de Base', extensions: ['base'] }, { name: 'Todos los archivos', extensions: ['*'] }] });
  if (r.canceled || !r.filePaths.length) return { ok: false, canceled: true };
  try { loadedPack = readPack(r.filePaths[0]); return { ok: true, summary: packSummary(loadedPack, r.filePaths[0]) }; }
  catch (e) { loadedPack = null; return { ok: false, error: e.message || 'No se pudo leer la copia' }; }
});
// copia que dejó el instalador (archivo .base al lado de "Instalar Base")
ipcMain.handle('backup:pending', async () => {
  if (!fs.existsSync(pendingFile())) return null;
  try { loadedPack = readPack(pendingFile()); return { ok: true, summary: packSummary(loadedPack, pendingFile()) }; }
  catch (e) { try { fs.renameSync(pendingFile(), pendingFile() + '.error'); } catch {} return null; }
});
ipcMain.handle('backup:dismiss', async () => {
  loadedPack = null;
  try { if (fs.existsSync(pendingFile())) fs.renameSync(pendingFile(), path.join(userDir(), 'importar-descartado.base')); } catch {}
  return true;
});
ipcMain.handle('backup:apply', async (_e, which, current) => {
  const pack = loadedPack;
  if (!pack) return { ok: false, error: 'Primero elegí la copia' };
  try {
    // guardamos lo que había, por si querés volver atrás
    flushData();
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    if (fs.existsSync(dataFile())) fs.copyFileSync(dataFile(), path.join(userDir(), `datos-antes-de-importar-${stamp}.json`));
    const inc = JSON.parse(JSON.stringify(pack.data));
    // fondos que venían adentro de la copia
    for (const m of Object.values(inc.modes || {})) {
      const bg = m && m.theme && m.theme.bg;
      if (bg && bg.kind === 'image' && /^base-file:/.test(bg.value || '')) {
        const key = path.basename(bg.value.slice(10));
        const b64 = (pack.files || {})[key];
        if (b64) {
          fs.mkdirSync(bgDir(), { recursive: true });
          const dest = path.join(bgDir(), 'importado-' + key);
          fs.writeFileSync(dest, Buffer.from(b64, 'base64'));
          bg.value = 'file:///' + encodeURI(dest.replace(/\\/g, '/').replace(/^\//, ''));
        } else { bg.kind = 'preset'; bg.value = ''; }
      }
    }
    let out;
    const cur = current && current.modes ? JSON.parse(JSON.stringify(current)) : null;
    if (which === 'casa' || which === 'trabajo') {
      if (!inc.modes[which]) return { ok: false, error: 'La copia no trae ese modo' };
      out = cur || inc;
      out.modes[which] = inc.modes[which];
      if (which === 'casa' && inc.settings) for (const k of ['topic', 'socials', 'tz', 'gameSort', 'pomo', 'convType', 'criptoCur']) if (k in inc.settings) out.settings[k] = inc.settings[k];
    } else {
      out = inc;
      if (cur) {
        out.cache = cur.cache || {};
        // lo propio de esta compu se mantiene
        for (const k of ['startWithWindows', 'hiddenSys', 'briefDay', 'geoDone']) if (cur.settings && k in cur.settings) out.settings[k] = cur.settings[k];
        out.notifs = cur.notifs || [];
      }
    }
    out.cache = out.cache || {};
    if (pack.google && pack.google.clientId) { try { if (!google.getConfig()) google.setConfig(pack.google.clientId, pack.google.clientSecret); } catch {} }
    pending = out; flushData();
    try { if (fs.existsSync(pendingFile())) fs.renameSync(pendingFile(), path.join(userDir(), 'importar-usado.base')); } catch {}
    loadedPack = null;
    log('Copia importada (' + (which || 'todo') + ')');
    return { ok: true, data: out };
  } catch (e) { return { ok: false, error: e.message }; }
});

// ----- Marco de fotos: elegir una carpeta y listar sus imágenes -----
const IMG_EXT = /\.(jpe?g|png|webp|gif|bmp|avif)$/i;
function listPhotos(dir) {
  const out = [];
  const walk = (d, depth) => {
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (out.length >= 400) return;
      const f = path.join(d, e.name);
      if (e.isFile() && IMG_EXT.test(e.name)) out.push(require('url').pathToFileURL(f).href);
      else if (e.isDirectory() && depth < 2 && !e.name.startsWith('.')) walk(f, depth + 1);
    }
  };
  walk(dir, 0);
  return out;
}
ipcMain.handle('photos:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Elegí la carpeta de fotos', properties: ['openDirectory'], defaultPath: app.getPath('pictures') });
  if (r.canceled || !r.filePaths[0]) return null;
  return { dir: r.filePaths[0], list: listPhotos(r.filePaths[0]) };
});
ipcMain.handle('photos:list', async (_e, dir) => {
  dir = String(dir || '');
  if (!dir || !fs.existsSync(dir)) return null;
  return listPhotos(dir);
});
ipcMain.handle('photos:show', async (_e, url) => {
  try { const f = require('url').fileURLToPath(String(url)); if (IMG_EXT.test(f) && fs.existsSync(f)) shell.showItemInFolder(f); } catch {}
});

// ----- Qué tan claro es el fondo (para que el texto siempre se lea) -----
const lumaCache = new Map();
ipcMain.handle('img:luma', async (_e, src) => {
  src = String(src || '');
  if (lumaCache.has(src)) return lumaCache.get(src);
  let img = null;
  try {
    if (/^file:/i.test(src)) img = nativeImage.createFromPath(require('url').fileURLToPath(src));
    else if (/^https:\/\/www\.bing\.com\//i.test(src)) {
      const r = await net.fetch(src);
      if (r.ok) img = nativeImage.createFromBuffer(Buffer.from(await r.arrayBuffer()));
    }
  } catch {}
  if (!img || img.isEmpty()) return null;
  const small = img.resize({ width: 48, height: 27, quality: 'good' });
  const { width: w, height: h } = small.getSize();
  const px = small.toBitmap(); // BGRA
  const lum = (x0, y0, x1, y1) => {
    let sum = 0, n = 0;
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
      const i = (y * w + x) * 4;
      sum += (0.0722 * px[i] + 0.7152 * px[i + 1] + 0.2126 * px[i + 2]) / 255; n++;
    }
    return n ? sum / n : 0.5;
  };
  // la parte de arriba (reloj y clima) es la que más importa
  const out = { all: lum(0, 0, w, h), top: lum(0, 0, w, Math.round(h * 0.55)), bottom: lum(0, Math.round(h * 0.6), w, h) };
  lumaCache.set(src, out);
  return out;
});

// ----- Ubicación de la compu (para el clima) -----
async function windowsLocation() {
  if (process.platform !== 'win32') return null;
  const ps = [
    '[Console]::OutputEncoding=[Text.Encoding]::UTF8',
    'Add-Type -AssemblyName System.Device',
    '$w = New-Object System.Device.Location.GeoCoordinateWatcher',
    '$null = $w.TryStart($false, [TimeSpan]::FromSeconds(8))',
    '$t = 0; while (($w.Status -ne "Ready" -or $w.Position.Location.IsUnknown) -and $t -lt 40) { Start-Sleep -Milliseconds 250; $t++ }',
    '$l = $w.Position.Location',
    'if (-not $l.IsUnknown) { Write-Output ("{0};{1}" -f $l.Latitude.ToString([Globalization.CultureInfo]::InvariantCulture), $l.Longitude.ToString([Globalization.CultureInfo]::InvariantCulture)) }',
    '$w.Stop()'
  ].join('; ');
  const out = await run('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], 20000);
  const m = /(-?\d+(?:\.\d+)?);(-?\d+(?:\.\d+)?)/.exec(out);
  if (!m) return null;
  const lat = Number(m[1]), lon = Number(m[2]);
  if (!isFinite(lat) || !isFinite(lon) || (lat === 0 && lon === 0)) return null;
  let name = '', detail = '';
  try {
    const r = await net.fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12&accept-language=es&lat=${lat}&lon=${lon}`,
      { headers: { 'User-Agent': 'Base/1.6 (escritorio personal)' } });
    const j = await r.json();
    const a = j.address || {};
    name = a.city || a.town || a.village || a.suburb || a.municipality || a.county || '';
    detail = [a.state, a.country].filter(Boolean).join(', ');
  } catch {}
  return { lat, lon, name: name || 'Mi ubicación', detail, source: 'windows' };
}
async function ipLocation() {
  try {
    const r = await net.fetch('https://ipwho.is/?lang=es', { headers: { 'User-Agent': 'Base/1.6' } });
    const j = await r.json();
    if (!j.success) return null;
    return { lat: Number(j.latitude), lon: Number(j.longitude), name: j.city || 'Mi ubicación', detail: [j.region, j.country].filter(Boolean).join(', '), source: 'internet' };
  } catch { return null; }
}
ipcMain.handle('geo:locate', async () => {
  const w = await windowsLocation().catch(() => null);
  if (w) return { ok: true, data: w };
  const i = await ipLocation();
  return i ? { ok: true, data: i } : { ok: false, error: 'No se pudo averiguar la ubicación' };
});

// ----- Google (Calendar y Gmail) -----
const google = require('./google');
const wrap = (fn) => async (_e, ...args) => {
  try { return { ok: true, data: await fn(...args) }; }
  catch (e) { log('Google: ' + e.message); return { ok: false, error: e.message, code: e.code || '' }; }
};
const checkMode = (m) => { if (!google.MODES.has(m)) throw new Error('Modo inválido'); return m; };
ipcMain.handle('google:status', wrap(() => google.status()));
ipcMain.handle('google:setConfig', wrap((id, secret) => google.setConfig(id, secret)));
ipcMain.handle('google:link', wrap(async (m) => { const r = await google.link(checkMode(m)); showWindow(); return r; }));
ipcMain.handle('google:unlink', wrap((m) => google.unlink(checkMode(m))));
ipcMain.handle('google:events', wrap((m, a, b) => google.events(checkMode(m), String(a), String(b))));
ipcMain.handle('google:createEvent', wrap((m, ev) => google.createEvent(checkMode(m), ev)));
ipcMain.handle('google:deleteEvent', wrap((m, id) => google.deleteEvent(checkMode(m), String(id))));
ipcMain.handle('google:mail', wrap((m) => google.mail(checkMode(m))));
ipcMain.handle('google:message', wrap((m, id) => google.message(checkMode(m), id)));
ipcMain.handle('google:markRead', wrap((m, ids) => google.markRead(checkMode(m), ids)));
ipcMain.handle('google:cardMails', wrap((m, q, skip, days) => google.cardMails(checkMode(m), String(q || ''), skip, days)));
ipcMain.handle('open:mail', (_e, email, thread) => {
  const auth = /^[^@\s]+@[^@\s]+$/.test(String(email || '')) ? `?authuser=${encodeURIComponent(email)}` : '';
  const u = `https://mail.google.com/mail/${auth}` + (thread ? `#inbox/${encodeURIComponent(thread)}` : '#inbox');
  return shell.openExternal(u);
});
ipcMain.handle('open:google', (_e, url) => {
  if (/^https:\/\/(www\.google\.com\/calendar|calendar\.google\.com|console\.cloud\.google\.com)\//.test(String(url))) return shell.openExternal(url);
});

// ----- Accesos del sistema: barra de tareas y escritorio de Windows -----
const iconCache = new Map();
async function iconOf(p, size = 'large') {
  const key = size + '|' + p;
  if (iconCache.has(key)) return iconCache.get(key);
  let icon = null;
  try { const img = await app.getFileIcon(p, { size }); icon = img.isEmpty() ? null : img.toDataURL(); } catch {}
  iconCache.set(key, icon);
  return icon;
}
async function listShortcuts(folders, exts) {
  const out = [];
  const seen = new Set();
  for (const folder of folders) {
    let files = [];
    try { files = fs.readdirSync(folder); } catch { continue; }
    for (const f of files) {
      const ext = path.extname(f).toLowerCase();
      if (!exts.includes(ext) || /^desktop\.ini$/i.test(f)) continue;
      const name = f.slice(0, -ext.length);
      if (seen.has(name.toLowerCase())) continue;
      seen.add(name.toLowerCase());
      const full = path.join(folder, f);
      let iconPath = full;
      if (ext === '.lnk') {
        try {
          const info = shell.readShortcutLink(full);
          if (info.icon && fs.existsSync(info.icon)) iconPath = info.icon;
          else if (info.target && fs.existsSync(info.target)) iconPath = info.target;
        } catch { /* usamos el .lnk */ }
      }
      out.push({ name, target: full, icon: await iconOf(iconPath) });
    }
  }
  return out.sort((a, b) => a.name.localeCompare(b.name, 'es'));
}
ipcMain.handle('system:shortcuts', async () => {
  if (process.platform !== 'win32') return { taskbar: [], desktop: [] };
  const taskbar = await listShortcuts(
    [path.join(app.getPath('appData'), 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar')], ['.lnk']);
  const desktop = await listShortcuts(
    [app.getPath('desktop'), path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop')],
    ['.lnk', '.url', '.exe', '.appref-ms']);
  return { taskbar, desktop };
});
// compatibilidad con la versión anterior de la interfaz
ipcMain.handle('taskbar:list', async () => {
  if (process.platform !== 'win32') return [];
  return listShortcuts([path.join(app.getPath('appData'), 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar')], ['.lnk']);
});

// ----- Juegos (Steam y Xbox / Game Pass) y apps instaladas -----
const { execFile, spawn } = require('child_process');
function run(cmd, args, timeout = 20000) {
  return new Promise((resolve) => {
    execFile(cmd, args, { windowsHide: true, timeout, maxBuffer: 8 * 1024 * 1024, encoding: 'utf8' },
      (err, stdout) => resolve(err ? '' : String(stdout || '')));
  });
}
// apps del menú Inicio (incluye juegos de Xbox y apps de la Microsoft Store)
let startAppsCache = null;
async function startApps(force) {
  if (process.platform !== 'win32') return [];
  if (!force && startAppsCache && Date.now() - startAppsCache.at < 10 * 60000) return startAppsCache.data;
  const out = await run('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
    '[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-StartApps | Select-Object Name,AppID | ConvertTo-Json -Compress']);
  let data = [];
  try { data = JSON.parse(out.trim() || '[]'); if (!Array.isArray(data)) data = [data]; } catch { data = []; }
  data = data.filter(a => a && a.Name && a.AppID).map(a => ({ name: String(a.Name), id: String(a.AppID) }));
  startAppsCache = { at: Date.now(), data };
  return data;
}
// lector mínimo del formato de Steam (.vdf / .acf)
function vdfValues(text, key) {
  const re = new RegExp('"' + key + '"\\s+"([^"]*)"', 'gi');
  const out = []; let m;
  while ((m = re.exec(text))) out.push(m[1].replace(/\\\\/g, '\\'));
  return out;
}
const fileUrl = (f) => f ? 'file:///' + encodeURI(f.replace(/\\/g, '/')) : '';
// Steam guarda las imágenes como <appid>_<nombre> o en librarycache/<appid>/[<hash>/]<nombre>
function steamLocal(cache, appid, names) {
  for (const n of names) {
    for (const c of [path.join(cache, `${appid}_${n}`), path.join(cache, appid, n)]) {
      try { if (fs.existsSync(c)) return fileUrl(c); } catch {}
    }
  }
  try {
    const sub = path.join(cache, appid);
    for (const d of fs.readdirSync(sub, { withFileTypes: true })) {
      if (!d.isDirectory()) continue;
      for (const n of names) { const c = path.join(sub, d.name, n); if (fs.existsSync(c)) return fileUrl(c); }
    }
  } catch {}
  return '';
}
async function steamGames() {
  if (process.platform !== 'win32') return { ok: false, games: [] };
  let root = '';
  const reg = await run('reg', ['query', 'HKCU\\Software\\Valve\\Steam', '/v', 'SteamPath'], 5000);
  const m = /SteamPath\s+REG_SZ\s+(.+)/i.exec(reg);
  if (m) root = m[1].trim().replace(/\//g, '\\');
  if (!root || !fs.existsSync(root)) root = 'C:\\Program Files (x86)\\Steam';
  if (!fs.existsSync(root)) return { ok: false, games: [] };
  const libs = new Set([root]);
  try {
    const vdf = fs.readFileSync(path.join(root, 'steamapps', 'libraryfolders.vdf'), 'utf8');
    for (const p of vdfValues(vdf, 'path')) libs.add(p);
  } catch {}
  const skip = /redistributable|steamworks|proton|steam linux runtime|steamvr|soundtrack|dedicated server|sdk$/i;
  const games = [];
  const seen = new Set();
  for (const lib of libs) {
    const dir = path.join(lib, 'steamapps');
    let files = [];
    try { files = fs.readdirSync(dir).filter(f => /^appmanifest_\d+\.acf$/i.test(f)); } catch { continue; }
    for (const f of files) {
      try {
        const txt = fs.readFileSync(path.join(dir, f), 'utf8');
        const appid = (vdfValues(txt, 'appid')[0] || '').trim();
        const name = (vdfValues(txt, 'name')[0] || '').trim();
        if (!/^\d+$/.test(appid) || !name || skip.test(name) || appid === '228980' || seen.has(appid)) continue;
        seen.add(appid);
        const lastPlayed = Number(vdfValues(txt, 'LastPlayed')[0] || 0) * 1000;
        // imágenes guardadas por Steam en la compu (portada, banner y encabezado)
        const cache = path.join(root, 'appcache', 'librarycache');
        const local = steamLocal(cache, appid, ['library_600x900.jpg']);
        const localHero = steamLocal(cache, appid, ['library_hero.jpg', 'library_hero_blur.jpg']);
        const localHeader = steamLocal(cache, appid, ['header.jpg', 'library_header.jpg']);
        games.push({ src: 'steam', id: appid, name, lastPlayed, local, localHero, localHeader });
      } catch {}
    }
  }
  // tiempo jugado y última vez: Steam lo guarda por usuario en userdata/<id>/config/localconfig.vdf
  try {
    const ud = path.join(root, 'userdata');
    const wanted = new Map(games.map(g => [g.id, g]));
    for (const user of fs.readdirSync(ud)) {
      let txt = '';
      try { txt = fs.readFileSync(path.join(ud, user, 'config', 'localconfig.vdf'), 'utf8'); } catch { continue; }
      const re = /"(\d+)"\s*\{/g; let m;
      while ((m = re.exec(txt))) {
        const g = wanted.get(m[1]);
        if (!g) continue;
        // recorremos el bloque respetando las llaves anidadas
        let depth = 1, i = re.lastIndex;
        while (depth && i < txt.length) { const c = txt[i++]; if (c === '{') depth++; else if (c === '}') depth--; }
        const block = txt.slice(re.lastIndex, i);
        const pt = /"Playtime"\s+"(\d+)"/i.exec(block);
        const lp = /"LastPlayed"\s+"(\d+)"/i.exec(block);
        if (pt) g.minutes = Math.max(g.minutes || 0, Number(pt[1]));
        if (lp) g.lastPlayed = Math.max(g.lastPlayed || 0, Number(lp[1]) * 1000);
      }
    }
  } catch { /* sin datos de tiempo */ }
  return { ok: true, games };
}
async function xboxGames() {
  if (process.platform !== 'win32') return { ok: false, games: [] };
  const roots = [];
  for (const d of 'CDEFGHIJKLMNOPQRSTUVWXYZ') {
    const r = `${d}:\\XboxGames`;
    try { if (fs.existsSync(r)) roots.push(r); } catch {}
  }
  const apps = await startApps();
  const games = [];
  for (const r of roots) {
    let dirs = [];
    try { dirs = fs.readdirSync(r, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => x.name); } catch { continue; }
    for (const d of dirs) {
      if (/^GameSave|^\./i.test(d)) continue;
      const content = path.join(r, d, 'Content');
      let cfg = '';
      try { cfg = fs.readFileSync(path.join(content, 'MicrosoftGame.config'), 'utf8'); } catch { continue; }
      const attr = (re) => { const x = re.exec(cfg); return x ? x[1] : ''; };
      const ident = attr(/<Identity[^>]*\sName="([^"]+)"/i);
      const title = attr(/DefaultDisplayName="([^"]+)"/i) || d;
      const exeId = attr(/<Executable[^>]*\sId="([^"]+)"/i);
      let img = attr(/SplashScreenImage="([^"]+)"/i) || attr(/Square480x480Logo="([^"]+)"/i) || attr(/Square150x150Logo="([^"]+)"/i) || attr(/StoreLogo="([^"]+)"/i);
      let local = '';
      if (img) { const full = path.join(content, img); if (fs.existsSync(full)) local = 'file:///' + encodeURI(full.replace(/\\/g, '/')); }
      const match = apps.find(a => ident && a.id.toLowerCase().startsWith(ident.toLowerCase() + '_') && (!exeId || a.id.endsWith('!' + exeId)))
        || apps.find(a => ident && a.id.toLowerCase().startsWith(ident.toLowerCase() + '_'))
        || apps.find(a => a.name.toLowerCase() === title.toLowerCase());
      games.push({ src: 'xbox', id: match ? match.id : '', name: title.replace(/&amp;/g, '&'), local, lastPlayed: 0 });
    }
  }
  return { ok: true, games, xboxApp: apps.some(a => /Microsoft\.GamingApp_/i.test(a.id)) };
}
// ----- Otras bibliotecas: Epic, EA, Rockstar, Ubisoft, GOG y Battle.net -----
const knownExes = new Set();
const LAUNCHER_RX = /^(ea app|ea desktop|origin|rockstar games launcher|rockstar games social club|social club|battle\.net|ubisoft connect|uplay|gog galaxy|epic games launcher)\b|overlay|redistributable|anti-?cheat|easyanticheat|directx|vcredist|launcher$/i;
function pickExe(dir, name) {
  try {
    const files = fs.readdirSync(dir).filter(f => /\.exe$/i.test(f) && !/unins|uninstall|setup|crash|report|launcherpatcher|helper|redist|vc_?redist|dxsetup|cleanup|activation|eac/i.test(f));
    if (!files.length) return '';
    const words = String(name || '').toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 2);
    const score = (f) => { const l = f.toLowerCase(); return (l.startsWith('play') ? 5 : 0) + words.filter(w => l.includes(w)).length * 2 - (l.includes('launcher') ? 1 : 0); };
    files.sort((a, b) => score(b) - score(a));
    return path.join(dir, files[0]);
  } catch { return ''; }
}
async function exeIcon(exe) { try { const i = await app.getFileIcon(exe, { size: 'large' }); return i.isEmpty() ? '' : i.toDataURL(); } catch { return ''; } }
async function otherGames() {
  if (process.platform !== 'win32') return { ok: false, games: [] };
  const games = [];
  const seen = new Set();
  const add = async (g) => {
    const k = (g.src + ':' + g.name).toLowerCase();
    if (seen.has(k) || !g.name) return;
    seen.add(k);
    if (g.exe) { knownExes.add(g.exe.toLowerCase()); g.icon = await exeIcon(g.exe); }
    games.push(g);
  };
  // Epic Games: un archivo por juego instalado
  try {
    const dir = path.join(process.env.ProgramData || 'C:\\ProgramData', 'Epic', 'EpicGamesLauncher', 'Data', 'Manifests');
    for (const f of fs.readdirSync(dir).filter(x => /\.item$/i.test(x))) {
      try {
        const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
        if (j.bIsIncompleteInstall) continue;
        if (j.MainGameAppName && j.AppName && j.MainGameAppName !== j.AppName) continue; // contenido extra
        if (Array.isArray(j.AppCategories) && !j.AppCategories.includes('games')) continue;
        const exe = j.InstallLocation && j.LaunchExecutable ? path.join(j.InstallLocation, j.LaunchExecutable) : '';
        await add({ src: 'epic', name: j.DisplayName, id: `${j.CatalogNamespace}:${j.CatalogItemId}:${j.AppName}`, exe: exe && fs.existsSync(exe) ? exe : '', lastPlayed: 0 });
      } catch {}
    }
  } catch {}
  // GOG
  try {
    const out = await run('reg', ['query', 'HKLM\\SOFTWARE\\WOW6432Node\\GOG.com\\Games', '/s'], 8000);
    for (const blk of out.split(/\r?\n(?=HKEY_)/)) {
      const v = (k) => { const m = new RegExp(`^\\s+${k}\\s+REG_\\w+\\s+(.+)$`, 'mi').exec(blk); return m ? m[1].trim() : ''; };
      const name = v('gameName'), exe = v('exe');
      if (name && exe && fs.existsSync(exe)) await add({ src: 'gog', name, id: v('gameID'), exe, lastPlayed: 0 });
    }
  } catch {}
  // Ubisoft Connect
  try {
    const out = await run('reg', ['query', 'HKLM\\SOFTWARE\\WOW6432Node\\Ubisoft\\Launcher\\Installs', '/s'], 8000);
    for (const blk of out.split(/\r?\n(?=HKEY_)/)) {
      const id = (/Installs\\(\d+)/.exec(blk) || [])[1];
      const dir = (/InstallDir\s+REG_\w+\s+(.+)$/mi.exec(blk) || [])[1];
      if (id && dir && fs.existsSync(dir.trim())) await add({ src: 'ubisoft', name: path.basename(dir.trim().replace(/[\\/]+$/, '')), id, exe: '', lastPlayed: 0 });
    }
  } catch {}
  // EA, Rockstar, Blizzard (y Ubisoft si no apareció arriba): lo instalado en Windows por esas empresas
  try {
    const ps = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; $k='HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'; " +
      "Get-ItemProperty $k -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -and $_.Publisher -match 'Electronic Arts|Rockstar|Blizzard|Ubisoft' } | Select-Object DisplayName,Publisher,DisplayIcon,InstallLocation | ConvertTo-Json -Compress";
    const out = await run('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], 20000);
    let list = []; try { list = JSON.parse(out.trim() || '[]'); if (!Array.isArray(list)) list = [list]; } catch {}
    for (const it of list) {
      const name = String(it.DisplayName || '').trim();
      if (!name || LAUNCHER_RX.test(name)) continue;
      const pub = String(it.Publisher || '');
      const src = /electronic arts/i.test(pub) ? 'ea' : /rockstar/i.test(pub) ? 'rockstar' : /blizzard/i.test(pub) ? 'battlenet' : 'ubisoft';
      let exe = String(it.DisplayIcon || '').replace(/"/g, '').replace(/,\s*-?\d+$/, '').trim();
      if (!/\.exe$/i.test(exe) || /unins|uninstall|cleanup/i.test(exe) || !fs.existsSync(exe)) exe = '';
      const dir = String(it.InstallLocation || '').replace(/"/g, '').trim();
      if (!exe && dir && fs.existsSync(dir)) exe = pickExe(dir, name);
      if (!exe) continue;
      await add({ src, name: name.replace(/\s*\(.*?\)\s*$/, ''), id: '', exe, lastPlayed: 0 });
    }
  } catch {}
  return { ok: true, games };
}
ipcMain.handle('games:list', async () => {
  const [st, xb, ot] = await Promise.all([steamGames(), xboxGames(), otherGames().catch(() => ({ ok: false, games: [] }))]);
  return { steam: st, xbox: xb, others: ot };
});
ipcMain.handle('apps:start', async (_e, force) => startApps(!!force));
const XBOX_APP = 'Microsoft.GamingApp_8wekyb3d8bbwe!Microsoft.Xbox.App';
ipcMain.handle('launch:special', async (_e, kind, id) => {
  id = String(id || '');
  try {
    if (kind === 'steam' && /^\d+$/.test(id)) { await shell.openExternal(`steam://rungameid/${id}`); return ''; }
    if (kind === 'steam-app') { await shell.openExternal('steam://open/games'); return ''; }
    if (kind === 'aumid' && /^[^"&|<>^%\r\n\/-][^"&|<>^%\r\n]{0,299}$/.test(id)) {
      spawn('explorer.exe', [`shell:AppsFolder\\${id}`], { detached: true, stdio: 'ignore' }).unref(); return '';
    }
    if (kind === 'xbox-app') { spawn('explorer.exe', [`shell:AppsFolder\\${XBOX_APP}`], { detached: true, stdio: 'ignore' }).unref(); return ''; }
    if (kind === 'url' && /^https:\/\//i.test(id)) { await shell.openExternal(id); return ''; }
    if (kind === 'epic' && /^[\w.-]+:[\w-]+:[\w.-]+$/.test(id)) { await shell.openExternal(`com.epicgames.launcher://apps/${encodeURIComponent(id)}?action=launch&silent=true`); return ''; }
    if (kind === 'uplay' && /^\d{1,10}$/.test(id)) { await shell.openExternal(`uplay://launch/${id}/0`); return ''; }
    if (kind === 'exe' && knownExes.has(id.toLowerCase()) && fs.existsSync(id)) {
      spawn(id, [], { cwd: path.dirname(id), detached: true, stdio: 'ignore' }).unref(); return '';
    }
    if (kind === 'store') {
      const urls = { epic: 'com.epicgames.launcher://store', ubisoft: 'uplay://', gog: 'goggalaxy://', battlenet: 'battlenet://' };
      if (urls[id]) { await shell.openExternal(urls[id]); return ''; }
    }
  } catch (e) { return e.message; }
  return 'No se pudo abrir';
});

// ----- Explorador de archivos propio de Base -----
const fsp = fs.promises;
const okPath = (p) => typeof p === 'string' && p.length > 2 && p.length < 1000 && path.isAbsolute(p) && !/[\0]/.test(p);
const okName = (n) => typeof n === 'string' && n.trim() && n.length < 255 && !/[\\/:*?"<>|\0]/.test(n) && !/^\.+$/.test(n.trim());
ipcMain.handle('fx:places', async () => {
  const P = (k) => { try { return app.getPath(k); } catch { return ''; } };
  const places = [
    { k: 'desktop', n: 'Escritorio', p: P('desktop') }, { k: 'downloads', n: 'Descargas', p: P('downloads') },
    { k: 'documents', n: 'Documentos', p: P('documents') }, { k: 'pictures', n: 'Imágenes', p: P('pictures') },
    { k: 'music', n: 'Música', p: P('music') }, { k: 'videos', n: 'Videos', p: P('videos') }, { k: 'home', n: 'Tu carpeta', p: P('home') }
  ].filter(x => x.p && exists(x.p));
  const drives = [];
  if (process.platform === 'win32') {
    for (const l of 'CDEFGHIJKLMNOPQRSTUVWXYZ') { const d = l + ':\\'; try { fs.accessSync(d); drives.push({ k: 'drive', n: `Disco ${l}:`, p: d }); } catch {} }
  } else drives.push({ k: 'drive', n: 'Raíz', p: '/' });
  return { places, drives, sep: path.sep };
});
ipcMain.handle('fx:list', async (_e, dir, hidden) => {
  if (!okPath(dir)) return { ok: false, error: 'Ruta inválida' };
  let ents;
  try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch (e) { return { ok: false, error: e.code === 'EPERM' || e.code === 'EACCES' ? 'No tenés permiso para abrir esta carpeta' : e.code === 'ENOENT' ? 'La carpeta ya no existe' : e.message }; }
  if (!hidden) ents = ents.filter(e => !/^(desktop\.ini|thumbs\.db|ntuser\.|\$)/i.test(e.name) && !e.name.startsWith('.'));
  ents = ents.slice(0, 4000);
  const out = [];
  for (let i = 0; i < ents.length; i += 64) {
    const part = await Promise.all(ents.slice(i, i + 64).map(async (e) => {
      const full = path.join(dir, e.name);
      try {
        const st = await fsp.stat(full);
        return { n: e.name, p: full, d: st.isDirectory(), s: st.isDirectory() ? 0 : st.size, m: st.mtimeMs, x: st.isDirectory() ? '' : path.extname(e.name).slice(1).toLowerCase() };
      } catch { return e.isSymbolicLink() ? null : { n: e.name, p: full, d: e.isDirectory(), s: 0, m: 0, x: path.extname(e.name).slice(1).toLowerCase() }; }
    }));
    out.push(...part.filter(Boolean));
  }
  return { ok: true, dir, items: out, parent: path.dirname(dir) !== dir ? path.dirname(dir) : '' };
});
const thumbCache = new Map();
ipcMain.handle('fx:thumb', async (_e, p) => {
  if (!okPath(p)) return null;
  if (thumbCache.has(p)) return thumbCache.get(p);
  let url = null;
  try { const img = await nativeImage.createThumbnailFromPath(p, { width: 220, height: 220 }); if (!img.isEmpty()) url = img.toDataURL(); } catch {}
  if (thumbCache.size > 600) thumbCache.clear();
  thumbCache.set(p, url);
  return url;
});
ipcMain.handle('fx:icon', async (_e, p) => (okPath(p) ? iconOf(p, 'large') : null));
ipcMain.handle('fx:open', async (_e, p) => { if (!okPath(p)) return 'Ruta inválida'; return shell.openPath(p); });
ipcMain.handle('fx:reveal', async (_e, p) => { if (okPath(p)) shell.showItemInFolder(p); });
ipcMain.handle('fx:winexplorer', async (_e, p) => { if (okPath(p)) await shell.openPath(p); else spawn('explorer.exe', [], { detached: true, stdio: 'ignore' }).unref(); });
ipcMain.handle('fx:trash', async (_e, list) => {
  const errs = [];
  for (const p of (Array.isArray(list) ? list : [list]).slice(0, 500)) { if (!okPath(p)) continue; try { await shell.trashItem(p); } catch (e) { errs.push(path.basename(p)); } }
  return errs.length ? `No se pudieron mandar a la papelera: ${errs.slice(0, 3).join(', ')}` : '';
});
ipcMain.handle('fx:rename', async (_e, p, name) => {
  if (!okPath(p) || !okName(name)) return 'Nombre inválido';
  const to = path.join(path.dirname(p), name.trim());
  if (exists(to)) return 'Ya hay algo con ese nombre';
  try { await fsp.rename(p, to); return ''; } catch (e) { return e.message; }
});
ipcMain.handle('fx:mkdir', async (_e, dir, name) => {
  if (!okPath(dir)) return { error: 'Ruta inválida' };
  let n = okName(name) ? name.trim() : 'Nueva carpeta', i = 2, to = path.join(dir, n);
  while (exists(to)) to = path.join(dir, `${n} (${i++})`);
  try { await fsp.mkdir(to); return { path: to }; } catch (e) { return { error: e.message }; }
});
function freeName(dir, base) {
  const ext = path.extname(base), stem = ext ? base.slice(0, -ext.length) : base;
  let to = path.join(dir, base), i = 2;
  while (exists(to)) to = path.join(dir, `${stem} (${i++})${ext}`);
  return to;
}
ipcMain.handle('fx:paste', async (_e, list, dir, move) => {
  if (!okPath(dir)) return 'Ruta inválida';
  const errs = [];
  for (const src of (Array.isArray(list) ? list : []).slice(0, 500)) {
    if (!okPath(src) || !exists(src)) continue;
    if (dir === src || dir.startsWith(src + path.sep)) { errs.push(path.basename(src) + ' (no se puede meter adentro de sí misma)'); continue; }
    try {
      if (move && path.dirname(src) === dir) continue;
      const to = freeName(dir, path.basename(src));
      if (move) { try { await fsp.rename(src, to); } catch { await fsp.cp(src, to, { recursive: true, errorOnExist: true }); await fsp.rm(src, { recursive: true, force: true }); } }
      else await fsp.cp(src, to, { recursive: true, errorOnExist: true });
    } catch (e) { errs.push(path.basename(src)); }
  }
  return errs.length ? `No se pudieron ${move ? 'mover' : 'copiar'}: ${errs.slice(0, 3).join(', ')}` : '';
});
const TEXT_EXT = /\.(txt|md|csv|json|log|ini|xml|html?|css|js|ts|py|bat|ps1|sql|yml|yaml|cfg|conf)$/i;
ipcMain.handle('fx:peek', async (_e, p) => {
  if (!okPath(p) || !TEXT_EXT.test(p)) return null;
  try { const fh = await fsp.open(p, 'r'); const buf = Buffer.alloc(3000); const { bytesRead } = await fh.read(buf, 0, 3000, 0); await fh.close(); return buf.slice(0, bytesRead).toString('utf8'); } catch { return null; }
});
ipcMain.handle('fx:copypath', async (_e, p) => { if (okPath(p)) require('electron').clipboard.writeText(p); });
// más funciones del explorador: archivo nuevo, propiedades, tamaño de carpetas, zip, abrir con, espacio libre, buscar en subcarpetas
ipcMain.handle('fx:newfile', async (_e, dir, name) => {
  if (!okPath(dir)) return { error: 'Ruta inválida' };
  const to = freeName(dir, okName(name) ? name.trim() : 'Nuevo documento de texto.txt');
  try { await fsp.writeFile(to, '', { flag: 'wx' }); return { path: to }; } catch (e) { return { error: e.message }; }
});
ipcMain.handle('fx:stat', async (_e, p) => {
  if (!okPath(p)) return null;
  try { const st = await fsp.stat(p); return { d: st.isDirectory(), s: st.size, m: st.mtimeMs, c: st.birthtimeMs, a: st.atimeMs, ro: !(st.mode & 0o200) }; } catch (e) { return { error: e.message }; }
});
ipcMain.handle('fx:du', async (_e, p) => {
  if (!okPath(p)) return null;
  let size = 0, files = 0, dirs = 0; const t0 = Date.now();
  async function walk(d, depth) {
    if (depth > 30 || Date.now() - t0 > 15000) return;
    let ents; try { ents = await fsp.readdir(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      const f2 = path.join(d, e.name);
      if (e.isDirectory()) { dirs++; await walk(f2, depth + 1); }
      else if (e.isFile()) { files++; try { size += (await fsp.stat(f2)).size; } catch {} }
    }
  }
  await walk(p, 0);
  return { size, files, dirs, partial: Date.now() - t0 > 15000 };
});
ipcMain.handle('fx:free', async (_e, p) => {
  if (!okPath(p) || !fsp.statfs) return null;
  try { const st = await fsp.statfs(p); return { free: st.bavail * st.bsize, total: st.blocks * st.bsize }; } catch { return null; }
});
ipcMain.handle('fx:openwith', async (_e, p) => {
  if (!okPath(p) || process.platform !== 'win32') return 'No disponible';
  try { spawn('rundll32.exe', ['shell32.dll,OpenAs_RunDLL', p], { detached: true, stdio: 'ignore' }).unref(); return ''; } catch (e) { return e.message; }
});
ipcMain.handle('fx:zip', async (_e, list, dir) => {
  if (!okPath(dir) || !Array.isArray(list) || !list.length || !list.every(okPath)) return { error: 'Ruta inválida' };
  const base = list.length === 1 ? path.basename(list[0]).replace(/\.[^.]+$/, '') : path.basename(dir) || 'Archivos';
  const to = freeName(dir, base + '.zip');
  const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
  const r = await psRun(`$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Compress-Archive -LiteralPath ${list.map(q).join(',')} -DestinationPath ${q(to)}`);
  return r.code === 0 ? { path: to } : { error: 'No se pudo comprimir' };
});
ipcMain.handle('fx:unzip', async (_e, p) => {
  if (!okPath(p) || !/\.zip$/i.test(p)) return { error: 'Sólo archivos .zip' };
  const to = freeName(path.dirname(p), path.basename(p).replace(/\.zip$/i, ''));
  const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
  const r = await psRun(`$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Expand-Archive -LiteralPath ${q(p)} -DestinationPath ${q(to)}`);
  return r.code === 0 ? { path: to } : { error: 'No se pudo descomprimir' };
});
ipcMain.handle('fx:search', async (_e, dir, q, hidden) => {
  if (!okPath(dir) || typeof q !== 'string' || q.trim().length < 2) return { items: [] };
  const needle = q.trim().toLowerCase(), out = []; const t0 = Date.now();
  async function walk(d, depth) {
    if (depth > 8 || out.length >= 1500 || Date.now() - t0 > 8000) return;
    let ents; try { ents = await fsp.readdir(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (out.length >= 1500) return;
      if (!hidden && (e.name.startsWith('.') || /^(\$|node_modules$|appdata$)/i.test(e.name))) continue;
      const f2 = path.join(d, e.name);
      if (e.name.toLowerCase().includes(needle)) { try { const st = await fsp.stat(f2); out.push({ n: e.name, p: f2, d: st.isDirectory(), s: st.isDirectory() ? 0 : st.size, m: st.mtimeMs, x: st.isDirectory() ? '' : path.extname(e.name).slice(1).toLowerCase(), in: path.relative(dir, d) }); } catch {} }
      if (e.isDirectory()) await walk(f2, depth + 1);
    }
  }
  await walk(dir, 0);
  return { items: out, partial: out.length >= 1500 || Date.now() - t0 > 8000 };
});

// ----- Menú Inicio propio de Base: apps instaladas, recientes -----
async function walkLnk(dir, depth, out, cat) {
  let ents = [];
  try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    const full = path.join(dir, e.name);
    if (e.isDirectory() && depth > 0) await walkLnk(full, depth - 1, out, cat || e.name);
    else if (/\.(lnk|url|appref-ms)$/i.test(e.name) && !/^(desinstalar|uninstall|léame|readme|help|ayuda|website|sitio web)\b/i.test(e.name)) {
      out.push({ n: e.name.replace(/\.(lnk|url|appref-ms)$/i, ''), p: full, cat: cat || '' });
    }
  }
}
let startMenuCache = null;
ipcMain.handle('sm:apps', async (_e, force) => {
  if (!force && startMenuCache && Date.now() - startMenuCache.at < 10 * 60000) return startMenuCache.data;
  const out = [];
  if (process.platform === 'win32') {
    await walkLnk(path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs'), 2, out, '');
    await walkLnk(path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs'), 2, out, '');
  }
  const seen = new Set(out.map(a => a.n.toLowerCase()));
  let store = [];
  try { store = (await startApps()).filter(a => /!/.test(a.id) && !seen.has(a.name.toLowerCase())).map(a => ({ n: a.name, aumid: a.id, cat: '' })); } catch {}
  const data = [...out, ...store].filter((a, i, arr) => arr.findIndex(b => b.n.toLowerCase() === a.n.toLowerCase()) === i).sort((a, b) => a.n.localeCompare(b.n, 'es'));
  startMenuCache = { at: Date.now(), data };
  return data;
});
ipcMain.handle('sm:icon', async (_e, p) => {
  if (!okPath(p)) return null;
  let ip = p;
  if (/\.lnk$/i.test(p)) { try { const info = shell.readShortcutLink(p); if (info.icon && exists(info.icon)) ip = info.icon; else if (info.target && exists(info.target)) ip = info.target; } catch {} }
  return iconOf(ip, 'large');
});
ipcMain.handle('sm:open', async (_e, it) => {
  try {
    if (it && it.aumid && /^[^"&|<>^%\r\n\/-][^"&|<>^%\r\n]{0,299}$/.test(it.aumid)) { spawn('explorer.exe', [`shell:AppsFolder\\${it.aumid}`], { detached: true, stdio: 'ignore' }).unref(); return ''; }
    if (it && okPath(it.p)) return await shell.openPath(it.p);
  } catch (e) { return e.message; }
  return 'No se pudo abrir';
});
ipcMain.handle('sm:recent', async () => {
  if (process.platform !== 'win32') return [];
  const dir = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Recent');
  let ents = [];
  try { ents = (await fsp.readdir(dir)).filter(f => /\.lnk$/i.test(f)); } catch { return []; }
  const stats = await Promise.all(ents.map(async f => { try { return { f, m: (await fsp.stat(path.join(dir, f))).mtimeMs }; } catch { return null; } }));
  const out = [];
  for (const x of stats.filter(Boolean).sort((a, b) => b.m - a.m)) {
    if (out.length >= 14) break;
    try {
      const t = shell.readShortcutLink(path.join(dir, x.f)).target;
      if (!t || !exists(t)) continue;
      let isDir = false; try { isDir = fs.statSync(t).isDirectory(); } catch {}
      out.push({ n: path.basename(t), p: t, d: isDir, m: x.m });
    } catch {}
  }
  return out;
});

// ----- Ventanas abiertas (ayudante de PowerShell) -----
const winHelper = {
  proc: null, ready: false, failed: '', seq: 0, waiting: new Map(), buf: '', starting: null, restarts: 0,
  start() {
    if (process.platform !== 'win32') { this.failed = 'Solo en Windows'; return Promise.resolve(false); }
    if (this.ready) return Promise.resolve(true);
    if (this.starting) return this.starting;
    this.starting = new Promise((resolve) => {
      let p;
      try {
        p = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'ventanas.ps1')],
          { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      } catch (e) { this.failed = e.message; this.starting = null; return resolve(false); }
      this.proc = p;
      // la primera vez puede tardar (compila); en compus lentas o con antivirus, bastante más
      const timer = setTimeout(() => { if (!this.ready) { this.failed = 'El ayudante de ventanas tardó demasiado en arrancar'; this.failedAt = Date.now(); log(this.failed); try { p.kill(); } catch {} resolve(false); } }, 90000);
      p.stdout.setEncoding('utf8');
      p.stdout.on('data', (chunk) => {
        this.buf += chunk;
        let i;
        while ((i = this.buf.indexOf('\n')) >= 0) {
          const line = this.buf.slice(0, i).trim(); this.buf = this.buf.slice(i + 1);
          if (!line) continue;
          let msg; try { msg = JSON.parse(line); } catch { continue; }
          if ('ready' in msg) {
            clearTimeout(timer);
            this.ready = !!msg.ready;
            if (!msg.ready) { this.failed = msg.error || 'No se pudo iniciar'; this.failedAt = Date.now(); log('Ayudante de ventanas: ' + this.failed); }
            else {
              this.failed = ''; this.restarts = 0;
              log('Ayudante de ventanas listo');
              // si Base se cierra de golpe, el ayudante la vuelve a abrir
              if (app.isPackaged) {
                p.stdin.write('0 relaunch ' + process.execPath + '\n');
                // vigilante: si la ventana queda trabada 40 s, el ayudante cierra Base y la vuelve a abrir
                p.stdin.write('0 watch ' + selfHandle() + '|' + process.execPath + '|' + logFile() + '\n');
              }
              const st = settings(); DESK.tb = false; DESK.on = false;
              setTimeout(() => deskApply(st), 300);
            }
            resolve(this.ready);
          } else if (this.waiting.has(msg.id)) {
            const w = this.waiting.get(msg.id); this.waiting.delete(msg.id);
            clearTimeout(w.t); w.resolve(msg);
          }
        }
      });
      p.stderr.on('data', (d) => log('Ayudante de ventanas (error): ' + String(d).slice(0, 300)));
      p.on('exit', () => {
        clearTimeout(timer);
        const wasReady = this.ready;
        this.ready = false; this.proc = null; this.starting = null;
        for (const w of this.waiting.values()) { clearTimeout(w.t); w.resolve({ ok: false }); }
        this.waiting.clear();
        if (!wasReady) { if (!this.failed) { this.failed = 'El ayudante de ventanas se cerró al arrancar'; } this.failedAt = Date.now(); resolve(false); }
      });
    });
    return this.starting;
  },
  async send(cmd, arg = '') {
    if (!this.ready) {
      if (this.starting && this.proc) { const ok0 = await this.starting; if (!ok0 && !this.ready) return { ok: false, error: this.failed || 'Arrancando…' }; }
      // si falló, lo vuelve a intentar solo cada tanto (no queda apagado para siempre)
      if (!this.ready && (this.failed || this.restarts > 3)) {
        if (this.proc || this.restarts > 12 || Date.now() - (this.failedAt || 0) < 45000) return { ok: false, error: this.failed || 'No disponible' };
        this.failed = '';
      }
    }
    if (!this.ready) {
      this.restarts++;
      const ok = await this.start();
      if (!ok) return { ok: false, error: this.failed || 'No disponible' };
    }
    if (!this.proc || !this.proc.stdin || !this.proc.stdin.writable || this.closing) return { ok: false, error: 'Cerrando' };
    const id = ++this.seq;
    return new Promise((resolve) => {
      const t = setTimeout(() => { this.waiting.delete(id); resolve({ ok: false, error: 'Sin respuesta' }); }, 5000);
      this.waiting.set(id, { resolve, t });
      try { this.proc.stdin.write(`${id} ${cmd} ${arg}\n`); } catch { clearTimeout(t); this.waiting.delete(id); resolve({ ok: false }); }
    });
  },
  stop() {
    // cierre prolijo: el ayudante devuelve la barra de Windows y sabe que no tiene que reabrir Base
    try {
      if (this.proc && this.ready && this.proc.stdin.writable) { this.closing = true; this.proc.stdin.write('0 bye x\n'); this.proc.stdin.end(); }
      else if (this.proc) this.proc.kill();
    } catch { try { this.proc.kill(); } catch {} }
  }
};

// ----- Escritorio minimalista: la barra de Base va abajo, así que las ventanas de Windows tienen que usar
// toda la pantalla menos esa barra (sin dejar lugar arriba). Base ocupa toda la pantalla, detrás. -----
const WA = { mdesk: false, on: false, rect: null, orig: null, sets: [], last: 0, mode: 'appbar', checkT: 0 };
function waWanted() { return process.platform === 'win32' && WA.mdesk && WA.mode !== 'none'; }
async function waOff() { await winHelper.send('appbar', 'off'); await winHelper.send('workarea', 'off'); }
// ¿Windows dejó libre el lugar de la barra en ese monitor? Si no, se la vuelve a anotar (hasta 3 veces seguidas)
// y recién ahí se prueba el método anterior
// píxeles reales: con monitores a distinto zoom, multiplicar por la escala no alcanza (el origen se corre)
function physRect(r, sf) {
  try { if (process.platform === 'win32' && screen.dipToScreenRect) { const p = screen.dipToScreenRect(null, r); return { x: Math.round(p.x), y: Math.round(p.y), width: Math.round(p.width), height: Math.round(p.height) }; } } catch {}
  return { x: Math.round(r.x * sf), y: Math.round(r.y * sf), width: Math.round(r.width * sf), height: Math.round(r.height * sf) };
}
async function waCheck(b, sf, bar) {
  if (!WA.on || WA.mode !== 'appbar' || DESK.peek) return;
  WA.lastCheck = Date.now();
  const pr = physRect({ x: b.x, y: b.y + b.height - bar, width: b.width, height: bar }, sf);
  const g = await winHelper.send('waget', `${pr.x + Math.round(pr.width / 2)}|${pr.y - 20}`);
  if (!g || !g.ok || typeof g.data !== 'string') return;
  const bottom = Number(g.data.split('|')[3]), expect = pr.y;
  if (bottom <= expect + 4) {
    WA.fails = 0;
    if (!WA.okLogged) { WA.okLogged = true; log(`Área de ventanas: Windows reservó la barra de Base (las ventanas terminan en ${bottom})`); }
    return;
  }
  const info = await winHelper.send('abinfo', 'x');
  WA.fails = (WA.fails || 0) + 1;
  log(`Área de ventanas: la barra no está reservada (${bottom} en vez de ${expect}; ${info && info.data}), intento ${WA.fails}`);
  if (WA.fails <= 3) { await winHelper.send('abrenew', 'x'); WA.checkT = setTimeout(() => waCheck(b, sf, bar), 2500); return; }
  WA.fails = 0;
  log('Área de ventanas: pruebo el método anterior');
  await winHelper.send('appbar', 'off'); WA.mode = 'spi'; WA.rect = null; waApply();
}
async function waApply() {
  if (!win || win.isDestroyed()) return;
  if (DESK.peek) return;   // mirando el escritorio de Windows: nada que acomodar
  if (!waWanted()) {
    if (WA.on) { WA.on = false; WA.rect = null; WA.orig = null; await waOff(); setTimeout(() => { try { const d = targetDisplay(); win.setBounds(d.workArea); win.maximize(); } catch {} }, 400); }
    return;
  }
  const d = targetDisplay(), sf = d.scaleFactor || 1, bar = 54;
  // con la barra de Windows escondida, toda la pantalla; si no, lo que deja la barra de Windows (tomado antes de cambiarlo)
  if (!WA.on || !WA.orig) WA.orig = Object.assign({}, d.workArea);
  const b = settings().hideTaskbar ? d.bounds : WA.orig;
  WA.on = true;
  try { if (win.isMaximized()) win.unmaximize(); const cb = win.getBounds(); if (Math.abs(cb.x - b.x) > 2 || Math.abs(cb.y - b.y) > 2 || Math.abs(cb.width - b.width) > 2 || Math.abs(cb.height - b.height) > 2) win.setBounds(b); } catch {}
  if (WA.mode === 'appbar') {
    // la barra de Base se anota como barra de aplicación (abajo, 54 px): Windows mismo deja ese lugar libre
    const pr = physRect({ x: b.x, y: b.y + b.height - bar, width: b.width, height: bar }, sf);
    const r = [pr.x, pr.y, pr.width, pr.height].join('|');
    if (WA.rect === r && Date.now() - WA.last < 2500) return;
    WA.rect = r; WA.last = Date.now();
    const res = await winHelper.send('appbar', r);
    if (!res || !res.ok || res.data === false) { log('Área de ventanas: no se pudo anotar la barra, pruebo el método anterior'); WA.mode = 'spi'; WA.rect = null; return waApply(); }
    // comprobamos que Windows lo tomó (también cada tanto, por si después la soltó); si no, se vuelve a anotar
    if (res.data === 'set' || Date.now() - (WA.lastCheck || 0) > 20000) { clearTimeout(WA.checkT); WA.checkT = setTimeout(() => waCheck(b, sf, bar), 1800); }
    return;
  }
  // método anterior: cambiar el área a mano (SPI_SETWORKAREA)
  const pw = physRect({ x: b.x, y: b.y, width: b.width, height: b.height - bar }, sf);
  const r = [pw.x, pw.y, pw.width, pw.height].join('|');
  if (WA.rect === r && Date.now() - WA.last < 2500) return;
  WA.rect = r; WA.last = Date.now();
  const res = await winHelper.send('workarea', r);
  if (res && res.ok && res.data === 'set') {
    const now = Date.now(); WA.sets = WA.sets.filter(t => now - t < 60000); WA.sets.push(now);
    // si Windows lo deshace una y otra vez, se deja de insistir hasta que se reinicie Base (antes volvía cada 10 minutos
    // y la barra de Windows aparecía y desaparecía)
    if (WA.sets.length > 3) { log('Área de ventanas: Windows no la acepta, se deja como está'); WA.mode = 'none'; WA.on = false; WA.rect = null; WA.orig = null; await winHelper.send('workarea', 'off'); }
  }
}
ipcMain.on('desk:mdesk', (_e, on) => { WA.mdesk = !!on; waApply(); });
setInterval(() => { if (WA.on) waApply(); }, 6000);
app.on('will-quit', () => { if (WA.on) { try { winHelper.send('appbar', 'off'); winHelper.send('workarea', 'off'); } catch {} } });

// ----- Modo escritorio: Base hace de escritorio de Windows -----
const DESK = { on: false, tb: false, poll: null, keep: null, busy: false, hang: null };
function deskApply(s) {
  if (process.platform !== 'win32' || !win) return;
  const on = !!s.deskMode, tb = !!s.hideTaskbar;
  if (on !== DESK.on) {
    DESK.on = on;
    clearInterval(DESK.poll); DESK.poll = null;
    if (on) {
      DESK.poll = setInterval(deskTick, 800);
      startupFast();
      if (win.isMinimized()) win.restore();
      if (!win.isVisible()) win.show();
    }
  }
  if (tb !== DESK.tb) {
    DESK.tb = tb;
    clearInterval(DESK.keep); DESK.keep = null;
    const reWa = WA.on; if (reWa) { WA.on = false; WA.rect = null; WA.orig = null; winHelper.send('appbar', 'off'); winHelper.send('workarea', 'off'); }
    winHelper.send('taskbar', tb ? '1' : '0').then(() => setTimeout(() => { placeWin(true); waApply(); }, 900));
    if (tb) DESK.keep = setInterval(() => winHelper.send('tbkeep', 'x'), 5000);
  }
}
// cuando Base no está adelante: si el usuario fue al escritorio (Win+D, clic en el escritorio), aparece Base
async function deskTick() {
  if (!DESK.on || DESK.busy || DESK.peek || !win || win.isDestroyed() || quitting) return;
  if (win.isFocused() && !win.isMinimized()) return;
  DESK.busy = true;
  try {
    const r = await winHelper.send('fgclass', 'x');
    const cls = r.ok && r.data ? String(r.data.c || '') : '';
    if (cls === 'WorkerW' || cls === 'Progman') {
      if (win.isMinimized()) win.restore();
      win.show(); win.focus();
      await winHelper.send('focus', selfHandle());
    }
  } catch {} finally { DESK.busy = false; }
}
// Windows demora los programas de inicio unos segundos; con Base como escritorio lo sacamos
function startupFast() {
  if (!app.isPackaged) return;
  try {
    spawn('reg.exe', ['add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Serialize', '/v', 'StartupDelayInMSec', '/t', 'REG_DWORD', '/d', '0', '/f'], { windowsHide: true, stdio: 'ignore' }).on('error', () => {});
  } catch {}
}
// "Ver el escritorio de Windows": Base se corre hasta que lo vuelvas a abrir
function deskPeek() {
  if (!win) return;
  DESK.peek = true;
  win.minimize();
  for (const w of S2.wins.values()) { try { w.minimize(); } catch {} }
  winHelper.send('keys', 'win+d');
  // la barra de Windows a la vista mientras tanto (aunque esté escondida o en "ocultar automáticamente"),
  // y Base suelta el lugar de su barra para que el escritorio de Windows quede entero
  winHelper.send('tbpeek', 'x');
  if (WA.on && WA.mode === 'appbar') { clearTimeout(WA.checkT); WA.rect = null; winHelper.send('appbar', 'off'); }
  pillShow();
}
function deskUnpeek() {
  if (!DESK.peek) return;
  DESK.peek = false;
  // vuelve todo como estaba: la barra de Windows (escondida o como la tenga el usuario) y el lugar de la barra de Base
  winHelper.send('taskbar', DESK.tb ? '1' : '0').then(() => { WA.rect = null; WA.last = 0; waApply(); });
  pillHide();
  for (const w of S2.wins.values()) { try { if (w.isMinimized()) w.restore(); w.showInactive(); s2Bottom(w); } catch {} }
}
// Base <-> escritorio de Windows (el mismo botón va y vuelve)
function deskSwap() { if (DESK.peek) { showWindow(); deskUnpeek(); } else deskPeek(); }
ipcMain.on('desk:peek', deskPeek);
ipcMain.on('desk:swap', deskSwap);
// cartelito flotante "Volver a Base" mientras se ve el escritorio de Windows
let pill = null;
function pillShow() {
  try {
    if (pill && !pill.isDestroyed()) { pill.showInactive(); return; }
    const d = targetDisplay().workArea, W = 210, Hh = 46;
    pill = new BrowserWindow({ x: Math.round(d.x + d.width / 2 - W / 2), y: d.y + d.height - Hh - 14, width: W, height: Hh, frame: false, transparent: true, resizable: false, movable: true, minimizable: false, maximizable: false, skipTaskbar: true, alwaysOnTop: true, focusable: true, show: false, hasShadow: false, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } });
    pill.setAlwaysOnTop(true, 'floating');
    const html = `<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:transparent;overflow:hidden;font:600 14px 'Segoe UI',system-ui,sans-serif;-webkit-user-select:none}button{width:${W - 8}px;height:${Hh - 8}px;margin:4px;border:0;border-radius:999px;background:rgba(20,26,33,.92);color:#fff;font:inherit;cursor:pointer;box-shadow:0 6px 18px rgba(0,0,0,.45),inset 0 0 0 1px rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;gap:8px}button:hover{background:rgba(40,52,66,.96)}b{font-size:16px}</style><button onclick="document.title='volver'"><b>⇄</b> Volver a Base</button>`;
    pill.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    pill.on('page-title-updated', (e, t) => { e.preventDefault(); if (t === 'volver') { showWindow(); deskUnpeek(); } });
    pill.once('ready-to-show', () => { try { pill.showInactive(); } catch {} });
    pill.on('closed', () => { pill = null; });
  } catch (e) { log('Cartel para volver: ' + (e && e.message)); }
}
function pillHide() { try { if (pill && !pill.isDestroyed()) pill.close(); } catch {} pill = null; }
// ---------- Escritorios virtuales de Windows ----------
ipcMain.handle('vdesk:list', async () => { const r = await winHelper.send('vdesk', 'x'); return r.ok && r.data ? r.data : null; });
ipcMain.handle('vdesk:do', async (_e, what, n) => {
  const K = { prev: 'ctrl+win+left', next: 'ctrl+win+right', add: 'ctrl+win+d', close: 'ctrl+win+f4', view: 'win+tab' };
  if (what === 'go') {
    const r = await winHelper.send('vdesk', 'x'); const cur = r.ok && r.data ? Number(r.data.cur) || 0 : 0;
    const d = Math.max(-20, Math.min(20, (Number(n) || 0) - cur));
    for (let i = 0; i < Math.abs(d); i++) { await winHelper.send('keys', d > 0 ? K.next : K.prev); await new Promise(res => setTimeout(res, 160)); }
    return { ok: true };
  }
  if (!K[what]) return { ok: false };
  return winHelper.send('keys', K[what]);
});
// ---------- Otros monitores: Base también se ve ahí (fondo, reloj, clima, accesos) ----------
const S2 = { wins: new Map(), snap: null };
function s2Bottom(w) { try { const b = w.getNativeWindowHandle(); const hh = b.length >= 8 ? b.readBigUInt64LE(0).toString() : String(b.readUInt32LE(0)); winHelper.send('bottom', hh); } catch {} }
function screen2Sync() {
  if (!app.isReady() || quitting) return;
  const s = settings(), on = !!win && (s.screen2 === true || (s.screen2 == null && !!s.deskMode)); // si no se eligió, sólo cuando Base hace de escritorio
  const main = targetDisplay(), want = on ? screen.getAllDisplays().filter(d => d.id !== main.id) : [];
  for (const [id, w] of S2.wins) if (!want.some(d => d.id === id)) { try { w.destroy(); } catch {} S2.wins.delete(id); }
  for (const d of want) {
    let w = S2.wins.get(d.id);
    if (w && !w.isDestroyed()) { const b = w.getBounds(), a = d.workArea; if (b.x !== a.x || b.y !== a.y || b.width !== a.width || b.height !== a.height) w.setBounds(a); continue; }
    const a = d.workArea;
    w = new BrowserWindow({ x: a.x, y: a.y, width: a.width, height: a.height, frame: false, show: false, skipTaskbar: true, resizable: false, minimizable: true, maximizable: false, backgroundColor: '#141a21', title: 'Base (otro monitor)',
      webPreferences: { preload: path.join(__dirname, 'preload2.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
    S2.wins.set(d.id, w);
    w.loadFile(path.join(__dirname, 'src', 'pantalla2.html'));
    w.webContents.on('did-finish-load', () => { if (S2.snap) w.webContents.send('s2:snap', S2.snap); });
    w.webContents.on('render-process-gone', (_e, det) => { log('Otro monitor: ' + JSON.stringify(det)); setTimeout(() => { try { if (!w.isDestroyed()) w.reload(); } catch {} }, 2000); });
    w.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
    w.webContents.on('will-navigate', (e) => e.preventDefault());
    w.once('ready-to-show', () => { if (!DESK.peek) { w.showInactive(); s2Bottom(w); } });
    // hace de escritorio: siempre detrás de los programas (y no se va con Win+D)
    w.on('focus', () => setTimeout(() => s2Bottom(w), 50));
    w.on('minimize', () => { if (DESK.peek || quitting) return; setTimeout(() => { try { w.restore(); s2Bottom(w); } catch {} }, 0); });
    w.on('closed', () => S2.wins.delete(d.id));
  }
}
ipcMain.on('s2:snap', (_e, snap) => { S2.snap = snap; for (const w of S2.wins.values()) { try { if (!w.isDestroyed()) w.webContents.send('s2:snap', snap); } catch {} } });
ipcMain.handle('s2:open', (_e, item) => openItem(item));
ipcMain.on('s2:base', () => { showWindow(); deskUnpeek(); });
ipcMain.on('s2:swap', () => deskSwap());
app.whenReady().then(() => setTimeout(screen2Sync, 4000));
app.on('before-quit', () => { for (const w of S2.wins.values()) { try { w.destroy(); } catch {} } pillHide(); });
function deskHookWindow() {
  const unpeek = () => { if (DESK.peek) setTimeout(() => { if (win && win.isFocused() && !win.isMinimized()) deskUnpeek(); }, 300); };
  win.on('focus', unpeek); win.on('restore', deskUnpeek);
  // en modo escritorio Base no se minimiza: se va al fondo, detrás de los programas
  win.on('minimize', () => {
    if (!DESK.on || quitting || DESK.peek) return;
    setTimeout(() => { try { win.restore(); winHelper.send('bottom', selfHandle()); } catch {} }, 0);
  });
  // al pasar a otro programa, Base se va al fondo (salvo que sea un programa metido dentro de Base o un aviso nuestro)
  win.on('blur', () => {
    if (!DESK.on) return;
    setTimeout(async () => {
      if (win.isFocused()) return;
      const r = await winHelper.send('fgclass', 'x');
      const h = r.ok && r.data ? String(r.data.h || '') : '';
      if (!h || h === '0' || (DOCK.h && h === String(DOCK.h))) return;
      const ours = BrowserWindow.getAllWindows().some(w => { try { const b = w.getNativeWindowHandle(); return (b.length >= 8 ? b.readBigUInt64LE(0).toString() : String(b.readUInt32LE(0))) === h; } catch { return false; } });
      if (!ours) winHelper.send('bottom', selfHandle());
    }, 150);
  });
  // si la pantalla se cuelga, la recargamos sola
  win.on('unresponsive', () => {
    log('Base dejó de responder');
    clearTimeout(DESK.hang);
    DESK.hang = setTimeout(() => {
      log('Sigue colgada: la recargo');
      try { win.webContents.forcefullyCrashRenderer(); } catch {}
      setTimeout(() => { try { win.reload(); } catch {} }, 800);
    }, 12000);
  });
  win.on('responsive', () => { clearTimeout(DESK.hang); });
}
function selfHandle() {
  try {
    const b = win.getNativeWindowHandle();
    return b.length >= 8 ? b.readBigUInt64LE(0).toString() : String(b.readUInt32LE(0));
  } catch { return '0'; }
}
const validHwnd = (h) => /^\d{1,20}$/.test(String(h));
ipcMain.handle('win:list', async () => {
  const r = await winHelper.send('list', selfHandle());
  if (!r.ok) return { ok: false, error: r.error || winHelper.failed || 'No disponible' };
  let fl = new Set(); try { const f = await winHelper.send('flashes', 'x'); if (f.ok && Array.isArray(f.data)) fl = new Set(f.data.map(String)); } catch {}
  const items = [];
  for (const w of r.data || []) {
    const exe = w.exe || '';
    items.push({
      h: w.h, title: w.t, min: !!w.min, max: !!w.max, fg: !!w.fg, fl: fl.has(String(w.h)) && !w.fg,
      app: exe ? path.basename(exe).replace(/\.exe$/i, '') : '',
      exe, icon: exe ? await iconOf(exe, 'normal') : null
    });
  }
  return { ok: true, data: items };
});
ipcMain.handle('win:do', async (_e, action, h) => {
  const allowed = { focus: 1, minimize: 1, close: 1, max: 1 };
  if (!allowed[action] || !validHwnd(h)) return { ok: false };
  const r = await winHelper.send(action, String(h));
  // Base ocupa toda la pantalla: si la ventana que pediste no quedó adelante, Base se corre al fondo para que se vea
  if ((action === 'focus' || action === 'max') && win && !win.isDestroyed()) winHelper.send('bottom', selfHandle());
  return r;
});
async function sysAction(name) {
  switch (name) {
    case 'start': return winHelper.send('keys', 'win');
    case 'taskview': return winHelper.send('keys', 'win+tab');
    case 'quick': return winHelper.send('keys', 'win+a');
    case 'notifications': return winHelper.send('keys', 'win+n');
    case 'minimizeAll': return winHelper.send('minimizeAll', selfHandle());
    case 'explorer': spawn('explorer.exe', [], { detached: true, stdio: 'ignore' }).unref(); return { ok: true };
    case 'taskmgr': spawn('taskmgr.exe', [], { detached: true, stdio: 'ignore', shell: true }).unref(); return { ok: true };
    case 'settings': await shell.openExternal('ms-settings:'); return { ok: true };
    case 'mouse': await shell.openExternal('ms-settings:easeofaccess-mousepointer'); return { ok: true };
    case 'lock': spawn('rundll32.exe', ['user32.dll,LockWorkStation'], { detached: true, stdio: 'ignore' }).unref(); return { ok: true };
    case 'sleep': spawn('rundll32.exe', ['powrprof.dll,SetSuspendState', '0,1,0'], { detached: true, stdio: 'ignore' }).unref(); return { ok: true };
    case 'shutdown': spawn('shutdown.exe', ['/s', '/t', '0'], { detached: true, stdio: 'ignore' }).unref(); return { ok: true };
    case 'restart': spawn('shutdown.exe', ['/r', '/t', '0'], { detached: true, stdio: 'ignore' }).unref(); return { ok: true };
    case 'signout': spawn('shutdown.exe', ['/l'], { detached: true, stdio: 'ignore' }).unref(); return { ok: true };
    case 'sound': await shell.openExternal('ms-settings:sound'); return { ok: true };
    default: return { ok: false };
  }
}
ipcMain.handle('sys:action', (_e, name) => sysAction(name));
ipcMain.handle('media:state', async () => {
  const r = await winHelper.send('spotify');
  return r.ok ? { ok: true, data: r.data } : { ok: false };
});
// control multimedia de Windows: todas las sesiones (Spotify, navegador, etc.)
const appIdOk = (a) => typeof a === 'string' && a.length < 300 && !/[|\r\n]/.test(a);
ipcMain.handle('media:sessions', async () => {
  const r = await winHelper.send('smtc');
  return r.ok && Array.isArray(r.data) ? { ok: true, data: r.data } : { ok: false };
});
ipcMain.handle('media:thumb', async (_e, app) => {
  if (!appIdOk(app)) return null;
  const r = await winHelper.send('smtcthumb', app);
  if (!r.ok || !r.data || !r.data.data) return null;
  const type = /^image\/[\w.+-]+$/.test(r.data.type) ? r.data.type : 'image/png';
  return `data:${type};base64,${r.data.data}`;
});
ipcMain.handle('media:do', async (_e, app, act, val) => {
  if (!appIdOk(app) || !['toggle', 'next', 'prev', 'seek'].includes(act)) return { ok: false };
  const v = act === 'seek' ? Math.max(0, Math.min(86400, Number(val) || 0)).toFixed(1) : '';
  const r = await winHelper.send('smtcdo', `${app}|${act}|${v}`);
  return { ok: !!(r.ok && r.data) };
});
// volumen general de Windows (nivel exacto y silencio)
ipcMain.handle('vol:get', async () => { const r = await winHelper.send('vol'); return r.ok && r.data ? r.data : null; });
ipcMain.handle('vol:set', async (_e, v) => { const r = await winHelper.send('volset', String(Math.max(0, Math.min(100, Math.round(Number(v) || 0))))); return r.ok && r.data ? r.data : null; });
ipcMain.handle('vol:mute', async (_e, on) => { const r = await winHelper.send('volmute', on ? '1' : '0'); return r.ok && r.data ? r.data : null; });
ipcMain.handle('media:key', async (_e, key) => {
  if (!['play', 'next', 'prev', 'volup', 'voldown', 'mute'].includes(key)) return { ok: false };
  return winHelper.send('media', key);
});
app.on('will-quit', () => winHelper.stop());

// ----- Programa acoplado: un .exe tuyo (por ejemplo Recepciones) que se ve en grande adentro de un tablero -----
const DOCK = { exe: '', h: '', style: '', rect: null, want: false, busy: null, launchedAt: 0, off: false };
const exeBase = (p) => path.basename(String(p || '')).toLowerCase();
function dockSearchDirs() {
  const home = app.getPath('home');
  const dirs = [app.getPath('desktop'), app.getPath('documents'), app.getPath('downloads'), path.join(home, 'OneDrive', 'Escritorio'), path.join(home, 'OneDrive', 'Desktop'), path.join(home, 'OneDrive', 'Documentos'),
    LAD && path.join(LAD, 'Programs'), PF, PF86, home];
  return [...new Set(dirs.filter(Boolean))];
}
function findExe(name) {
  const want = String(name || '').toLowerCase().replace(/\.exe$/, '') + '.exe';
  const skip = /^(node_modules|\.git|appdata|windows|\$recycle\.bin|program files \(x86\)\\common files)$/i;
  let found = '', seen = 0;
  const walk = (d, depth) => {
    if (found || seen > 6000) return;
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      seen++;
      if (e.isFile() && e.name.toLowerCase() === want) { found = path.join(d, e.name); return; }
    }
    if (depth <= 0) return;
    for (const e of ents) if (e.isDirectory() && !skip.test(e.name) && !e.name.startsWith('.')) { walk(path.join(d, e.name), depth - 1); if (found) return; }
  };
  for (const d of dockSearchDirs()) { walk(d, d === app.getPath('home') ? 1 : 3); if (found) break; }
  return found;
}
ipcMain.handle('dock:find', async (_e, name) => { try { return findExe(name); } catch { return ''; } });
ipcMain.handle('dock:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Elegí el programa', properties: ['openFile'], filters: [{ name: 'Programas', extensions: ['exe', 'lnk'] }] });
  if (r.canceled || !r.filePaths[0]) return '';
  let f = r.filePaths[0];
  if (/\.lnk$/i.test(f)) { try { f = shell.readShortcutLink(f).target || f; } catch {} }
  return /\.exe$/i.test(f) ? f : '';
});
async function dockList() { const r = await winHelper.send('list', selfHandle()); return (r.ok && Array.isArray(r.data)) ? r.data : []; }
// cómo reconocemos la ventana del programa: muchos .exe hechos a partir de una página abren la ventana con otro proceso
// (Edge, Chrome, WebView), así que probamos por nombre del .exe, por título y por "la ventana nueva que apareció"
const BROWSER_EXE = /^(opera|launcher|chrome|msedge|firefox|brave|vivaldi|iexplore|explorer)\.exe$/i;
async function dockFindWindow() {
  const list = await dockList();
  const want = exeBase(DOCK.exe), name = want.replace(/\.exe$/, '');
  const m = DOCK.match;
  const tl = (x) => String(x.t || '').toLowerCase();
  // los navegadores solo valen si elegiste esa ventana a mano (si no, se puede colar una pestaña de Opera)
  const cands = list.filter(x => !BROWSER_EXE.test(exeBase(x.exe)) || exeBase(x.exe) === want);
  let w = null, manual = false;
  if (DOCK.pickH) { w = list.find(x => String(x.h) === DOCK.pickH); manual = !!w; }
  if (!w && m && m.exe) {
    const pool = m.manual ? list : cands;
    w = pool.find(x => exeBase(x.exe) === m.exe && (!m.title || (m.manual && BROWSER_EXE.test(m.exe) ? tl(x) === m.title || tl(x).startsWith(m.title) : tl(x).includes(m.title))));
    manual = !!(w && m.manual);
  }
  if (!w) w = cands.find(x => exeBase(x.exe) === want);
  if (!w && name.length > 3) w = cands.find(x => tl(x).includes(name));
  if (!w && DOCK.known && Date.now() - DOCK.launchedAt < 40000) w = cands.find(x => !DOCK.known.has(String(x.h)));
  if (!w) return '';
  if (!manual) DOCK.match = { exe: exeBase(w.exe), title: name.length > 3 && tl(w).includes(name) ? name : '' };
  return String(w.h);
}
function dockScreenRect() {
  if (!win || !DOCK.rect) return null;
  const cb = win.getContentBounds();
  const r = { x: Math.round(cb.x + DOCK.rect.x), y: Math.round(cb.y + DOCK.rect.y), width: Math.round(DOCK.rect.w), height: Math.round(DOCK.rect.h) };
  try { return process.platform === 'win32' ? screen.dipToScreenRect(win, r) : r; } catch { return r; }
}
async function dockEnsure() {
  if (DOCK.busy) return DOCK.busy;
  DOCK.busy = (async () => {
    if (DOCK.h) {
      const a = await winHelper.send('dockalive', DOCK.h);
      if (a.ok && a.data === true) return true;
      DOCK.h = ''; DOCK.style = '';
    }
    if (!DOCK.exe || !exists(DOCK.exe)) return false;
    let h = await dockFindWindow();
    if (!h && Date.now() - DOCK.launchedAt > 30000) {
      DOCK.launchedAt = Date.now();
      DOCK.known = new Set((await dockList()).map(x => String(x.h)));
      try { spawn(DOCK.exe, [], { detached: true, stdio: 'ignore', cwd: path.dirname(DOCK.exe) }).unref(); } catch (e) { log('Programa acoplado: ' + e.message); return false; }
    }
    for (let i = 0; !h && i < 50; i++) { await new Promise(r => setTimeout(r, 500)); if (!DOCK.want) return false; h = await dockFindWindow(); }
    if (!h) { log('Programa acoplado: no encontré la ventana de ' + exeBase(DOCK.exe) + '. Ventanas: ' + (await dockList()).map(x => `${exeBase(x.exe)} "${x.t}"`).join(', ').slice(0, 900)); return false; }
    DOCK.pickH = '';
    await new Promise(r => setTimeout(r, 600)); // que termine de dibujarse
    const sr = dockScreenRect();
    if (!sr) return false;
    const a = await winHelper.send('dockon', `${h}|${selfHandle()}|${sr.x}|${sr.y}|${sr.width}|${sr.height}`);
    if (!a.ok || !a.data || !a.data.style) { log('Programa acoplado: no se pudo acomodar la ventana (' + JSON.stringify(a).slice(0, 200) + ')'); return false; }
    DOCK.h = h; DOCK.style = a.data.style;
    return true;
  })().finally(() => { DOCK.busy = null; });
  return DOCK.busy;
}
async function dockPlace() {
  if (!DOCK.want || !DOCK.h || !win || !win.isVisible() || win.isMinimized()) return;
  const sr = dockScreenRect();
  if (sr) await winHelper.send('dockmove', `${DOCK.h}|${sr.x}|${sr.y}|${sr.width}|${sr.height}`);
}
async function dockHide() { if (DOCK.h) await winHelper.send('dockhide', DOCK.h); }
async function dockRelease() {
  if (!DOCK.h) return;
  const h = DOCK.h; DOCK.h = '';
  await winHelper.send('dockoff', `${h}|${DOCK.style}`);
  DOCK.style = '';
}
ipcMain.handle('dock:bounds', async (_e, b) => {
  if (process.platform !== 'win32') return { ok: false, error: 'Solo en Windows' };
  b = b || {};
  const exe = String(b.exe || '');
  if (b.show && exe !== DOCK.exe) { await dockRelease(); DOCK.exe = /\.exe$/i.test(exe) ? exe : ''; DOCK.launchedAt = 0; DOCK.match = null; }
  if (!b.show || !DOCK.exe) { DOCK.want = false; await dockHide(); return { ok: true, h: DOCK.h, exists: !!DOCK.exe && exists(DOCK.exe) }; }
  DOCK.want = true;
  if (b.match && typeof b.match === 'object' && !DOCK.match && (b.match.manual || !BROWSER_EXE.test(exeBase(b.match.exe)))) DOCK.match = { exe: exeBase(b.match.exe), title: String(b.match.title || '').toLowerCase().slice(0, 80), manual: !!b.match.manual };
  DOCK.rect = { x: Number(b.x) || 0, y: Number(b.y) || 0, w: Math.max(50, Number(b.w) || 0), h: Math.max(50, Number(b.h) || 0) };
  if (!exists(DOCK.exe)) return { ok: false, error: 'No encuentro el programa', exists: false };
  const had = DOCK.h;
  const ok = await dockEnsure();
  if (ok && had) await dockPlace();
  return { ok, h: DOCK.h, exists: true, match: DOCK.match || null };
});
// elegir a mano la ventana del programa (si no la reconocemos sola)
ipcMain.handle('dock:windows', async () => (await dockList()).map(x => ({ h: String(x.h), t: String(x.t || ''), exe: exeBase(x.exe) })));
ipcMain.handle('dock:adopt', async (_e, h) => {
  h = String(h || '');
  const w = (await dockList()).find(x => String(x.h) === h);
  if (!w) return null;
  await dockRelease();
  DOCK.pickH = h;
  DOCK.match = { exe: exeBase(w.exe), title: '', manual: true };
  // si el título es estable (no cambia con lo que muestra), lo usamos para reconocerla la próxima vez
  const t = String(w.t || '').toLowerCase().trim();
  if (t && t.length <= 60) DOCK.match.title = t.split(/ [-–|·] /)[0].slice(0, 60);
  return DOCK.match;
});
ipcMain.handle('dock:release', async () => { DOCK.want = false; await dockRelease(); DOCK.launchedAt = Date.now(); return true; });
ipcMain.handle('dock:state', async () => ({ h: DOCK.h, exe: DOCK.exe }));
function dockHookWindow() {
  if (!win) return;
  const re = () => { if (DOCK.want && DOCK.h) dockPlace(); };
  win.on('move', re); win.on('resize', re); win.on('restore', re); win.on('show', re);
  win.on('hide', () => { dockHide(); });
}
app.on('before-quit', (e) => {
  if (DOCK.h && !DOCK.off) {
    e.preventDefault(); DOCK.off = true;
    dockRelease().catch(() => {}).finally(() => { quitting = true; app.quit(); });
  }
});

// ----- Avisos flotantes propios (abajo a la derecha, arriba de todo) -----
let notifWin = null, notifReady = null;
function ensureNotifWin() {
  if (notifWin && !notifWin.isDestroyed()) return notifReady;
  const wa = targetDisplay().workArea;
  notifWin = new BrowserWindow({
    width: 400, height: 120, x: wa.x + wa.width - 410, y: wa.y + wa.height - 130,
    frame: false, transparent: true, resizable: false, movable: false, minimizable: false, maximizable: false,
    skipTaskbar: true, alwaysOnTop: true, focusable: false, show: false, hasShadow: false,
    webPreferences: { preload: path.join(__dirname, 'notif-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  notifWin.setAlwaysOnTop(true, 'screen-saver');
  notifWin.setVisibleOnAllWorkspaces && notifWin.setVisibleOnAllWorkspaces(true);
  notifWin.on('closed', () => { notifWin = null; notifReady = null; });
  notifReady = new Promise((res) => notifWin.webContents.once('did-finish-load', res));
  notifWin.loadFile(path.join(__dirname, 'src', 'notif.html'));
  return notifReady;
}
let notifPos = 'br', notifMdesk = false;
ipcMain.on('fnotif:show', async (_e, n) => {
  try {
    const np = ['br', 'tr', 'bl', 'tl'].includes(n.pos) ? n.pos : 'br';
    if (np !== notifPos && notifWin && !notifWin.isDestroyed()) notifWin.hide();
    notifPos = np; notifMdesk = !!n.mdesk;
    await ensureNotifWin();
    notifWin.webContents.send('fnotif:add', {
      id: String(n.id || ''), kind: String(n.kind || 'gen'), title: String(n.title || '').slice(0, 200), body: String(n.body || '').slice(0, 400),
      label: String(n.label || '').slice(0, 40), color: /^#[0-9a-f]{3,8}$/i.test(n.color || '') ? n.color : '', scheme: n.scheme === 'dark' ? 'dark' : 'light', life: Number(n.life) || 8,
      look: String(n.look || 'tarjeta').slice(0, 20), pos: notifPos, sound: String(n.sound || 'none').slice(0, 20)
    });
  } catch (e) { log('Aviso flotante: ' + e.message); }
});
ipcMain.on('fnotif:size', (_e, h) => {
  if (!notifWin || notifWin.isDestroyed()) return;
  h = Math.max(0, Math.min(700, Math.round(Number(h) || 0)));
  if (!h) { notifWin.hide(); return; }
  const wa = targetDisplay().workArea;
  // con Base a la vista, los avisos van más arriba para no tapar las tarjetas de abajo
  const baseUp = win && win.isVisible() && !win.isMinimized();
  // con el escritorio minimalista la barra de Base está abajo (y arriba no hay nada que esquivar)
  const lift = baseUp ? (notifMdesk ? 66 : 150) : 8;
  const x = notifPos[1] === 'l' ? wa.x + 10 : wa.x + wa.width - 410;
  // arriba: debajo de la barra de Base para no tapar los botones
  const y = notifPos[0] === 't' ? wa.y + (baseUp && !notifMdesk ? 56 : 8) : wa.y + wa.height - h - lift;
  notifWin.setBounds({ x, y, width: 400, height: h });
  if (!notifWin.isVisible()) notifWin.showInactive();
});
ipcMain.on('fnotif:click', (_e, id) => {
  showWindow();
  if (win) win.webContents.send('fnotif:open', String(id || ''));
});

ipcMain.on('notify', (_e, { title, body }) => {
  if (!Notification.isSupported()) return;
  const n = new Notification({
    title, body,
    icon: path.join(__dirname, 'build', process.platform === 'win32' ? 'icon.ico' : 'icon.png')
  });
  n.on('click', showWindow);
  n.show();
});

// ---------- Accesos de Windows ----------
// El acceso del menú Inicio lleva el mismo AppUserModelId que la app:
// Windows lo necesita para mostrar las notificaciones de la agenda.
function ensureWindowsShortcuts() {
  if (process.platform !== 'win32' || !app.isPackaged) return;
  const opts = {
    target: process.execPath,
    appUserModelId: APP_ID,
    icon: path.join(__dirname, 'build', 'icon.ico'),
    iconIndex: 0,
    description: 'Tu escritorio personal'
  };
  try {
    const startMenu = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Base.lnk');
    shell.writeShortcutLink(startMenu, fs.existsSync(startMenu) ? 'replace' : 'create', opts);
    if (process.argv.includes('--crear-accesos')) {
      const desktop = path.join(app.getPath('desktop'), 'Base.lnk');
      shell.writeShortcutLink(desktop, fs.existsSync(desktop) ? 'replace' : 'create', opts);
    }
  } catch (e) {
    console.error('No se pudieron crear los accesos', e);
  }
}

// ---------- Ciclo de vida ----------
app.on('second-instance', showWindow);

app.whenReady().then(() => {
  try {
    fs.mkdirSync(userDir(), { recursive: true });
    // guardamos el registro de la vez anterior (si se cerró de golpe, ahí queda el porqué)
    if (fs.existsSync(logFile())) fs.copyFileSync(logFile(), path.join(userDir(), 'registro-anterior.txt'));
    fs.writeFileSync(logFile(), '', 'utf8');
  } catch {}
  log(`Arrancando Base ${app.getVersion()} · Electron ${process.versions.electron} · Chrome ${process.versions.chrome} · ${process.platform} ${require('os').release()}`);
  ensureWindowsShortcuts();
  createWindow();
  setTimeout(() => winHelper.start(), settings().deskMode ? 200 : 1500);
  buildTray();
  const s = settings();
  registerHotkey(s.hotkey === undefined ? DEFAULT_HOTKEY : s.hotkey);
  registerSearchHotkey(s.searchHotkey === undefined ? DEFAULT_SEARCH_HOTKEY : s.searchHotkey);
});

app.on('before-quit', () => { quitting = true; flushData(); });
app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => { /* seguimos vivos en la bandeja */ });

// ---------- Actualizaciones automáticas (desde GitHub) ----------
// Cada versión nueva se publica en github.com/Redux-7/base-escritorio: version.json dice cuál es y dónde está el zip.
// Se reemplaza solo el programa: tus datos, tus cuentas de Google y la edición (completa o para compartir) quedan igual.
const UPD_REPO = 'Redux-7/base-escritorio';
const UPD = { latest: null, state: 'idle', error: '', checkedAt: 0, timer: null };
function verNum(v) { return String(v || '').replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0); }
function verNewer(a, b) { const x = verNum(a), y = verNum(b); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; }
async function updCheck(manual) {
  UPD.checkedAt = Date.now();
  try {
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 15000);
    const r = await net.fetch(`https://raw.githubusercontent.com/${UPD_REPO}/main/version.json?t=${Date.now()}`, { signal: ctrl.signal, headers: { 'User-Agent': 'Base/' + app.getVersion(), 'Cache-Control': 'no-cache' } });
    clearTimeout(t);
    if (r.status === 404) { UPD.latest = null; return { ok: true, none: true, current: app.getVersion() }; }
    if (!r.ok) throw new Error('GitHub respondió ' + r.status);
    const j = await r.json();
    const version = String(j.version || '').replace(/^v/i, '');
    if (!version || !j.file || !/^[\w./-]+\.zip$/.test(j.file)) return { ok: true, none: true, current: app.getVersion() };
    UPD.latest = { version, notes: String(j.notes || '').slice(0, 2000), url: `https://raw.githubusercontent.com/${UPD_REPO}/main/${j.file}`, size: Number(j.size) || 0, sha256: String(j.sha256 || '').toLowerCase() };
    const newer = verNewer(version, app.getVersion());
    if (newer && win && !win.isDestroyed()) win.webContents.send('update:available', { version, notes: UPD.latest.notes, current: app.getVersion() });
    return { ok: true, newer, version, current: app.getVersion() };
  } catch (e) {
    if (manual) log('Buscar actualización: ' + e.message);
    return { ok: false, error: e.name === 'AbortError' ? 'GitHub no respondió' : e.message, current: app.getVersion() };
  }
}
function updSchedule() {
  clearInterval(UPD.timer);
  setTimeout(() => { if (settings().autoUpdate !== 'off') updCheck(false); }, 45000);
  UPD.timer = setInterval(() => { if (settings().autoUpdate !== 'off') updCheck(false); }, 6 * 3600 * 1000);
}
function updProgress(p) { try { if (win && !win.isDestroyed()) win.webContents.send('update:progress', p); } catch {} }
function psRun(script, args) {
  return new Promise((resolve) => {
    let p; try { p = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script, ...(args || [])], { windowsHide: true }); } catch (e) { return resolve({ code: -1, err: e.message }); }
    let err = ''; p.stderr.on('data', d => { err += d; });
    p.on('error', e => resolve({ code: -1, err: e.message }));
    p.on('exit', code => resolve({ code, err }));
  });
}
async function updInstall() {
  if (!UPD.latest) { const c = await updCheck(true); if (!c.ok || !c.newer) return { ok: false, error: c.error || 'No hay una versión nueva' }; }
  if (!app.isPackaged || process.platform !== 'win32') return { ok: false, error: 'Solo funciona en Base instalado en Windows' };
  if (UPD.state === 'busy') return { ok: false, error: 'Ya se está actualizando' };
  UPD.state = 'busy';
  const L = UPD.latest;
  const work = path.join(app.getPath('temp'), 'base-actualizacion');
  const zip = path.join(work, 'base-app.zip');
  const nuevo = path.join(work, 'nuevo');
  try {
    fs.rmSync(work, { recursive: true, force: true });
    fs.mkdirSync(work, { recursive: true });
    updProgress({ step: 'descargando', pct: 0 });
    const r = await net.fetch(L.url, { headers: { 'User-Agent': 'Base/' + app.getVersion() } });
    if (!r.ok || !r.body) throw new Error('No se pudo descargar (' + r.status + ')');
    const total = Number(r.headers.get('content-length')) || L.size || 0;
    const out = fs.createWriteStream(zip);
    const reader = r.body.getReader();
    let got = 0, lastPct = -1;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      got += value.length;
      if (!out.write(Buffer.from(value))) await new Promise(res => out.once('drain', res));
      const pct = total ? Math.floor(got * 100 / total) : 0;
      if (pct !== lastPct) { lastPct = pct; updProgress({ step: 'descargando', pct }); }
    }
    await new Promise((res, rej) => out.end(err => err ? rej(err) : res()));
    if (L.sha256) {
      const got256 = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
      if (got256 !== L.sha256) throw new Error('La descarga llegó dañada, probá de nuevo');
    }
    updProgress({ step: 'preparando', pct: 100 });
    const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
    const ex = await psRun(`$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Expand-Archive -LiteralPath ${q(zip)} -DestinationPath ${q(nuevo)} -Force`);
    if (ex.code !== 0) throw new Error('No se pudo descomprimir');
    // el zip puede traer los archivos sueltos o adentro de una carpeta
    let root = nuevo;
    if (!fs.existsSync(path.join(root, 'main.js'))) {
      const sub = fs.readdirSync(nuevo).map(n => path.join(nuevo, n)).find(d => fs.existsSync(path.join(d, 'main.js')));
      if (!sub) throw new Error('El archivo descargado no es de Base');
      root = sub;
    }
    const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
    if (pkg.name !== require('./package.json').name) throw new Error('El archivo descargado no es de Base');
    // el reemplazo lo hace un ayudante aparte, cuando Base ya se cerró
    const appDir = __dirname;
    const script = path.join(work, 'actualizar.ps1');
    const ps = [
      '$ErrorActionPreference = "Continue"',
      `Add-Content -Encoding UTF8 '${path.join(userDir(), 'registro.txt').replace(/'/g, "''")}' "[actualizador] arrancó"`,
      // si por las dudas arrancaron dos ayudantes, sigue uno solo
      `try { New-Item -ItemType File -Path '${path.join(work, 'lock.txt').replace(/'/g, "''")}' -ErrorAction Stop | Out-Null } catch { exit }`,
      `Set-Content -LiteralPath '${path.join(work, 'arranco.txt').replace(/'/g, "''")}' 'ok'`,
      `$pidBase = ${process.pid}`,
      `$nuevo = '${root.replace(/'/g, "''")}'`,
      `$app = '${appDir.replace(/'/g, "''")}'`,
      `$exe = '${process.execPath.replace(/'/g, "''")}'`,
      `$reg = '${path.join(userDir(), 'registro.txt').replace(/'/g, "''")}'`,
      'for ($i = 0; $i -lt 60; $i++) { if (-not (Get-Process -Id $pidBase -ErrorAction SilentlyContinue)) { break }; Start-Sleep -Milliseconds 500 }',
      'Get-Process -Id $pidBase -ErrorAction SilentlyContinue | Stop-Process -Force',
      'Start-Sleep -Milliseconds 700',
      // lo que es de cada instalación queda: la edición y la tipografía
      'Copy-Item (Join-Path $app "edicion.json") (Join-Path $nuevo "edicion.json") -Force -ErrorAction SilentlyContinue',
      '$f = Join-Path $app "src\\fonts\\BricolageGrotesque.ttf"; if (Test-Path $f) { Copy-Item $f (Join-Path $nuevo "src\\fonts\\BricolageGrotesque.ttf") -Force }',
      '$viejo = $app + ".anterior"',
      'Remove-Item $viejo -Recurse -Force -ErrorAction SilentlyContinue',
      '$ok = $false; for ($i = 0; $i -lt 20 -and -not $ok; $i++) { try { Move-Item -LiteralPath $app -Destination $viejo -ErrorAction Stop; $ok = $true } catch { Get-Process -Name "Base" -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe } | Stop-Process -Force; Start-Sleep -Milliseconds 500 } }',
      'try { if (-not $ok) { throw "la carpeta está en uso" }; Copy-Item $nuevo $app -Recurse -Force -ErrorAction Stop; Get-ChildItem $app -Recurse -File | Unblock-File -ErrorAction SilentlyContinue; Add-Content -Encoding UTF8 $reg "Actualización instalada" }',
      'catch { Add-Content -Encoding UTF8 $reg ("ERROR actualizando: " + $_.Exception.Message); if (Test-Path $viejo) { Remove-Item $app -Recurse -Force -ErrorAction SilentlyContinue; Move-Item -LiteralPath $viejo -Destination $app } }',
      `try { $pk = Get-Content (Join-Path $app "package.json") -Raw | ConvertFrom-Json; Set-ItemProperty "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Base" DisplayVersion $pk.version -ErrorAction SilentlyContinue } catch {}`,
      'Start-Process -FilePath $exe -ArgumentList "--actualizado"'
    ].join('\r\n');
    fs.writeFileSync(script, '﻿' + ps, 'utf8');
    updProgress({ step: 'reiniciando', pct: 100 });
    log('Actualizando a ' + L.version);
    // El actualizador se lanza "suelto" (por WMI): así no muere cuando Base se cierra.
    const cmdLine = `powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "${script}"`;
    const launch = `$ErrorActionPreference='Stop'; try { $si = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ ShowWindow = [uint16]0 }; $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = ${q(cmdLine)}; ProcessStartupInformation = $si }; if ($r.ReturnValue -ne 0) { throw 'wmi ' + $r.ReturnValue } } catch { Start-Process -FilePath powershell.exe -WindowStyle Hidden -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',${q('"' + script + '"')}) }`;
    // Base sólo se cierra cuando el ayudante avisó que arrancó; si no, prueba con una tarea programada
    // y, si tampoco, no se cierra (así nunca queda cerrado sin actualizar).
    const mark = path.join(work, 'arranco.txt');
    const waitMark = async (ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (fs.existsSync(mark)) return true; await new Promise(r2 => setTimeout(r2, 250)); } return fs.existsSync(mark); };
    const lr = await psRun(launch);
    if (lr.code !== 0) log('Actualizador: no se pudo lanzar (' + String(lr.err || lr.code).slice(0, 200) + ')');
    let started = await waitMark(8000);
    if (!started) {
      log('Actualizador: no arrancó; pruebo con una tarea programada');
      const tn = 'BaseActualizar', bat = path.join(work, 'actualizar.cmd');
      fs.writeFileSync(bat, '@echo off\r\n' + cmdLine + '\r\n');
      const args = `/Create /F /TN ${tn} /SC ONCE /ST 23:59 /RL LIMITED /TR "\\"${bat}\\""`;
      await psRun(`Start-Process -FilePath schtasks.exe -ArgumentList ${q(args)} -Wait -WindowStyle Hidden; Start-Process -FilePath schtasks.exe -ArgumentList ${q('/Run /TN ' + tn)} -Wait -WindowStyle Hidden`);
      started = await waitMark(10000);
      psRun(`Start-Sleep -Seconds 60; schtasks.exe /Delete /F /TN ${tn} | Out-Null`);
    }
    if (!started) {
      UPD.state = 'idle';
      const msg = 'Windows no dejó arrancar el actualizador (puede ser un bloqueo de la compu). Probá con "Actualizar Base.cmd", que está en github.com/Redux-7/base-escritorio';
      log('ERROR actualización: el ayudante no arrancó');
      updProgress({ step: 'error', error: msg });
      return { ok: false, error: msg };
    }
    setTimeout(() => { quitting = true; flushData(); app.quit(); }, 300);
    return { ok: true };
  } catch (e) {
    UPD.state = 'idle';
    log('ERROR actualización: ' + e.message);
    updProgress({ step: 'error', error: e.message });
    return { ok: false, error: e.message };
  }
}
ipcMain.handle('update:check', () => updCheck(true));
ipcMain.handle('update:install', () => updInstall());
ipcMain.handle('update:info', () => ({ current: app.getVersion(), repo: UPD_REPO, latest: UPD.latest, checkedAt: UPD.checkedAt, updated: process.argv.includes('--actualizado') }));
app.whenReady().then(() => { if (app.isPackaged) updSchedule(); });

// ---------- Luces (lamparitas Smart Life por la red de casa) ----------
const tuya = require('./tuya.js');
function lampCfg(l) { return l && { id: String(l.id || ''), key: String(l.key || ''), ip: String(l.ip || ''), ver: String(l.ver || '3.3'), schema: l.schema || undefined }; }
function lampsFromSettings() { const s = settings(); return ((s.luces && s.luces.lamps) || []).filter(l => l && l.id && l.key && l.ip); }
async function lampsAll(fn) { return Promise.all(lampsFromSettings().map(async l => { try { return { id: l.id, ok: true, st: await fn(l) }; } catch (e) { return { id: l.id, ok: false, error: e.message }; } })); }
const errOut = (e) => ({ ok: false, error: e && e.message || String(e) });
ipcMain.handle('luces:scan', async () => { try { return { ok: true, list: await tuya.scan(6000) }; } catch (e) { return errOut(e); } });
ipcMain.handle('luces:cloud', async (_e, cid, secret, region) => { try { return Object.assign({ ok: true }, await tuya.cloudDevices(cid, secret, region)); } catch (e) { return errOut(e); } });
ipcMain.handle('luces:detect', async (_e, l) => { try { const r = await tuya.detect(lampCfg(Object.assign({}, l, { ver: l.ver || 'auto' }))); return { ok: true, ver: r.ver, schema: tuya.lampSchema(r.dps), st: tuya.lampState(r.dps) }; } catch (e) { return errOut(e); } });
ipcMain.handle('luces:status', async (_e, l) => { try { return { ok: true, st: await tuya.lampStatus(lampCfg(l)) }; } catch (e) { return errOut(e); } });
ipcMain.handle('luces:do', async (_e, l, a) => { try { return { ok: true, st: await tuya.lampAction(lampCfg(l), a || {}) }; } catch (e) { return errOut(e); } });
ipcMain.handle('luces:scenes', () => tuya.AMBIENTES.map(a => ({ id: a.id, n: a.n, color: a.color || tuya.hsv2hex(30, (100 - a.temp) / 160, 1) })));
app.on('will-quit', () => { try { tuya.closeAll(); } catch {} });

// ---------- Panel para la tablet ----------
const panelSrv = require('./tablet-server.js');
const PANEL = { snap: null, seq: 0, wait: new Map() };
panelSrv.init({
  log, userDir, version: app.getVersion(), helper: winHelper, tuya, iconOf: (p) => iconOf(p, 'normal'),
  sysAction, selfHandle, lamps: lampsFromSettings,
  screenshot: async () => { try { return await screenshot(); } catch (e) { return { ok: false, error: e.message }; } },
  openFolder: (p) => shell.openPath(p),
  snap: () => PANEL.snap,
  show: () => { showWindow(); winHelper.send('focus', selfHandle()); },
  toRenderer: (msg) => { try { if (win && !win.isDestroyed()) win.webContents.send('panel:do', msg); } catch {} },
  askRenderer: (msg) => new Promise((resolve) => {
    if (!win || win.isDestroyed()) return resolve({ ok: false, error: 'Base no está lista' });
    const id = ++PANEL.seq;
    const t = setTimeout(() => { PANEL.wait.delete(id); resolve({ ok: false, error: 'Base no contestó' }); }, 5000);
    PANEL.wait.set(id, (r) => { clearTimeout(t); resolve(r); });
    win.webContents.send('panel:do', Object.assign({}, msg, { _id: id }));
  })
});
ipcMain.on('panel:snap', (_e, snap) => { PANEL.snap = snap; });
ipcMain.on('panel:reply', (_e, id, r) => { const f = PANEL.wait.get(id); if (f) { PANEL.wait.delete(id); f(r || { ok: true }); } });
ipcMain.handle('panel:info', () => panelSrv.info());
ipcMain.handle('panel:reset', () => panelSrv.resetToken());
async function panelApply(s) {
  if (s.panelOn) await panelSrv.start(s.panelPort || 8766);
  else panelSrv.stop();
}
app.whenReady().then(() => { const s = settings(); if (s.panelOn) setTimeout(() => panelApply(s), 2500); });
app.on('will-quit', () => panelSrv.stop());

// ---------- La pantalla avisa que sigue viva; si se traba con Base adelante, se recarga ----------
const HB = { at: Date.now() };
ipcMain.on('hb', () => { HB.at = Date.now(); });
setInterval(() => {
  if (!win || win.isDestroyed() || quitting) return;
  if (!win.isFocused() || win.isMinimized() || !win.isVisible()) { HB.at = Date.now(); return; }
  if (Date.now() - HB.at > 30000) {
    HB.at = Date.now();
    log('La pantalla no responde hace 30 segundos: la recargo');
    try { win.webContents.forcefullyCrashRenderer(); } catch {}
    setTimeout(() => { try { if (!win.isDestroyed()) win.reload(); } catch {} }, 800);
  }
}, 5000);

// ---------- Tienda de mini juegos (se bajan del mismo lugar que las actualizaciones) ----------
const STORE_BASE = `https://raw.githubusercontent.com/${UPD_REPO}/main/tienda/`;
const storeDir = () => path.join(userDir(), 'juegos');
const storeMetaFile = () => path.join(storeDir(), 'instalados.json');
const storeIdOk = (id) => /^[a-z0-9-]{1,40}$/.test(String(id || ''));
function storeMeta() { try { return JSON.parse(fs.readFileSync(storeMetaFile(), 'utf8')) || {}; } catch { return {}; } }
function storeUrl(id) { return 'file:///' + encodeURI(path.join(storeDir(), id + '.js').replace(/\\/g, '/').replace(/^\//, '')); }
async function storeCatalog() {
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const r = await net.fetch(STORE_BASE + 'catalogo.json?t=' + Date.now(), { signal: ctrl.signal, headers: { 'User-Agent': 'Base/' + app.getVersion(), 'Cache-Control': 'no-cache' } });
    if (!r.ok) throw new Error('La tienda respondió ' + r.status);
    const j = await r.json();
    return (Array.isArray(j.juegos) ? j.juegos : []).filter(g => g && storeIdOk(g.id) && /^[\w.-]+\.js$/.test(g.file || ''));
  } finally { clearTimeout(t); }
}
ipcMain.handle('store:catalog', async () => { try { return { ok: true, list: await storeCatalog(), installed: storeMeta() }; } catch (e) { return { ok: false, error: e.name === 'AbortError' ? 'La tienda no respondió' : e.message }; } });
ipcMain.handle('store:installed', () => {
  const m = storeMeta();
  return Object.keys(m).filter(id => storeIdOk(id) && fs.existsSync(path.join(storeDir(), id + '.js'))).map(id => ({ id, v: m[id].v, url: storeUrl(id) + '?v=' + encodeURIComponent(m[id].v || '') }));
});
ipcMain.handle('store:install', async (_e, id) => {
  try {
    if (!storeIdOk(id)) throw new Error('Juego no válido');
    const g = (await storeCatalog()).find(x => x.id === id);
    if (!g) throw new Error('Ese juego ya no está en la tienda');
    const r = await net.fetch(STORE_BASE + g.file + '?v=' + encodeURIComponent(g.v || ''), { headers: { 'User-Agent': 'Base/' + app.getVersion() } });
    if (!r.ok) throw new Error('No se pudo descargar (' + r.status + ')');
    const buf = Buffer.from(await r.arrayBuffer());
    if (g.sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== String(g.sha256).toLowerCase()) throw new Error('La descarga llegó dañada');
    fs.mkdirSync(storeDir(), { recursive: true });
    fs.writeFileSync(path.join(storeDir(), id + '.js'), buf);
    const m = storeMeta(); m[id] = { v: g.v || '1', at: Date.now() };
    fs.writeFileSync(storeMetaFile(), JSON.stringify(m, null, 2), 'utf8');
    log('Tienda: instalado ' + id + ' ' + (g.v || ''));
    return { ok: true, url: storeUrl(id) + '?v=' + encodeURIComponent(g.v || '') };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('store:remove', (_e, id) => {
  if (!storeIdOk(id)) return { ok: false };
  try { fs.rmSync(path.join(storeDir(), id + '.js'), { force: true }); } catch {}
  const m = storeMeta(); delete m[id];
  try { fs.writeFileSync(storeMetaFile(), JSON.stringify(m, null, 2), 'utf8'); } catch {}
  return { ok: true };
});

// ---------- Captura de pantalla (la pide la tablet) ----------
async function screenshot() {
  const { desktopCapturer, clipboard } = require('electron');
  const disp = screen.getAllDisplays();
  const big = disp.reduce((m, d) => ({ width: Math.max(m.width, Math.round(d.size.width * d.scaleFactor)), height: Math.max(m.height, Math.round(d.size.height * d.scaleFactor)) }), { width: 0, height: 0 });
  const srcs = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: big });
  if (!srcs.length) throw new Error('No pude capturar la pantalla');
  const dir = path.join(app.getPath('pictures'), 'Capturas de Base');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date(); const p2 = (n) => String(n).padStart(2, '0');
  const base = `Captura ${stamp.getFullYear()}-${p2(stamp.getMonth() + 1)}-${p2(stamp.getDate())} ${p2(stamp.getHours())}.${p2(stamp.getMinutes())}.${p2(stamp.getSeconds())}`;
  const files = [];
  srcs.forEach((s, i) => { const f = path.join(dir, base + (srcs.length > 1 ? ` (pantalla ${i + 1})` : '') + '.png'); fs.writeFileSync(f, s.thumbnail.toPNG()); files.push(f); });
  try { clipboard.writeImage(srcs[0].thumbnail); } catch {}
  log('Captura guardada: ' + files[0]);
  return { ok: true, files, dir, preview: srcs[0].thumbnail.resize({ width: 900 }).toDataURL() };
}
ipcMain.handle('shot:take', async () => { try { return await screenshot(); } catch (e) { return { ok: false, error: e.message }; } });

// ---------- Archivos del escritorio de Windows (el tuyo y el compartido) ----------
ipcMain.handle('desk:files', async () => {
  const dirs = [app.getPath('desktop')];
  if (process.platform === 'win32') { const pub = path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop'); if (exists(pub)) dirs.push(pub); }
  const out = [];
  for (const dir of dirs) {
    let ents = []; try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of ents) {
      if (/^(desktop\.ini|thumbs\.db)$/i.test(e.name) || e.name.startsWith('.') || e.name.startsWith('~$')) continue;
      const full = path.join(dir, e.name);
      try { const st = await fsp.stat(full); out.push({ n: e.name.replace(/\.(lnk|url)$/i, ''), p: full, d: st.isDirectory(), m: st.mtimeMs, x: st.isDirectory() ? '' : path.extname(e.name).slice(1).toLowerCase(), pub: dir !== dirs[0] }); } catch {}
    }
  }
  return { dir: dirs[0], items: out };
});
ipcMain.handle('desk:import', async (_e, list) => {
  const dir = app.getPath('desktop'); const done = []; const errs = [];
  for (const src of (Array.isArray(list) ? list : []).slice(0, 200)) {
    if (!okPath(src) || !exists(src)) continue;
    if (path.dirname(src) === dir) continue;
    try { const to = freeName(dir, path.basename(src)); await fsp.cp(src, to, { recursive: true, errorOnExist: true }); done.push(path.basename(to)); } catch { errs.push(path.basename(src)); }
  }
  return { ok: !errs.length, done, errs };
});

// ---------- Botones rápidos: Wi-Fi, Bluetooth, brillo ----------
function netsh(args) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve('');
    execFile('cmd.exe', ['/d', '/s', '/c', 'chcp 65001>nul & netsh ' + args], { windowsHide: true, timeout: 8000, maxBuffer: 2 * 1024 * 1024 }, (err, out) => resolve(String(out || '')));
  });
}
async function wifiNow() {
  const t = await netsh('wlan show interfaces');
  const ssid = (/^\s*SSID\s*:\s*(.+)$/m.exec(t) || [])[1];
  const sig = (/:\s*(\d{1,3})\s*%/m.exec(t) || [])[1];
  return { has: /SSID|Nombre|Name/i.test(t), ssid: ssid ? ssid.trim() : '', signal: sig ? Number(sig) : null };
}
ipcMain.handle('quick:get', async () => {
  const [rad, wifi, br] = await Promise.all([winHelper.send('radios'), wifiNow(), winHelper.send('bright')]);
  return { radios: rad.ok && Array.isArray(rad.data) ? rad.data : [], wifi, bright: br.ok && Array.isArray(br.data) ? br.data : [] };
});
ipcMain.handle('quick:radio', async (_e, kind, on) => { if (!['WiFi', 'Bluetooth'].includes(kind)) return false; const r = await winHelper.send('radioset', kind + '|' + (on ? '1' : '0')); return !!(r.ok && r.data); });
ipcMain.handle('quick:bright', async (_e, i, v) => { const r = await winHelper.send('brightset', Math.round(Number(i) || 0) + '|' + Math.max(0, Math.min(100, Math.round(Number(v) || 0)))); return !!(r.ok && r.data); });
ipcMain.handle('quick:wifiList', async () => {
  const [nets, profs] = await Promise.all([netsh('wlan show networks'), netsh('wlan show profiles')]);
  const saved = new Set([...profs.matchAll(/^\s*[^:\r\n]*(?:Perfil|Profile)[^:\r\n]*:\s*(.+)$/gim)].map(m => m[1].trim()));
  const seen = [...nets.matchAll(/^SSID\s+\d+\s*:\s*(.*)$/gim)].map(m => m[1].trim()).filter(Boolean);
  return [...new Set(seen)].map(n => ({ n, saved: saved.has(n) })).sort((a, b) => b.saved - a.saved);
});
ipcMain.handle('quick:wifiConnect', async (_e, name) => {
  if (typeof name !== 'string' || !name || name.length > 64 || /["\r\n&|<>^%]/.test(name)) return 'Nombre de red no válido';
  const out = await netsh(`wlan connect name="${name}"`);
  return /correctamente|successfully/i.test(out) ? '' : (out.trim().split('\n').pop() || 'No se pudo conectar');
});

ipcMain.handle('sys:settings', async (_e, uri) => { if (typeof uri === 'string' && /^ms-settings:[a-z0-9-]*$/i.test(uri)) { await shell.openExternal(uri); return true; } return false; });

ipcMain.handle('win:thumb', async (_e, h) => { if (!validHwnd(h)) return null; const r = await winHelper.send('wthumb', String(h)); return r.ok && typeof r.data === 'string' && r.data ? 'data:image/jpeg;base64,' + r.data : null; });

// ---- Buscar archivos en toda la compu (índice de búsqueda de Windows) ----
ipcMain.handle('files:search', async (_e, q) => {
  q = String(q || '').replace(/[\r\n]/g, ' ').trim().slice(0, 80);
  if (q.length < 2) return [];
  const r = await winHelper.send('fsearch', q);
  if (!r.ok || !Array.isArray(r.data)) return null;
  const out = [];
  for (const f of r.data.slice(0, 30)) {
    if (!f || !f.p) continue;
    out.push({ path: f.p, name: f.n || path.basename(f.p), dir: !!f.dir, mod: f.m || 0, folder: path.dirname(f.p) });
  }
  await Promise.all(out.slice(0, 8).map(async (f) => { f.icon = await iconOf(f.path, 'small'); }));
  return out;
});
ipcMain.handle('files:searchAll', async (_e, q) => {
  q = String(q || '').trim().slice(0, 120);
  if (!q) return false;
  await shell.openExternal('search-ms:query=' + encodeURIComponent(q) + '&crumb=location:' + encodeURIComponent(app.getPath('home')));
  return true;
});

// ---- Modo descanso: cuánto hace que no se toca la compu, y si Base está al frente ----
ipcMain.handle('sys:idle', () => {
  let idle = 0; try { idle = powerMonitor.getSystemIdleTime(); } catch {}
  const focused = !!(win && !win.isDestroyed() && win.isVisible() && !win.isMinimized() && win.isFocused());
  return { idle, focused };
});

// ---------- Historial del portapapeles ----------
// Guarda lo último que copiaste (texto e imágenes). Lo que copian los gestores de contraseñas no se guarda.
const CLIP = { on: true, items: [], seq: -1, lastText: null, lastImg: '', timer: null, busy: false, saveT: null };
const clipFile = () => path.join(userDir(), 'portapapeles.json');
function clipLoad() {
  try {
    const j = JSON.parse(fs.readFileSync(clipFile(), 'utf8'));
    CLIP.items = (j.items || []).filter(x => x && (x.t === 'text' ? typeof x.text === 'string' : typeof x.png === 'string')).slice(0, 60);
    for (const x of CLIP.items) if (x.t === 'img') { try { x.img = nativeImage.createFromDataURL(x.png); x.thumb = x.img.resize({ width: Math.min(240, x.img.getSize().width) }).toDataURL(); } catch {} }
    if (CLIP.items[0] && CLIP.items[0].t === 'text') CLIP.lastText = CLIP.items[0].text;
  } catch {}
}
function clipSave() {
  clearTimeout(CLIP.saveT);
  CLIP.saveT = setTimeout(() => {
    // las imágenes solo se guardan si están fijadas (para no llenar el disco)
    const items = CLIP.items.filter(x => x.t === 'text' || x.pin).map(x => x.t === 'text' ? { id: x.id, t: 'text', text: x.text, at: x.at, pin: !!x.pin } : { id: x.id, t: 'img', png: x.png || (x.png = x.img.toDataURL()), w: x.w, h: x.h, at: x.at, pin: true });
    try { fs.writeFileSync(clipFile(), JSON.stringify({ items })); } catch {}
  }, 800);
}
function clipPush(item) {
  const keepPinned = CLIP.items.filter(x => x.pin);
  let rest = CLIP.items.filter(x => !x.pin);
  if (item.t === 'text') rest = rest.filter(x => !(x.t === 'text' && x.text === item.text));
  const pinnedSame = keepPinned.find(x => x.t === 'text' && item.t === 'text' && x.text === item.text);
  if (pinnedSame) { pinnedSame.at = item.at; }
  else rest.unshift(item);
  // máximo 40 sueltos, y de ellos solo 10 imágenes
  let imgs = 0; rest = rest.filter(x => x.t !== 'img' || ++imgs <= 10).slice(0, 40);
  CLIP.items = [...keepPinned, ...rest].sort((a, b) => (b.pin - a.pin) || (b.at - a.at));
  clipSave();
  if (win && !win.isDestroyed()) win.webContents.send('clip:changed');
}
async function clipPoll() {
  if (!CLIP.on || CLIP.busy) return;
  CLIP.busy = true;
  try {
    const { clipboard } = require('electron');
    let skip = false;
    if (process.platform === 'win32') {
      const r = await winHelper.send('clipseq', 'x');
      if (r.ok && r.data && typeof r.data.s === 'number') {
        if (r.data.s === CLIP.seq) return;
        const first = CLIP.seq === -1;
        CLIP.seq = r.data.s; skip = !!r.data.x;
        if (first) { CLIP.lastText = clipboard.readText(); return; } // lo que ya había al abrir Base no cuenta
      }
    }
    if (skip) return;
    const fm = clipboard.availableFormats();
    const hasImg = fm.some(f => /^image\//.test(f)) && !fm.includes('text/uri-list');
    const text = clipboard.readText();
    if (text && text.trim() && !hasImg) {
      if (text === CLIP.lastText) return;
      CLIP.lastText = text;
      clipPush({ id: crypto.randomUUID(), t: 'text', text: text.slice(0, 50000), at: Date.now() });
      return;
    }
    if (hasImg) {
      const img = clipboard.readImage();
      if (img.isEmpty()) return;
      const sz = img.getSize();
      const sig = sz.width + 'x' + sz.height + ':' + crypto.createHash('md5').update(img.resize({ width: 32 }).toBitmap()).digest('hex');
      if (sig === CLIP.lastImg) return;
      CLIP.lastImg = sig; CLIP.lastText = text || null;
      clipPush({ id: crypto.randomUUID(), t: 'img', img, w: sz.width, h: sz.height, thumb: img.resize({ width: Math.min(240, sz.width) }).toDataURL(), at: Date.now() });
    }
  } catch (e) { /* el portapapeles puede estar ocupado por otro programa: se reintenta solo */ }
  finally { CLIP.busy = false; }
}
app.whenReady().then(() => { clipLoad(); CLIP.timer = setInterval(clipPoll, 1200); });
const clipOut = (x) => x.t === 'text' ? { id: x.id, t: 'text', text: x.text.slice(0, 4000), long: x.text.length > 4000, at: x.at, pin: !!x.pin } : { id: x.id, t: 'img', thumb: x.thumb, w: x.w, h: x.h, at: x.at, pin: !!x.pin };
ipcMain.handle('clip:list', () => ({ on: CLIP.on, items: CLIP.items.map(clipOut) }));
ipcMain.handle('clip:use', (_e, id) => {
  const x = CLIP.items.find(i => i.id === id); if (!x) return false;
  const { clipboard } = require('electron');
  if (x.t === 'text') { clipboard.writeText(x.text); CLIP.lastText = x.text; }
  else { clipboard.writeImage(x.img); }
  if (!x.pin) { x.at = Date.now(); CLIP.items.sort((a, b) => (b.pin - a.pin) || (b.at - a.at)); clipSave(); }
  return true;
});
ipcMain.handle('clip:pin', (_e, id) => { const x = CLIP.items.find(i => i.id === id); if (!x) return false; x.pin = !x.pin; CLIP.items.sort((a, b) => (b.pin - a.pin) || (b.at - a.at)); clipSave(); return x.pin; });
ipcMain.handle('clip:del', (_e, id) => { CLIP.items = CLIP.items.filter(i => i.id !== id); clipSave(); return true; });
ipcMain.handle('clip:clear', () => { CLIP.items = CLIP.items.filter(i => i.pin); clipSave(); return true; });
ipcMain.handle('clip:set', (_e, on) => { CLIP.on = !!on; return CLIP.on; });

// ---------- Captura recortando una parte de la pantalla ----------
let cropWin = null;
async function cropShot() {
  if (cropWin && !cropWin.isDestroyed()) { cropWin.focus(); return; }
  const { desktopCapturer } = require('electron');
  const pt = screen.getCursorScreenPoint();
  const disp = screen.getDisplayNearestPoint(pt);
  const want = { width: Math.round(disp.size.width * disp.scaleFactor), height: Math.round(disp.size.height * disp.scaleFactor) };
  const srcs = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: want });
  const src = srcs.find(s => String(s.display_id) === String(disp.id)) || srcs[0];
  if (!src) throw new Error('No pude capturar la pantalla');
  const shot = src.thumbnail;
  cropWin = new BrowserWindow({
    x: disp.bounds.x, y: disp.bounds.y, width: disp.bounds.width, height: disp.bounds.height,
    frame: false, show: false, alwaysOnTop: true, skipTaskbar: true, resizable: false, movable: false, fullscreenable: false, hasShadow: false,
    backgroundColor: '#000000',
    webPreferences: { preload: path.join(__dirname, 'crop-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  cropWin.setAlwaysOnTop(true, 'screen-saver');
  cropWin.setMenu(null);
  const cw = cropWin;
  cw.on('closed', () => { if (cropWin === cw) cropWin = null; });
  cw.webContents.once('did-finish-load', () => { cw.webContents.send('crop:img', shot.toDataURL()); cw.setBounds(disp.bounds); cw.show(); cw.focus(); });
  cw.__shot = shot; cw.__disp = disp;
  cw.loadFile(path.join(__dirname, 'src', 'crop.html'));
}
ipcMain.handle('crop:done', async (e, r) => {
  const cw = BrowserWindow.fromWebContents(e.sender);
  if (!cw || cw !== cropWin) return false;
  const shot = cw.__shot, disp = cw.__disp;
  cw.close();
  if (!r) return false;
  const sz = shot.getSize(), k = sz.width / disp.bounds.width;
  const rect = r === 'all' ? { x: 0, y: 0, width: sz.width, height: sz.height }
    : { x: Math.max(0, Math.round(r.x * k)), y: Math.max(0, Math.round(r.y * k)), width: Math.round(r.w * k), height: Math.round(r.h * k) };
  rect.width = Math.max(1, Math.min(rect.width, sz.width - rect.x)); rect.height = Math.max(1, Math.min(rect.height, sz.height - rect.y));
  const img = shot.crop(rect);
  const dir = path.join(app.getPath('pictures'), 'Capturas de Base');
  fs.mkdirSync(dir, { recursive: true });
  const d = new Date(), p2 = (n) => String(n).padStart(2, '0');
  const file = path.join(dir, `Recorte ${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}.${p2(d.getMinutes())}.${p2(d.getSeconds())}.png`);
  fs.writeFileSync(file, img.toPNG());
  try { require('electron').clipboard.writeImage(img); } catch {}
  log('Recorte guardado: ' + file);
  if (win && !win.isDestroyed()) win.webContents.send('shot:done', { file, dir, preview: img.resize({ width: Math.min(520, img.getSize().width) }).toDataURL() });
  return true;
});
ipcMain.handle('shot:crop', async () => { try { await cropShot(); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; } });
app.whenReady().then(() => { try { globalShortcut.register('Control+Alt+S', () => cropShot().catch(e => log('Recorte: ' + e.message))); } catch {} });

// ---------- Copia automática semanal (Documentos\Base\Copias, quedan las últimas 4) ----------
const autoBkDir = () => path.join(app.getPath('documents'), 'Base', 'Copias');
const autoBkState = () => { try { return JSON.parse(fs.readFileSync(path.join(userDir(), 'copias.json'), 'utf8')); } catch { return {}; } };
function autoBkList() {
  try { return fs.readdirSync(autoBkDir()).filter(f => /^Base-copia-auto-.*\.base$/i.test(f)).sort().reverse(); } catch { return []; }
}
function autoBackup(force) {
  try {
    const st = autoBkState();
    if (!force && Date.now() - (st.last || 0) < 7 * 864e5) return { ok: true, skipped: true };
    const data = readData();
    if (!data || !data.modes) return { ok: false, error: 'Todavía no hay datos para copiar' };
    const pack = buildPack(data, { google: true });
    fs.mkdirSync(autoBkDir(), { recursive: true });
    const d = new Date(), p2 = (n) => String(n).padStart(2, '0');
    const file = path.join(autoBkDir(), `Base-copia-auto-${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}.base`);
    fs.writeFileSync(file + '.tmp', JSON.stringify(pack), 'utf8');
    fs.renameSync(file + '.tmp', file);
    for (const old of autoBkList().slice(4)) { try { fs.unlinkSync(path.join(autoBkDir(), old)); } catch {} }
    fs.writeFileSync(path.join(userDir(), 'copias.json'), JSON.stringify({ last: Date.now(), file }));
    log('Copia automática: ' + file);
    return { ok: true, file };
  } catch (e) { log('Copia automática falló: ' + e.message); return { ok: false, error: e.message }; }
}
function autoBkTick() { if (settings().autoBackup === false) return; autoBackup(false); }
app.whenReady().then(() => { setTimeout(autoBkTick, 3 * 60 * 1000); setInterval(autoBkTick, 6 * 3600 * 1000); });
ipcMain.handle('backup:autoInfo', () => ({ last: autoBkState().last || 0, dir: autoBkDir(), files: autoBkList() }));
ipcMain.handle('backup:autoNow', () => autoBackup(true));
ipcMain.handle('backup:autoOpen', () => { fs.mkdirSync(autoBkDir(), { recursive: true }); return shell.openPath(autoBkDir()); });

// ---------- Mapas para el juego "Manejá por tu barrio" (OpenStreetMap) ----------
const MAPAS = require('./mapas.js').create({ fetch: (u, o) => net.fetch(u, o), userDir, log });
ipcMain.handle('map:search', async (_e, q) => { try { return { ok: true, list: await MAPAS.search(q) }; } catch (e) { return { ok: false, error: e.message }; } });
ipcMain.handle('map:download', async (e, a) => {
  try { return { ok: true, map: await MAPAS.download(a || {}, (t) => { try { e.sender.send('map:progress', t); } catch {} }) }; }
  catch (err) { return { ok: false, error: err.message }; }
});
ipcMain.handle('map:list', () => MAPAS.list());
ipcMain.handle('map:get', (_e, id) => MAPAS.get(id));
ipcMain.handle('map:remove', (_e, id) => MAPAS.remove(id));

// ======================================================================
// Salud de la compu, copia de carpetas, atajos propios y esquinas activas
// ======================================================================
const osX = require('os');
function psJson(cmd, timeout = 9000) {
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd + ' | ConvertTo-Json -Compress'], { timeout, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, out) => {
      if (err || !out) return resolve(null);
      try { const j = JSON.parse(String(out).trim()); resolve(Array.isArray(j) ? j : [j]); } catch { resolve(null); }
    });
  });
}
function cpuSample(ms = 400) {
  const a = osX.cpus();
  return new Promise((res) => setTimeout(() => {
    const b = osX.cpus(); let idle = 0, tot = 0;
    b.forEach((c, i) => { const p = a[i] && a[i].times, q = c.times; if (!p) return; for (const k of Object.keys(q)) tot += q[k] - p[k]; idle += q.idle - p.idle; });
    res(tot ? Math.round((1 - idle / tot) * 100) : null);
  }, ms));
}
async function dirSize(dir, budget) {
  // suma tamaños recorriendo la carpeta, con un tope de archivos y de tiempo para no trabar nada
  let size = 0, files = 0, partial = false; const stack = [dir];
  while (stack.length) {
    if (files > budget.max || Date.now() > budget.until) { partial = true; break; }
    const d = stack.pop(); let h;
    try { h = await fs.promises.opendir(d); } catch { continue; }
    try {
      for await (const e of h) {
        const p = path.join(d, e.name);
        if (e.isSymbolicLink()) continue;
        if (e.isDirectory()) stack.push(p);
        else if (e.isFile()) { try { const st = await fs.promises.stat(p); size += st.size; files++; } catch {} }
        if (files > budget.max || Date.now() > budget.until) { partial = true; break; }
      }
    } catch {}
  }
  return { size, files, partial };
}
ipcMain.handle('health:get', async () => {
  const [disks, bat, cpu, tmp] = await Promise.all([
    psJson("Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID,VolumeName,Size,FreeSpace"),
    psJson('Get-CimInstance Win32_Battery | Select-Object EstimatedChargeRemaining,BatteryStatus'),
    cpuSample(),
    dirSize(osX.tmpdir(), { max: 60000, until: Date.now() + 6000 })
  ]);
  return {
    ok: true,
    disks: (disks || []).filter(d => d && d.Size).map(d => ({ id: d.DeviceID, name: d.VolumeName || '', size: Number(d.Size), free: Number(d.FreeSpace) })),
    battery: bat && bat[0] && bat[0].EstimatedChargeRemaining != null ? { pct: bat[0].EstimatedChargeRemaining, charging: [2, 6, 7, 8, 9].includes(Number(bat[0].BatteryStatus)) } : null,
    mem: { total: osX.totalmem(), free: osX.freemem() }, cpu, uptime: osX.uptime(), temp: tmp
  };
});
ipcMain.handle('health:folders', async () => {
  const names = { downloads: 'Descargas', desktop: 'Escritorio', documents: 'Documentos', pictures: 'Imágenes', videos: 'Videos', music: 'Música' };
  const out = []; const until = Date.now() + 25000;
  for (const [k, n] of Object.entries(names)) { let p; try { p = app.getPath(k); } catch { continue; } const r = await dirSize(p, { max: 250000, until }); out.push({ name: n, path: p, ...r }); }
  return out;
});
ipcMain.handle('health:clean', async () => {
  // borra lo de la carpeta temporal que tenga más de 2 días (lo que está en uso se saltea solo)
  const dir = osX.tmpdir(), limit = Date.now() - 2 * 86400000; let freed = 0, n = 0;
  let list = []; try { list = await fs.promises.readdir(dir); } catch {}
  for (const name of list) {
    const p = path.join(dir, name);
    try {
      const st = await fs.promises.stat(p);
      if (st.mtimeMs > limit) continue;
      const sz = st.isDirectory() ? (await dirSize(p, { max: 20000, until: Date.now() + 3000 })).size : st.size;
      await fs.promises.rm(p, { recursive: true, force: true, maxRetries: 0 });
      freed += sz; n++;
    } catch {}
  }
  return { ok: true, freed, n };
});
ipcMain.handle('health:recycle', async () => { await psJson('Clear-RecycleBin -Force -ErrorAction SilentlyContinue; @{ok=$true}'); return { ok: true }; });
ipcMain.handle('health:storage', () => shell.openExternal('ms-settings:storagesense'));

// ---- copia de carpetas a la carpeta de Google Drive (o a un disco) ----
ipcMain.handle('fbk:pick', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] }); return r.canceled ? null : r.filePaths[0]; });
ipcMain.handle('fbk:drive', async () => {
  const home = osX.homedir(), cands = [];
  for (const L of 'GHIJKLMNOPQRSTUVWXYZDEF') for (const n of ['Mi unidad', 'My Drive']) cands.push(`${L}:\\${n}`);
  for (const n of ['Google Drive\\Mi unidad', 'Google Drive\\My Drive', 'Google Drive', 'Mi unidad', 'My Drive']) cands.push(path.join(home, n));
  for (const c of cands) { try { if ((await fs.promises.stat(c)).isDirectory()) return c; } catch {} }
  return null;
});
const FBK = { busy: false };
const SKIP = /^(desktop\.ini|thumbs\.db|~\$.*|.*\.tmp|.*\.crdownload|.*\.part)$/i;
async function copyTree(src, dst, st) {
  const stack = [[src, dst]];
  while (stack.length) {
    const [s, d] = stack.pop(); let entries;
    try { entries = await fs.promises.readdir(s, { withFileTypes: true }); } catch { st.errors++; continue; }
    try { await fs.promises.mkdir(d, { recursive: true }); } catch { st.errors++; continue; }
    for (const e of entries) {
      if (SKIP.test(e.name) || e.isSymbolicLink()) continue;
      const sp = path.join(s, e.name), dp = path.join(d, e.name);
      if (e.isDirectory()) { if (!/^(node_modules|\$recycle\.bin|system volume information)$/i.test(e.name)) stack.push([sp, dp]); continue; }
      if (!e.isFile()) continue;
      try {
        const a = await fs.promises.stat(sp); let b = null; try { b = await fs.promises.stat(dp); } catch {}
        if (b && b.size === a.size && Math.abs(b.mtimeMs - a.mtimeMs) < 2000) { st.same++; continue; }
        await fs.promises.copyFile(sp, dp); await fs.promises.utimes(dp, a.atime, a.mtime);
        st.copied++; st.bytes += a.size;
        if (st.copied % 50 === 0 && win && !win.isDestroyed()) win.webContents.send('fbk:progress', { copied: st.copied, same: st.same });
      } catch { st.errors++; }
    }
  }
}
ipcMain.handle('fbk:run', async (_e, cfg) => {
  if (FBK.busy) return { ok: false, error: 'Ya hay una copia en marcha' };
  const dest = cfg && String(cfg.dest || ''); const folders = (cfg && Array.isArray(cfg.folders) ? cfg.folders : []).map(String);
  if (!dest || !folders.length) return { ok: false, error: 'Elegí las carpetas y dónde guardar la copia' };
  try { await fs.promises.mkdir(dest, { recursive: true }); } catch { return { ok: false, error: 'No puedo escribir en el destino' }; }
  const norm = (p) => path.resolve(p).toLowerCase() + path.sep;
  FBK.busy = true; const st = { copied: 0, same: 0, errors: 0, bytes: 0, t0: Date.now() };
  try {
    const root = path.join(dest, 'Copia de Base'); const used = new Set();
    for (const f of folders) {
      if (norm(dest).startsWith(norm(f)) || norm(f).startsWith(norm(root))) { st.errors++; continue; } // no copiar una carpeta adentro de sí misma
      let name = path.basename(f) || f.replace(/[:\\]/g, ''); let k = 2; while (used.has(name.toLowerCase())) name = `${path.basename(f)} (${k++})`; used.add(name.toLowerCase());
      await copyTree(f, path.join(root, name), st);
    }
  } finally { FBK.busy = false; }
  return { ok: true, ...st, ms: Date.now() - st.t0 };
});
ipcMain.handle('fbk:open', (_e, p) => p && shell.openPath(String(p)));

// ---- copia directa a Google Drive (datos de Base + carpetas elegidas) ----
const gdFile = () => path.join(userDir(), 'drive-copia.json');
const gdLoad = () => { try { return JSON.parse(fs.readFileSync(gdFile(), 'utf8')); } catch { return {}; } };
const gdSave = (x) => { try { fs.writeFileSync(gdFile() + '.tmp', JSON.stringify(x)); fs.renameSync(gdFile() + '.tmp', gdFile()); } catch {} };
let gdIdx = null;
const gdMode = () => ['casa', 'trabajo'].find(m => google.hasDrive(m)) || null;
async function gdWalk(src, idx, out) {
  // lista los archivos que cambiaron desde la última subida
  const stack = [src];
  while (stack.length) {
    const s = stack.pop(); let entries;
    try { entries = await fs.promises.readdir(s, { withFileTypes: true }); } catch { out.errors++; continue; }
    out.dirs.push(s);
    for (const e of entries) {
      if (SKIP.test(e.name) || e.isSymbolicLink()) continue;
      const sp = path.join(s, e.name);
      if (e.isDirectory()) { if (!/^(node_modules|\$recycle\.bin|system volume information|\.git)$/i.test(e.name)) stack.push(sp); continue; }
      if (!e.isFile()) continue;
      try {
        const a = await fs.promises.stat(sp), k = sp.toLowerCase(), prev = idx.files[k];
        if (prev && prev[1] === a.size && Math.abs(prev[2] - a.mtimeMs) < 2000) { out.same++; continue; }
        out.todo.push({ p: sp, size: a.size, mtime: a.mtimeMs, prev: prev && prev[0] }); out.bytes += a.size;
      } catch { out.errors++; }
    }
  }
}
ipcMain.handle('gdrive:info', () => { const x = gdLoad(); return { mode: gdMode(), root: x.root || null, last: x.last || 0 }; });
ipcMain.handle('gdrive:run', async (_e, cfg) => {
  if (FBK.busy) return { ok: false, error: 'Ya hay una copia en marcha' };
  const mode = gdMode();
  if (!mode) return { ok: false, code: 'need_drive', error: 'Falta darle a Base permiso para tu Google Drive' };
  const folders = (cfg && Array.isArray(cfg.folders) ? cfg.folders : []).map(String);
  FBK.busy = true;
  const st = { copied: 0, same: 0, errors: 0, bytes: 0, t0: Date.now() };
  const send = (x) => { if (win && !win.isDestroyed()) win.webContents.send('fbk:progress', x); };
  try {
    let idx = gdLoad();
    if (idx.mode !== mode || !idx.root || !(await google.driveAlive(mode, idx.root))) idx = { mode, root: await google.driveFolder(mode, 'Copia de Base - ' + (osX.hostname() || 'esta compu')), dirs: {}, files: {} };
    idx.dirs = idx.dirs || {}; idx.files = idx.files || {}; gdIdx = idx; gdSave(idx);
    const dirId = async (local, name, parent) => {
      const k = local.toLowerCase(); if (idx.dirs[k]) return idx.dirs[k];
      const id = await google.driveFolder(mode, name, parent); idx.dirs[k] = id; return id;
    };
    // 1) los datos de Base (tareas, notas, agenda, ajustes…), uno por día, quedan los últimos 14
    const data = readData();
    if (data && data.modes) {
      const datos = await dirId('::datos', 'Datos de Base', idx.root);
      const d = new Date(), p2 = (n) => String(n).padStart(2, '0'), name = `Base-datos-${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}.base`;
      const tmp = path.join(osX.tmpdir(), name);
      fs.writeFileSync(tmp, JSON.stringify(buildPack(data, { google: false })), 'utf8');
      try {
        const list = await google.driveChildren(mode, datos);
        const same = list.find(f => f.name === name);
        await google.driveUpload(mode, tmp, same ? { id: same.id } : { name, parent: datos });
        const old = list.filter(f => /^Base-datos-.*\.base$/.test(f.name) && f.name !== name).sort((a, b) => b.name.localeCompare(a.name)).slice(13);
        for (const f of old) { try { await google.driveTrash(mode, f.id); } catch {} }
      } finally { try { fs.unlinkSync(tmp); } catch {} }
      st.data = true;
    }
    // 2) las carpetas elegidas: sólo lo nuevo o cambiado, nunca borra nada
    const scan = { todo: [], dirs: [], same: 0, errors: 0, bytes: 0 };
    const roots = [];
    for (const f of folders) { if (fs.existsSync(f)) { roots.push(f); await gdWalk(f, idx, scan); } else st.errors++; }
    st.same = scan.same; st.errors += scan.errors; st.total = scan.todo.length;
    if (scan.bytes) {
      const q = await google.driveQuota(mode);
      if (q.limit && q.usage + scan.bytes > q.limit - 200e6) {
        const gb = (b) => (b / 1e9).toFixed(1).replace('.', ',') + ' GB';
        return { ok: false, code: 'full', error: `No entra: hay que subir ${gb(scan.bytes)} y en tu Drive quedan ${gb(Math.max(0, q.limit - q.usage))} libres. Sacá alguna carpeta de la lista.`, need: scan.bytes, free: q.limit - q.usage };
      }
    }
    // carpetas de Drive para cada carpeta local
    const used = new Set(), rootName = {};
    for (const r of roots) { let n = path.basename(r) || r.replace(/[:\\]/g, ''), k = 2; while (used.has(n.toLowerCase())) n = `${path.basename(r)} (${k++})`; used.add(n.toLowerCase()); rootName[r.toLowerCase()] = n; }
    const folderFor = async (dir) => {
      const k = dir.toLowerCase(); if (idx.dirs[k]) return idx.dirs[k];
      const r = roots.find(x => k === x.toLowerCase() || k.startsWith(x.toLowerCase() + path.sep));
      if (k === r.toLowerCase()) return dirId(dir, rootName[k], idx.root);
      return dirId(dir, path.basename(dir), await folderFor(path.dirname(dir)));
    };
    let n = 0, lastSave = Date.now(); const q = scan.todo.slice();
    const work = async (it) => {
      try {
        const parent = await folderFor(path.dirname(it.p));
        let id;
        try { id = await google.driveUpload(mode, it.p, it.prev ? { id: it.prev } : { name: path.basename(it.p), parent }); }
        catch (e) { if (it.prev && e.code === 'notfound') id = await google.driveUpload(mode, it.p, { name: path.basename(it.p), parent }); else throw e; }
        idx.files[it.p.toLowerCase()] = [id, it.size, it.mtime];
        st.copied++; st.bytes += it.size;
      } catch (e) { st.errors++; if (/lleno|permiso|API|vincular/i.test(e.message)) { q.length = 0; throw e; } }
      if (++n % 10 === 0) send({ copied: st.copied, total: st.total, drive: true });
      if (Date.now() - lastSave > 20000) { lastSave = Date.now(); gdSave(idx); }
    };
    // crear primero las carpetas (en orden) y después subir de a 4 archivos a la vez
    for (const it of scan.todo) await folderFor(path.dirname(it.p));
    await Promise.all(Array.from({ length: 4 }, async () => { while (q.length) await work(q.shift()); }));
    idx.last = Date.now(); gdSave(idx);
    return { ok: true, ...st, root: idx.root, ms: Date.now() - st.t0 };
  } catch (e) {
    log('Copia a Drive: ' + e.message);
    if (gdIdx) gdSave(gdIdx);
    return { ok: false, code: e.code, error: e.message, url: e.url || null, ...st };
  } finally { FBK.busy = false; gdIdx = null; }
});

// ---- atajos propios (también funcionan con Base escondida) ----
const EXT = { keys: [], corners: {}, cornerT: null, inCorner: null, since: 0 };
ipcMain.handle('ext:keys', (_e, list) => {
  for (const k of EXT.keys) { try { globalShortcut.unregister(k); } catch {} }
  EXT.keys = [];
  const res = [];
  for (const [i, acc] of (Array.isArray(list) ? list : []).entries()) {
    let ok = false;
    try { ok = globalShortcut.register(String(acc), () => { if (win && !win.isDestroyed()) win.webContents.send('ext:key', i); }); } catch {}
    if (ok) EXT.keys.push(String(acc));
    res.push(ok);
  }
  return res;
});
// ---- esquinas activas: llevar el mouse a una esquina de la pantalla ----
ipcMain.handle('ext:corners', (_e, map) => {
  EXT.corners = map && typeof map === 'object' ? map : {};
  clearInterval(EXT.cornerT); EXT.cornerT = null;
  if (!Object.values(EXT.corners).some(Boolean)) return true;
  EXT.cornerT = setInterval(() => {
    const p = screen.getCursorScreenPoint(), d = screen.getDisplayNearestPoint(p).bounds, m = 2;
    const c = p.x <= d.x + m && p.y <= d.y + m ? 'tl' : p.x >= d.x + d.width - 1 - m && p.y <= d.y + m ? 'tr' : p.x <= d.x + m && p.y >= d.y + d.height - 1 - m ? 'bl' : p.x >= d.x + d.width - 1 - m && p.y >= d.y + d.height - 1 - m ? 'br' : null;
    if (c !== EXT.inCorner) { EXT.inCorner = c; EXT.since = Date.now(); EXT.fired = false; return; }
    if (c && !EXT.fired && EXT.corners[c] && Date.now() - EXT.since > 350) {
      EXT.fired = true; const act = EXT.corners[c];
      if (act === 'desktop') return sysAction('minimizeAll');
      if (act === 'taskview') return sysAction('taskview');
      if (act === 'start') return sysAction('start');
      showWindow(); if (win && !win.isDestroyed()) win.webContents.send('ext:corner', act);
    }
  }, 120);
  return true;
});
// ---- apagar la compu en un rato (desde el buscador) ----
ipcMain.handle('sys:shutdownIn', (_e, secs) => { const s = Math.max(60, Math.min(86400, Math.round(Number(secs) || 0))); spawn('shutdown.exe', ['/s', '/t', String(s)], { detached: true, stdio: 'ignore' }).unref(); return { ok: true }; });
ipcMain.handle('sys:shutdownAbort', () => { spawn('shutdown.exe', ['/a'], { detached: true, stdio: 'ignore' }).unref(); return { ok: true }; });
