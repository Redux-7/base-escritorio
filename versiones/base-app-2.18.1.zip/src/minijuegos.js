// Mini juegos de Base: Solitario, Sudoku, Mahjong, Buscaminas y 2048.
// Cada juego arma su tablero y le avisa a la Sala de juegos el estado (tiempo, movimientos) y los récords.
(() => {
  'use strict';

  // ---------- utilidades ----------
  function h(tag, attrs = {}, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === false || v == null) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const k of kids.flat()) if (k != null && k !== false) e.append(k);
    return e;
  }
  const rnd = (n) => Math.floor(Math.random() * n);
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  const fmtTime = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  function timer(onTick) {
    let start = 0, acc = 0, t = null;
    const now = () => acc + (start ? (Date.now() - start) / 1000 : 0);
    return {
      start() { if (start) return; start = Date.now(); t = setInterval(() => onTick(now()), 500); onTick(now()); },
      stop() { if (!start) return; acc = now(); start = 0; clearInterval(t); onTick(acc); },
      reset() { start = 0; acc = 0; clearInterval(t); onTick(0); },
      get running() { return !!start; },
      get secs() { return now(); }
    };
  }
  function seg(options, value, onChange) {
    const box = h('div', { class: 'mg-seg', role: 'tablist' });
    for (const [v, label] of options) {
      const b = h('button', { type: 'button', class: v === value ? 'on' : '', text: label });
      b.onclick = () => { for (const x of box.children) x.classList.toggle('on', x === b); onChange(v); };
      box.append(b);
    }
    return box;
  }
  const btn = (label, onclick, cls = '') => { const b = h('button', { type: 'button', class: 'mg-btn ' + cls, text: label }); b.onclick = onclick; return b; };
  function overlay(root, title, sub, actions) {
    const old = root.querySelector('.mg-over');
    if (old) old.remove();
    const o = h('div', { class: 'mg-over' }, h('div', { class: 'mg-over-card' }, h('b', { text: title }), sub ? h('span', { text: sub }) : null, h('div', { class: 'mg-over-acts' }, actions)));
    root.append(o);
    return o;
  }
  function confetti(root) {
    const box = h('div', { class: 'mg-confetti', 'aria-hidden': 'true' });
    const colors = ['#ff5d73', '#ffc145', '#4cc9f0', '#7bd389', '#b388ff', '#ff9f68'];
    for (let i = 0; i < 70; i++) {
      box.append(h('i', { style: `left:${rnd(100)}%;background:${colors[i % colors.length]};animation-delay:${(Math.random() * .6).toFixed(2)}s;animation-duration:${(1.6 + Math.random() * 1.4).toFixed(2)}s;transform:rotate(${rnd(360)}deg)` }));
    }
    root.append(box);
    setTimeout(() => box.remove(), 3600);
  }

  // =====================================================================
  // BUSCAMINAS
  // =====================================================================
  function buscaminas(H) {
    const LV = { facil: { r: 9, c: 9, m: 10, n: 'Fácil', cs: 42 }, medio: { r: 16, c: 16, m: 40, n: 'Medio', cs: 32 }, dificil: { r: 16, c: 30, m: 99, n: 'Difícil', cs: 28 } };
    let lv = H.get().lv || 'facil';
    let L, mines, open, flag, cells, over, first, opened;
    const root = h('div', { class: 'mg-mines' });
    const board = h('div', { class: 'mn-board' });
    root.append(board);
    const t = timer((s) => status());
    const status = () => {
      const left = L ? L.m - flag.filter(Boolean).length : 0;
      H.status([`💣 ${left}`, fmtTime(t.secs), H.get()['best_' + lv] ? `Récord ${fmtTime(H.get()['best_' + lv])}` : '']);
    };
    const nb = (i) => {
      const r = Math.floor(i / L.c), c = i % L.c, out = [];
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        if (!dr && !dc) continue;
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < L.r && cc >= 0 && cc < L.c) out.push(rr * L.c + cc);
      }
      return out;
    };
    function newGame() {
      L = LV[lv];
      const n = L.r * L.c;
      mines = new Array(n).fill(false); open = new Array(n).fill(false); flag = new Array(n).fill(false);
      over = false; first = true; opened = 0;
      t.reset();
      const old = root.querySelector('.mg-over'); if (old) old.remove();
      board.style.setProperty('--cols', L.c);
      board.style.setProperty('--cs', L.cs + 'px');
      board.replaceChildren();
      cells = [];
      for (let i = 0; i < n; i++) {
        const b = h('button', { type: 'button', class: 'mn-c', 'data-i': i, 'aria-label': 'Casilla' });
        cells.push(b);
        board.append(b);
      }
      status();
    }
    function place(safe) {
      const avoid = new Set([safe, ...nb(safe)]);
      const idx = shuffle([...Array(L.r * L.c).keys()].filter(i => !avoid.has(i)));
      for (let k = 0; k < L.m; k++) mines[idx[k]] = true;
    }
    const count = (i) => nb(i).filter(j => mines[j]).length;
    function reveal(i) {
      if (over || open[i] || flag[i]) return;
      if (first) { first = false; place(i); t.start(); }
      if (mines[i]) return lose(i);
      const stack = [i];
      while (stack.length) {
        const j = stack.pop();
        if (open[j] || flag[j]) continue;
        open[j] = true; opened++;
        const n = count(j);
        const c = cells[j];
        c.classList.add('open');
        c.style.setProperty('--d', (Math.min(opened, 60) * 4) + 'ms');
        if (n) { c.textContent = n; c.dataset.n = n; }
        else for (const k of nb(j)) if (!open[k]) stack.push(k);
      }
      if (opened === L.r * L.c - L.m) win();
    }
    function chord(i) {
      if (!open[i] || over) return;
      const n = count(i);
      const ns = nb(i);
      if (ns.filter(j => flag[j]).length !== n) { for (const j of ns) if (!open[j] && !flag[j]) { cells[j].classList.add('hint'); setTimeout(() => cells[j].classList.remove('hint'), 180); } return; }
      for (const j of ns) if (!open[j] && !flag[j]) reveal(j);
    }
    function toggleFlag(i) {
      if (over || open[i]) return;
      flag[i] = !flag[i];
      cells[i].classList.toggle('flag', flag[i]);
      cells[i].textContent = flag[i] ? '⚑' : '';
      status();
    }
    function lose(i) {
      over = true; t.stop();
      mines.forEach((m, j) => {
        if (m && !flag[j]) { cells[j].classList.add('mine'); cells[j].textContent = '✹'; }
        if (!m && flag[j]) cells[j].classList.add('wrong');
      });
      cells[i].classList.add('boom');
      const st = H.get(); st.played = (st.played || 0) + 1; H.set(st);
      setTimeout(() => overlay(root, '¡Boom!', 'Pisaste una mina.', [btn('Jugar de nuevo', newGame, 'primary')]), 500);
    }
    function win() {
      over = true; t.stop();
      mines.forEach((m, j) => { if (m) { cells[j].classList.add('flag'); cells[j].textContent = '⚑'; } });
      const st = H.get(); const s = Math.round(t.secs);
      st.played = (st.played || 0) + 1; st.wins = (st.wins || 0) + 1;
      const rec = !st['best_' + lv] || s < st['best_' + lv];
      if (rec) st['best_' + lv] = s;
      H.set(st); status();
      confetti(root);
      overlay(root, '¡Ganaste!', `${LV[lv].n} en ${fmtTime(s)}${rec ? ' · ¡nuevo récord!' : ''}`, [btn('Otra partida', newGame, 'primary')]);
    }
    board.addEventListener('click', (e) => {
      const c = e.target.closest('.mn-c'); if (!c) return;
      const i = +c.dataset.i;
      if (open[i]) chord(i); else reveal(i);
    });
    board.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const c = e.target.closest('.mn-c'); if (!c) return;
      const i = +c.dataset.i;
      if (open[i]) chord(i); else toggleFlag(i);
    });
    board.addEventListener('auxclick', (e) => { if (e.button === 1) { const c = e.target.closest('.mn-c'); if (c) chord(+c.dataset.i); } });
    const tools = [
      seg(Object.entries(LV).map(([k, v]) => [k, v.n]), lv, (v) => { lv = v; const st = H.get(); st.lv = v; H.set(st); newGame(); }),
      btn('Nueva partida', newGame)
    ];
    newGame();
    return { el: root, tools, help: 'Clic: destapar · Clic derecho: bandera · Clic en un número: destapa alrededor', hide: () => t.running && t.stop(), show: () => { if (!first && !over) t.start(); } };
  }

  // =====================================================================
  // SUDOKU
  // =====================================================================
  const BOX = (i) => Math.floor(Math.floor(i / 9) / 3) * 3 + Math.floor((i % 9) / 3);
  function sudokuSolve(grid, limit) {
    const g = grid.slice();
    const rows = new Array(9).fill(0), cols = new Array(9).fill(0), boxes = new Array(9).fill(0);
    for (let i = 0; i < 81; i++) if (g[i]) { const b = 1 << g[i]; rows[Math.floor(i / 9)] |= b; cols[i % 9] |= b; boxes[BOX(i)] |= b; }
    let count = 0, sol = null;
    const pop = (x) => { let n = 0; while (x) { x &= x - 1; n++; } return n; };
    (function rec() {
      if (count >= limit) return;
      let best = -1, bestMask = 0, bestN = 10;
      for (let i = 0; i < 81; i++) {
        if (g[i]) continue;
        const mask = ~(rows[Math.floor(i / 9)] | cols[i % 9] | boxes[BOX(i)]) & 0x3fe;
        const n = pop(mask);
        if (n < bestN) { best = i; bestMask = mask; bestN = n; if (n <= 1) break; }
      }
      if (best < 0) { count++; if (!sol) sol = g.slice(); return; }
      if (!bestN) return;
      const r = Math.floor(best / 9), c = best % 9, b = BOX(best);
      for (let d = 1; d <= 9; d++) {
        if (!(bestMask & (1 << d))) continue;
        g[best] = d; rows[r] |= 1 << d; cols[c] |= 1 << d; boxes[b] |= 1 << d;
        rec();
        g[best] = 0; rows[r] &= ~(1 << d); cols[c] &= ~(1 << d); boxes[b] &= ~(1 << d);
        if (count >= limit) return;
      }
    })();
    return { count, sol };
  }
  function sudokuFull() {
    const g = new Array(81).fill(0);
    // diagonal de cajas al azar, el resto lo completa el solver
    for (let k = 0; k < 3; k++) {
      const ds = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
      for (let j = 0; j < 9; j++) g[(k * 3 + Math.floor(j / 3)) * 9 + k * 3 + (j % 3)] = ds[j];
    }
    return sudokuSolve(g, 1).sol;
  }
  function sudokuMake(level) {
    const sol = sudokuFull();
    const target = { facil: 38, medio: 48, dificil: 55 }[level] || 45;
    const p = sol.slice();
    let removed = 0;
    for (const i of shuffle([...Array(81).keys()])) {
      if (removed >= target) break;
      const keep = p[i]; p[i] = 0;
      if (sudokuSolve(p, 2).count !== 1) p[i] = keep; else removed++;
    }
    return { puzzle: p, sol };
  }
  function sudoku(H) {
    let lv = H.get().lv || 'facil';
    let P, cur, notes, given, sel, notesOn, errors, hints, done, hist;
    const root = h('div', { class: 'mg-sudoku' });
    const grid = h('div', { class: 'sd-grid' });
    const pad = h('div', { class: 'sd-pad' });
    root.append(grid, pad);
    const t = timer(() => status());
    const status = () => H.status([lv === 'facil' ? 'Fácil' : lv === 'medio' ? 'Medio' : 'Difícil', fmtTime(t.secs), `Errores: ${errors || 0}`, H.get()['best_' + lv] ? `Récord ${fmtTime(H.get()['best_' + lv])}` : '']);
    const cellsEl = [];
    for (let i = 0; i < 81; i++) {
      const c = h('button', { type: 'button', class: 'sd-c', 'data-i': i });
      if (i % 9 === 2 || i % 9 === 5) c.classList.add('br');
      if (Math.floor(i / 9) === 2 || Math.floor(i / 9) === 5) c.classList.add('bb');
      c.onclick = () => select(i);
      cellsEl.push(c); grid.append(c);
    }
    const padBtns = [];
    for (let d = 1; d <= 9; d++) {
      const b = h('button', { type: 'button', class: 'sd-n' }, h('b', { text: String(d) }), h('small'));
      b.onclick = () => input(d);
      padBtns.push(b); pad.append(b);
    }
    const bNotes = btn('Notas', () => { notesOn = !notesOn; bNotes.classList.toggle('on', notesOn); }, 'sd-tool');
    const bErase = btn('Borrar', () => input(0), 'sd-tool');
    const bUndo = btn('Deshacer', undo, 'sd-tool');
    const bHint = btn('Pista', hint, 'sd-tool');
    pad.append(h('div', { class: 'sd-tools' }, bUndo, bErase, bNotes, bHint));
    function newGame() {
      const old = root.querySelector('.mg-over'); if (old) old.remove();
      root.classList.add('busy');
      setTimeout(() => {
        P = sudokuMake(lv);
        cur = P.puzzle.slice(); given = P.puzzle.map(Boolean); notes = new Array(81).fill(0);
        sel = cur.findIndex(v => !v); notesOn = false; errors = 0; hints = 0; done = false; hist = [];
        bNotes.classList.remove('on');
        t.reset(); t.start();
        root.classList.remove('busy');
        render();
      }, 30);
    }
    function select(i) { sel = i; render(); }
    function input(d) {
      if (done || sel < 0 || given[sel]) return;
      if (notesOn && d) {
        hist.push([sel, cur[sel], notes[sel]]);
        notes[sel] ^= 1 << d; cur[sel] = 0;
      } else {
        if (cur[sel] === d && d) return;
        hist.push([sel, cur[sel], notes[sel]]);
        cur[sel] = d; notes[sel] = 0;
        if (d && d !== P.sol[sel]) { errors++; cellsEl[sel].classList.remove('shake'); void cellsEl[sel].offsetWidth; cellsEl[sel].classList.add('shake'); }
        if (d && d === P.sol[sel]) {
          // borrar esa nota de la fila, columna y caja
          const r = Math.floor(sel / 9), c = sel % 9, b = BOX(sel);
          for (let j = 0; j < 81; j++) if (Math.floor(j / 9) === r || j % 9 === c || BOX(j) === b) notes[j] &= ~(1 << d);
        }
      }
      render();
      if (cur.every((v, i) => v === P.sol[i])) win();
    }
    function undo() {
      const x = hist.pop(); if (!x || done) return;
      [sel, cur[x[0]], notes[x[0]]] = [x[0], x[1], x[2]];
      render();
    }
    function hint() {
      if (done) return;
      let i = sel >= 0 && !given[sel] && cur[sel] !== P.sol[sel] ? sel : cur.findIndex((v, k) => v !== P.sol[k]);
      if (i < 0) return;
      sel = i; hints++;
      const wasNotes = notesOn; notesOn = false; input(P.sol[i]); notesOn = wasNotes;
      cellsEl[i].classList.add('hinted');
    }
    function win() {
      done = true; t.stop();
      const st = H.get(); const s = Math.round(t.secs);
      st.wins = (st.wins || 0) + 1;
      const rec = !hints && (!st['best_' + lv] || s < st['best_' + lv]);
      if (rec) st['best_' + lv] = s;
      H.set(st); status();
      confetti(root);
      overlay(root, '¡Sudoku resuelto!', `${fmtTime(s)} · ${errors ? `${errors} errores` : 'sin errores'}${hints ? ` · ${hints} pistas` : ''}${rec ? ' · ¡nuevo récord!' : ''}`, [btn('Otro sudoku', newGame, 'primary')]);
    }
    function render() {
      const sv = sel >= 0 ? cur[sel] : 0;
      const r0 = Math.floor(sel / 9), c0 = sel % 9, b0 = sel >= 0 ? BOX(sel) : -1;
      const counts = new Array(10).fill(0);
      for (let i = 0; i < 81; i++) if (cur[i] && cur[i] === P.sol[i]) counts[cur[i]]++;
      for (let i = 0; i < 81; i++) {
        const c = cellsEl[i];
        c.classList.toggle('given', given[i]);
        c.classList.toggle('sel', i === sel);
        c.classList.toggle('rel', sel >= 0 && i !== sel && (Math.floor(i / 9) === r0 || i % 9 === c0 || BOX(i) === b0));
        c.classList.toggle('same', !!sv && cur[i] === sv && i !== sel);
        c.classList.toggle('err', !!cur[i] && !given[i] && cur[i] !== P.sol[i]);
        if (cur[i]) c.textContent = cur[i];
        else if (notes[i]) {
          c.replaceChildren(h('span', { class: 'sd-notes' }, ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map(d => h('i', { text: notes[i] & (1 << d) ? String(d) : '' }))));
        } else c.textContent = '';
      }
      padBtns.forEach((b, k) => { const left = 9 - counts[k + 1]; b.querySelector('small').textContent = left ? String(left) : ''; b.classList.toggle('full', !left); });
      status();
    }
    const key = (e) => {
      if (/^[1-9]$/.test(e.key)) { input(+e.key); return true; }
      if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') { input(0); return true; }
      if (e.key === 'n' || e.key === 'N') { bNotes.click(); return true; }
      if ((e.ctrlKey && e.key === 'z')) { undo(); return true; }
      const mv = { ArrowUp: -9, ArrowDown: 9, ArrowLeft: -1, ArrowRight: 1 }[e.key];
      if (mv && sel >= 0) { const n = sel + mv; if (n >= 0 && n < 81 && !(Math.abs(mv) === 1 && Math.floor(n / 9) !== Math.floor(sel / 9))) select(n); return true; }
      return false;
    };
    const tools = [
      seg([['facil', 'Fácil'], ['medio', 'Medio'], ['dificil', 'Difícil']], lv, (v) => { lv = v; const st = H.get(); st.lv = v; H.set(st); newGame(); }),
      btn('Nuevo', newGame)
    ];
    newGame();
    return { el: root, tools, key, help: 'Tocá una casilla y un número (o usá el teclado). "Notas" para anotar posibles.', hide: () => t.running && t.stop(), show: () => { if (!done && P) t.start(); } };
  }

  // =====================================================================
  // 2048
  // =====================================================================
  function g2048(H) {
    const N = 4;
    let grid, score, won, over, prev;
    let tiles = []; // {id, v, r, c, el, merged, isNew}
    let nextId = 1;
    const root = h('div', { class: 'mg-2048' });
    const board = h('div', { class: 'tz-board' });
    for (let i = 0; i < N * N; i++) board.append(h('div', { class: 'tz-bg' }));
    const layer = h('div', { class: 'tz-layer' });
    board.append(layer);
    root.append(board);
    const status = () => H.status([`Puntos ${score}`, `Mejor ${Math.max(H.get().best || 0, score)}`]);
    function addRandom() {
      const empty = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!grid[r][c]) empty.push([r, c]);
      if (!empty.length) return;
      const [r, c] = empty[rnd(empty.length)];
      const t = { id: nextId++, v: Math.random() < 0.9 ? 2 : 4, r, c, isNew: true };
      grid[r][c] = t; tiles.push(t);
    }
    function newGame() {
      const old = root.querySelector('.mg-over'); if (old) old.remove();
      grid = Array.from({ length: N }, () => new Array(N).fill(null));
      tiles = []; layer.replaceChildren(); score = 0; won = false; over = false; prev = null;
      addRandom(); addRandom(); render(); status();
    }
    function snapshot() { return { score, cells: grid.map(row => row.map(t => t ? t.v : 0)) }; }
    function restore(s) {
      grid = Array.from({ length: N }, () => new Array(N).fill(null)); tiles = []; layer.replaceChildren();
      s.cells.forEach((row, r) => row.forEach((v, c) => { if (v) { const t = { id: nextId++, v, r, c }; grid[r][c] = t; tiles.push(t); } }));
      score = s.score; over = false; render(); status();
    }
    function move(dir) {
      if (over) return;
      const before = snapshot();
      let moved = false;
      for (const t of tiles) { t.merged = false; t.isNew = false; }
      const vec = { left: [0, -1], right: [0, 1], up: [-1, 0], down: [1, 0] }[dir];
      const rs = [...Array(N).keys()], cs = [...Array(N).keys()];
      if (vec[0] === 1) rs.reverse();
      if (vec[1] === 1) cs.reverse();
      const gone = [];
      for (const r of rs) for (const c of cs) {
        const t = grid[r][c];
        if (!t) continue;
        let nr = r, nc = c;
        while (true) {
          const tr = nr + vec[0], tc = nc + vec[1];
          if (tr < 0 || tr >= N || tc < 0 || tc >= N) break;
          const o = grid[tr][tc];
          if (!o) { nr = tr; nc = tc; continue; }
          if (o.v === t.v && !o.merged && !o.dying) {
            // fusión
            grid[r][c] = null;
            o.v *= 2; o.merged = true; score += o.v;
            t.r = tr; t.c = tc; t.dying = true; gone.push(t);
            if (o.v === 2048 && !won) { won = true; setTimeout(() => { confetti(root); overlay(root, '¡Llegaste a 2048!', 'Podés seguir jugando para superar tu marca.', [btn('Seguir', () => root.querySelector('.mg-over').remove(), 'primary'), btn('Nueva partida', newGame)]); }, 250); }
            moved = true;
            nr = null;
            break;
          }
          break;
        }
        if (nr != null && (nr !== r || nc !== c)) { grid[r][c] = null; grid[nr][nc] = t; t.r = nr; t.c = nc; moved = true; }
      }
      if (!moved) return;
      prev = before;
      render();
      setTimeout(() => {
        for (const t of gone) { t.el && t.el.remove(); }
        tiles = tiles.filter(t => !t.dying);
        addRandom(); render();
        const st = H.get(); if (score > (st.best || 0)) { st.best = score; H.set(st); }
        status();
        if (!canMove()) { over = true; overlay(root, 'No hay más movimientos', `Hiciste ${score} puntos.`, [btn('Otra vez', newGame, 'primary'), btn('Deshacer', () => { root.querySelector('.mg-over').remove(); undo(); })]); }
      }, 120);
    }
    function undo() { if (prev) { restore(prev); prev = null; } }
    function canMove() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const t = grid[r][c]; if (!t) return true;
        if (c + 1 < N && grid[r][c + 1] && grid[r][c + 1].v === t.v) return true;
        if (r + 1 < N && grid[r + 1][c] && grid[r + 1][c].v === t.v) return true;
      }
      return false;
    }
    function render() {
      for (const t of tiles) {
        if (!t.el) { t.el = h('div', { class: 'tz-t' + (t.isNew ? ' new' : '') }, h('span')); layer.append(t.el); }
        t.el.style.setProperty('--r', t.r); t.el.style.setProperty('--c', t.c);
        t.el.dataset.v = t.v > 2048 ? 'big' : t.v;
        t.el.firstChild.textContent = t.v;
        t.el.classList.toggle('merged', !!t.merged && !t.dying);
        if (t.merged && !t.dying) { t.el.classList.remove('pop'); void t.el.offsetWidth; t.el.classList.add('pop'); }
        t.el.style.zIndex = t.dying ? 1 : 2;
      }
    }
    const key = (e) => {
      const d = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down', a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down' }[e.key];
      if (d) { move(d); return true; }
      if (e.ctrlKey && e.key === 'z') { undo(); return true; }
      return false;
    };
    let sx = 0, sy = 0;
    board.addEventListener('pointerdown', (e) => { sx = e.clientX; sy = e.clientY; });
    board.addEventListener('pointerup', (e) => {
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 30) return;
      move(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
    });
    const tools = [btn('Deshacer', undo), btn('Nueva partida', newGame)];
    newGame();
    return { el: root, tools, key, help: 'Flechas del teclado (o arrastrá) para juntar números iguales.' };
  }

  // =====================================================================
  // SOLITARIO (Klondike)
  // =====================================================================
  const SUITS = ['♠', '♥', '♦', '♣'];
  const RANKS = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const red = (s) => s === 1 || s === 2;
  function solitario(H) {
    let draw = H.get().draw || 1;
    let st, hist, moves, won, cardEls = {}, sizes;
    const root = h('div', { class: 'mg-sol' });
    const board = h('div', { class: 'so-board' });
    root.append(board);
    const t = timer(() => status());
    const status = () => H.status([`Movimientos ${moves || 0}`, fmtTime(t.secs), H.get()['best' + draw] ? `Récord ${fmtTime(H.get()['best' + draw])}` : '', `Ganadas ${H.get().wins || 0}`]);
    // lugares fijos
    const slots = {};
    const mkSlot = (id, cls) => { const s = h('div', { class: 'so-slot ' + cls, 'data-p': id }); slots[id] = s; board.append(s); return s; };
    mkSlot('stock', 'stock'); mkSlot('waste', 'waste');
    for (let i = 0; i < 4; i++) mkSlot('f' + i, 'found');
    for (let i = 0; i < 7; i++) mkSlot('t' + i, 'tab');
    slots.stock.append(h('span', { class: 'so-recycle', text: '↻' }));
    function cardEl(c) {
      let e = cardEls[c.id];
      if (!e) {
        const color = red(c.s) ? 'red' : 'black';
        const center = c.r > 10 ? h('span', { class: 'so-face' }, RANKS[c.r]) : h('span', { class: 'so-pip', text: SUITS[c.s] });
        e = h('div', { class: 'so-card ' + color, 'data-id': c.id },
          h('div', { class: 'so-front' },
            h('span', { class: 'so-corner' }, h('b', { text: RANKS[c.r] }), h('i', { text: SUITS[c.s] })),
            center,
            h('span', { class: 'so-corner br' }, h('b', { text: RANKS[c.r] }), h('i', { text: SUITS[c.s] }))),
          h('div', { class: 'so-back' }));
        cardEls[c.id] = e; board.append(e);
      }
      return e;
    }
    function deal() {
      const deck = [];
      for (let s = 0; s < 4; s++) for (let r = 1; r <= 13; r++) deck.push({ id: s * 13 + r, s, r, up: false });
      shuffle(deck);
      st = { stock: [], waste: [], f: [[], [], [], []], t: [[], [], [], [], [], [], []] };
      for (let i = 0; i < 7; i++) for (let j = i; j < 7; j++) { const c = deck.pop(); st.t[j].push(c); }
      for (let i = 0; i < 7; i++) st.t[i][st.t[i].length - 1].up = true;
      st.stock = deck;
      hist = []; moves = 0; won = false;
      const old = root.querySelector('.mg-over'); if (old) old.remove();
      t.reset();
      layout();
      // reparto animado: todas salen del mazo
      const sr = slotPos('stock');
      for (const c of [...st.stock, ...st.t.flat()]) cardEl(c);
      for (const id in cardEls) { cardEls[id].style.transition = 'none'; cardEls[id].style.left = sr.x + 'px'; cardEls[id].style.top = sr.y + 'px'; }
      void board.offsetWidth;
      render(true);
      status();
    }
    const clone = () => JSON.parse(JSON.stringify(st));
    function push() { hist.push(clone()); if (hist.length > 200) hist.shift(); }
    function undo() { if (!hist.length || won) return; st = hist.pop(); moves++; render(); status(); }
    function layout() {
      const W = Math.max(520, board.clientWidth || 900);
      const cw = Math.min(118, Math.floor((W - 8 * 14) / 7));
      const ch = Math.round(cw * 1.4);
      const gap = Math.max(10, Math.floor((W - cw * 7) / 8));
      sizes = { cw, ch, gap, top: 8, tabTop: 8 + ch + 26 };
      board.style.setProperty('--cw', cw + 'px');
      board.style.setProperty('--ch', ch + 'px');
      const place = (id, x, y) => { slots[id].style.left = x + 'px'; slots[id].style.top = y + 'px'; };
      const colX = (i) => gap + i * (cw + gap);
      place('stock', colX(0), sizes.top); place('waste', colX(1), sizes.top);
      for (let i = 0; i < 4; i++) place('f' + i, colX(3 + i), sizes.top);
      for (let i = 0; i < 7; i++) place('t' + i, colX(i), sizes.tabTop);
    }
    function slotPos(id) { return { x: parseFloat(slots[id].style.left) || 0, y: parseFloat(slots[id].style.top) || 0 }; }
    function render(dealing) {
      const H2 = board.clientHeight || 600;
      let z = 1;
      const set = (c, x, y, up, delay) => {
        const e = cardEl(c);
        if (dealing) e.style.transition = `left .32s ${delay}ms cubic-bezier(.2,.8,.2,1), top .32s ${delay}ms cubic-bezier(.2,.8,.2,1), transform .3s`;
        else if (!e.classList.contains('drag')) e.style.transition = '';
        e.style.left = x + 'px'; e.style.top = y + 'px'; e.style.zIndex = z++;
        e.classList.toggle('up', up);
      };
      const sp = slotPos('stock');
      st.stock.forEach((c, i) => set(c, sp.x + Math.min(i, 6) * 0.6, sp.y - Math.min(i, 6) * 0.6, false, 0));
      const wp = slotPos('waste');
      const fan = draw === 3 ? 3 : 1;
      const wl = st.waste.length;
      st.waste.forEach((c, i) => { const k = Math.max(0, i - (wl - fan)); set(c, wp.x + k * sizes.cw * 0.28, wp.y, true, 0); });
      st.f.forEach((pile, i) => { const p = slotPos('f' + i); pile.forEach(c => set(c, p.x, p.y, true, 0)); });
      let d = 0;
      st.t.forEach((pile, i) => {
        const p = slotPos('t' + i);
        // si la columna es muy larga, se aprieta
        const downs = pile.filter(c => !c.up).length, ups = pile.length - downs;
        let du = sizes.ch * 0.12, uu = sizes.ch * 0.26;
        const need = p.y + downs * du + Math.max(0, ups - 1) * uu + sizes.ch;
        if (need > H2 - 8 && ups > 1) uu = Math.max(sizes.ch * 0.14, (H2 - 8 - sizes.ch - p.y - downs * du) / (ups - 1));
        let y = p.y;
        pile.forEach((c, j) => { set(c, p.x, y, c.up, dealing ? (d++) * 22 : 0); y += c.up ? uu : du; });
      });
      slots.stock.classList.toggle('empty', !st.stock.length);
      checkAuto();
    }
    function find(id) {
      for (const k of ['stock', 'waste']) { const i = st[k].findIndex(c => c.id === id); if (i >= 0) return { pile: st[k], key: k, i }; }
      for (let n = 0; n < 4; n++) { const i = st.f[n].findIndex(c => c.id === id); if (i >= 0) return { pile: st.f[n], key: 'f' + n, i }; }
      for (let n = 0; n < 7; n++) { const i = st.t[n].findIndex(c => c.id === id); if (i >= 0) return { pile: st.t[n], key: 't' + n, i }; }
      return null;
    }
    const pileOf = (key) => key === 'stock' ? st.stock : key === 'waste' ? st.waste : key[0] === 'f' ? st.f[+key[1]] : st.t[+key[1]];
    function canDrop(cards, key) {
      const c = cards[0], pile = pileOf(key), top = pile[pile.length - 1];
      if (key[0] === 'f') return cards.length === 1 && (top ? top.s === c.s && top.r === c.r - 1 : c.r === 1);
      if (key[0] === 't') return top ? top.up && red(top.s) !== red(c.s) && top.r === c.r + 1 : c.r === 13;
      return false;
    }
    function doMove(fromKey, i, toKey) {
      push();
      const from = pileOf(fromKey);
      const cards = from.splice(i);
      pileOf(toKey).push(...cards);
      const last = from[from.length - 1];
      if (fromKey[0] === 't' && last && !last.up) last.up = true;
      moves++; t.start();
      render(); status();
      if (st.f.every(p => p.length === 13)) victory();
    }
    function drawCard() {
      if (won) return;
      push(); t.start(); moves++;
      if (!st.stock.length) {
        if (!st.waste.length) { hist.pop(); moves--; return; }
        st.stock = st.waste.reverse().map(c => ({ ...c, up: false })); st.waste = [];
      } else {
        for (let k = 0; k < draw && st.stock.length; k++) { const c = st.stock.pop(); c.up = true; st.waste.push(c); }
      }
      render(); status();
    }
    function autoMove(loc) {
      const cards = loc.pile.slice(loc.i);
      if (cards.length === 1) for (let n = 0; n < 4; n++) if (canDrop(cards, 'f' + n)) return doMove(loc.key, loc.i, 'f' + n);
      const order = [...Array(7).keys()].map(n => 't' + n).filter(k => k !== loc.key);
      const nonEmpty = order.filter(k => pileOf(k).length), empty = order.filter(k => !pileOf(k).length);
      for (const k of [...nonEmpty, ...(loc.i === 0 && loc.key[0] === 't' ? [] : empty)]) if (canDrop(cards, k)) return doMove(loc.key, loc.i, k);
      const e = cardEls[cards[0].id]; e.classList.remove('nope'); void e.offsetWidth; e.classList.add('nope');
    }
    let autoBtn = null;
    function checkAuto() {
      const ready = !won && !st.stock.length && !st.waste.length && st.t.every(p => p.every(c => c.up)) && st.f.some(p => p.length < 13);
      if (ready && !autoBtn) { autoBtn = btn('Terminar solo ✨', autoFinish, 'primary so-auto'); root.append(autoBtn); }
      if (!ready && autoBtn) { autoBtn.remove(); autoBtn = null; }
    }
    function autoFinish() {
      if (autoBtn) { autoBtn.remove(); autoBtn = null; }
      const step = () => {
        for (let n = 0; n < 7; n++) {
          const p = st.t[n]; if (!p.length) continue;
          for (let f = 0; f < 4; f++) if (canDrop([p[p.length - 1]], 'f' + f)) { doMove('t' + n, p.length - 1, 'f' + f); if (!won) setTimeout(step, 70); return; }
        }
      };
      step();
    }
    function victory() {
      won = true; t.stop();
      const s = H.get(); const secs = Math.round(t.secs);
      s.wins = (s.wins || 0) + 1;
      const rec = !s['best' + draw] || secs < s['best' + draw];
      if (rec) s['best' + draw] = secs;
      H.set(s); status();
      // las cartas saltan
      Object.values(cardEls).forEach((e, i) => setTimeout(() => e.classList.add('jump'), i * 25));
      confetti(root);
      setTimeout(() => overlay(root, '¡Ganaste!', `${moves} movimientos · ${fmtTime(secs)}${rec ? ' · ¡nuevo récord!' : ''}`, [btn('Repartir de nuevo', deal, 'primary')]), 900);
    }
    // arrastrar y soltar
    let drag = null;
    board.addEventListener('pointerdown', (e) => {
      if (won || e.button !== 0) return;
      const ce = e.target.closest('.so-card');
      const slot = e.target.closest('.so-slot');
      if (!ce) { if (slot && slot.dataset.p === 'stock') drawCard(); return; }
      const loc = find(+ce.dataset.id);
      if (!loc) return;
      if (loc.key === 'stock') return drawCard();
      const c = loc.pile[loc.i];
      if (!c.up) return;
      if ((loc.key === 'waste' || loc.key[0] === 'f') && loc.i !== loc.pile.length - 1) return;
      const els = loc.pile.slice(loc.i).map(x => cardEls[x.id]);
      drag = { loc, els, x0: e.clientX, y0: e.clientY, moved: false, starts: els.map(el => ({ l: parseFloat(el.style.left), t: parseFloat(el.style.top) })) };
      board.setPointerCapture(e.pointerId);
    });
    board.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
      if (!drag.moved && Math.hypot(dx, dy) < 5) return;
      if (!drag.moved) { drag.moved = true; drag.els.forEach((el, k) => { el.classList.add('drag'); el.style.transition = 'none'; el.style.zIndex = 1000 + k; }); }
      drag.els.forEach((el, k) => { el.style.left = (drag.starts[k].l + dx) + 'px'; el.style.top = (drag.starts[k].t + dy) + 'px'; });
    });
    const endDrag = (e) => {
      if (!drag) return;
      const d = drag; drag = null;
      d.els.forEach(el => el.classList.remove('drag'));
      if (!d.moved) return autoMove(d.loc);
      // ¿sobre qué pila se soltó? Usamos el centro de la carta arrastrada
      const r0 = d.els[0].getBoundingClientRect();
      const cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 3;
      const cards = d.loc.pile.slice(d.loc.i);
      let target = null, bestDist = Infinity;
      for (const key of [...[0, 1, 2, 3].map(n => 'f' + n), ...[0, 1, 2, 3, 4, 5, 6].map(n => 't' + n)]) {
        if (key === d.loc.key) continue;
        const pile = pileOf(key);
        const ref = pile.length ? cardEls[pile[pile.length - 1].id] : slots[key];
        const r = ref.getBoundingClientRect();
        const inside = cx > r.left - 20 && cx < r.right + 20 && cy > r.top - 30 && cy < r.bottom + 40;
        if (!inside) continue;
        const dist = Math.hypot(cx - (r.left + r.width / 2), cy - (r.top + r.height / 2));
        if (dist < bestDist && canDrop(cards, key)) { bestDist = dist; target = key; }
      }
      if (target) doMove(d.loc.key, d.loc.i, target);
      else render();
    };
    board.addEventListener('pointerup', endDrag);
    board.addEventListener('pointercancel', endDrag);
    board.addEventListener('dblclick', (e) => e.preventDefault());
    const ro = new ResizeObserver(() => { if (st) { layout(); render(); } });
    ro.observe(board);
    const key = (e) => { if (e.ctrlKey && e.key === 'z') { undo(); return true; } if (e.key === ' ') { drawCard(); return true; } return false; };
    const tools = [
      seg([[1, 'Robar 1'], [3, 'Robar 3']], draw, (v) => { draw = v; const s = H.get(); s.draw = v; H.set(s); deal(); }),
      btn('Deshacer', undo), btn('Repartir', deal)
    ];
    requestAnimationFrame(deal);
    return { el: root, tools, key, help: 'Arrastrá las cartas, o tocá una para moverla sola. Tocá el mazo para robar. Ctrl+Z deshace.', hide: () => t.running && t.stop(), show: () => { if (moves && !won) t.start(); if (st) { layout(); render(); } } };
  }

  // =====================================================================
  // MAHJONG (solitario de fichas)
  // =====================================================================
  const DOTS = {
    1: [[15, 20]], 2: [[15, 11], [15, 29]], 3: [[8, 9], [15, 20], [22, 31]], 4: [[9, 11], [21, 11], [9, 29], [21, 29]],
    5: [[9, 10], [21, 10], [15, 20], [9, 30], [21, 30]], 6: [[9, 9], [21, 9], [9, 20], [21, 20], [9, 31], [21, 31]],
    7: [[7, 7], [15, 11], [23, 15], [9, 25], [21, 25], [9, 33], [21, 33]], 8: [[9, 6], [21, 6], [9, 15], [21, 15], [9, 25], [21, 25], [9, 34], [21, 34]],
    9: [[7, 9], [15, 9], [23, 9], [7, 20], [15, 20], [23, 20], [7, 31], [15, 31], [23, 31]]
  };
  const CN = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  const MJ_KINDS = [];
  for (let n = 1; n <= 9; n++) MJ_KINDS.push({ k: 'd' + n }, { k: 'b' + n }, { k: 'c' + n });
  for (const w of ['東', '南', '西', '北']) MJ_KINDS.push({ k: 'w' + w });
  MJ_KINDS.push({ k: 'r中' }, { k: 'g發' }, { k: 'x白' });
  const faceCache = {};
  const CJK = "font-family=\"'Microsoft YaHei','Microsoft JhengHei','Noto Sans CJK SC','SimHei',sans-serif\"";
  const LAT = "font-family=\"'Segoe UI',Arial,sans-serif\"";
  // número chiquito en la esquina: ayuda a distinguir las fichas de un vistazo
  const corner = (txt, col) => `<text x="2.6" y="8.6" font-size="8" font-weight="800" fill="${col}" ${LAT}>${txt}</text>`;
  const WIND_ES = { '東': 'E', '南': 'S', '西': 'O', '北': 'N' };
  function mjFace(k) {
    if (faceCache[k]) return faceCache[k];
    const t = k[0], v = k.slice(1);
    let body = '';
    if (t === 'd') {
      // círculos: más grandes y con borde grueso
      const n = +v, big = n === 1;
      const sx = (x) => 15 + (x - 15) * 1.04, sy = (y) => 24.2 + (y - 20) * 0.8;
      body = DOTS[n].map(([x, y], i) => {
        const col = big ? '#c0392b' : n <= 2 ? '#1f6fb2' : (i % 3 === 0 ? '#c0392b' : i % 3 === 1 ? '#1f6fb2' : '#1e8449');
        const r = big ? 9.5 : n >= 7 ? 3.4 : n >= 5 ? 4.1 : 4.6;
        return `<circle cx="${sx(x)}" cy="${sy(y)}" r="${r}" fill="#fff" stroke="${col}" stroke-width="${big ? 2.6 : 1.9}"/><circle cx="${sx(x)}" cy="${sy(y)}" r="${r * .5}" fill="${col}"/>`;
      }).join('') + (big ? '' : corner(n, '#1f6fb2'));
    } else if (t === 'b') {
      // cañas: palitos gruesos verdes
      const n = +v;
      if (n === 1) body = '<g transform="translate(15 25) scale(.84) translate(-15 -22)"><path d="M15 7c5 0 8 5 6 10l-2 6 5 4-6 2 1 8h-8l1-8-6-2 5-4-2-6c-2-5 1-10 6-10z" fill="#1e8449"/><circle cx="15" cy="13" r="2.2" fill="#c0392b"/></g>' + corner(1, '#1e8449');
      else body = DOTS[n].map(([x, y], i) => {
        const X = 15 + (x - 15) * 1.05, Y = 24.2 + (y - 20) * 0.8, w = n >= 7 ? 4.4 : 5.4, hh = n >= 7 ? 6.8 : 9;
        const col = (n === 9 || n === 5 || n === 7) && i % 3 === 1 ? '#c0392b' : '#1e8449';
        return `<rect x="${X - w / 2}" y="${Y - hh / 2}" width="${w}" height="${hh}" rx="${w / 2}" fill="${col}"/><path d="M${X - w / 2} ${Y}h${w}" stroke="#fff" stroke-width="1"/>`;
      }).join('') + corner(n, '#1e8449');
    } else if (t === 'c') {
      // caracteres: el número bien grande y "萬" abajo
      body = `<text x="15" y="21" text-anchor="middle" font-size="17" font-weight="800" fill="#1a1a1a" ${LAT}>${v}</text><text x="15" y="36" text-anchor="middle" font-size="12.5" font-weight="700" fill="#c0392b" ${CJK}>萬</text>` + `<text x="27.4" y="8.6" text-anchor="end" font-size="7" font-weight="700" fill="#1a1a1a" ${CJK}>${CN[+v]}</text>`;
    } else if (t === 'w') {
      body = `<text x="15" y="29" text-anchor="middle" font-size="20" font-weight="800" fill="#1a1a1a" ${CJK}>${v}</text><text x="15" y="38.2" text-anchor="middle" font-size="7.5" font-weight="800" fill="#566573" ${LAT}>${WIND_ES[v] || ''}</text>`;
    } else if (t === 'r' || t === 'g') {
      body = `<text x="15" y="30" text-anchor="middle" font-size="22" font-weight="900" fill="${t === 'r' ? '#c0392b' : '#1e8449'}" ${CJK}>${v}</text>`;
    } else body = '<rect x="6.5" y="8" width="17" height="24" rx="2.5" fill="none" stroke="#1f6fb2" stroke-width="2.6"/><rect x="10" y="11.5" width="10" height="17" rx="1" fill="none" stroke="#1f6fb2" stroke-width="1.2"/>';
    return (faceCache[k] = `<svg viewBox="0 0 30 40" aria-hidden="true">${body}</svg>`);
  }
  const MJ_LAYOUTS = {
    piramide: () => {
      const p = [];
      for (let y = 0; y < 6; y++) for (let x = 0; x < 10; x++) p.push({ x, y, z: 0 });
      for (let y = 1; y < 5; y++) for (let x = 1; x < 9; x++) p.push({ x, y, z: 1 });
      for (let y = 2; y < 4; y++) for (let x = 2; x < 8; x++) p.push({ x, y, z: 2 });
      for (let y = 2; y < 4; y++) for (let x = 4; x < 6; x++) p.push({ x, y, z: 3 });
      return p; // 108
    },
    fortaleza: () => {
      const p = [];
      for (let y = 0; y < 6; y++) for (let x = 0; x < 12; x++) if (!(y >= 2 && y <= 3 && x >= 4 && x <= 7)) p.push({ x, y, z: 0 });
      for (let y = 0; y < 6; y++) for (let x of [0, 1, 10, 11]) p.push({ x, y, z: 1 });
      for (let y = 1; y < 5; y++) for (let x of [0, 11]) p.push({ x, y, z: 2 });
      for (let y = 2; y < 4; y++) for (let x = 4; x < 8; x++) p.push({ x, y, z: 0 });
      for (let y = 2; y < 4; y++) for (let x = 5; x < 7; x++) p.push({ x, y, z: 1 });
      return p; // 64 + 24 + 8 + 8 + 4 = 108
    },
    mariposa: () => {
      const p = [];
      const rows = [[0, 1, 2, 3, 8, 9, 10, 11], [0, 1, 2, 3, 4, 7, 8, 9, 10, 11], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [0, 1, 2, 3, 4, 7, 8, 9, 10, 11], [0, 1, 2, 3, 8, 9, 10, 11]];
      rows.forEach((xs, y) => xs.forEach(x => p.push({ x, y, z: 0 })));
      for (let y = 1; y < 5; y++) for (const x of [1, 2, 3, 8, 9, 10]) p.push({ x, y, z: 1 });
      for (let y = 2; y < 4; y++) for (const x of [2, 3, 5, 6, 8, 9]) p.push({ x, y, z: 2 });
      for (let y = 2; y < 4; y++) for (const x of [5, 6]) p.push({ x, y, z: 3 });
      return p; // 56 + 24 + 12 + 4 = 96
    }
  };
  function mahjong(H) {
    let lay = H.get().lay || 'piramide';
    let tiles, selId, hist, done, mapPos;
    const root = h('div', { class: 'mg-mj' });
    const board = h('div', { class: 'mj-board' });
    root.append(board);
    const t = timer(() => status());
    const left = () => tiles ? tiles.filter(x => !x.gone).length : 0;
    const status = () => H.status([`Quedan ${left()}`, fmtTime(t.secs), `Jugadas posibles ${tiles ? pairsAvail().length : 0}`, H.get()['best_' + lay] ? `Récord ${fmtTime(H.get()['best_' + lay])}` : '']);
    const keyOf = (x, y, z) => `${x},${y},${z}`;
    function isFree(tile, alive) {
      const has = (x, y, z) => alive.has(keyOf(x, y, z));
      if (has(tile.x, tile.y, tile.z + 1)) return false;
      return !has(tile.x - 1, tile.y, tile.z) || !has(tile.x + 1, tile.y, tile.z);
    }
    // asigna figuras de forma que siempre haya solución (se arma "al revés", sacando pares libres)
    function assign(list) {
      for (let tries = 0; tries < 60; tries++) {
        const alive = new Set(list.map(p => keyOf(p.x, p.y, p.z)));
        const remain = list.slice();
        const pairs = [];
        let ok = true;
        while (remain.length) {
          const free = remain.filter(p => isFree(p, alive));
          if (free.length < 2) { ok = false; break; }
          shuffle(free);
          // preferimos sacar fichas de arriba para que la solución no quede "trabada"
          free.sort((a, b) => b.z - a.z);
          const a = free[rnd(Math.min(free.length, 4))];
          const rest = free.filter(p => p !== a);
          const b = rest[rnd(rest.length)];
          pairs.push([a, b]);
          for (const p of [a, b]) { alive.delete(keyOf(p.x, p.y, p.z)); remain.splice(remain.indexOf(p), 1); }
        }
        if (!ok) continue;
        const kinds = [];
        while (kinds.length < pairs.length) kinds.push(...shuffle(MJ_KINDS.slice()));
        shuffle(kinds);
        pairs.forEach(([a, b], i) => { a.k = kinds[i].k; b.k = kinds[i].k; });
        return true;
      }
      return false;
    }
    function newGame() {
      const old = root.querySelector('.mg-over'); if (old) old.remove();
      const pos = MJ_LAYOUTS[lay]();
      tiles = pos.map((p, i) => ({ id: i, ...p, k: '', gone: false }));
      assign(tiles);
      selId = null; hist = []; done = false;
      t.reset();
      build();
    }
    function sizesFor() {
      const maxX = Math.max(...tiles.map(p => p.x)) + 1, maxY = Math.max(...tiles.map(p => p.y)) + 1;
      const W = board.clientWidth || 900, Hh = board.clientHeight || 560;
      const tw = Math.floor(Math.min(74, (W - 40) / (maxX + 0.4), ((Hh - 40) / (maxY + 0.4)) / 1.32));
      return { tw, th: Math.round(tw * 1.32), dz: Math.max(4, Math.round(tw * 0.1)), maxX, maxY };
    }
    function build() {
      board.replaceChildren();
      const s = sizesFor();
      board.style.setProperty('--tw', s.tw + 'px'); board.style.setProperty('--th', s.th + 'px'); board.style.setProperty('--dz', s.dz + 'px');
      const offX = Math.round(((board.clientWidth || 900) - s.maxX * s.tw) / 2), offY = Math.round(((board.clientHeight || 560) - s.maxY * s.th) / 2) + 6;
      for (const tl of tiles) {
        const e = h('button', { type: 'button', class: 'mj-t', 'data-id': tl.id, style: `left:${offX + tl.x * s.tw - tl.z * s.dz}px;top:${offY + tl.y * s.th - tl.z * s.dz}px;z-index:${tl.z * 1000 + tl.y * 20 + (20 - tl.x)}` });
        e.innerHTML = mjFace(tl.k);
        tl.el = e;
        if (tl.gone) e.classList.add('gone');
        board.append(e);
      }
      refresh();
    }
    function aliveSet() { return new Set(tiles.filter(x => !x.gone).map(p => keyOf(p.x, p.y, p.z))); }
    function pairsAvail() {
      const alive = aliveSet();
      const free = tiles.filter(x => !x.gone && isFree(x, alive));
      const out = [];
      for (let i = 0; i < free.length; i++) for (let j = i + 1; j < free.length; j++) if (free[i].k === free[j].k) out.push([free[i], free[j]]);
      return out;
    }
    function refresh() {
      const alive = aliveSet();
      for (const tl of tiles) if (!tl.gone) { tl.el.classList.toggle('free', isFree(tl, alive)); tl.el.classList.toggle('sel', tl.id === selId); }
      status();
      if (!done && left() && !pairsAvail().length) setTimeout(() => overlay(root, 'No quedan jugadas', 'Podés mezclar las fichas que quedan o deshacer.', [btn('Mezclar', () => { root.querySelector('.mg-over').remove(); reshuffle(); }, 'primary'), btn('Deshacer', () => { root.querySelector('.mg-over').remove(); undo(); })]), 300);
    }
    function clickTile(tl) {
      if (done || tl.gone) return;
      const alive = aliveSet();
      if (!isFree(tl, alive)) { tl.el.classList.remove('nope'); void tl.el.offsetWidth; tl.el.classList.add('nope'); return; }
      t.start();
      if (selId == null || selId === tl.id) { selId = selId === tl.id ? null : tl.id; refresh(); return; }
      const other = tiles[selId];
      if (other.k !== tl.k) { selId = tl.id; refresh(); return; }
      other.gone = tl.gone = true;
      hist.push([other.id, tl.id]);
      for (const x of [other, tl]) x.el.classList.add('gone');
      selId = null;
      if (!left()) return win();
      refresh();
    }
    function undo() {
      const p = hist.pop(); if (!p || done) return;
      for (const id of p) { tiles[id].gone = false; tiles[id].el.classList.remove('gone'); }
      selId = null; refresh();
    }
    function hint() {
      const ps = pairsAvail(); if (!ps.length) return;
      const [a, b] = ps[rnd(ps.length)];
      for (const x of [a, b]) { x.el.classList.remove('hint'); void x.el.offsetWidth; x.el.classList.add('hint'); }
    }
    function reshuffle() {
      const rest = tiles.filter(x => !x.gone);
      const kinds = rest.map(x => x.k);
      if (!assign(rest)) { shuffle(kinds); rest.forEach((x, i) => x.k = kinds[i]); }
      hist = [];
      for (const x of rest) x.el.innerHTML = mjFace(x.k);
      selId = null; refresh();
    }
    function win() {
      done = true; t.stop();
      const s = H.get(); const secs = Math.round(t.secs);
      s.wins = (s.wins || 0) + 1;
      const rec = !s['best_' + lay] || secs < s['best_' + lay];
      if (rec) s['best_' + lay] = secs;
      H.set(s); status();
      confetti(root);
      overlay(root, '¡Tablero limpio!', `${fmtTime(secs)}${rec ? ' · ¡nuevo récord!' : ''}`, [btn('Otra partida', newGame, 'primary')]);
    }
    board.addEventListener('click', (e) => { const b = e.target.closest('.mj-t'); if (b) clickTile(tiles[+b.dataset.id]); });
    const ro = new ResizeObserver(() => { if (tiles) build(); });
    ro.observe(board);
    const key = (e) => { if (e.ctrlKey && e.key === 'z') { undo(); return true; } if (e.key === 'h' || e.key === 'H') { hint(); return true; } return false; };
    const tools = [
      seg([['piramide', 'Pirámide'], ['fortaleza', 'Fortaleza'], ['mariposa', 'Mariposa']], lay, (v) => { lay = v; const s = H.get(); s.lay = v; H.set(s); newGame(); }),
      btn('Pista', hint), btn('Deshacer', undo), btn('Mezclar', reshuffle), btn('Nueva', newGame)
    ];
    requestAnimationFrame(newGame);
    return { el: root, tools, key, help: 'Juntá pares de fichas iguales que estén libres (sin nada arriba y con un costado libre).', hide: () => t.running && t.stop(), show: () => { if (hist && hist.length && !done) t.start(); } };
  }

  // ---------- catálogo ----------
  const GAMES = [
    { id: 'solitario', n: 'Solitario', d: 'El clásico de cartas. Robá de a 1 o de a 3.', c: '#1e8449', create: solitario,
      art: '<svg viewBox="0 0 64 64"><rect x="10" y="12" width="26" height="36" rx="4" fill="#fff" transform="rotate(-12 23 30)"/><rect x="24" y="14" width="28" height="38" rx="4" fill="#fff" stroke="rgba(0,0,0,.15)"/><text x="38" y="40" font-size="20" text-anchor="middle" fill="#c0392b">♥</text><text x="29" y="25" font-size="9" font-weight="700" fill="#c0392b">A</text></svg>',
      best: (s) => s.wins ? `${s.wins} ganadas${s.best1 ? ` · récord ${fmtTime(s.best1)}` : ''}` : 'Nunca jugaste' },
    { id: 'sudoku', n: 'Sudoku', d: 'Tres niveles, notas y pistas.', c: '#3a6fd8', create: sudoku,
      art: '<svg viewBox="0 0 64 64"><rect x="12" y="12" width="40" height="40" rx="5" fill="#fff"/><path d="M25.3 12v40M38.6 12v40M12 25.3h40M12 38.6h40" stroke="#3a6fd8" stroke-width="1.6"/><text x="18.6" y="23" font-size="9" font-weight="700" text-anchor="middle" fill="#1a1a1a">5</text><text x="32" y="36" font-size="9" font-weight="700" text-anchor="middle" fill="#3a6fd8">3</text><text x="45" y="49" font-size="9" font-weight="700" text-anchor="middle" fill="#1a1a1a">9</text></svg>',
      best: (s) => s.wins ? `${s.wins} resueltos${s.best_facil ? ` · fácil ${fmtTime(s.best_facil)}` : ''}` : 'Nunca jugaste' },
    { id: 'mahjong', n: 'Mahjong', d: 'Juntá pares de fichas libres. Tres tableros.', c: '#b7472a', create: mahjong,
      art: '<svg viewBox="0 0 64 64"><rect x="12" y="20" width="20" height="28" rx="3" fill="#e9dfc9"/><rect x="14" y="16" width="20" height="28" rx="3" fill="#fffaf0" stroke="rgba(0,0,0,.15)"/><text x="24" y="36" font-size="13" font-weight="800" text-anchor="middle" fill="#c0392b">中</text><rect x="32" y="22" width="20" height="28" rx="3" fill="#e9dfc9"/><rect x="34" y="18" width="20" height="28" rx="3" fill="#fffaf0" stroke="rgba(0,0,0,.15)"/><circle cx="44" cy="32" r="5" fill="none" stroke="#1f6fb2" stroke-width="2"/><circle cx="44" cy="32" r="2" fill="#1f6fb2"/></svg>',
      best: (s) => s.wins ? `${s.wins} tableros limpios` : 'Nunca jugaste' },
    { id: 'buscaminas', n: 'Buscaminas', d: 'Encontrá todas las minas sin pisar ninguna.', c: '#566573', create: buscaminas,
      art: '<svg viewBox="0 0 64 64"><g fill="#d5dbe1"><rect x="12" y="12" width="12" height="12" rx="2"/><rect x="26" y="12" width="12" height="12" rx="2"/><rect x="40" y="12" width="12" height="12" rx="2"/><rect x="12" y="26" width="12" height="12" rx="2"/><rect x="12" y="40" width="12" height="12" rx="2"/></g><text x="32" y="35" font-size="10" font-weight="800" text-anchor="middle" fill="#1f6fb2">1</text><text x="46" y="35" font-size="10" font-weight="800" text-anchor="middle" fill="#1e8449">2</text><circle cx="39" cy="45" r="6" fill="#1a1a1a"/><path d="M39 36v18M30 45h18M33 39l12 12M45 39 33 51" stroke="#1a1a1a" stroke-width="2"/><circle cx="37" cy="43" r="1.5" fill="#fff"/></svg>',
      best: (s) => s.wins ? `${s.wins} ganadas${s.best_facil ? ` · fácil ${fmtTime(s.best_facil)}` : ''}` : 'Nunca jugaste' },
    { id: '2048', n: '2048', d: 'Juntá números iguales hasta llegar a 2048.', c: '#e08e1b', create: g2048,
      art: '<svg viewBox="0 0 64 64"><rect x="10" y="10" width="44" height="44" rx="6" fill="#bbada0"/><rect x="14" y="14" width="17" height="17" rx="3" fill="#eee4da"/><rect x="33" y="14" width="17" height="17" rx="3" fill="#f2b179"/><rect x="14" y="33" width="17" height="17" rx="3" fill="#f67c5f"/><rect x="33" y="33" width="17" height="17" rx="3" fill="#edc22e"/><text x="22.5" y="26" font-size="9" font-weight="800" text-anchor="middle" fill="#776e65">2</text><text x="41.5" y="45" font-size="6.5" font-weight="800" text-anchor="middle" fill="#fff">2048</text></svg>',
      best: (s) => s.best ? `Mejor: ${s.best} puntos` : 'Nunca jugaste' }
  ];

  window.BaseMini = { GAMES, fmtTime, util: { h, rnd, shuffle, timer, seg, btn, overlay, confetti, fmtTime } };
})();
