﻿# Ayudante de Base para ver y manejar las ventanas abiertas de Windows.
# Corre escondido, recibe órdenes por la entrada estándar y responde una línea JSON por orden.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8

# Compilar el C# tarda (y en algunas compus, con antivirus, mucho): la primera vez se guarda compilado en
# %LOCALAPPDATA%\Base\ayudante y las siguientes se carga directo. Si algo de eso falla, se compila en memoria como antes.
function LoadCs([string]$name, [string]$typeName, [string]$src, [string[]]$refs) {
  if ($typeName -as [type]) { return }
  try {
    $dir = Join-Path $env:LOCALAPPDATA 'Base\ayudante'
    $sha = [Security.Cryptography.SHA256]::Create()
    $hb = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($src + '|' + $PSVersionTable.PSVersion + '|' + [IntPtr]::Size + '|' + ($refs -join ',')))
    $h = -join ($hb[0..7] | ForEach-Object { $_.ToString('x2') })
    $dll = Join-Path $dir "$name-$h.dll"
    if (-not (Test-Path $dll)) {
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      Get-ChildItem -Path $dir -Filter "$name-*.dll" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
      $p = @{ TypeDefinition = $src; Language = 'CSharp'; OutputAssembly = $dll; OutputType = 'Library' }
      if ($refs) { $p.ReferencedAssemblies = $refs }
      Add-Type @p
    }
    if (-not ($typeName -as [type])) { Add-Type -Path $dll }
  } catch { }
  if ($typeName -as [type]) { return }
  $p = @{ TypeDefinition = $src; Language = 'CSharp' }
  if ($refs) { $p.ReferencedAssemblies = $refs }
  Add-Type @p
}

$code = @'
using System;
using System.Text;
using System.Runtime.InteropServices;

public static class BaseWin {
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte sc, uint f, UIntPtr e);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int s);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a, bool i, uint pid);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, int f, StringBuilder s, ref int n);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

  static string Esc(string s) {
    var b = new StringBuilder();
    foreach (char c in s) {
      if (c == '"' || c == '\\') b.Append('\\').Append(c);
      else if (c < 32) b.AppendFormat("\\u{0:x4}", (int)c);
      else b.Append(c);
    }
    return b.ToString();
  }
  static string ExePath(uint pid) {
    IntPtr h = OpenProcess(0x1000, false, pid);
    if (h == IntPtr.Zero) return "";
    var sb = new StringBuilder(1024); int n = 1024;
    string r = QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : "";
    CloseHandle(h);
    return r;
  }
  static bool IsAppWindow(IntPtr h) {
    if (!IsWindowVisible(h)) return false;
    if (GetWindow(h, 4) != IntPtr.Zero) return false;           // tiene dueño (diálogos)
    if ((GetWindowLong(h, -20) & 0x80) != 0) return false;      // ventana de herramientas
    int cloaked = 0; DwmGetWindowAttribute(h, 14, out cloaked, 4);
    if (cloaked != 0) return false;                             // oculta (otro escritorio, apps suspendidas)
    return GetWindowTextLength(h) > 0;
  }
  public static string List(long self) {
    IntPtr fg = GetForegroundWindow();
    var sb = new StringBuilder("["); bool first = true;
    EnumWindows((h, l) => {
      if (h.ToInt64() == self || !IsAppWindow(h)) return true;
      int len = GetWindowTextLength(h);
      var t = new StringBuilder(len + 1); GetWindowText(h, t, len + 1);
      string title = t.ToString();
      if (title == "Program Manager") return true;
      uint pid; GetWindowThreadProcessId(h, out pid);
      if (!first) sb.Append(','); first = false;
      sb.Append("{\"h\":\"").Append(h.ToInt64()).Append("\",\"t\":\"").Append(Esc(title))
        .Append("\",\"exe\":\"").Append(Esc(ExePath(pid)))
        .Append("\",\"min\":").Append(IsIconic(h) ? "true" : "false")
        .Append(",\"max\":").Append(IsZoomed(h) ? "true" : "false")
        .Append(",\"fg\":").Append(h == fg ? "true" : "false").Append('}');
      return true;
    }, IntPtr.Zero);
    return sb.Append(']').ToString();
  }
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool on);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern void SwitchToThisWindow(IntPtr h, bool alt);
  // traer una ventana al frente (y restaurarla si estaba minimizada). Windows pone trabas para que un programa
  // de fondo pase otra ventana adelante: se "engancha" al que está adelante, y si igual no alcanza, SwitchToThisWindow.
  public static void Focus(long v) {
    var h = new IntPtr(v);
    keybd_event(0x12, 0, 0, UIntPtr.Zero); keybd_event(0x12, 0, 2, UIntPtr.Zero);
    if (IsIconic(h)) {
      // lo mismo que hace la barra de Windows: el pedido de "restaurar" del sistema (algunos navegadores, como Opera,
      // no vuelven con ShowWindow solo)
      PostMessage(h, 0x0112, new IntPtr(0xF120), IntPtr.Zero);
      for (int i = 0; i < 15 && IsIconic(h); i++) System.Threading.Thread.Sleep(20);
      if (IsIconic(h)) ShowWindow(h, 9);
    } else ShowWindow(h, 5);
    uint pid; IntPtr fg = GetForegroundWindow();
    uint ft = fg == IntPtr.Zero ? 0 : GetWindowThreadProcessId(fg, out pid), me = GetCurrentThreadId();
    bool att = ft != 0 && ft != me && AttachThreadInput(me, ft, true);
    try { BringWindowToTop(h); SetForegroundWindow(h); }
    finally { if (att) AttachThreadInput(me, ft, false); }
    if (GetForegroundWindow() != h) { try { SwitchToThisWindow(h, true); } catch { } }
    if (IsIconic(h)) { PostMessage(h, 0x0112, new IntPtr(0xF120), IntPtr.Zero); ShowWindow(h, 9); }
  }
  public static void Minimize(long v) { ShowWindow(new IntPtr(v), 6); }
  public static void Close(long v) { PostMessage(new IntPtr(v), 0x10, IntPtr.Zero, IntPtr.Zero); }
  public static void ToggleMax(long v) {
    var h = new IntPtr(v);
    ShowWindow(h, IsZoomed(h) && !IsIconic(h) ? 9 : 3);
    Focus(v);
  }
  public static void MinimizeAll(long self) {
    EnumWindows((h, l) => { if (h.ToInt64() != self && IsAppWindow(h)) ShowWindow(h, 6); return true; }, IntPtr.Zero);
  }
  // Spotify: la ventana muestra "Artista - Canción" mientras suena y "Spotify ..." en pausa
  public static string Spotify() {
    string best = ""; bool running = false;
    EnumWindows((h, l) => {
      int len = GetWindowTextLength(h);
      if (len == 0) return true;
      uint pid; GetWindowThreadProcessId(h, out pid);
      string exe = ExePath(pid);
      if (!exe.EndsWith("Spotify.exe", StringComparison.OrdinalIgnoreCase)) return true;
      running = true;
      var t = new StringBuilder(len + 1); GetWindowText(h, t, len + 1);
      string title = t.ToString();
      if (title == "GDI+ Window" || title == "Default IME" || title.StartsWith("MSCTFIME") || title.Contains("SpotifyMainWindow")) return true;
      if (title.Contains(" - ") || best == "") best = title;
      return true;
    }, IntPtr.Zero);
    return "{\"running\":" + (running ? "true" : "false") + ",\"title\":\"" + Esc(best) + "\"}";
  }
  public static void Media(string key) {
    byte vk;
    switch (key) {
      case "play": vk = 0xB3; break;
      case "next": vk = 0xB0; break;
      case "prev": vk = 0xB1; break;
      case "volup": vk = 0xAF; break;
      case "voldown": vk = 0xAE; break;
      case "mute": vk = 0xAD; break;
      default: return;
    }
    keybd_event(vk, 0, 1, UIntPtr.Zero);
    keybd_event(vk, 0, 3, UIntPtr.Zero);
  }
  public static void Keys(string combo) {
    byte[] vks;
    switch (combo) {
      case "win": vks = new byte[] { 0x5B }; break;
      case "win+tab": vks = new byte[] { 0x5B, 0x09 }; break;
      case "win+a": vks = new byte[] { 0x5B, 0x41 }; break;
      case "win+n": vks = new byte[] { 0x5B, 0x4E }; break;
      case "win+d": vks = new byte[] { 0x5B, 0x44 }; break;
      case "win+shift+s": vks = new byte[] { 0x5B, 0x10, 0x53 }; break;
      case "win+.": vks = new byte[] { 0x5B, 0xBE }; break;
      case "win+v": vks = new byte[] { 0x5B, 0x56 }; break;
      case "win+prtsc": vks = new byte[] { 0x5B, 0x2C }; break;
      // escritorios virtuales de Windows
      case "ctrl+win+left": vks = new byte[] { 0x11, 0x5B, 0x25 }; break;
      case "ctrl+win+right": vks = new byte[] { 0x11, 0x5B, 0x27 }; break;
      case "ctrl+win+d": vks = new byte[] { 0x11, 0x5B, 0x44 }; break;
      case "ctrl+win+f4": vks = new byte[] { 0x11, 0x5B, 0x73 }; break;
      default: return;
    }
    // las flechas son teclas "extendidas" (si no, Windows las toma como las del teclado numérico)
    foreach (var k in vks) keybd_event(k, 0, (uint)((k == 0x25 || k == 0x27) ? 1 : 0), UIntPtr.Zero);
    for (int i = vks.Length - 1; i >= 0; i--) keybd_event(vks[i], 0, (uint)((vks[i] == 0x25 || vks[i] == 0x27) ? 3 : 2), UIntPtr.Zero);
  }
}
'@

try {
  LoadCs 'win' 'BaseWin' $code
} catch {
  $msg = ($_.Exception.Message -replace '["\\]', '' -replace '\s+', ' ')
  [Console]::Out.WriteLine('{"ready":false,"error":"' + $msg + '"}')
  [Console]::Out.Flush()
  exit 1
}
$code2 = @'
using System;
using System.Text;

public static class BaseSys {
  [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  // la deja en un lugar y tamaño fijos, arriba de todo
  public static string Place(string arg) {
    string[] p = arg.Split('|');
    if (p.Length < 5) return "false";
    IntPtr h = new IntPtr(long.Parse(p[0]));
    ShowWindow(h, 9);
    bool ok = SetWindowPos(h, new IntPtr(-1), int.Parse(p[1]), int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]), 0x0040);
    return ok ? "true" : "false";
  }
  public static string TopMost(long h) {
    bool ok = SetWindowPos(new IntPtr(h), new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040);
    return ok ? "true" : "false";
  }
  static string Esc(string s) {
    var b = new StringBuilder();
    foreach (char c in s) {
      if (c == '"' || c == '\\') b.Append('\\').Append(c);
      else if (c < 32) b.AppendFormat("\\u{0:x4}", (int)c);
      else b.Append(c);
    }
    return b.ToString();
  }
  // Unidades de almacenamiento (fijas, extraíbles, de red y lectoras)
  public static string Drives() {
    var b = new StringBuilder("[");
    bool first = true;
    foreach (var d in System.IO.DriveInfo.GetDrives()) {
      try {
        if (!d.IsReady) continue;
        string label = "", fmt = "";
        try { label = d.VolumeLabel ?? ""; } catch {}
        try { fmt = d.DriveFormat ?? ""; } catch {}
        long size = d.TotalSize, free = d.AvailableFreeSpace;
        string item = "{\"n\":\"" + Esc(d.Name) + "\",\"l\":\"" + Esc(label) + "\",\"t\":\"" + d.DriveType.ToString()
          + "\",\"f\":\"" + Esc(fmt) + "\",\"size\":" + size + ",\"free\":" + free + "}";
        if (!first) b.Append(',');
        first = false;
        b.Append(item);
      } catch {}
    }
    return b.Append(']').ToString();
  }
  // Bytes enviados y recibidos por las conexiones activas
  public static string Net() {
    long rx = 0, tx = 0; string name = "", kind = ""; long speed = 0;
    foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()) {
      try {
        if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;
        var nt = ni.NetworkInterfaceType;
        if (nt == System.Net.NetworkInformation.NetworkInterfaceType.Loopback || nt == System.Net.NetworkInformation.NetworkInterfaceType.Tunnel) continue;
        var st = ni.GetIPv4Statistics();
        rx += st.BytesReceived; tx += st.BytesSent;
        if (st.BytesReceived > 0 && (name == "" || nt == System.Net.NetworkInformation.NetworkInterfaceType.Wireless80211 || nt == System.Net.NetworkInformation.NetworkInterfaceType.Ethernet)) {
          if (name == "" || kind != "Ethernet") { name = ni.Name; kind = nt.ToString(); speed = ni.Speed; }
        }
      } catch {}
    }
    return "{\"rx\":" + rx + ",\"tx\":" + tx + ",\"name\":\"" + Esc(name) + "\",\"kind\":\"" + kind + "\",\"speed\":" + speed + "}";
  }
  // Programas que más memoria usan (agrupados por nombre)
  public static string Procs() {
    var mem = new System.Collections.Generic.Dictionary<string, long>();
    var cnt = new System.Collections.Generic.Dictionary<string, int>();
    int total = 0;
    foreach (var p in System.Diagnostics.Process.GetProcesses()) {
      try {
        total++;
        string n = p.ProcessName;
        if (n == "Idle" || n == "System" || n == "Memory Compression" || n == "Registry") continue;
        long w = p.WorkingSet64;
        if (mem.ContainsKey(n)) { mem[n] += w; cnt[n]++; } else { mem[n] = w; cnt[n] = 1; }
      } catch {} finally { p.Dispose(); }
    }
    var keys = new System.Collections.Generic.List<string>(mem.Keys);
    keys.Sort((a, c) => mem[c].CompareTo(mem[a]));
    var b = new StringBuilder("{\"total\":" + total + ",\"top\":[");
    for (int i = 0; i < Math.Min(6, keys.Count); i++) {
      if (i > 0) b.Append(',');
      b.Append("{\"n\":\"").Append(Esc(keys[i])).Append("\",\"m\":").Append(mem[keys[i]]).Append(",\"c\":").Append(cnt[keys[i]]).Append('}');
    }
    return b.Append("]}").ToString();
  }
}
'@
$sysOk = $true
try { LoadCs 'sys' 'BaseSys' $code2 } catch { $sysOk = $false }
# ---- Volumen general de Windows (Core Audio) ----
$code3 = @'
using System;
using System.Runtime.InteropServices;
[ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IBaseEpVol {
  int RegisterControlChangeNotify(IntPtr p);
  int UnregisterControlChangeNotify(IntPtr p);
  int GetChannelCount(out uint c);
  int SetMasterVolumeLevel(float l, ref Guid ctx);
  int SetMasterVolumeLevelScalar(float l, ref Guid ctx);
  int GetMasterVolumeLevel(out float l);
  int GetMasterVolumeLevelScalar(out float l);
  int SetChannelVolumeLevel(uint ch, float l, ref Guid ctx);
  int SetChannelVolumeLevelScalar(uint ch, float l, ref Guid ctx);
  int GetChannelVolumeLevel(uint ch, out float l);
  int GetChannelVolumeLevelScalar(uint ch, out float l);
  int SetMute([MarshalAs(UnmanagedType.Bool)] bool m, ref Guid ctx);
  int GetMute([MarshalAs(UnmanagedType.Bool)] out bool m);
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IBaseMMDevice {
  int Activate(ref Guid iid, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o);
}
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IBaseMMEnum {
  int EnumAudioEndpoints(int flow, int mask, out IntPtr devs);
  int GetDefaultAudioEndpoint(int flow, int role, out IBaseMMDevice d);
}
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
class BaseMMEnumCom {}
public static class BaseVol {
  static IBaseEpVol Ep() {
    var en = (IBaseMMEnum)(new BaseMMEnumCom());
    IBaseMMDevice d;
    Marshal.ThrowExceptionForHR(en.GetDefaultAudioEndpoint(0, 1, out d));
    Guid iid = typeof(IBaseEpVol).GUID;
    object o;
    Marshal.ThrowExceptionForHR(d.Activate(ref iid, 23, IntPtr.Zero, out o));
    return (IBaseEpVol)o;
  }
  static string State(IBaseEpVol e) {
    float l; e.GetMasterVolumeLevelScalar(out l);
    bool m; e.GetMute(out m);
    return "{\"level\":" + ((int)Math.Round(l * 100)).ToString() + ",\"muted\":" + (m ? "true" : "false") + "}";
  }
  public static string Get() { return State(Ep()); }
  public static string Set(int v) {
    var e = Ep(); Guid g = Guid.Empty;
    v = Math.Max(0, Math.Min(100, v));
    e.SetMasterVolumeLevelScalar(v / 100f, ref g);
    if (v > 0) e.SetMute(false, ref g);
    return State(e);
  }
  public static string Mute(bool on) { var e = Ep(); Guid g = Guid.Empty; e.SetMute(on, ref g); return State(e); }
}
'@
$volOk = $true
try { LoadCs 'vol' 'BaseVol' $code3 } catch { $volOk = $false }
# ---- Programa "acoplado" adentro de Base (por ejemplo Recepciones.exe) ----
$code4 = @'
using System;
using System.Runtime.InteropServices;
public static class BaseDock {
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] static extern IntPtr GetLong(IntPtr h, int i);
  [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")] static extern IntPtr SetLong(IntPtr h, int i, IntPtr v);
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  static void Dpi() { try { SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch {} }
  const long STRIP = 0x00C00000L | 0x00040000L | 0x00020000L | 0x00010000L;
  public static string Attach(string arg) {
    string[] p = arg.Split('|');
    if (p.Length < 6) return "false";
    IntPtr h = new IntPtr(long.Parse(p[0]));
    if (!IsWindow(h)) return "false";
    Dpi();
    if (IsZoomed(h) || IsIconic(h)) ShowWindow(h, 9);
    long st = GetLong(h, -16).ToInt64();
    SetLong(h, -16, new IntPtr(st & ~STRIP));
    SetLong(h, -8, new IntPtr(long.Parse(p[1])));
    SetWindowPos(h, IntPtr.Zero, int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]), int.Parse(p[5]), 0x0020 | 0x0040 | 0x0010);
    return "{\"style\":\"" + st.ToString() + "\"}";
  }
  public static string Move(string arg) {
    string[] p = arg.Split('|');
    if (p.Length < 5) return "false";
    IntPtr h = new IntPtr(long.Parse(p[0]));
    if (!IsWindow(h)) return "false";
    Dpi();
    if (IsIconic(h)) ShowWindow(h, 9);
    SetWindowPos(h, IntPtr.Zero, int.Parse(p[1]), int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]), 0x0040 | 0x0010);
    return "true";
  }
  public static string Hide(long v) {
    IntPtr h = new IntPtr(v);
    if (!IsWindow(h)) return "false";
    ShowWindow(h, 0);
    return "true";
  }
  public static string Detach(string arg) {
    string[] p = arg.Split('|');
    IntPtr h = new IntPtr(long.Parse(p[0]));
    if (!IsWindow(h)) return "false";
    SetLong(h, -8, IntPtr.Zero);
    if (p.Length > 1 && p[1] != "") SetLong(h, -16, new IntPtr(long.Parse(p[1])));
    SetWindowPos(h, IntPtr.Zero, 0, 0, 0, 0, 0x0020 | 0x0001 | 0x0002 | 0x0004 | 0x0040);
    ShowWindow(h, 9);
    return "true";
  }
  public static string Alive(long v) { return IsWindow(new IntPtr(v)) ? "true" : "false"; }
}
'@
$dockOk = $true
try { LoadCs 'dock' 'BaseDock' $code4 } catch { $dockOk = $false }
# ---- Control multimedia de Windows (lo que suena en Spotify, el navegador, etc.) ----
$smtc = $null
$asTaskOp = $null
function Await($op, [Type]$t) {
  $task = $script:asTaskOp.MakeGenericMethod($t).Invoke($null, @($op))
  if (-not $task.Wait(1500)) { throw 'timeout' }
  return $task.Result
}
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTaskOp = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $smtc = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
} catch { $smtc = $null }
function SmtcFind($app) {
  if (-not $smtc) { return $null }
  if ($app) { foreach ($s in $smtc.GetSessions()) { if ($s.SourceAppUserModelId -eq $app) { return $s } } }
  return $smtc.GetCurrentSession()
}
function SmtcState {
  if (-not $smtc) { return 'null' }
  $cur = $smtc.GetCurrentSession()
  $list = New-Object System.Collections.ArrayList
  foreach ($s in $smtc.GetSessions()) {
    $p = $null
    try { $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]) } catch {}
    $tl = $s.GetTimelineProperties()
    $pb = $s.GetPlaybackInfo()
    $upd = 0
    try { $upd = [long]$tl.LastUpdatedTime.ToUnixTimeMilliseconds() } catch {}
    $null = $list.Add([pscustomobject]@{
      app = [string]$s.SourceAppUserModelId
      title = if ($p) { [string]$p.Title } else { '' }
      artist = if ($p) { [string]$p.Artist } else { '' }
      album = if ($p) { [string]$p.AlbumTitle } else { '' }
      status = [string]$pb.PlaybackStatus
      pos = [double]$tl.Position.TotalSeconds
      start = [double]$tl.StartTime.TotalSeconds
      end = [double]$tl.EndTime.TotalSeconds
      upd = $upd
      seek = [bool]$pb.Controls.IsPlaybackPositionEnabled
      cur = [bool]($cur -ne $null -and $s.SourceAppUserModelId -eq $cur.SourceAppUserModelId)
    })
  }
  if ($list.Count -eq 0) { return '[]' }
  return (ConvertTo-Json -InputObject @($list.ToArray()) -Compress -Depth 3)
}
function SmtcThumb($app) {
  $s = SmtcFind $app
  if (-not $s) { return 'null' }
  $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
  if (-not $p -or -not $p.Thumbnail) { return 'null' }
  $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
  $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st)
  $ms = New-Object System.IO.MemoryStream
  $net.CopyTo($ms)
  $net.Dispose()
  if ($ms.Length -gt 4MB) { return 'null' }
  $ct = [string]$st.ContentType
  return '{"type":"' + ($ct -replace '[^\w/+.-]', '') + '","data":"' + [Convert]::ToBase64String($ms.ToArray()) + '"}'
}
function SmtcDo($arg) {
  $parts = $arg.Split('|')
  $s = SmtcFind $parts[0]
  if (-not $s) { return 'false' }
  $ok = $false
  switch ($parts[1]) {
    'toggle' { $ok = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
    'next'   { $ok = Await ($s.TrySkipNextAsync()) ([bool]) }
    'prev'   { $ok = Await ($s.TrySkipPreviousAsync()) ([bool]) }
    'seek'   { $ok = Await ($s.TryChangePlaybackPositionAsync([long]([double]$parts[2] * 10000000))) ([bool]) }
  }
  if ($ok) { return 'true' } else { return 'false' }
}
# ---- Modo escritorio: ventana del frente, barra de tareas de Windows ----
$code5 = @'
using System;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Runtime.InteropServices;
public static class BaseDesk {
  [DllImport("user32.dll")] static extern bool IsHungAppWindow(IntPtr h);
  // Vigilante: si la ventana de Base queda "no responde" 40 segundos, se cierra (y el ayudante la vuelve a abrir)
  static Timer watchTimer; static IntPtr watchH = IntPtr.Zero; static int hungN = 0; static string watchExe = "", watchLog = "";
  public static string Watch(string arg) {
    string[] p = arg.Split(new char[] { '|' }, 3);
    if (p.Length < 3) return "false";
    watchH = new IntPtr(long.Parse(p[0])); watchExe = p[1]; watchLog = p[2]; hungN = 0;
    if (watchTimer == null) watchTimer = new Timer(WatchTick, null, 5000, 5000);
    return "true";
  }
  static void WatchTick(object o) {
    try {
      if (watchH == IntPtr.Zero) return;
      if (IsHungAppWindow(watchH)) hungN++; else hungN = 0;
      if (hungN < 8) return;
      hungN = 0; watchH = IntPtr.Zero;
      try { File.AppendAllText(watchLog, "[" + DateTime.UtcNow.ToString("o") + "] Base quedó trabada 40 segundos: la cierro y se vuelve a abrir sola\r\n"); } catch { }
      foreach (Process pr in Process.GetProcessesByName("Base")) {
        try { if (string.Equals(pr.MainModule.FileName, watchExe, StringComparison.OrdinalIgnoreCase)) pr.Kill(); } catch { }
      }
    } catch { }
  }
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string c, string t);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr after, string c, string t);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int l, t, r, b; }
  [StructLayout(LayoutKind.Sequential)] struct APPBARDATA { public int cbSize; public IntPtr hWnd; public uint msg; public uint edge; public RECT rc; public IntPtr lParam; }
  [DllImport("shell32.dll")] static extern IntPtr SHAppBarMessage(uint msg, ref APPBARDATA d);
  public static bool hidden = false;
  static int savedState = -1;
  // Sin barra de tareas, Windows dibuja las ventanas minimizadas como barritas abajo a la izquierda.
  // Mientras la barra está escondida le pedimos que las esconda (como hace con la barra visible).
  [StructLayout(LayoutKind.Sequential)] struct MINIMIZEDMETRICS { public uint cbSize; public int iWidth; public int iHorzGap; public int iVertGap; public int iArrange; }
  [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint a, uint b, ref MINIMIZEDMETRICS m, uint c);
  static int savedArrange = -1;
  static void MinHide(bool on) {
    try {
      var m = new MINIMIZEDMETRICS(); m.cbSize = (uint)Marshal.SizeOf(m);
      if (!SystemParametersInfo(0x002B, m.cbSize, ref m, 0)) return;
      if (on) { if (savedArrange < 0) savedArrange = m.iArrange; m.iArrange = m.iArrange | 0x0008; }
      else { if (savedArrange < 0) return; m.iArrange = savedArrange; savedArrange = -1; }
      SystemParametersInfo(0x002C, m.cbSize, ref m, 0);
    } catch { }
  }
  public static string FgClass() {
    IntPtr h = GetForegroundWindow();
    var sb = new StringBuilder(128); GetClassName(h, sb, 128);
    return "{\"c\":\"" + sb.ToString().Replace("\\", "").Replace("\"", "") + "\",\"h\":\"" + h.ToInt64() + "\"}";
  }
  static void Bars(int cmd) {
    IntPtr t = FindWindow("Shell_TrayWnd", null);
    if (t != IntPtr.Zero) ShowWindow(t, cmd);
    IntPtr s = IntPtr.Zero;
    while ((s = FindWindowEx(IntPtr.Zero, s, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero) ShowWindow(s, cmd);
  }
  static void AutoHide(bool on) {
    var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(d); d.hWnd = FindWindow("Shell_TrayWnd", null);
    if (savedState < 0) savedState = (int)SHAppBarMessage(4, ref d).ToInt64(); // ABM_GETSTATE
    d.lParam = new IntPtr(on ? 1 : (savedState & 1)); // ABS_AUTOHIDE
    SHAppBarMessage(10, ref d); // ABM_SETSTATE
  }
  public static string Taskbar(bool hide) {
    if (hide) { AutoHide(true); Bars(0); MinHide(true); hidden = true; }
    else { if (hidden || savedState >= 0) AutoHide(false); Bars(5); MinHide(false); hidden = false; }
    return "true";
  }
  // la volvemos a esconder si Windows la mostró (por ejemplo al reiniciarse el Explorador)
  public static string Keep() {
    if (!hidden) return "false";
    IntPtr t = FindWindow("Shell_TrayWnd", null);
    if (t != IntPtr.Zero && IsWindowVisible(t)) Bars(0);
    return "true";
  }
  // Área de trabajo (lo que usan las ventanas maximizadas). Con el escritorio minimalista y la barra de Windows
  // escondida, las ventanas tienen que llegar arriba de todo y terminar justo encima de la barra de Base.
  [DllImport("user32.dll", EntryPoint = "SystemParametersInfo")] static extern bool SpiRect(uint a, uint b, ref RECT r, uint c);
  static RECT savedWa; static bool waSaved = false;
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  // en píxeles reales: si la pantalla está al 125% o 150%, sin esto Windows "escala" los números, nunca coinciden
  // y el área se volvía a poner a cada rato (las ventanas maximizadas temblaban)
  [StructLayout(LayoutKind.Sequential)] struct MINFO { public int cb; public RECT mon; public RECT work; public int flags; }
  [StructLayout(LayoutKind.Sequential)] struct PT { public int x, y; }
  [DllImport("user32.dll")] static extern IntPtr MonitorFromPoint(PT p, uint f);
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MINFO i);
  // el área de trabajo del monitor donde está ese punto (SPI_GETWORKAREA da siempre la del monitor principal,
  // y con Base en el segundo monitor nunca coincidía)
  static RECT MonWork(int x, int y) {
    PT pt = new PT(); pt.x = x; pt.y = y;
    MINFO mi = new MINFO(); mi.cb = Marshal.SizeOf(typeof(MINFO));
    IntPtr m = MonitorFromPoint(pt, 2);
    if (m != IntPtr.Zero && GetMonitorInfo(m, ref mi)) return mi.work;
    RECT r = new RECT(); SpiRect(0x0030, 0, ref r, 0); return r;
  }
  public static string WorkArea(string arg) {
    IntPtr old = IntPtr.Zero;
    try { old = SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { }
    try {
      if (arg == "off") {
        if (!waSaved) return "false";
        SpiRect(0x002F, 0, ref savedWa, 0x02); waSaved = false; return "true";
      }
      var p = arg.Split('|');
      RECT cur = MonWork(int.Parse(p[0]) + 10, int.Parse(p[1]) + 10);
      if (!waSaved) { savedWa = cur; waSaved = true; }
      RECT r = new RECT(); r.l = int.Parse(p[0]); r.t = int.Parse(p[1]); r.r = r.l + int.Parse(p[2]); r.b = r.t + int.Parse(p[3]);
      if (Math.Abs(cur.l - r.l) <= 2 && Math.Abs(cur.t - r.t) <= 2 && Math.Abs(cur.r - r.r) <= 2 && Math.Abs(cur.b - r.b) <= 2) return "\"same\"";
      // SPI_SETWORKAREA y avisar a las ventanas: en otro hilo, porque el aviso espera a que cada programa lo atienda
      // y si alguno está colgado el ayudante quedaba trabado (y Base mostraba "ventanas no disponibles")
      RECT rr = r;
      System.Threading.ThreadPool.QueueUserWorkItem(delegate {
        IntPtr o2 = IntPtr.Zero;
        try { o2 = SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { }
        try { SpiRect(0x002F, 0, ref rr, 0x02); } catch { }
        finally { try { if (o2 != IntPtr.Zero) SetThreadDpiAwarenessContext(o2); } catch { } }
      });
      return "\"set\"";
    } finally { try { if (old != IntPtr.Zero) SetThreadDpiAwarenessContext(old); } catch { } }
  }
  public static string Bottom(long v) {
    SetWindowPos(new IntPtr(v), new IntPtr(1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010); // HWND_BOTTOM, sin mover ni activar
    return "true";
  }
}
'@
$deskOk = $true
try { LoadCs 'desk' 'BaseDesk' $code5 } catch { $deskOk = $false }

# ---- Ventanas que piden atención (las que en la barra de Windows parpadean en naranja) ----
# Una ventanita invisible escucha los avisos del "shell" de Windows: HSHELL_FLASH dice qué ventana pide atención
# y se borra cuando esa ventana pasa adelante o se cierra.
$code8 = @'
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
public class BaseFlash : NativeWindow {
  [DllImport("user32.dll")] static extern bool RegisterShellHookWindow(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern uint RegisterWindowMessage(string s);
  static uint msgId = 0; static BaseFlash inst = null;
  static readonly HashSet<long> on = new HashSet<long>(); static readonly object L = new object();
  public static string Start() {
    if (inst != null) return "true";
    var t = new Thread(() => {
      try {
        inst = new BaseFlash(); inst.CreateHandle(new CreateParams());
        msgId = RegisterWindowMessage("SHELLHOOK"); RegisterShellHookWindow(inst.Handle);
        Application.Run();
      } catch { }
    });
    t.IsBackground = true; t.SetApartmentState(ApartmentState.STA); t.Start();
    return "true";
  }
  protected override void WndProc(ref Message m) {
    if (msgId != 0 && m.Msg == (int)msgId) {
      int w = m.WParam.ToInt32(), code = w & 0x7FFF; bool hi = (w & 0x8000) != 0; long h = m.LParam.ToInt64();
      lock (L) {
        if (code == 6 && hi) on.Add(h);                  // HSHELL_FLASH: pide atención
        else if (code == 4 || code == 2) on.Remove(h);   // pasó adelante o se cerró
      }
    }
    base.WndProc(ref m);
  }
  public static string List() { lock (L) { var b = new System.Text.StringBuilder("["); bool f = true; foreach (long h in on) { if (!f) b.Append(','); f = false; b.Append('"').Append(h).Append('"'); } return b.Append(']').ToString(); } }
  public static string Clear(long h) { lock (L) on.Remove(h); return "true"; }
}
'@
$flashOk = $true
try { LoadCs 'flash' 'BaseFlash' $code8 @('System.Windows.Forms'); [void][BaseFlash]::Start() } catch { $flashOk = $false }

# ---- Escritorio minimalista: la barra de Base se anota en Windows como "barra de aplicación" (como la de Windows),
# así las ventanas maximizadas terminan justo arriba. Cambiar el área a mano (SPI_SETWORKAREA) Windows lo deshacía
# cada tanto y la barra de Windows aparecía y desaparecía.
$code9 = @'
using System;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
public class BaseBar : NativeWindow {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int l, t, r, b; }
  [StructLayout(LayoutKind.Sequential)] struct APPBARDATA { public int cbSize; public IntPtr hWnd; public uint uCallbackMessage; public uint uEdge; public RECT rc; public IntPtr lParam; }
  [DllImport("shell32.dll")] static extern UIntPtr SHAppBarMessage(uint msg, ref APPBARDATA d);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll", EntryPoint = "SystemParametersInfo")] static extern bool SpiRect(uint a, uint b, ref RECT r, uint c);
  [DllImport("user32.dll")] static extern bool SetLayeredWindowAttributes(IntPtr h, uint key, byte alpha, uint flags);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  static BaseBar inst = null; static uint cbMsg = 0, tbCreated = 0; static bool reg = false, on = false; static RECT want;
  static readonly ManualResetEvent ready = new ManualResetEvent(false);
  static int applies = 0; static DateTime appliesFrom = DateTime.UtcNow;
  static string trace = ""; static int nApply = 0, nNotify = 0, nBrake = 0;
  public static string Info() { return "\"" + (on ? "on" : "off") + (reg ? " anotada " : " sin anotar ") + trace + "\""; }
  // Windows a veces la suelta (se reinicia algo del Explorador, cambia la barra de Windows): se anota otra vez
  public static string Renew() { if (inst == null || !on) return "false"; PostMessage(inst.Handle, 0x8002, IntPtr.Zero, IntPtr.Zero); return "true"; }
  public static string Start() {
    if (inst != null) return inst.Handle != IntPtr.Zero ? "true" : "false";
    var t = new Thread(() => {
      try {
        try { SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { }
        // ventana de verdad (Windows respeta mejor una barra que existe): transparente, sin foco y sin recibir clics
        var b = new BaseBar(); var cp = new CreateParams(); cp.ExStyle = 0x80 | 0x08000000 | 0x80000 | 0x20; cp.Style = unchecked((int)0x80000000); cp.Caption = "BaseBarra"; cp.Width = 1; cp.Height = 1; b.CreateHandle(cp);
        SetLayeredWindowAttributes(b.Handle, 0, 1, 2);
        cbMsg = RegisterWindowMessage("BaseAppBarAviso"); tbCreated = RegisterWindowMessage("TaskbarCreated");
        inst = b; ready.Set(); Application.Run();
      } catch { ready.Set(); }
    });
    t.IsBackground = true; t.SetApartmentState(ApartmentState.STA); t.Start(); ready.WaitOne(4000);
    return inst != null && inst.Handle != IntPtr.Zero ? "true" : "false";
  }
  APPBARDATA D() { var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(typeof(APPBARDATA)); d.hWnd = Handle; d.uCallbackMessage = cbMsg; d.uEdge = 3; return d; }
  void Apply() {
    var d = D();
    if (!on) { if (reg) { SHAppBarMessage(1, ref d); reg = false; } SetWindowPos(Handle, IntPtr.Zero, 0, 0, 0, 0, 0x0080 | 0x0001 | 0x0002 | 0x0004 | 0x0010); return; }
    // freno: si Windows nos avisa sin parar, no seguimos acomodando
    if ((DateTime.UtcNow - appliesFrom).TotalSeconds > 20) { appliesFrom = DateTime.UtcNow; applies = 0; }
    if (++applies > 12) { nBrake++; return; }
    if (!reg) { SHAppBarMessage(0, ref d); reg = true; }
    int h = want.b - want.t;
    d.rc = want; SHAppBarMessage(2, ref d);      // ABM_QUERYPOS: Windows dice dónde puede ir
    d.rc.t = d.rc.b - h;
    SHAppBarMessage(3, ref d);                   // ABM_SETPOS: reserva ese lugar
    trace = "apply#" + (++nApply) + " pos=" + d.rc.l + "," + d.rc.t + "," + d.rc.r + "," + d.rc.b + " avisos=" + nNotify + " frenos=" + nBrake;
    // la ventanita invisible ocupa ese lugar (al fondo, sin activarse)
    SetWindowPos(Handle, new IntPtr(1), d.rc.l, d.rc.t, d.rc.r - d.rc.l, d.rc.b - d.rc.t, 0x0010 | 0x0040);
  }
  protected override void WndProc(ref Message m) {
    if (m.Msg == 0x8001) Apply();
    else if (cbMsg != 0 && m.Msg == (int)cbMsg) { nNotify++; if (m.WParam.ToInt32() == 1) Apply(); }   // ABN_POSCHANGED
    else if (m.Msg == 0x8002) { if (reg) { var d = D(); SHAppBarMessage(1, ref d); reg = false; } applies = 0; Apply(); }   // volver a anotarla de cero
    else if (tbCreated != 0 && m.Msg == (int)tbCreated) { reg = false; Apply(); }         // se reinició el Explorador
    base.WndProc(ref m);
  }
  public static string Set(string arg) {
    if (Start() != "true") return "false";
    if (arg == "off") { if (!on) return "\"same\""; on = false; }
    else {
      var p = arg.Split('|'); var r = new RECT(); r.l = int.Parse(p[0]); r.t = int.Parse(p[1]); r.r = r.l + int.Parse(p[2]); r.b = r.t + int.Parse(p[3]);
      if (on && reg && r.l == want.l && r.t == want.t && r.r == want.r && r.b == want.b) return "\"same\"";
      want = r; on = true; applies = 0;
    }
    PostMessage(inst.Handle, 0x8001, IntPtr.Zero, IntPtr.Zero);
    return "\"set\"";
  }
  [StructLayout(LayoutKind.Sequential)] struct MINFO { public int cb; public RECT mon; public RECT work; public int flags; }
  [StructLayout(LayoutKind.Sequential)] struct PT { public int x, y; }
  [DllImport("user32.dll")] static extern IntPtr MonitorFromPoint(PT p, uint f);
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MINFO i);
  // área de trabajo del monitor de la barra (no la del principal)
  public static string Area(string arg) {
    IntPtr old = IntPtr.Zero; try { old = SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { }
    try {
      RECT r = new RECT(); bool got = false;
      var p = (arg ?? "").Split('|');
      if (p.Length >= 2) { int x, y; if (int.TryParse(p[0], out x) && int.TryParse(p[1], out y)) {
        PT pt = new PT(); pt.x = x; pt.y = y; MINFO mi = new MINFO(); mi.cb = Marshal.SizeOf(typeof(MINFO));
        IntPtr m = MonitorFromPoint(pt, 2); if (m != IntPtr.Zero && GetMonitorInfo(m, ref mi)) { r = mi.work; got = true; } } }
      if (!got) SpiRect(0x0030, 0, ref r, 0);
      return "\"" + r.l + "|" + r.t + "|" + r.r + "|" + r.b + "\""; }
    finally { try { if (old != IntPtr.Zero) SetThreadDpiAwarenessContext(old); } catch { } }
  }
}
'@
$barOk = $true
try { LoadCs 'bar' 'BaseBar' $code9 @('System.Windows.Forms') } catch { $barOk = $false }
$relaunch = ''
$cleanExit = $false

# ---- Botones rápidos: Wi-Fi / Bluetooth (radios de Windows) y brillo de pantalla ----
$radiosOk = $false
try {
  $null = [Windows.Devices.Radios.Radio, Windows.System.Devices, ContentType = WindowsRuntime]
  $null = [Windows.Devices.Radios.RadioAccessStatus, Windows.System.Devices, ContentType = WindowsRuntime]
  $radiosOk = $true
} catch {}
function RadioList {
  if (-not $radiosOk) { return 'null' }
  $all = Await ([Windows.Devices.Radios.Radio]::GetRadiosAsync()) ([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]])
  $out = New-Object System.Collections.ArrayList
  foreach ($r in $all) { $null = $out.Add([pscustomobject]@{ kind = [string]$r.Kind; on = ([string]$r.State -eq 'On'); name = [string]$r.Name }) }
  if ($out.Count -eq 0) { return '[]' }
  return (ConvertTo-Json -InputObject @($out.ToArray()) -Compress)
}
function RadioSet($arg) {
  if (-not $radiosOk) { return 'false' }
  $p = $arg.Split('|'); $kind = $p[0]; $on = ($p[1] -eq '1')
  $null = Await ([Windows.Devices.Radios.Radio]::RequestAccessAsync()) ([Windows.Devices.Radios.RadioAccessStatus])
  $all = Await ([Windows.Devices.Radios.Radio]::GetRadiosAsync()) ([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]])
  $st = if ($on) { [Windows.Devices.Radios.RadioState]::On } else { [Windows.Devices.Radios.RadioState]::Off }
  $done = $false
  foreach ($r in $all) { if ([string]$r.Kind -eq $kind) { $res = Await ($r.SetStateAsync($st)) ([Windows.Devices.Radios.RadioAccessStatus]); $done = ([string]$res -eq 'Allowed') } }
  if ($done) { return 'true' } else { return 'false' }
}
function VDesk {
  $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VirtualDesktops'
  $p = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
  if (-not $p -or -not $p.VirtualDesktopIDs) { return '{"n":1,"cur":0,"names":[]}' }
  $ids = [byte[]]$p.VirtualDesktopIDs; $n = [int]($ids.Length / 16); $curB = $p.CurrentVirtualDesktop
  if (-not $curB) { try { $sid = (Get-Process -Id $PID).SessionId; $curB = (Get-ItemProperty -Path ('HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\SessionInfo\' + $sid + '\VirtualDesktops') -ErrorAction Stop).CurrentVirtualDesktop } catch {} }
  $cur = 0; $names = New-Object System.Collections.ArrayList
  for ($i = 0; $i -lt $n; $i++) {
    $g = New-Object Guid (,[byte[]]$ids[($i * 16)..($i * 16 + 15)])
    if ($curB -and ([Guid](New-Object Guid (,[byte[]]$curB))) -eq $g) { $cur = $i }
    $nm = ''; try { $nm = [string](Get-ItemProperty -Path ($k + '\Desktops\{' + $g.ToString() + '}') -ErrorAction Stop).Name } catch {}
    $null = $names.Add($nm)
  }
  return (ConvertTo-Json -Compress -InputObject @{ n = $n; cur = $cur; names = @($names.ToArray()) })
}
$code6 = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class BaseBright {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] struct PHYSICAL_MONITOR { public IntPtr h; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string d; }
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int l, t, r, b; }
  delegate bool MonProc(IntPtr m, IntPtr dc, ref RECT r, IntPtr p);
  [DllImport("user32.dll")] static extern bool EnumDisplayMonitors(IntPtr dc, IntPtr clip, MonProc f, IntPtr p);
  [DllImport("dxva2.dll")] static extern bool GetNumberOfPhysicalMonitorsFromHMONITOR(IntPtr m, out uint n);
  [DllImport("dxva2.dll")] static extern bool GetPhysicalMonitorsFromHMONITOR(IntPtr m, uint n, [Out] PHYSICAL_MONITOR[] a);
  [DllImport("dxva2.dll")] static extern bool DestroyPhysicalMonitors(uint n, PHYSICAL_MONITOR[] a);
  [DllImport("dxva2.dll")] static extern bool GetMonitorBrightness(IntPtr h, out uint min, out uint cur, out uint max);
  [DllImport("dxva2.dll")] static extern bool SetMonitorBrightness(IntPtr h, uint v);
  static List<PHYSICAL_MONITOR[]> Grab() {
    var list = new List<PHYSICAL_MONITOR[]>();
    EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (IntPtr m, IntPtr dc, ref RECT r, IntPtr p) => {
      uint n; if (GetNumberOfPhysicalMonitorsFromHMONITOR(m, out n) && n > 0) { var a = new PHYSICAL_MONITOR[n]; if (GetPhysicalMonitorsFromHMONITOR(m, n, a)) list.Add(a); }
      return true; }, IntPtr.Zero);
    return list;
  }
  // pantallas externas (DDC/CI): [{i, v}] en porcentaje
  public static string Get() {
    var sb = new System.Text.StringBuilder("["); int i = 0; bool first = true;
    foreach (var a in Grab()) { foreach (var pm in a) { uint mn, cur, mx; if (GetMonitorBrightness(pm.h, out mn, out cur, out mx) && mx > mn) { if (!first) sb.Append(","); first = false; sb.Append("{\"i\":" + i + ",\"v\":" + (int)Math.Round((cur - mn) * 100.0 / (mx - mn)) + "}"); } i++; } DestroyPhysicalMonitors((uint)a.Length, a); }
    return sb.Append("]").ToString();
  }
  public static string Set(int which, int pct) {
    int i = 0; bool ok = false;
    foreach (var a in Grab()) { foreach (var pm in a) { if (which < 0 || which == i) { uint mn, cur, mx; if (GetMonitorBrightness(pm.h, out mn, out cur, out mx) && mx > mn) ok = SetMonitorBrightness(pm.h, (uint)(mn + (mx - mn) * Math.Max(0, Math.Min(100, pct)) / 100)) || ok; } i++; } DestroyPhysicalMonitors((uint)a.Length, a); }
    return ok ? "true" : "false";
  }
}
'@
$brightOk = $true
try { LoadCs 'bright' 'BaseBright' $code6 } catch { $brightOk = $false }
function BrightGet {
  $out = New-Object System.Collections.ArrayList
  try { $w = Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorBrightness -ErrorAction Stop | Select-Object -First 1; if ($w) { $null = $out.Add([pscustomobject]@{ i = -1; v = [int]$w.CurrentBrightness; k = 'interna' }) } } catch {}
  if ($brightOk) { try { foreach ($d in (ConvertFrom-Json ([BaseBright]::Get()))) { $null = $out.Add([pscustomobject]@{ i = [int]$d.i; v = [int]$d.v; k = 'externa' }) } } catch {} }
  if ($out.Count -eq 0) { return '[]' }
  return (ConvertTo-Json -InputObject @($out.ToArray()) -Compress)
}
function BrightSet($arg) {
  $p = $arg.Split('|'); $i = [int]$p[0]; $v = [int]$p[1]
  if ($i -lt 0) { try { $m = Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorBrightnessMethods -ErrorAction Stop | Select-Object -First 1; $null = Invoke-CimMethod -InputObject $m -MethodName WmiSetBrightness -Arguments @{ Timeout = [uint32]0; Brightness = [byte]$v }; return 'true' } catch { return 'false' } }
  if ($brightOk) { return [BaseBright]::Set($i, $v) }
  return 'false'
}


# ---- Vista previa de una ventana (para la barra de ventanas de Base) ----
$code7 = @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
public static class BaseThumb {
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int l, t, r, b; }
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll")] static extern uint GetClipboardSequenceNumber();
  [DllImport("user32.dll")] static extern bool IsClipboardFormatAvailable(uint f);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern uint RegisterClipboardFormat(string n);
  static uint fEx = 0, fIgn = 0, fHist = 0;
  // número de cambio del portapapeles y si el programa que copió pidió no guardarlo (gestores de contraseñas)
  public static string ClipSeq() {
    if (fEx == 0) { fEx = RegisterClipboardFormat("ExcludeClipboardContentFromMonitorProcessing"); fIgn = RegisterClipboardFormat("Clipboard Viewer Ignore"); fHist = RegisterClipboardFormat("CanIncludeInClipboardHistory"); }
    bool skip = false;
    try { skip = IsClipboardFormatAvailable(fEx) || IsClipboardFormatAvailable(fIgn) || IsClipboardFormatAvailable(fHist); } catch { }
    return "{\"s\":" + GetClipboardSequenceNumber() + ",\"x\":" + (skip ? "true" : "false") + "}";
  }
  public static string Get(long hv, int maxW) {
    IntPtr h = new IntPtr(hv);
    if (IsIconic(h)) return "null";
    IntPtr old = IntPtr.Zero;
    try { old = SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { }
    try {
      RECT r; if (!GetWindowRect(h, out r)) return "null";
      int w = r.r - r.l, hh = r.b - r.t;
      if (w < 20 || hh < 20 || w > 10000 || hh > 10000) return "null";
      using (var bmp = new Bitmap(w, hh, PixelFormat.Format32bppArgb)) {
        using (var g = Graphics.FromImage(bmp)) { IntPtr dc = g.GetHdc(); bool ok = PrintWindow(h, dc, 2); g.ReleaseHdc(dc); if (!ok) return "null"; }
        double sc = Math.Min(1.0, (double)maxW / w);
        int tw = Math.Max(1, (int)(w * sc)), th = Math.Max(1, (int)(hh * sc));
        using (var small = new Bitmap(tw, th)) {
          using (var g2 = Graphics.FromImage(small)) { g2.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic; g2.DrawImage(bmp, 0, 0, tw, th); }
          using (var ms = new MemoryStream()) {
            var enc = Array.Find(ImageCodecInfo.GetImageEncoders(), c => c.MimeType == "image/jpeg");
            var ps = new EncoderParameters(1); ps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 80L);
            small.Save(ms, enc, ps);
            return "\"" + Convert.ToBase64String(ms.ToArray()) + "\"";
          }
        }
      }
    } catch { return "null"; }
    finally { try { if (old != IntPtr.Zero) SetThreadDpiAwarenessContext(old); } catch { } }
  }
}
'@
$thumbOk = $true
try { LoadCs 'thumb' 'BaseThumb' $code7 @('System.Drawing') } catch { $thumbOk = $false }


# ---- Búsqueda de archivos con el índice de Windows ----
function FileSearch($q) {
  $words = @(($q -replace "[^\p{L}\p{N}\s\.\-_]", ' ').Split(' ', [StringSplitOptions]::RemoveEmptyEntries) | Select-Object -First 5)
  if ($words.Count -eq 0) { return '[]' }
  $cond = ($words | ForEach-Object { "CONTAINS(System.FileName, '""" + $_ + "*""')" }) -join ' AND '
  $prof = ([Environment]::GetFolderPath('UserProfile')).Replace('\', '/')
  $sql = "SELECT TOP 30 System.ItemPathDisplay, System.ItemNameDisplay, System.ItemType, System.DateModified FROM SystemIndex WHERE SCOPE='file:$prof' AND $cond AND NOT System.ItemPathDisplay LIKE '%\AppData\%' ORDER BY System.Search.Rank DESC, System.DateModified DESC"
  $cn = New-Object System.Data.OleDb.OleDbConnection "Provider=Search.CollatorDSO;Extended Properties='Application=Windows';"
  $out = New-Object System.Collections.ArrayList
  try {
    $cn.Open()
    $cmd = $cn.CreateCommand(); $cmd.CommandText = $sql; $cmd.CommandTimeout = 4
    $rd = $cmd.ExecuteReader()
    while ($rd.Read()) {
      $p = [string]$rd.GetValue(0); if (-not $p) { continue }
      $t = [string]$rd.GetValue(2)
      $m = $rd.GetValue(3); $ms = if ($m -is [DateTime]) { [long]($m.ToUniversalTime() - [DateTime]'1970-01-01').TotalMilliseconds } else { 0 }
      $null = $out.Add([pscustomobject]@{ p = $p; n = [string]$rd.GetValue(1); dir = ($t -eq 'Directory' -or $t -eq 'Folder'); m = $ms })
    }
    $rd.Close()
  } catch { return 'null' } finally { try { $cn.Close() } catch { } }
  if ($out.Count -eq 0) { return '[]' }
  return (ConvertTo-Json -InputObject @($out.ToArray()) -Compress)
}

[Console]::Out.WriteLine('{"ready":true}')
[Console]::Out.Flush()

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  $p = $line.Split(' ', 3)
  if ($p.Length -lt 2) { continue }
  $id = [int]$p[0]; $cmd = $p[1]; $arg = if ($p.Length -gt 2) { $p[2] } else { '' }
  try {
    $out = 'true'
    switch ($cmd) {
      'list'        { $out = [BaseWin]::List([long]$arg) }
      'flashes'     { $out = if ($flashOk) { [BaseFlash]::List() } else { '[]' } }
      'flashclear'  { $out = if ($flashOk) { [BaseFlash]::Clear([long]$arg) } else { 'false' } }
      'focus'       { [BaseWin]::Focus([long]$arg); if ($flashOk) { [void][BaseFlash]::Clear([long]$arg) } }
      'minimize'    { [BaseWin]::Minimize([long]$arg) }
      'close'       { [BaseWin]::Close([long]$arg) }
      'max'         { [BaseWin]::ToggleMax([long]$arg) }
      'minimizeAll' { [BaseWin]::MinimizeAll([long]$arg) }
      'keys'        { [BaseWin]::Keys($arg) }
      'vdesk'       { $out = VDesk }
      'spotify'     { $out = [BaseWin]::Spotify() }
      'media'       { [BaseWin]::Media($arg) }
      'drives'      { $out = if ($sysOk) { [BaseSys]::Drives() } else { 'null' } }
      'net'         { $out = if ($sysOk) { [BaseSys]::Net() } else { 'null' } }
      'place'       { $out = if ($sysOk) { [BaseSys]::Place($arg) } else { 'false' } }
      'topmost'     { $out = if ($sysOk) { [BaseSys]::TopMost([long]$arg) } else { 'false' } }
      'smtc'        { $out = SmtcState }
      'smtcthumb'   { $out = SmtcThumb $arg }
      'smtcdo'      { $out = SmtcDo $arg }
      'procs'       { $out = if ($sysOk) { [BaseSys]::Procs() } else { 'null' } }
      'vol'         { $out = if ($volOk) { [BaseVol]::Get() } else { 'null' } }
      'dockon'      { $out = if ($dockOk) { [BaseDock]::Attach($arg) } else { 'false' } }
      'dockmove'    { $out = if ($dockOk) { [BaseDock]::Move($arg) } else { 'false' } }
      'dockhide'    { $out = if ($dockOk) { [BaseDock]::Hide([long]$arg) } else { 'false' } }
      'dockoff'     { $out = if ($dockOk) { [BaseDock]::Detach($arg) } else { 'false' } }
      'fgclass'     { $out = if ($deskOk) { [BaseDesk]::FgClass() } else { 'null' } }
      'taskbar'     { $out = if ($deskOk) { [BaseDesk]::Taskbar($arg -eq '1') } else { 'false' } }
      'tbkeep'      { $out = if ($deskOk) { [BaseDesk]::Keep() } else { 'false' } }
      'bottom'      { $out = if ($deskOk) { [BaseDesk]::Bottom([long]$arg) } else { 'false' } }
      'workarea'    { $out = if ($deskOk) { [BaseDesk]::WorkArea($arg) } else { 'false' } }
      'appbar'      { $out = if ($barOk) { [BaseBar]::Set($arg) } else { 'false' } }
      'abinfo'      { $out = if ($barOk) { [BaseBar]::Info() } else { 'null' } }
      'abrenew'     { $out = if ($barOk) { [BaseBar]::Renew() } else { 'false' } }
      'waget'       { $out = if ($barOk) { [BaseBar]::Area($arg) } else { 'null' } }
      'relaunch'    { $script:relaunch = $arg; $out = 'true' }
      'bye'         { $script:cleanExit = $true; $out = 'true' }
      'radios'      { $out = RadioList }
      'clipseq'     { $out = if ($thumbOk) { [BaseThumb]::ClipSeq() } else { 'null' } }
      'fsearch'     { $out = FileSearch $arg }
      'wthumb'      { $out = if ($thumbOk) { [BaseThumb]::Get([long]$arg, 300) } else { 'null' } }
      'radioset'    { $out = RadioSet $arg }
      'bright'      { $out = BrightGet }
      'brightset'   { $out = BrightSet $arg }
      'watch'       { $out = if ($deskOk) { [BaseDesk]::Watch($arg) } else { 'false' } }
      'dockalive'   { $out = if ($dockOk) { [BaseDock]::Alive([long]$arg) } else { 'false' } }
      'volset'      { $out = if ($volOk) { [BaseVol]::Set([int]$arg) } else { 'null' } }
      'volmute'     { $out = if ($volOk) { [BaseVol]::Mute($arg -eq '1') } else { 'null' } }
      default       { $out = 'false' }
    }
    [Console]::Out.WriteLine('{"id":' + $id + ',"ok":true,"data":' + $out + '}')
  } catch {
    [Console]::Out.WriteLine('{"id":' + $id + ',"ok":false}')
  }
  [Console]::Out.Flush()
}
# Base se cerró: si escondimos la barra de Windows, la devolvemos; si se cerró de golpe, lo volvemos a abrir
if ($barOk) { try { [BaseBar]::Set('off') | Out-Null; Start-Sleep -Milliseconds 400 } catch {} }
if ($deskOk) { try { [BaseDesk]::WorkArea('off') | Out-Null } catch {} }
if ($deskOk -and [BaseDesk]::hidden) { try { [BaseDesk]::Taskbar($false) | Out-Null } catch {} }
if (-not $cleanExit -and $relaunch -and (Test-Path $relaunch)) {
  Start-Sleep -Seconds 3
  if (-not (Get-Process -Name 'Base' -ErrorAction SilentlyContinue)) { Start-Process -FilePath $relaunch -ArgumentList '--reabierto' }
}
