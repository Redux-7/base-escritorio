// Panel de Base para la tablet
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const ICO = {
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  windows: '<rect x="3" y="7" width="13" height="12" rx="2"/><path d="M8 7V5h13v12h-5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  power: '<path d="M12 3v9M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  prev: '<path d="M7 5v14M19 5L9 12l10 7z"/>', next: '<path d="M17 5v14M5 5l10 7-10 7z"/>',
  play: '<path d="M7 4.5v15l13-7.5z"/>', pause: '<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/>',
  mute: '<path d="M4 9h4l5-4v14l-5-4H4zM17 9l5 5M22 9l-5 5"/>', vol: '<path d="M4 9h4l5-4v14l-5-4H4zM16.5 8.5a5 5 0 0 1 0 7M19.5 5.5a9 9 0 0 1 0 13"/>',
  shot: '<rect x="3" y="6" width="18" height="13" rx="2"/><circle cx="12" cy="12.5" r="3.2"/><path d="M8 6l1.5-2h5L16 6"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15zM10 20a2 2 0 0 0 4 0"/><path d="M3 3l18 18"/>',
  grid4: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>', drag: '<circle cx="9" cy="6" r="1.3"/><circle cx="15" cy="6" r="1.3"/><circle cx="9" cy="12" r="1.3"/><circle cx="15" cy="12" r="1.3"/><circle cx="9" cy="18" r="1.3"/><circle cx="15" cy="18" r="1.3"/>',
  wide: '<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>', tall: '<path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4"/>',
  cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/><path d="M3 4h2l2.5 11h11l2-8H7"/>',
  bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', restart: '<path d="M4 12a8 8 0 1 0 2.5-5.8M4 4v5h5"/>', full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  desk: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M7 21h10"/>', music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', note: '<path d="M5 4h14v11l-5 5H5z"/><path d="M14 20v-5h5"/>', timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9.5 3h5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.3-1.3M17.7 6.3l1.4-1.4"/>'
};
const svg = (k, cls) => `<svg viewBox="0 0 24 24" class="${cls || ''}" aria-hidden="true">${ICO[k] || ''}</svg>`;
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const h = (tag, attrs, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'html') e.innerHTML = v; else if (k === 'text') e.textContent = v; else if (k.startsWith('on')) e[k] = v; else e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) e.append(k);
  return e;
};

// ---------- clave de vinculación ----------
let KEY = '';
try { KEY = localStorage.getItem('base-k') || ''; } catch {}
const qk = new URLSearchParams(location.search).get('k');
if (qk && /^[0-9a-f]{32}$/.test(qk)) { KEY = qk; try { localStorage.setItem('base-k', qk); } catch {} history.replaceState(null, '', location.pathname); }

async function api(path, body) {
  const r = await fetch('/api/' + path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Base-Key': KEY }, body: JSON.stringify(body) } : { headers: { 'X-Base-Key': KEY }, cache: 'no-store' });
  if (r.status === 401) { showPair(); throw new Error('sin vincular'); }
  return r.json();
}
const doIt = (b) => api('do', b).catch(e => ({ ok: false, error: e.message }));

// ---------- estado ----------
const T = { snap: null, media: [], vol: null, edit: false, layout: null, structKey: '', upd: [], dragging: 0, failed: 0, now: 0, skew: 0 };
const DEFAULT = () => ({ v: 2, blocks: [
  { id: 'b1', t: 'accesos', w: 2, h: 4 }, { id: 'b2', t: 'musica', w: 2, h: 3 },
  { id: 'b3', t: 'luz', w: 2, h: 3 }, { id: 'b4', t: 'atajos', w: 2, h: 2 }
], accent: '', scale: 'm' });
const layout = () => T.layout || (T.snap && T.snap.panel && Array.isArray(T.snap.panel.blocks) && T.snap.panel.v === 2 ? T.snap.panel : DEFAULT());
// con "un diseño por tablero", cada tablero guarda sus propios bloques
function BL(l) {
  const bd = T.snap && T.snap.board;
  if (l.perBoard && bd) { l.boards = l.boards || {}; if (!Array.isArray(l.boards[bd])) l.boards[bd] = JSON.parse(JSON.stringify(l.blocks)); return l.boards[bd]; }
  return l.blocks;
}
let saveT = null;
function saveLayout() {
  clearTimeout(saveT);
  saveT = setTimeout(async () => { await doIt({ a: 'layout', panel: T.layout }); saveT = null; }, 400);
}
function editLayout(fn) {
  T.layout = JSON.parse(JSON.stringify(layout()));
  fn(T.layout);
  saveLayout();
  render(true);
}

function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 2600); }
function showPair() { $('#pair').hidden = false; $('#app').hidden = true; }

async function poll() {
  if (!KEY) return showPair();
  if (document.hidden) return;
  try {
    const r = await api('state');
    if (!r || !r.ok) throw new Error('mal');
    T.failed = 0; $('#offline').hidden = true;
    // si Base se actualizó, la tablet se recarga sola para tomar lo nuevo
    if (r.ver) { if (T.ver && T.ver !== r.ver && !T.edit) { location.reload(); return; } T.ver = r.ver; }
    T.skew = r.now - Date.now();
    T.snap = r.snap; T.media = r.media || []; T.vol = r.vol;
    if (T.snap && T.snap.panel && !T.edit && !saveT) T.layout = null;
    render(false);
  } catch (e) {
    if (e.message === 'sin vincular') return;
    if (++T.failed >= 2) $('#offline').hidden = false;
  }
}

// ---------- dibujo ----------
function structKey() {
  const s = T.snap || {};
  return JSON.stringify([layout(), s.items, s.boards, s.board, (s.lamps || []).map(l => l.id + l.n), s.super, s.scenes, s.wx, s.name, s.dnd, s.dark, T.edit, innerWidth > innerHeight]);
}
function render(force) {
  const s = T.snap;
  $('#app').hidden = false; $('#pair').hidden = true;
  const L = layout();
  document.documentElement.style.setProperty('--ac', L.accent || (s && s.accent) || '#8b5cf6');
  document.documentElement.dataset.scale = L.scale || 'm';
  document.documentElement.dataset.bg = L.bg || 'base';
  document.documentElement.dataset.round = L.round || 'r';
  document.documentElement.dataset.glass = L.glass || '1';
  if (T.idleKey !== String(L.idle || 0)) { T.idleKey = String(L.idle || 0); bumpIdle(); }
  document.body.classList.toggle('editing', T.edit);
  const k = structKey();
  if (force || (k !== T.structKey && !T.typing)) {
    T.structKey = k;
    T.upd = [];
    renderTop(); renderGrid(); renderTray(); renderBar();
  }
  for (const f of T.upd) { try { f(); } catch (e) { console.error(e); } }
}
const DOW = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MON = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
function tickClock() {
  const d = new Date();
  $('#hh').textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  const ds = DOW[d.getDay()]; $('#date').textContent = ds[0].toUpperCase() + ds.slice(1) + ' ' + d.getDate() + ' de ' + MON[d.getMonth()];
  const hr = d.getHours(), n = T.snap && T.snap.name;
  $('#greet').textContent = (hr < 6 ? 'Buenas noches' : hr < 13 ? 'Buen día' : hr < 20 ? 'Buenas tardes' : 'Buenas noches') + (n ? ', ' + n : '');
}
function renderTop() {
  const s = T.snap || {};
  tickClock();
  const nav = $('#boards'); nav.replaceChildren();
  for (const b of s.boards || []) {
    nav.append(h('button', { class: 'chip' + (b.id === s.board ? ' on' : ''), text: b.n, onclick: async () => { s.board = b.id; render(true); await doIt({ a: 'board', id: b.id }); setTimeout(poll, 300); } }));
  }
  const wx = s.wx;
  $('#wx').innerHTML = wx ? `<svg viewBox="0 0 24 24" aria-hidden="true">${wx.ic}</svg><b>${wx.t}°</b><span>${esc(wx.d)}<br>${wx.min}° / ${wx.max}°</span>` : '';
  const eb = $('#edit-btn');
  eb.innerHTML = svg(T.edit ? 'check' : 'edit') + `<span>${T.edit ? 'Listo' : 'Personalizar'}</span>`;
  eb.classList.toggle('on', T.edit);
}
$('#edit-btn').onclick = () => { T.edit = !T.edit; if (T.edit) T.layout = JSON.parse(JSON.stringify(layout())); render(true); };

function blockShell(b, title, body, extraCls) {
  const L = layout();
  const portrait = innerWidth < innerHeight;
  const w = Math.min(b.w || 2, portrait ? 2 : 4), hh = Math.max(1, Math.min(6, b.h || 2));
  const el = h('section', { class: 'blk t-' + b.t + (extraCls ? ' ' + extraCls : '') + (b.tint ? ' tinted' : ''), 'data-id': b.id, style: `grid-column: span ${w}; grid-row: span ${hh}` + (b.tint ? `;--tint:${b.tint}` : '') });
  if (b.title && b.t !== 'boton') title = b.title;
  if (title) el.append(h('div', { class: 'blk-h', text: title }));
  el.append(body);
  if (T.edit) {
    const tools = h('div', { class: 'blk-tools' },
      h('button', { class: 'tl drag', html: svg('drag'), 'aria-label': 'Arrastrar', onpointerdown: (e) => startDrag(e, b.id) }),
      h('button', { class: 'tl', html: svg('wide'), title: 'Ancho', onclick: () => editLayout(l => { const x = BL(l).find(y => y.id === b.id); x.w = (x.w || 2) % 4 + 1; }) }),
      h('button', { class: 'tl', html: svg('tall'), title: 'Alto', onclick: () => editLayout(l => { const x = BL(l).find(y => y.id === b.id); const HS = [2, 3, 4, 6]; x.h = HS[(HS.indexOf(x.h) + 1) % HS.length]; }) }),
      h('button', { class: 'tl', html: svg('edit'), title: 'Nombre y color', onclick: () => editBlock(b) }),
      h('button', { class: 'tl del', html: svg('x'), title: 'Quitar', onclick: () => editLayout(l => { const a = BL(l); a.splice(a.findIndex(y => y.id === b.id), 1); }) }));
    el.append(tools);
  }
  return el;
}
function renderGrid() {
  const g = $('#grid'); g.replaceChildren();
  const L = layout();
  for (const b of BL(L)) {
    const f = BLOCKS[b.t];
    if (!f) continue;
    try { g.append(f(b)); } catch (e) { console.error(e); }
  }
  if (!BL(L).length) g.append(h('div', { class: 'empty', text: T.edit ? 'Sumá bloques desde abajo' : 'Tocá Personalizar para armar tu panel' }));
}

// ----- bloques -----
function iconEl(it) {
  const box = h('span', { class: 'aic' });
  const letter = () => { box.replaceChildren(h('span', { class: 'let', text: it.l || '?' })); };
  if (it.ic) { const img = h('img', { src: it.ic, alt: '', draggable: 'false' }); img.onerror = letter; img.onload = () => { if (img.naturalWidth < 8) letter(); }; box.append(img); } else letter();
  return box;
}
const BLOCKS = {
  accesos(b) {
    const s = T.snap || {}; const hide = new Set(b.hide || []);
    const grid = h('div', { class: 'apps' });
    const add = (it, inGroup) => {
      if (hide.has(it.id)) return;
      const btn = h('button', { class: 'app', onclick: () => { if (T.edit) return; if (it.g) return openGroup(it); tap(btn); doIt({ a: 'open', id: it.id }).then(r => { if (r && r.ok === false) toast(r.error || 'No se pudo abrir'); else toast('Abriendo ' + it.n); }); } },
        it.g ? h('span', { class: 'aic grp' }, ...it.g.slice(0, 4).map(x => iconEl(x))) : iconEl(it), h('span', { class: 'an', text: it.n }));
      if (T.edit) btn.append(h('i', { class: 'rm', html: svg('x'), onclick: (e) => { e.stopPropagation(); editLayout(l => { const x = BL(l).find(y => y.id === b.id); x.hide = [...(x.hide || []), it.id]; }); } }));
      grid.append(btn);
    };
    for (const it of s.items || []) add(it);
    if (!grid.children.length) grid.append(h('p', { class: 'muted', text: 'Este tablero no tiene accesos.' }));
    if (T.edit && hide.size) grid.append(h('button', { class: 'app ghost', onclick: () => editLayout(l => { delete BL(l).find(y => y.id === b.id).hide; }) }, h('span', { class: 'aic', html: svg('restart') }), h('span', { class: 'an', text: 'Mostrar todos' })));
    return blockShell(b, 'Accesos', grid);
  },
  atajos(b) {
    const s = T.snap || {};
    const list = [
      ['shot', 'Captura', () => takeShot()],
      ['bell', s.dnd ? 'Avisos: no' : 'No molestar', async () => { const r = await doIt({ a: 'dnd' }); toast(r && r.on ? 'No molestar activado' : 'Avisos activados'); poll(); }, s.dnd],
      ['moon', s.dark ? 'Modo claro' : 'Modo oscuro', async () => { await doIt({ a: 'theme' }); setTimeout(poll, 300); }],
      ['grid4', 'Minimizar todo', () => doIt({ a: 'sys', name: 'minimizeAll' })]
    ];
    return blockShell(b, 'Atajos rápidos', h('div', { class: 'quick' }, ...list.map(([ic, n, fn, on]) => { const x = h('button', { class: 'qb' + (on ? ' on' : ''), html: svg(ic) + `<span>${esc(n)}</span>`, onclick: () => { if (!T.edit) { tap(x); fn(); } } }); return x; })));
  },
  musica(b) {
    const artImg = h('img', { alt: '' }); artImg.onerror = () => { artImg.hidden = true; }; artImg.onload = () => { artImg.hidden = false; };
    const art = h('div', { class: 'art', html: svg('music') }); art.append(artImg);
    const src = h('div', { class: 'msrc' }), tt = h('div', { class: 'mtt' }), ar = h('div', { class: 'mar' });
    const prog = h('div', { class: 'prog' }, h('i')), t1 = h('span'), t2 = h('span');
    const bPrev = h('button', { class: 'mb', html: svg('prev') }), bPlay = h('button', { class: 'mb big' }), bNext = h('button', { class: 'mb', html: svg('next') });
    const cur = () => { const m = T.media || []; return m.find(x => x.cur) || m.find(x => x.status === 'Playing') || m[0] || null; };
    const go = (act) => { const c = cur(); if (c) doIt({ a: 'media', app: c.app, act }).then(() => setTimeout(poll, 250)); else doIt({ a: 'mediakey', k: act === 'toggle' ? 'play' : act }); };
    bPrev.onclick = () => go('prev'); bNext.onclick = () => go('next'); bPlay.onclick = () => { const c = cur(); if (c) c.status = c.status === 'Playing' ? 'Paused' : 'Playing'; upd(); go('toggle'); };
    const vol = volume();
    let lastArt = '';
    const upd = () => {
      const c = cur();
      const name = c ? (/spotify/i.test(c.app) ? 'Spotify' : /chrome/i.test(c.app) ? 'Chrome' : /opera/i.test(c.app) ? 'Opera' : /edge/i.test(c.app) ? 'Edge' : /firefox/i.test(c.app) ? 'Firefox' : (c.app.split(/[!.\\]/).filter(Boolean).pop() || '')) : '';
      src.textContent = c ? name : 'Nada sonando';
      tt.textContent = c ? (c.title || 'Sin título') : 'Poné música en la compu';
      ar.textContent = c ? [c.artist, c.album].filter(Boolean).join(' · ') : '';
      bPlay.innerHTML = svg(c && c.status === 'Playing' ? 'pause' : 'play');
      const key = c ? c.app + '|' + c.title : '';
      if (key !== lastArt) { lastArt = key; artImg.hidden = true; if (c && c.title) artImg.src = `/api/thumb?app=${encodeURIComponent(c.app)}&v=${encodeURIComponent(c.title)}&k=${KEY}`; }
      if (c && c.end > 0) {
        let pos = c.pos; if (c.status === 'Playing' && c.upd) pos += (Date.now() + T.skew - c.upd) / 1000;
        pos = Math.max(0, Math.min(c.end, pos));
        prog.firstChild.style.width = (pos / c.end * 100).toFixed(1) + '%';
        t1.textContent = fmtT(pos); t2.textContent = fmtT(c.end); prog.hidden = false;
      } else { prog.hidden = true; t1.textContent = ''; t2.textContent = ''; }
    };
    T.upd.push(upd);
    return blockShell(b, 'Sonando en la compu', h('div', { class: 'music' },
      h('div', { class: 'mtop' }, art, h('div', { class: 'minfo' }, src, tt, ar, prog, h('div', { class: 'times' }, t1, t2))),
      h('div', { class: 'mctl' }, bPrev, bPlay, bNext), vol));
  },
  volumen(b) { return blockShell(b, 'Volumen', volume()); },
  luz(b) {
    const s = T.snap || {};
    const lamps = s.lamps || [];
    const l = lamps.find(x => x.id === b.lamp) || lamps[0];
    if (!l) return blockShell(b, 'Luces', h('p', { class: 'muted', text: 'Sumá tus lamparitas desde Base en la compu (tarjeta Luces).' }));
    const orb = h('button', { class: 'orb' }), nm = h('b'), sw = h('button', { class: 'tog' });
    const br = range(1, (v, fin) => lampDo(l, { bright: v }, fin));
    const cols = h('div', { class: 'cols' });
    const COLS = [['#ffffff', { temp: 50 }], ['#ffd29a', { temp: 0 }], ['#ff4d4d'], ['#ff9a2e'], ['#4fd36b'], ['#3d9bff'], ['#a77bff'], ['#ff5fc1']];
    for (const [c, ex] of COLS) cols.append(h('button', { class: 'col', style: `--c:${c}`, 'data-c': c, onclick: () => lampDo(l, ex || { color: c }, true) }));
    const pick = h('input', { type: 'color', value: '#a77bff' }); pick.onchange = () => lampDo(l, { color: pick.value }, true);
    cols.append(h('label', { class: 'col rainbow' }, pick));
    const scenes = h('div', { class: 'scenes' }, ...(s.scenes || []).slice(0, 4).map(sc => h('button', { class: 'scn', style: `--c:${sc.color}`, html: `<i></i>${esc(sc.n)}`, onclick: () => lampDo(l, { scene: sc.id }, true) })));
    orb.onclick = () => lampDo(l, { toggle: true }, true); sw.onclick = orb.onclick;
    const upd = () => {
      const st = (T.snap.lamps.find(x => x.id === l.id) || {}).st;
      const on = st && st.on;
      orb.classList.toggle('off', !on); sw.classList.toggle('on', !!on);
      orb.style.setProperty('--c', lampColor(st));
      nm.textContent = st ? (on ? colorName(st) + ' · ' + st.bright + '%' : 'Apagada') : 'Conectando…';
      if (st && !br.busy) br.set(st.bright);
      br.input.style.setProperty('--c', st && st.mode === 'colour' ? st.color : '#ffd9a0');
      for (const c of cols.querySelectorAll('.col[data-c]')) c.classList.toggle('on', !!(on && st.mode === 'colour' && c.dataset.c === nearest(st.color)));
    };
    if (!l.st) doIt({ a: 'lamp', id: l.id, status: true }).then(r => { if (r && r.ok) { l.st = r.st; upd(); } });
    T.upd.push(upd);
    const title = lamps.length > 1 ? 'Luz: ' + l.n : 'Luz del ' + l.n.toLowerCase();
    const head = h('div', { class: 'lhead' }, orb, h('div', { class: 'lmain' }, nm, br.wrap), sw);
    return blockShell(b, lamps.length > 1 || !/^[a-záéíóú]/i.test(l.n) ? l.n : title, h('div', { class: 'lamp' }, head, cols, scenes));
  },
  super(b) {
    const s = T.snap || {};
    const inp = h('input', { placeholder: 'Agregar… (ej. 2 leche)', enterkeyhint: 'done' });
    const addIt = async () => { const v = inp.value.trim(); if (!v) return; inp.value = ''; await doIt({ a: 'super', add: v }); poll(); };
    inp.onkeydown = (e) => { if (e.key === 'Enter') addIt(); };
    const list = h('div', { class: 'slist' }, ...(s.super || []).map(it => h('button', { class: 'sit', onclick: async (e) => { e.currentTarget.classList.add('done'); await doIt({ a: 'super', done: it.id }); setTimeout(poll, 300); } }, h('i'), h('span', { text: (it.q ? it.q + ' ' : '') + it.t }))));
    if (!(s.super || []).length) list.append(h('p', { class: 'muted', text: 'Nada para comprar' }));
    return blockShell(b, 'Supermercado', h('div', { class: 'super' }, h('div', { class: 'sadd' }, inp, h('button', { class: 'sbtn', html: svg('plus'), onclick: addIt })), list));
  },
  clima(b) {
    const w = (T.snap || {}).wx;
    return blockShell(b, w ? 'Clima en ' + w.city : 'Clima', w ? h('div', { class: 'clima', html: `<svg viewBox="0 0 24 24">${w.ic}</svg><div><b>${w.t}°</b><span>${esc(w.d)}</span><small>Mín ${w.min}° · Máx ${w.max}°</small></div>` }) : h('p', { class: 'muted', text: 'Sin datos' }));
  },
  boton(b) {
    const r = refInfo(b.ref);
    const btn = h('button', { class: 'bigbtn', onclick: () => { if (T.edit) return; tap(btn); r.run(); } }, r.icon, h('span', { text: b.title || r.n }));
    return blockShell(b, null, btn, 'solo');
  },
  reloj(b) {
    const hh = h('b', { class: 'rl-h' }), dd = h('span', { class: 'rl-d' });
    const upd = () => { const d = new Date(); hh.textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); const ds = DOW[d.getDay()]; dd.textContent = ds[0].toUpperCase() + ds.slice(1) + ' ' + d.getDate() + ' de ' + MON[d.getMonth()]; };
    T.upd.push(upd); upd();
    return blockShell(b, null, h('div', { class: 'reloj' }, hh, dd), 'solo');
  },
  notas(b) {
    const ta = h('textarea', { class: 'nota', placeholder: 'Escribí lo que quieras recordar…' });
    ta.value = b.text || '';
    ta.oninput = () => { clearTimeout(ta.t); ta.t = setTimeout(() => { T.layout = JSON.parse(JSON.stringify(layout())); const x = BL(T.layout).find(y => y.id === b.id); if (x) { x.text = ta.value.slice(0, 2000); saveLayout(); } }, 700); };
    ta.onfocus = () => { T.typing = true; }; ta.onblur = () => { T.typing = false; };
    return blockShell(b, 'Nota', ta);
  },
  timer(b) {
    const big = h('b', { class: 'tm-big', text: '00:00' });
    const st = TIMERS[b.id] = TIMERS[b.id] || { end: 0, left: 0, run: false, set: 5 * 60 };
    const fmt = (s) => { s = Math.max(0, Math.ceil(s)); const m = Math.floor(s / 60); return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s % 60).padStart(2, '0'); };
    const left = () => st.run ? (st.end - Date.now()) / 1000 : (st.left || st.set);
    const go = h('button', { class: 'tm-go' });
    const upd = () => {
      const l = left();
      if (st.run && l <= 0) { st.run = false; st.left = 0; alarm(); }
      big.textContent = fmt(left()); go.innerHTML = svg(st.run ? 'pause' : 'play');
      big.classList.toggle('ring', !st.run && st.left === 0 && st.rang);
    };
    go.onclick = () => { if (st.run) { st.left = left(); st.run = false; } else { if (!st.left) st.left = st.set; st.end = Date.now() + st.left * 1000; st.run = true; st.rang = true; } upd(); };
    const presets = h('div', { class: 'tm-pre' }, ...[1, 3, 5, 10, 15, 30].map(m => h('button', { class: 'tm-p', text: m + ' min', onclick: () => { st.set = m * 60; st.left = m * 60; st.run = false; upd(); } })),
      h('button', { class: 'tm-p', text: '+1', onclick: () => { if (st.run) st.end += 60000; else st.left = (st.left || st.set) + 60; upd(); } }),
      h('button', { class: 'tm-p', html: svg('restart'), onclick: () => { st.run = false; st.left = st.set; st.rang = false; upd(); } }));
    T.upd.push(upd);
    return blockShell(b, 'Temporizador', h('div', { class: 'timer' }, h('div', { class: 'tm-row' }, big, go), presets));
  },
  escenas(b) {
    const s = T.snap || {}; const lamps = s.lamps || [];
    if (!lamps.length) return blockShell(b, 'Escenas', h('p', { class: 'muted', text: 'Sumá tus lamparitas desde Base en la compu (tarjeta Luces).' }));
    const all = (a) => { for (const l of lamps) doIt({ a: 'lamp', id: l.id, do: a }); toast(lamps.length > 1 ? 'Listo, en todas las luces' : 'Listo'); setTimeout(poll, 800); };
    const btns = [...(s.scenes || []).map(sc => h('button', { class: 'scn big', style: `--c:${sc.color}`, html: `<i></i>${esc(sc.n)}`, onclick: () => all({ scene: sc.id }) })),
      h('button', { class: 'scn big', style: '--c:#ffd9a0', html: `<i></i>Prender todo`, onclick: () => all({ on: true }) }),
      h('button', { class: 'scn big', style: '--c:#3a3f4b', html: `<i></i>Apagar todo`, onclick: () => all({ on: false }) })];
    return blockShell(b, 'Escenas de luz', h('div', { class: 'scenes all' }, ...btns));
  }
};
const TIMERS = {};
let actx = null;
function alarm() {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime;
    for (let i = 0; i < 6; i++) { const o = actx.createOscillator(), g = actx.createGain(); o.frequency.value = i % 2 ? 660 : 880; o.connect(g); g.connect(actx.destination); g.gain.setValueAtTime(0.0001, t0 + i * 0.35); g.gain.exponentialRampToValueAtTime(0.4, t0 + i * 0.35 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + i * 0.35 + 0.3); o.start(t0 + i * 0.35); o.stop(t0 + i * 0.35 + 0.32); }
  } catch {}
  if (navigator.vibrate) try { navigator.vibrate([300, 150, 300, 150, 300]); } catch {}
  toast('¡Terminó el temporizador!');
}
const TINTS = ['', '#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6'];
function editBlock(b) {
  const name = h('input', { class: 'eb-in', value: b.title || '', placeholder: 'Nombre (dejalo vacío para el de siempre)' });
  let tint = b.tint || '';
  const sw = h('div', { class: 'accs' }, ...TINTS.map(c => { const x = h('button', { class: 'acc' + (c === tint ? ' on' : '') + (c ? '' : ' auto'), style: c ? `--c:${c}` : '', text: c ? '' : 'Sin color', onclick: () => { tint = c; for (const y of sw.children) y.classList.toggle('on', y === x); } }); return x; }));
  sheet('Personalizar este bloque', h('div', { class: 'eb' }, h('label', { class: 'tl2', text: 'Nombre' }), name, h('label', { class: 'tl2', text: 'Color' }), sw,
    h('div', { class: 'eb-acts' }, h('button', { class: 'pw ghost', html: '<span>Cancelar</span>', onclick: closeSheet }), h('button', { class: 'pw', html: '<span>Guardar</span>', onclick: () => { editLayout(l => { const x = BL(l).find(y => y.id === b.id); if (!x) return; const n = name.value.trim().slice(0, 40); if (n) x.title = n; else delete x.title; if (tint) x.tint = tint; else delete x.tint; }); closeSheet(); } }))));
}
// ----- captura de pantalla de la compu -----
async function takeShot() {
  toast('Sacando la captura…');
  const r = await doIt({ a: 'shot' });
  $('#toast').classList.remove('on');
  if (!r || !r.ok) return toast('No se pudo: ' + ((r && r.error) || 'error'));
  sheet('Captura de la compu', h('img', { class: 'shot-img', src: r.preview, alt: 'Captura' }),
    h('p', { class: 'muted', text: 'Quedó guardada en la compu, en Imágenes › Capturas de Base, y copiada para pegar con Ctrl+V.' }),
    h('div', { class: 'eb-acts' }, h('button', { class: 'pw ghost', html: '<span>Abrir la carpeta en la compu</span>', onclick: () => { doIt({ a: 'shotfolder' }); closeSheet(); } }), h('button', { class: 'pw', html: '<span>Listo</span>', onclick: closeSheet })));
}
// ----- ajustes (de la tablet y de Base en la compu) -----
function openSettings() {
  const s = T.snap || {}, cfg = s.cfg || {}, L = layout();
  const tog = (label, hint, on, fn) => { const b = h('button', { class: 'tog' + (on ? ' on' : ''), 'aria-label': label, onclick: async () => { b.classList.toggle('on'); await fn(b.classList.contains('on')); setTimeout(poll, 400); } }); return h('div', { class: 'st-row' }, h('div', {}, h('b', { text: label }), hint ? h('small', { text: hint }) : null), b); };
  const set = (k) => (v) => doIt({ a: 'setting', k, v });
  const accents = h('div', { class: 'accs' }, ...ACCENTS.map(c => h('button', { class: 'acc' + (s.accent === c ? ' on' : ''), style: `--c:${c}`, onclick: async () => { await doIt({ a: 'setting', k: 'accent', v: c }); toast('Color cambiado en la compu'); setTimeout(poll, 300); closeSheet(); } })));
  sheet('Ajustes',
    h('div', { class: 'st-sec' }, h('span', { class: 'tl2', text: 'Esta tablet' })),
    h('div', { class: 'st-grid' },
      h('button', { class: 'pw', html: svg('sun') + '<span>Fondo y estilo</span>', onclick: openLook }),
      h('button', { class: 'pw', html: svg('edit') + '<span>Ordenar bloques</span>', onclick: () => { closeSheet(); T.edit = true; T.layout = JSON.parse(JSON.stringify(layout())); render(true); } }),
      h('button', { class: 'pw', html: svg('full') + '<span>Pantalla completa</span>', onclick: () => { closeSheet(); document.documentElement.requestFullscreen().catch(() => toast('Este navegador no lo permite')); } }),
      h('button', { class: 'pw ghost', html: svg('x') + '<span>Desvincular</span>', onclick: () => { if (!confirm('¿Desvincular esta tablet? Vas a tener que escanear el código de nuevo.')) return; try { localStorage.removeItem('base-k'); } catch {} KEY = ''; closeSheet(); showPair(); } })),
    h('div', { class: 'st-sec' }, h('span', { class: 'tl2', text: 'Base en la compu' })),
    h('button', { class: 'pw pcs-open', html: svg('monitor') + '<span>Todos los ajustes de Base (los mismos que en la compu)</span>', onclick: () => openPcSettings() }),
    tog('Modo oscuro', 'Del tablero que está abierto', !!s.dark, set('dark')),
    tog('No molestar', 'Los avisos no aparecen en pantalla', !!s.dnd, (v) => doIt({ a: 'dnd', on: v })),
    tog('Base como escritorio', 'Siempre al fondo; aparece con Windows+D', !!cfg.deskMode, set('deskMode')),
    tog('Esconder la barra de tareas', 'La de Windows', !!cfg.hideTaskbar, set('hideTaskbar')),
    tog('Pantalla completa', 'Base tapa toda la pantalla', !!cfg.fullscreen, set('fullscreen')),
    tog('Abrir con Windows', 'Base arranca solo al prender la compu', !!cfg.startWithWindows, set('startWithWindows')),
    h('div', { class: 'st-row' }, h('div', {}, h('b', { text: 'Color del tablero' }), h('small', { text: 'El color de Base para ' + ((s.boards || []).find(b => b.id === s.board) || { n: 'este tablero' }).n })), accents),
    h('div', { class: 'eb-acts' }, h('button', { class: 'pw', html: '<span>Listo</span>', onclick: closeSheet })));
}
$('#cfg-btn').onclick = openSettings;
// ----- todos los Ajustes de Base (la misma lista que en la compu) -----
const PCS = { sec: '', schema: null, busy: false };
async function openPcSettings(sec) {
  if (sec) PCS.sec = sec;
  sheet('Ajustes de Base', h('p', { class: 'muted', text: 'Cargando los ajustes de la compu…' }));
  $('#sheet').classList.add('wide');
  const r = await doIt({ a: 'drawer' });
  if (!r || !r.ok || !r.schema) return sheet('Ajustes de Base', h('p', { class: 'muted', text: 'No pude traer los ajustes. ¿Base está abierto en la compu?' }));
  PCS.schema = r.schema; paintPcs();
}
async function pcsSet(msg, keepScroll) {
  if (PCS.busy) return; PCS.busy = true;
  const body = $('#sheet .pcs-body'), top = body ? body.scrollTop : 0;
  const r = await doIt(Object.assign({ a: 'drawerset' }, msg));
  PCS.busy = false;
  if (r && r.schema) { PCS.schema = r.schema; paintPcs(); const b2 = $('#sheet .pcs-body'); if (b2) b2.scrollTop = top; }
  else toast('No se pudo cambiar');
  setTimeout(poll, 300);
}
function paintPcs() {
  const sc = PCS.schema; if (!sc) return;
  if (!sc.secs.some(x => x.key === PCS.sec)) PCS.sec = sc.secs[0] ? sc.secs[0].key : '';
  const sec = sc.secs.find(x => x.key === PCS.sec);
  const nav = h('nav', { class: 'pcs-nav' }, ...sc.secs.map(x => h('button', { class: 'pcs-tab' + (x.key === PCS.sec ? ' on' : ''), text: x.title.replace(/ de .*$/, ''), onclick: () => { PCS.sec = x.key; paintPcs(); } })));
  const rows = [];
  for (const it of (sec ? sec.items : [])) {
    if (it.t === 'hint') { rows.push(h('p', { class: 'pcs-hint', text: it.text })); continue; }
    if (it.t === 'toggle') { const b = h('button', { class: 'tog' + (it.v ? ' on' : ''), onclick: () => pcsSet({ id: it.id, v: !it.v }) }); rows.push(h('div', { class: 'st-row' }, h('div', {}, h('b', { text: it.label })), b)); continue; }
    if (it.t === 'select') { const sel = h('select', { class: 'pcs-sel' }, ...it.opts.map(([v, n]) => { const o = h('option', { value: v, text: n }); if (v === it.v) o.selected = true; return o; })); sel.onchange = () => pcsSet({ id: it.id, v: sel.value }); rows.push(h('div', { class: 'st-row stack' }, h('b', { text: it.label }), sel)); continue; }
    if (it.t === 'range') { const r = h('input', { type: 'range', class: 'pcs-range', min: String(it.min), max: String(it.max), step: String(it.step), value: String(it.v) }); r.onchange = () => pcsSet({ id: it.id, v: r.value }); rows.push(h('div', { class: 'st-row stack' }, h('b', { text: it.label }), r)); continue; }
    if (it.t === 'color') { const c = h('input', { type: 'color', class: 'pcs-color', value: it.v }); c.onchange = () => pcsSet({ id: it.id, v: c.value }); rows.push(h('div', { class: 'st-row' }, h('b', { text: it.label }), c)); continue; }
    if (it.t === 'text') { const t = h('input', { class: 'eb-in', value: it.v, placeholder: it.ph }); const ok = h('button', { class: 'pw', html: '<span>Guardar</span>', onclick: () => pcsSet({ id: it.id, v: t.value }) }); rows.push(h('div', { class: 'st-row stack' }, h('b', { text: it.label }), h('div', { class: 'pcs-text' }, t, ok))); continue; }
    if (it.t === 'button') { rows.push(h('button', { class: 'pw pcs-btn', html: `<span>${esc(it.label)}</span>`, onclick: async () => { await pcsSet({ id: it.id }); toast('Listo, mirá la compu'); } })); continue; }
    if (it.t === 'choice') {
      rows.push(h('div', { class: 'st-row stack' }, it.label ? h('b', { text: it.label }) : null, h('div', { class: 'pcs-choices' + (it.opts.every(o => o.bg && !o.n) || it.opts.length > 10 && it.opts.every(o => o.bg) ? ' swatchy' : '') }, ...it.opts.map(o => h('button', { class: 'pcs-ch' + (o.on ? ' on' : ''), onclick: () => pcsSet({ id: it.id, opt: o.i }) }, o.bg ? h('i', { style: `background:${o.bg}` }) : null, o.n ? h('span', { text: o.n }) : null)))));
    }
  }
  sheet('Ajustes de Base' + (sc.board ? ' · ' + sc.board : ''), h('div', { class: 'pcs' }, nav, h('div', { class: 'pcs-body' }, ...rows)),
    h('div', { class: 'eb-acts' }, h('button', { class: 'pw', html: '<span>Listo</span>', onclick: () => { $('#sheet').classList.remove('wide'); closeSheet(); } })));
  $('#sheet').classList.add('wide');
}
// ----- apariencia -----
const BGS = [['base', 'Como Base'], ['noche', 'Noche'], ['aurora', 'Aurora'], ['oceano', 'Océano'], ['bosque', 'Bosque'], ['atardecer', 'Atardecer'], ['claro', 'Claro']];
function openLook() {
  const L = layout();
  const row = (label, opts, cur, key) => h('div', { class: 'lk-row' }, h('span', { class: 'tl2', text: label }), h('div', { class: 'szs wrap' }, ...opts.map(([v, n]) => h('button', { class: 'sz' + (String(cur) === String(v) ? ' on' : ''), text: n, 'data-bg': key === 'bg' ? v : null, onclick: () => { editLayout(l => { l[key] = v; }); openLook(); } }))));
  sheet('Apariencia del panel',
    h('div', { class: 'lk-bgs' }, ...BGS.map(([v, n]) => h('button', { class: 'lk-bg' + ((L.bg || 'base') === v ? ' on' : ''), 'data-bg': v, onclick: () => { editLayout(l => { l.bg = v; }); openLook(); } }, h('i'), h('span', { text: n })))),
    row('Esquinas', [['r', 'Redondeadas'], ['s', 'Rectas']], L.round || 'r', 'round'),
    row('Bloques', [['0', 'Sólidos'], ['1', 'Translúcidos'], ['2', 'Vidrio']], L.glass || '1', 'glass'),
    row('Botones', [['s', 'Chicos'], ['m', 'Normales'], ['l', 'Grandes']], L.scale || 'm', 'scale'),
    row('Reposo', [['0', 'Nunca'], ['2', '2 min'], ['5', '5 min'], ['10', '10 min'], ['30', '30 min']], L.idle || '0', 'idle'),
    h('p', { class: 'muted lk-note', text: 'Reposo: si nadie toca la tablet, muestra un reloj grande con el clima y lo que suena. Tocá la pantalla para volver.' }),
    h('div', { class: 'eb-acts' }, h('button', { class: 'pw', html: '<span>Listo</span>', onclick: closeSheet })));
}
// ----- reposo -----
let idleT = null;
function bumpIdle() {
  clearTimeout(idleT);
  const rest = $('#rest'); if (rest && !rest.hidden) rest.hidden = true;
  const m = Number(layout().idle || 0);
  if (m > 0 && !T.edit) idleT = setTimeout(showRest, m * 60000);
}
function showRest() {
  let r = $('#rest');
  if (!r) { r = h('div', { id: 'rest', class: 'rest' }); document.body.append(r); r.onpointerdown = (e) => { e.preventDefault(); e.stopPropagation(); bumpIdle(); }; }
  const paint = () => {
    if (r.hidden) return;
    const d = new Date(), s = T.snap || {}, w = s.wx;
    const m = (T.media || []).find(x => x.status === 'Playing');
    const ds = DOW[d.getDay()];
    r.innerHTML = `<b>${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}</b><span>${ds[0].toUpperCase() + ds.slice(1)} ${d.getDate()} de ${MON[d.getMonth()]}</span>` +
      (w ? `<div class="rs-wx"><svg viewBox="0 0 24 24">${w.ic}</svg>${w.t}° · ${esc(w.d)}</div>` : '') + (m ? `<div class="rs-m">${svg('music')}${esc(m.title)}${m.artist ? ' · ' + esc(m.artist) : ''}</div>` : '');
  };
  r.hidden = false; paint();
  clearInterval(r.iv); r.iv = setInterval(() => { if (r.hidden) clearInterval(r.iv); else paint(); }, 5000);
}
['pointerdown', 'keydown'].forEach(ev => addEventListener(ev, bumpIdle, true));
function refInfo(ref) {
  ref = String(ref || '');
  if (ref.startsWith('sc:')) {
    const id = ref.slice(3); let it = null;
    for (const x of (T.snap && T.snap.items) || []) { if (x.id === id) it = x; for (const y of x.g || []) if (y.id === id) it = y; }
    return { n: it ? it.n : 'Acceso', icon: it ? iconEl(it) : h('span', { class: 'aic', html: svg('folder') }), run: () => doIt({ a: 'open', id }).then(r2 => r2 && r2.ok === false && toast(r2.error || 'No se pudo abrir')) };
  }
  const A = ACTIONS.find(a => a.id === ref.slice(4)) || ACTIONS[0];
  return { n: A.n, icon: h('span', { class: 'aic sys', html: svg(A.ic) }), run: A.run };
}
const ACTIONS = [
  { id: 'show', n: 'Mostrar Base', ic: 'monitor', run: () => doIt({ a: 'show' }) },
  { id: 'files', n: 'Archivos', ic: 'folder', run: () => doIt({ a: 'sys', name: 'explorer' }) },
  { id: 'lock', n: 'Bloquear', ic: 'lock', run: () => doIt({ a: 'sys', name: 'lock' }) },
  { id: 'shot', n: 'Captura', ic: 'shot', run: () => takeShot() },
  { id: 'cut', n: 'Recortar pantalla', ic: 'shot', run: () => doIt({ a: 'keys', k: 'recorte' }).then(() => toast('Elegí el recorte en la compu')) },
  { id: 'min', n: 'Minimizar todo', ic: 'grid4', run: () => doIt({ a: 'sys', name: 'minimizeAll' }) },
  { id: 'desk', n: 'Ver el escritorio', ic: 'desk', run: () => doIt({ a: 'keys', k: 'escritorio' }) },
  { id: 'play', n: 'Pausa / seguir', ic: 'play', run: () => doIt({ a: 'mediakey', k: 'play' }) }
];
function fmtT(s) { s = Math.floor(s); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function tap(el) { el.classList.add('tap'); setTimeout(() => el.classList.remove('tap'), 180); if (navigator.vibrate) try { navigator.vibrate(12); } catch {} }

// barra de volumen grande
function volume() {
  const muteB = h('button', { class: 'vb' }), upB = h('span', { class: 'vb ico', html: svg('vol') }), pct = h('b', { class: 'vpct' });
  const r = range(0, async (v, fin) => {
    T.vol = Object.assign({}, T.vol || {}, { level: v, muted: false }); pct.textContent = v + '%';
    if (fin || !r.lastSent || Date.now() - r.lastSent > 120) { r.lastSent = Date.now(); const x = await doIt({ a: 'vol', v }); if (x && x.vol && !r.busy) T.vol = x.vol; }
  });
  muteB.onclick = async () => { const m = !(T.vol && T.vol.muted); T.vol = Object.assign({}, T.vol || {}, { muted: m }); upd(); const x = await doIt({ a: 'mute', on: m }); if (x && x.vol) T.vol = x.vol; upd(); };
  const upd = () => {
    const v = T.vol; const lv = v ? Math.round(v.level != null ? v.level : v.vol != null ? v.vol : 0) : 0;
    muteB.innerHTML = svg(v && v.muted ? 'mute' : 'vol');
    muteB.classList.toggle('on', !!(v && v.muted));
    if (!r.busy) { r.set(lv); pct.textContent = (v ? lv : '--') + '%'; }
  };
  T.upd.push(upd);
  return h('div', { class: 'volume' }, muteB, r.wrap, pct);
}
// deslizador táctil grande (no usa el input nativo para que el dedo no "salte")
function range(min, onSet) {
  const fill = h('i'), knob = h('b');
  const input = h('div', { class: 'rng' }, fill, knob);
  const wrap = h('div', { class: 'rngw' }, input);
  const o = { wrap, input, busy: false, val: 0 };
  o.set = (v) => { o.val = Math.max(min, Math.min(100, Math.round(v))); const p = (o.val - min) / (100 - min) * 100; fill.style.width = p + '%'; knob.style.left = p + '%'; };
  const at = (e) => { const rc = input.getBoundingClientRect(); return min + Math.max(0, Math.min(1, (e.clientX - rc.left) / rc.width)) * (100 - min); };
  input.onpointerdown = (e) => {
    if (T.edit) return;
    o.busy = true; input.setPointerCapture(e.pointerId); input.classList.add('drag');
    o.set(at(e)); onSet(o.val, false);
    input.onpointermove = (ev) => { o.set(at(ev)); onSet(o.val, false); };
    input.onpointerup = input.onpointercancel = () => { input.onpointermove = null; input.classList.remove('drag'); onSet(o.val, true); setTimeout(() => { o.busy = false; }, 900); };
  };
  return o;
}
// luces
let lampT = null;
async function lampDo(l, a, fin) {
  const st = (T.snap.lamps.find(x => x.id === l.id) || {}).st;
  if (st) { if (a.toggle) st.on = !st.on; if (a.bright != null) st.bright = a.bright; if (a.color) { st.color = a.color; st.mode = 'colour'; st.on = true; } if (a.temp != null) { st.temp = a.temp; st.mode = 'white'; st.on = true; } }
  for (const f of T.upd) f();
  clearTimeout(lampT);
  const run = async () => { const r = await doIt({ a: 'lamp', id: l.id, do: a }); if (r && r.ok) { const x = T.snap.lamps.find(y => y.id === l.id); if (x) x.st = r.st; for (const f of T.upd) f(); } else toast((r && r.error) || 'La luz no respondió'); };
  if (fin) run(); else lampT = setTimeout(run, 200);
}
function lampColor(st) {
  if (!st || !st.on) return '#7d8590';
  if (st.mode === 'colour') return st.color;
  const t = st.temp / 100, m = (a, b) => Math.round(a + (b - a) * t);
  return `rgb(${m(255, 220)},${m(196, 236)},${m(120, 255)})`;
}
const NAMES = { '#ff4d4d': 'Rojo', '#ff9a2e': 'Naranja', '#4fd36b': 'Verde', '#3d9bff': 'Azul', '#a77bff': 'Violeta', '#ff5fc1': 'Rosa' };
function nearest(hex) {
  const n = parseInt(String(hex || '#ffffff').slice(1), 16), r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
  let best = '', bd = 1e9;
  for (const c of Object.keys(NAMES)) { const m = parseInt(c.slice(1), 16); const d = (r - (m >> 16 & 255)) ** 2 + (g - (m >> 8 & 255)) ** 2 + (b - (m & 255)) ** 2; if (d < bd) { bd = d; best = c; } }
  return best;
}
function colorName(st) { if (st.mode !== 'colour') return st.temp < 25 ? 'Blanco cálido' : st.temp > 70 ? 'Blanco frío' : 'Blanco'; return NAMES[nearest(st.color)] || 'Color'; }

// ----- hojas (ventanas, confirmar, elegir) -----
function sheet(title, ...kids) {
  const sh = $('#sheet'); sh.classList.remove('wide'); sh.replaceChildren(h('h2', { text: title }), ...kids);
  $('#sheet-bg').hidden = false;
}
function closeSheet() { $('#sheet-bg').hidden = true; }
$('#sheet-bg').onclick = (e) => { if (e.target.id === 'sheet-bg') closeSheet(); };
function openGroup(g) {
  sheet(g.n, h('div', { class: 'apps sheet-apps' }, ...g.g.map(it => { const b = h('button', { class: 'app', onclick: () => { doIt({ a: 'open', id: it.id }).then(r => r && r.ok === false ? toast(r.error || 'No se pudo abrir') : toast('Abriendo ' + it.n)); closeSheet(); } }, iconEl(it), h('span', { class: 'an', text: it.n })); return b; })));
}
async function openWindows() {
  sheet('Ventanas abiertas', h('p', { class: 'muted', text: 'Cargando…' }));
  const r = await doIt({ a: 'wins' });
  if (!r || !r.ok) return sheet('Ventanas abiertas', h('p', { class: 'muted', text: 'No pude ver las ventanas.' }));
  const list = h('div', { class: 'wins' }, ...r.list.map(w => h('div', { class: 'win' },
    h('button', { class: 'wgo', onclick: () => { doIt({ a: 'win', h: w.h, do: 'focus' }); closeSheet(); toast('Listo, ' + (w.app || 'la ventana') + ' quedó adelante'); } }, w.icon ? h('img', { src: w.icon, alt: '' }) : h('span', { class: 'aic', html: svg('windows') }), h('span', {}, h('b', { text: w.t }), h('small', { text: w.app + (w.min ? ' · minimizada' : '') }))),
    h('button', { class: 'wx2', html: svg('x'), 'aria-label': 'Cerrar', onclick: async (e) => { e.currentTarget.closest('.win').remove(); await doIt({ a: 'win', h: w.h, do: 'close' }); } }))));
  sheet('Ventanas abiertas', r.list.length ? list : h('p', { class: 'muted', text: 'No hay ventanas abiertas.' }));
}
function confirmPower() {
  const b = (ic, n, cls, fn) => h('button', { class: 'pw ' + (cls || ''), html: svg(ic) + `<span>${n}</span>`, onclick: () => { closeSheet(); fn(); } });
  sheet('¿Qué hacemos con la compu?', h('div', { class: 'pws' },
    b('power', 'Apagar', 'danger', () => { doIt({ a: 'sys', name: 'shutdown' }); toast('Apagando la compu…'); }),
    b('restart', 'Reiniciar', '', () => { doIt({ a: 'sys', name: 'restart' }); toast('Reiniciando…'); }),
    b('moon', 'Suspender', '', () => { doIt({ a: 'sys', name: 'sleep' }); toast('Suspendiendo…'); }),
    b('x', 'Cancelar', 'ghost', () => {})));
}
function renderBar() {
  const items = [
    ['monitor', 'Mostrar Base', () => doIt({ a: 'show' }).then(() => toast('Base quedó adelante en la compu'))],
    ['windows', 'Ventanas', openWindows],
    ['folder', 'Archivos', () => doIt({ a: 'sys', name: 'explorer' }).then(() => toast('Abrí el Explorador en la compu'))],
    ['lock', 'Bloquear', () => doIt({ a: 'sys', name: 'lock' }).then(() => toast('Compu bloqueada'))],
    ['moon', 'Suspender', () => sheet('¿Suspender la compu?', h('div', { class: 'pws' }, h('button', { class: 'pw', html: svg('moon') + '<span>Suspender</span>', onclick: () => { closeSheet(); doIt({ a: 'sys', name: 'sleep' }); toast('Suspendiendo…'); } }), h('button', { class: 'pw ghost', html: svg('x') + '<span>Cancelar</span>', onclick: closeSheet })))],
    ['power', 'Apagar', confirmPower, 'danger']
  ];
  const bar = $('#bar'); bar.replaceChildren(...items.map(([ic, n, fn, cls]) => { const b = h('button', { class: 'bb ' + (cls || ''), html: svg(ic) + `<span>${n}</span>`, onclick: () => { if (!T.edit) { tap(b); fn(); } } }); return b; }));
  if (document.fullscreenEnabled && !document.fullscreenElement) bar.append(h('button', { class: 'bb mini', html: svg('full'), 'aria-label': 'Pantalla completa', onclick: () => document.documentElement.requestFullscreen().catch(() => {}) }));
}

// ----- modo Personalizar -----
const ADDS = [
  ['accesos', 'Accesos', 'grid4', { w: 2, h: 4 }], ['musica', 'Música y volumen', 'music', { w: 2, h: 3 }], ['volumen', 'Solo volumen', 'vol', { w: 2, h: 2 }],
  ['luz', 'Luz', 'bulb', { w: 2, h: 3 }], ['super', 'Supermercado', 'cart', { w: 1, h: 4 }], ['clima', 'Clima', 'sun', { w: 1, h: 2 }], ['atajos', 'Atajos rápidos', 'shot', { w: 2, h: 2 }],
  ['reloj', 'Reloj grande', 'clock', { w: 2, h: 2 }], ['notas', 'Nota', 'note', { w: 1, h: 3 }], ['timer', 'Temporizador', 'timer', { w: 2, h: 2 }], ['escenas', 'Escenas de luz', 'bulb', { w: 2, h: 2 }]
];
const ACCENTS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6', '#64748b'];
function renderTray() {
  const tray = $('#tray');
  tray.hidden = !T.edit;
  if (!T.edit) return tray.replaceChildren();
  const L = layout();
  const lamps = (T.snap && T.snap.lamps) || [];
  const add = (t, extra) => editLayout(l => { BL(l).push(Object.assign({ id: 'b' + Date.now().toString(36), t }, extra)); setTimeout(() => { const g = $('#grid'); g.scrollTop = g.scrollHeight; }, 50); });
  const chips = [];
  for (const [t, n, ic, sz] of ADDS) {
    if (t === 'luz' && lamps.length > 1) { for (const lp of lamps) chips.push(h('button', { class: 'tc', html: svg(ic) + `<span>+ ${esc(lp.n)}</span>`, onclick: () => add('luz', Object.assign({ lamp: lp.id }, sz)) })); continue; }
    chips.push(h('button', { class: 'tc', html: svg(ic) + `<span>+ ${n}</span>`, onclick: () => add(t, Object.assign({}, sz)) }));
  }
  chips.push(h('button', { class: 'tc', html: svg('plus') + '<span>+ Botón</span>', onclick: () => pickButton(add) }));
  const acc = h('div', { class: 'accs' }, ...ACCENTS.map(c => h('button', { class: 'acc' + ((L.accent || '') === c ? ' on' : ''), style: `--c:${c}`, onclick: () => editLayout(l => { l.accent = c; }) })),
    h('button', { class: 'acc auto' + (!L.accent ? ' on' : ''), text: 'Base', onclick: () => editLayout(l => { l.accent = ''; }) }));
  const sizes = null && h('div', { class: 'szs' }, ...[['s', 'Chicos'], ['m', 'Normales'], ['l', 'Grandes']].map(([k, n]) => h('button', { class: 'sz' + ((L.scale || 'm') === k ? ' on' : ''), text: n, onclick: () => editLayout(l => { l.scale = k; }) })));
  const per = h('button', { class: 'tc' + (L.perBoard ? ' on' : ''), html: svg('grid4') + `<span>${L.perBoard ? 'Un diseño por tablero: sí' : 'Un diseño por tablero: no'}</span>`, onclick: () => editLayout(l => { l.perBoard = !l.perBoard; if (l.perBoard) BL(l); }) });
  tray.replaceChildren(
    h('div', { class: 'trow' }, h('span', { class: 'tl2', text: 'Sumar' }), ...chips),
    h('div', { class: 'trow' }, h('span', { class: 'tl2', text: 'Color' }), acc,
      h('button', { class: 'tc', html: svg('sun') + '<span>Fondo, esquinas, reposo…</span>', onclick: openLook }), per,
      h('button', { class: 'tc ghost', text: 'Volver al diseño original', onclick: () => editLayout(l => { const a = BL(l); a.splice(0, a.length, ...DEFAULT().blocks); }) })));
}
function pickButton(add) {
  const items = [];
  for (const x of (T.snap && T.snap.items) || []) { if (x.g) x.g.forEach(y => items.push(y)); else items.push(x); }
  sheet('¿Qué hace el botón?',
    h('div', { class: 'apps sheet-apps' }, ...ACTIONS.map(a => h('button', { class: 'app', onclick: () => { closeSheet(); add('boton', { ref: 'act:' + a.id, w: 1, h: 2 }); } }, h('span', { class: 'aic sys', html: svg(a.ic) }), h('span', { class: 'an', text: a.n }))),
      ...items.map(it => h('button', { class: 'app', onclick: () => { closeSheet(); add('boton', { ref: 'sc:' + it.id, w: 1, h: 2 }); } }, iconEl(it), h('span', { class: 'an', text: it.n })))));
}
// arrastrar bloques para ordenarlos
function startDrag(e, id) {
  e.preventDefault();
  const g = $('#grid'); const blk = g.querySelector(`.blk[data-id="${id}"]`);
  if (!blk) return;
  blk.classList.add('dragging');
  const ghost = blk.cloneNode(true); ghost.classList.add('ghost'); const rc = blk.getBoundingClientRect();
  Object.assign(ghost.style, { position: 'fixed', left: rc.left + 'px', top: rc.top + 'px', width: rc.width + 'px', height: rc.height + 'px', pointerEvents: 'none', zIndex: 50 });
  document.body.append(ghost);
  const ox = e.clientX - rc.left, oy = e.clientY - rc.top;
  let target = null;
  const move = (ev) => {
    ghost.style.left = (ev.clientX - ox) + 'px'; ghost.style.top = (ev.clientY - oy) + 'px';
    const over = document.elementsFromPoint(ev.clientX, ev.clientY).find(x => x.classList && x.classList.contains('blk') && !x.classList.contains('ghost') && x !== blk);
    for (const x of g.querySelectorAll('.blk.over')) x.classList.remove('over');
    target = over ? over.dataset.id : null;
    if (over) over.classList.add('over');
  };
  const up = () => {
    removeEventListener('pointermove', move); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
    ghost.remove(); blk.classList.remove('dragging');
    if (target) editLayout(l => { const arr = BL(l); const a = arr.findIndex(x => x.id === id), b = arr.findIndex(x => x.id === target); const [it] = arr.splice(a, 1); arr.splice(b, 0, it); });
    else render(true);
  };
  addEventListener('pointermove', move); addEventListener('pointerup', up); addEventListener('pointercancel', up);
}

// ---------- arranque ----------
if (!KEY) showPair();
else { $('#app').hidden = false; poll(); }
setInterval(poll, 1500);
setInterval(() => { tickClock(); for (const f of T.upd) { try { f(); } catch {} } }, 1000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
addEventListener('resize', () => render(false));
// la pantalla queda prendida mientras se usa el panel (si el navegador lo permite)
async function wake() { try { if (navigator.wakeLock) T.wl = await navigator.wakeLock.request('screen'); } catch {} }
document.addEventListener('visibilitychange', () => { if (!document.hidden) wake(); });
wake();
})();
