﻿# Ayudante de Base para ver y manejar las ventanas abiertas de Windows.
# Corre escondido, recibe órdenes por la entrada estándar y responde una línea JSON por orden.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$code = @'
using System;
using System.Text;
using System.Runtime.InteropServices;

public static class BaseWin {
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte sc, uint f, UIntPtr e);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int s);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a, bool i, uint pid);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, int f, StringBuilder s, ref int n);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

  static string Esc(string s) {
    var b = new StringBuilder();
    foreach (char c in s) {
      if (c == '"' || c == '\\') b.Append('\\').Append(c);
      else if (c < 32) b.AppendFormat("\\u{0:x4}", (int)c);
      else b.Append(c);
    }
    return b.ToString();
  }
  static string ExePath(uint pid) {
    IntPtr h = OpenProcess(0x1000, false, pid);
    if (h == IntPtr.Zero) return "";
    var sb = new StringBuilder(1024); int n = 1024;
    string r = QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : "";
    CloseHandle(h);
    return r;
  }
  static bool IsAppWindow(IntPtr h) {
    if (!IsWindowVisible(h)) return false;
    if (GetWindow(h, 4) != IntPtr.Zero) return false;           // tiene dueño (diálogos)
    if ((GetWindowLong(h, -20) & 0x80) != 0) return false;      // ventana de herramientas
    int cloaked = 0; DwmGetWindowAttribute(h, 14, out cloaked, 4);
    if (cloaked != 0) return false;                             // oculta (otro escritorio, apps suspendidas)
    return GetWindowTextLength(h) > 0;
  }
  public static string List(long self) {
    IntPtr fg = GetForegroundWindow();
    var sb = new StringBuilder("["); bool first = true;
    EnumWindows((h, l) => {
      if (h.ToInt64() == self || !IsAppWindow(h)) return true;
      int len = GetWindowTextLength(h);
      var t = new StringBuilder(len + 1); GetWindowText(h, t, len + 1);
      string title = t.ToString();
      if (title == "Program Manager") return true;
      uint pid; GetWindowThreadProcessId(h, out pid);
      if (!first) sb.Append(','); first = false;
      sb.Append("{\"h\":\"").Append(h.ToInt64()).Append("\",\"t\":\"").Append(Esc(title))
        .Append("\",\"exe\":\"").Append(Esc(ExePath(pid)))
        .Append("\",\"min\":").Append(IsIconic(h) ? "true" : "false")
        .Append(",\"max\":").Append(IsZoomed(h) ? "true" : "false")
        .Append(",\"fg\":").Append(h == fg ? "true" : "false").Append('}');
      return true;
    }, IntPtr.Zero);
    return sb.Append(']').ToString();
  }
  public static void Focus(long v) {
    var h = new IntPtr(v);
    // tocar Alt habilita a esta app a pasar otra ventana al frente
    keybd_event(0x12, 0, 0, UIntPtr.Zero); keybd_event(0x12, 0, 2, UIntPtr.Zero);
    if (IsIconic(h)) ShowWindow(h, 9);
    BringWindowToTop(h);
    SetForegroundWindow(h);
  }
  public static void Minimize(long v) { ShowWindow(new IntPtr(v), 6); }
  public static void Close(long v) { PostMessage(new IntPtr(v), 0x10, IntPtr.Zero, IntPtr.Zero); }
  public static void ToggleMax(long v) {
    var h = new IntPtr(v);
    ShowWindow(h, IsZoomed(h) ? 9 : 3);
    keybd_event(0x12, 0, 0, UIntPtr.Zero); keybd_event(0x12, 0, 2, UIntPtr.Zero);
    SetForegroundWindow(h);
  }
  public static void MinimizeAll(long self) {
    EnumWindows((h, l) => { if (h.ToInt64() != self && IsAppWindow(h)) ShowWindow(h, 6); return true; }, IntPtr.Zero);
  }
  // Spotify: la ventana muestra "Artista - Canción" mientras suena y "Spotify ..." en pausa
  public static string Spotify() {
    string best = ""; bool running = false;
    EnumWindows((h, l) => {
      int len = GetWindowTextLength(h);
      if (len == 0) return true;
      uint pid; GetWindowThreadProcessId(h, out pid);
      string exe = ExePath(pid);
      if (!exe.EndsWith("Spotify.exe", StringComparison.OrdinalIgnoreCase)) return true;
      running = true;
      var t = new StringBuilder(len + 1); GetWindowText(h, t, len + 1);
      string title = t.ToString();
      if (title == "GDI+ Window" || title == "Default IME" || title.StartsWith("MSCTFIME") || title.Contains("SpotifyMainWindow")) return true;
      if (title.Contains(" - ") || best == "") best = title;
      return true;
    }, IntPtr.Zero);
    return "{\"running\":" + (running ? "true" : "false") + ",\"title\":\"" + Esc(best) + "\"}";
  }
  public static void Media(string key) {
    byte vk;
    switch (key) {
      case "play": vk = 0xB3; break;
      case "next": vk = 0xB0; break;
      case "prev": vk = 0xB1; break;
      case "volup": vk = 0xAF; break;
      case "voldown": vk = 0xAE; break;
      case "mute": vk = 0xAD; break;
      default: return;
    }
    keybd_event(vk, 0, 1, UIntPtr.Zero);
    keybd_event(vk, 0, 3, UIntPtr.Zero);
  }
  public static void Keys(string combo) {
    byte[] vks;
    switch (combo) {
      case "win": vks = new byte[] { 0x5B }; break;
      case "win+tab": vks = new byte[] { 0x5B, 0x09 }; break;
      case "win+a": vks = new byte[] { 0x5B, 0x41 }; break;
      case "win+n": vks = new byte[] { 0x5B, 0x4E }; break;
      case "win+d": vks = new byte[] { 0x5B, 0x44 }; break;
      case "win+shift+s": vks = new byte[] { 0x5B, 0x10, 0x53 }; break;
      case "win+.": vks = new byte[] { 0x5B, 0xBE }; break;
      case "win+v": vks = new byte[] { 0x5B, 0x56 }; break;
      case "win+prtsc": vks = new byte[] { 0x5B, 0x2C }; break;
      default: return;
    }
    foreach (var k in vks) keybd_event(k, 0, 0, UIntPtr.Zero);
    for (int i = vks.Length - 1; i >= 0; i--) keybd_event(vks[i], 0, 2, UIntPtr.Zero);
  }
}
'@

try {
  Add-Type -TypeDefinition $code -Language CSharp
} catch {
  $msg = ($_.Exception.Message -replace '["\\]', '' -replace '\s+', ' ')
  [Console]::Out.WriteLine('{"ready":false,"error":"' + $msg + '"}')
  [Console]::Out.Flush()
  exit 1
}
$code2 = @'
using System;
using System.Text;

public static class BaseSys {
  [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  // la deja en un lugar y tamaño fijos, arriba de todo
  public static string Place(string arg) {
    string[] p = arg.Split('|');
    if (p.Length < 5) return "false";
    IntPtr h = new IntPtr(long.Parse(p[0]));
    ShowWindow(h, 9);
    bool ok = SetWindowPos(h, new IntPtr(-1), int.Parse(p[1]), int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]), 0x0040);
    return ok ? "true" : "false";
  }
  public static string TopMost(long h) {
    bool ok = SetWindowPos(new IntPtr(h), new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040);
    return ok ? "true" : "false";
  }
  static string Esc(string s) {
    var b = new StringBuilder();
    foreach (char c in s) {
      if (c == '"' || c == '\\') b.Append('\\').Append(c);
      else if (c < 32) b.AppendFormat("\\u{0:x4}", (int)c);
      else b.Append(c);
    }
    return b.ToString();
  }
  // Unidades de almacenamiento (fijas, extraíbles, de red y lectoras)
  public static string Drives() {
    var b = new StringBuilder("[");
    bool first = true;
    foreach (var d in System.IO.DriveInfo.GetDrives()) {
      try {
        if (!d.IsReady) continue;
        string label = "", fmt = "";
        try { label = d.VolumeLabel ?? ""; } catch {}
        try { fmt = d.DriveFormat ?? ""; } catch {}
        long size = d.TotalSize, free = d.AvailableFreeSpace;
        string item = "{\"n\":\"" + Esc(d.Name) + "\",\"l\":\"" + Esc(label) + "\",\"t\":\"" + d.DriveType.ToString()
          + "\",\"f\":\"" + Esc(fmt) + "\",\"size\":" + size + ",\"free\":" + free + "}";
        if (!first) b.Append(',');
        first = false;
        b.Append(item);
      } catch {}
    }
    return b.Append(']').ToString();
  }
  // Bytes enviados y recibidos por las conexiones activas
  public static string Net() {
    long rx = 0, tx = 0; string name = "", kind = ""; long speed = 0;
    foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()) {
      try {
        if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;
        var nt = ni.NetworkInterfaceType;
        if (nt == System.Net.NetworkInformation.NetworkInterfaceType.Loopback || nt == System.Net.NetworkInformation.NetworkInterfaceType.Tunnel) continue;
        var st = ni.GetIPv4Statistics();
        rx += st.BytesReceived; tx += st.BytesSent;
        if (st.BytesReceived > 0 && (name == "" || nt == System.Net.NetworkInformation.NetworkInterfaceType.Wireless80211 || nt == System.Net.NetworkInformation.NetworkInterfaceType.Ethernet)) {
          if (name == "" || kind != "Ethernet") { name = ni.Name; kind = nt.ToString(); speed = ni.Speed; }
        }
      } catch {}
    }
    return "{\"rx\":" + rx + ",\"tx\":" + tx + ",\"name\":\"" + Esc(name) + "\",\"kind\":\"" + kind + "\",\"speed\":" + speed + "}";
  }
  // Programas que más memoria usan (agrupados por nombre)
  public static string Procs() {
    var mem = new System.Collections.Generic.Dictionary<string, long>();
    var cnt = new System.Collections.Generic.Dictionary<string, int>();
    int total = 0;
    foreach (var p in System.Diagnostics.Process.GetProcesses()) {
      try {
        total++;
        string n = p.ProcessName;
        if (n == "Idle" || n == "System" || n == "Memory Compression" || n == "Registry") continue;
        long w = p.WorkingSet64;
        if (mem.ContainsKey(n)) { mem[n] += w; cnt[n]++; } else { mem[n] = w; cnt[n] = 1; }
      } catch {} finally { p.Dispose(); }
    }
    var keys = new System.Collections.Generic.List<string>(mem.Keys);
    keys.Sort((a, c) => mem[c].CompareTo(mem[a]));
    var b = new StringBuilder("{\"total\":" + total + ",\"top\":[");
    for (int i = 0; i < Math.Min(6, keys.Count); i++) {
      if (i > 0) b.Append(',');
      b.Append("{\"n\":\"").Append(Esc(keys[i])).Append("\",\"m\":").Append(mem[keys[i]]).Append(",\"c\":").Append(cnt[keys[i]]).Append('}');
    }
    return b.Append("]}").ToString();
  }
}
'@
$sysOk = $true
try { Add-Type -TypeDefinition $code2 -Language CSharp } catch { $sysOk = $false }
# ---- Volumen general de Windows (Core Audio) ----
$code3 = @'
using System;
using System.Runtime.InteropServices;
[ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IBaseEpVol {
  int RegisterControlChangeNotify(IntPtr p);
  int UnregisterControlChangeNotify(IntPtr p);
  int GetChannelCount(out uint c);
  int SetMasterVolumeLevel(float l, ref Guid ctx);
  int SetMasterVolumeLevelScalar(float l, ref Guid ctx);
  int GetMasterVolumeLevel(out float l);
  int GetMasterVolumeLevelScalar(out float l);
  int SetChannelVolumeLevel(uint ch, float l, ref Guid ctx);
  int SetChannelVolumeLevelScalar(uint ch, float l, ref Guid ctx);
  int GetChannelVolumeLevel(uint ch, out float l);
  int GetChannelVolumeLevelScalar(uint ch, out float l);
  int SetMute([MarshalAs(UnmanagedType.Bool)] bool m, ref Guid ctx);
  int GetMute([MarshalAs(UnmanagedType.Bool)] out bool m);
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IBaseMMDevice {
  int Activate(ref Guid iid, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o);
}
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IBaseMMEnum {
  int EnumAudioEndpoints(int flow, int mask, out IntPtr devs);
  int GetDefaultAudioEndpoint(int flow, int role, out IBaseMMDevice d);
}
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
class BaseMMEnumCom {}
public static class BaseVol {
  static IBaseEpVol Ep() {
    var en = (IBaseMMEnum)(new BaseMMEnumCom());
    IBaseMMDevice d;
    Marshal.ThrowExceptionForHR(en.GetDefaultAudioEndpoint(0, 1, out d));
    Guid iid = typeof(IBaseEpVol).GUID;
    object o;
    Marshal.ThrowExceptionForHR(d.Activate(ref iid, 23, IntPtr.Zero, out o));
    return (IBaseEpVol)o;
  }
  static string State(IBaseEpVol e) {
    float l; e.GetMasterVolumeLevelScalar(out l);
    bool m; e.GetMute(out m);
    return "{\"level\":" + ((int)Math.Round(l * 100)).ToString() + ",\"muted\":" + (m ? "true" : "false") + "}";
  }
  public static string Get() { return State(Ep()); }
  public static string Set(int v) {
    var e = Ep(); Guid g = Guid.Empty;
    v = Math.Max(0, Math.Min(100, v));
    e.SetMasterVolumeLevelScalar(v / 100f, ref g);
    if (v > 0) e.SetMute(false, ref g);
    return State(e);
  }
  public static string Mute(bool on) { var e = Ep(); Guid g = Guid.Empty; e.SetMute(on, ref g); return State(e); }
}
'@
$volOk = $true
try { Add-Type -TypeDefinition $code3 -Language CSharp } catch { $volOk = $false }
# ---- Programa "acoplado" adentro de Base (por ejemplo Recepciones.exe) ----
$code4 = @'
using System;
using System.Runtime.InteropServices;
public static class BaseDock {
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] static extern IntPtr GetLong(IntPtr h, int i);
  [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")] static extern IntPtr SetLong(IntPtr h, int i, IntPtr v);
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  static void Dpi() { try { SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch {} }
  const long STRIP = 0x00C00000L | 0x00040000L | 0x00020000L | 0x00010000L;
  public static string Attach(string arg) {
    string[] p = arg.Split('|');
    if (p.Length < 6) return "false";
    IntPtr h = new IntPtr(long.Parse(p[0]));
    if (!IsWindow(h)) return "false";
    Dpi();
    if (IsZoomed(h) || IsIconic(h)) ShowWindow(h, 9);
    long st = GetLong(h, -16).ToInt64();
    SetLong(h, -16, new IntPtr(st & ~STRIP));
    SetLong(h, -8, new IntPtr(long.Parse(p[1])));
    SetWindowPos(h, IntPtr.Zero, int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]), int.Parse(p[5]), 0x0020 | 0x0040 | 0x0010);
    return "{\"style\":\"" + st.ToString() + "\"}";
  }
  public static string Move(string arg) {
    string[] p = arg.Split('|');
    if (p.Length < 5) return "false";
    IntPtr h = new IntPtr(long.Parse(p[0]));
    if (!IsWindow(h)) return "false";
    Dpi();
    if (IsIconic(h)) ShowWindow(h, 9);
    SetWindowPos(h, IntPtr.Zero, int.Parse(p[1]), int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]), 0x0040 | 0x0010);
    return "true";
  }
  public static string Hide(long v) {
    IntPtr h = new IntPtr(v);
    if (!IsWindow(h)) return "false";
    ShowWindow(h, 0);
    return "true";
  }
  public static string Detach(string arg) {
    string[] p = arg.Split('|');
    IntPtr h = new IntPtr(long.Parse(p[0]));
    if (!IsWindow(h)) return "false";
    SetLong(h, -8, IntPtr.Zero);
    if (p.Length > 1 && p[1] != "") SetLong(h, -16, new IntPtr(long.Parse(p[1])));
    SetWindowPos(h, IntPtr.Zero, 0, 0, 0, 0, 0x0020 | 0x0001 | 0x0002 | 0x0004 | 0x0040);
    ShowWindow(h, 9);
    return "true";
  }
  public static string Alive(long v) { return IsWindow(new IntPtr(v)) ? "true" : "false"; }
}
'@
$dockOk = $true
try { Add-Type -TypeDefinition $code4 -Language CSharp } catch { $dockOk = $false }
# ---- Control multimedia de Windows (lo que suena en Spotify, el navegador, etc.) ----
$smtc = $null
$asTaskOp = $null
function Await($op, [Type]$t) {
  $task = $script:asTaskOp.MakeGenericMethod($t).Invoke($null, @($op))
  if (-not $task.Wait(3000)) { throw 'timeout' }
  return $task.Result
}
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTaskOp = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $smtc = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
} catch { $smtc = $null }
function SmtcFind($app) {
  if (-not $smtc) { return $null }
  if ($app) { foreach ($s in $smtc.GetSessions()) { if ($s.SourceAppUserModelId -eq $app) { return $s } } }
  return $smtc.GetCurrentSession()
}
function SmtcState {
  if (-not $smtc) { return 'null' }
  $cur = $smtc.GetCurrentSession()
  $list = New-Object System.Collections.ArrayList
  foreach ($s in $smtc.GetSessions()) {
    $p = $null
    try { $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]) } catch {}
    $tl = $s.GetTimelineProperties()
    $pb = $s.GetPlaybackInfo()
    $upd = 0
    try { $upd = [long]$tl.LastUpdatedTime.ToUnixTimeMilliseconds() } catch {}
    $null = $list.Add([pscustomobject]@{
      app = [string]$s.SourceAppUserModelId
      title = if ($p) { [string]$p.Title } else { '' }
      artist = if ($p) { [string]$p.Artist } else { '' }
      album = if ($p) { [string]$p.AlbumTitle } else { '' }
      status = [string]$pb.PlaybackStatus
      pos = [double]$tl.Position.TotalSeconds
      start = [double]$tl.StartTime.TotalSeconds
      end = [double]$tl.EndTime.TotalSeconds
      upd = $upd
      seek = [bool]$pb.Controls.IsPlaybackPositionEnabled
      cur = [bool]($cur -ne $null -and $s.SourceAppUserModelId -eq $cur.SourceAppUserModelId)
    })
  }
  if ($list.Count -eq 0) { return '[]' }
  return (ConvertTo-Json -InputObject @($list.ToArray()) -Compress -Depth 3)
}
function SmtcThumb($app) {
  $s = SmtcFind $app
  if (-not $s) { return 'null' }
  $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
  if (-not $p -or -not $p.Thumbnail) { return 'null' }
  $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
  $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st)
  $ms = New-Object System.IO.MemoryStream
  $net.CopyTo($ms)
  $net.Dispose()
  if ($ms.Length -gt 4MB) { return 'null' }
  $ct = [string]$st.ContentType
  return '{"type":"' + ($ct -replace '[^\w/+.-]', '') + '","data":"' + [Convert]::ToBase64String($ms.ToArray()) + '"}'
}
function SmtcDo($arg) {
  $parts = $arg.Split('|')
  $s = SmtcFind $parts[0]
  if (-not $s) { return 'false' }
  $ok = $false
  switch ($parts[1]) {
    'toggle' { $ok = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
    'next'   { $ok = Await ($s.TrySkipNextAsync()) ([bool]) }
    'prev'   { $ok = Await ($s.TrySkipPreviousAsync()) ([bool]) }
    'seek'   { $ok = Await ($s.TryChangePlaybackPositionAsync([long]([double]$parts[2] * 10000000))) ([bool]) }
  }
  if ($ok) { return 'true' } else { return 'false' }
}
# ---- Modo escritorio: ventana del frente, barra de tareas de Windows ----
$code5 = @'
using System;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Runtime.InteropServices;
public static class BaseDesk {
  [DllImport("user32.dll")] static extern bool IsHungAppWindow(IntPtr h);
  // Vigilante: si la ventana de Base queda "no responde" 40 segundos, se cierra (y el ayudante la vuelve a abrir)
  static Timer watchTimer; static IntPtr watchH = IntPtr.Zero; static int hungN = 0; static string watchExe = "", watchLog = "";
  public static string Watch(string arg) {
    string[] p = arg.Split(new char[] { '|' }, 3);
    if (p.Length < 3) return "false";
    watchH = new IntPtr(long.Parse(p[0])); watchExe = p[1]; watchLog = p[2]; hungN = 0;
    if (watchTimer == null) watchTimer = new Timer(WatchTick, null, 5000, 5000);
    return "true";
  }
  static void WatchTick(object o) {
    try {
      if (watchH == IntPtr.Zero) return;
      if (IsHungAppWindow(watchH)) hungN++; else hungN = 0;
      if (hungN < 8) return;
      hungN = 0; watchH = IntPtr.Zero;
      try { File.AppendAllText(watchLog, "[" + DateTime.UtcNow.ToString("o") + "] Base quedó trabada 40 segundos: la cierro y se vuelve a abrir sola\r\n"); } catch { }
      foreach (Process pr in Process.GetProcessesByName("Base")) {
        try { if (string.Equals(pr.MainModule.FileName, watchExe, StringComparison.OrdinalIgnoreCase)) pr.Kill(); } catch { }
      }
    } catch { }
  }
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string c, string t);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr after, string c, string t);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int l, t, r, b; }
  [StructLayout(LayoutKind.Sequential)] struct APPBARDATA { public int cbSize; public IntPtr hWnd; public uint msg; public uint edge; public RECT rc; public IntPtr lParam; }
  [DllImport("shell32.dll")] static extern IntPtr SHAppBarMessage(uint msg, ref APPBARDATA d);
  public static bool hidden = false;
  static int savedState = -1;
  // Sin barra de tareas, Windows dibuja las ventanas minimizadas como barritas abajo a la izquierda.
  // Mientras la barra está escondida le pedimos que las esconda (como hace con la barra visible).
  [StructLayout(LayoutKind.Sequential)] struct MINIMIZEDMETRICS { public uint cbSize; public int iWidth; public int iHorzGap; public int iVertGap; public int iArrange; }
  [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint a, uint b, ref MINIMIZEDMETRICS m, uint c);
  static int savedArrange = -1;
  static void MinHide(bool on) {
    try {
      var m = new MINIMIZEDMETRICS(); m.cbSize = (uint)Marshal.SizeOf(m);
      if (!SystemParametersInfo(0x002B, m.cbSize, ref m, 0)) return;
      if (on) { if (savedArrange < 0) savedArrange = m.iArrange; m.iArrange = m.iArrange | 0x0008; }
      else { if (savedArrange < 0) return; m.iArrange = savedArrange; savedArrange = -1; }
      SystemParametersInfo(0x002C, m.cbSize, ref m, 0);
    } catch { }
  }
  public static string FgClass() {
    IntPtr h = GetForegroundWindow();
    var sb = new StringBuilder(128); GetClassName(h, sb, 128);
    return "{\"c\":\"" + sb.ToString().Replace("\\", "").Replace("\"", "") + "\",\"h\":\"" + h.ToInt64() + "\"}";
  }
  static void Bars(int cmd) {
    IntPtr t = FindWindow("Shell_TrayWnd", null);
    if (t != IntPtr.Zero) ShowWindow(t, cmd);
    IntPtr s = IntPtr.Zero;
    while ((s = FindWindowEx(IntPtr.Zero, s, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero) ShowWindow(s, cmd);
  }
  static void AutoHide(bool on) {
    var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(d); d.hWnd = FindWindow("Shell_TrayWnd", null);
    if (savedState < 0) savedState = (int)SHAppBarMessage(4, ref d).ToInt64(); // ABM_GETSTATE
    d.lParam = new IntPtr(on ? 1 : (savedState & 1)); // ABS_AUTOHIDE
    SHAppBarMessage(10, ref d); // ABM_SETSTATE
  }
  public static string Taskbar(bool hide) {
    if (hide) { AutoHide(true); Bars(0); MinHide(true); hidden = true; }
    else { if (hidden || savedState >= 0) AutoHide(false); Bars(5); MinHide(false); hidden = false; }
    return "true";
  }
  // la volvemos a esconder si Windows la mostró (por ejemplo al reiniciarse el Explorador)
  public static string Keep() {
    if (!hidden) return "false";
    IntPtr t = FindWindow("Shell_TrayWnd", null);
    if (t != IntPtr.Zero && IsWindowVisible(t)) Bars(0);
    return "true";
  }
  public static string Bottom(long v) {
    SetWindowPos(new IntPtr(v), new IntPtr(1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010); // HWND_BOTTOM, sin mover ni activar
    return "true";
  }
}
'@
$deskOk = $true
try { Add-Type -TypeDefinition $code5 -Language CSharp } catch { $deskOk = $false }
$relaunch = ''
$cleanExit = $false
[Console]::Out.WriteLine('{"ready":true}')
[Console]::Out.Flush()

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  $p = $line.Split(' ', 3)
  if ($p.Length -lt 2) { continue }
  $id = [int]$p[0]; $cmd = $p[1]; $arg = if ($p.Length -gt 2) { $p[2] } else { '' }
  try {
    $out = 'true'
    switch ($cmd) {
      'list'        { $out = [BaseWin]::List([long]$arg) }
      'focus'       { [BaseWin]::Focus([long]$arg) }
      'minimize'    { [BaseWin]::Minimize([long]$arg) }
      'close'       { [BaseWin]::Close([long]$arg) }
      'max'         { [BaseWin]::ToggleMax([long]$arg) }
      'minimizeAll' { [BaseWin]::MinimizeAll([long]$arg) }
      'keys'        { [BaseWin]::Keys($arg) }
      'spotify'     { $out = [BaseWin]::Spotify() }
      'media'       { [BaseWin]::Media($arg) }
      'drives'      { $out = if ($sysOk) { [BaseSys]::Drives() } else { 'null' } }
      'net'         { $out = if ($sysOk) { [BaseSys]::Net() } else { 'null' } }
      'place'       { $out = if ($sysOk) { [BaseSys]::Place($arg) } else { 'false' } }
      'topmost'     { $out = if ($sysOk) { [BaseSys]::TopMost([long]$arg) } else { 'false' } }
      'smtc'        { $out = SmtcState }
      'smtcthumb'   { $out = SmtcThumb $arg }
      'smtcdo'      { $out = SmtcDo $arg }
      'procs'       { $out = if ($sysOk) { [BaseSys]::Procs() } else { 'null' } }
      'vol'         { $out = if ($volOk) { [BaseVol]::Get() } else { 'null' } }
      'dockon'      { $out = if ($dockOk) { [BaseDock]::Attach($arg) } else { 'false' } }
      'dockmove'    { $out = if ($dockOk) { [BaseDock]::Move($arg) } else { 'false' } }
      'dockhide'    { $out = if ($dockOk) { [BaseDock]::Hide([long]$arg) } else { 'false' } }
      'dockoff'     { $out = if ($dockOk) { [BaseDock]::Detach($arg) } else { 'false' } }
      'fgclass'     { $out = if ($deskOk) { [BaseDesk]::FgClass() } else { 'null' } }
      'taskbar'     { $out = if ($deskOk) { [BaseDesk]::Taskbar($arg -eq '1') } else { 'false' } }
      'tbkeep'      { $out = if ($deskOk) { [BaseDesk]::Keep() } else { 'false' } }
      'bottom'      { $out = if ($deskOk) { [BaseDesk]::Bottom([long]$arg) } else { 'false' } }
      'relaunch'    { $script:relaunch = $arg; $out = 'true' }
      'bye'         { $script:cleanExit = $true; $out = 'true' }
      'watch'       { $out = if ($deskOk) { [BaseDesk]::Watch($arg) } else { 'false' } }
      'dockalive'   { $out = if ($dockOk) { [BaseDock]::Alive([long]$arg) } else { 'false' } }
      'volset'      { $out = if ($volOk) { [BaseVol]::Set([int]$arg) } else { 'null' } }
      'volmute'     { $out = if ($volOk) { [BaseVol]::Mute($arg -eq '1') } else { 'null' } }
      default       { $out = 'false' }
    }
    [Console]::Out.WriteLine('{"id":' + $id + ',"ok":true,"data":' + $out + '}')
  } catch {
    [Console]::Out.WriteLine('{"id":' + $id + ',"ok":false}')
  }
  [Console]::Out.Flush()
}
# Base se cerró: si escondimos la barra de Windows, la devolvemos; si se cerró de golpe, lo volvemos a abrir
if ($deskOk -and [BaseDesk]::hidden) { try { [BaseDesk]::Taskbar($false) | Out-Null } catch {} }
if (-not $cleanExit -and $relaunch -and (Test-Path $relaunch)) {
  Start-Sleep -Seconds 3
  if (-not (Get-Process -Name 'Base' -ErrorAction SilentlyContinue)) { Start-Process -FilePath $relaunch -ArgumentList '--reabierto' }
}
