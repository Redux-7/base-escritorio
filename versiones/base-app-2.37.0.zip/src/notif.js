// Avisos flotantes de Base: tarjetitas que aparecen abajo a la derecha y se van solas.
(() => {
  const stack = document.getElementById('stack');
  const ICONS = {
    agenda: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/>',
    f1: '<path d="M4 21V4M4 4h14l-3 4 3 4H4"/>',
    team: '<circle cx="12" cy="12" r="9"/><path d="m12 7 4 3-1.5 4.5h-5L8 10z"/>',
    pomo: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9.5 3h5"/>',
    gen: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15zM10 20a2 2 0 0 0 4 0"/>'
  };
  const COLORS = { agenda: '#3a86d6', mail: '#e0533d', f1: '#e10600', team: '#2f9e44', pomo: '#e8590c', gen: '#7b4fc9' };
  const LABEL = { agenda: 'Agenda', mail: 'Correo', f1: 'Fórmula 1', team: 'Tu equipo', pomo: 'Pomodoro', gen: 'Base' };
  const report = () => requestAnimationFrame(() => window.avisos.size(stack.children.length ? Math.ceil(stack.getBoundingClientRect().height) : 0));
  function remove(card) {
    if (card.classList.contains('out')) return;
    card.classList.add('out');
    setTimeout(() => { card.remove(); report(); }, 300);
  }
  const LOOKS = ['tarjeta', 'compacta', 'burbuja', 'color', 'vidrio', 'linea', 'neon'];
  let actx = null;
  function chime(kind) {
    try {
      actx = actx || new AudioContext();
      const notes = kind === 'campana' ? [[1318.5, 0, .9], [1975.5, .0, .7]] : kind === 'gota' ? [[880, 0, .25]] : [[784, 0, .35], [1046.5, .12, .5]];
      for (const [f, at, dur] of notes) {
        const o = actx.createOscillator(), g = actx.createGain();
        o.type = kind === 'gota' ? 'sine' : 'triangle';
        o.frequency.setValueAtTime(f, actx.currentTime + at);
        if (kind === 'gota') o.frequency.exponentialRampToValueAtTime(f * 1.9, actx.currentTime + at + .12);
        g.gain.setValueAtTime(0, actx.currentTime + at);
        g.gain.linearRampToValueAtTime(kind === 'campana' ? .12 : .16, actx.currentTime + at + .015);
        g.gain.exponentialRampToValueAtTime(.0001, actx.currentTime + at + dur);
        o.connect(g).connect(actx.destination);
        o.start(actx.currentTime + at); o.stop(actx.currentTime + at + dur + .05);
      }
    } catch {}
  }
  window.avisos.onAdd((n) => {
    const pos = ['br', 'tr', 'bl', 'tl'].includes(n.pos) ? n.pos : 'br';
    document.documentElement.classList.toggle('top', pos[0] === 't');
    document.documentElement.classList.toggle('left', pos[1] === 'l');
    if (n.sound && n.sound !== 'none') chime(n.sound);
    const kind = ICONS[n.kind] ? n.kind : 'gen';
    const c = n.color || COLORS[kind];
    const life = Math.max(4, Math.min(20, n.life || 8));
    const card = document.createElement('div');
    card.className = 'nf l-' + (LOOKS.includes(n.look) ? n.look : 'tarjeta') + (n.scheme === 'dark' ? ' dark' : '');
    card.style.setProperty('--c', c);
    card.style.setProperty('--life', life + 's');
    const ico = document.createElement('span'); ico.className = 'ico';
    ico.innerHTML = `<svg viewBox="0 0 24 24">${ICONS[kind]}</svg>`;
    const tx = document.createElement('span'); tx.className = 'tx';
    const app = document.createElement('span'); app.className = 'app'; app.textContent = n.label || LABEL[kind];
    const t = document.createElement('span'); t.className = 't'; t.textContent = n.title || '';
    const b = document.createElement('span'); b.className = 'b'; b.textContent = n.body || '';
    tx.append(app, t);
    if (n.body) tx.append(b);
    const x = document.createElement('button'); x.className = 'x'; x.textContent = '×'; x.title = 'Cerrar';
    x.onclick = (e) => { e.stopPropagation(); remove(card); };
    const bar = document.createElement('span'); bar.className = 'bar';
    bar.addEventListener('animationend', () => remove(card));
    card.append(ico, tx, x, bar);
    card.onclick = () => { window.avisos.click(n.id); remove(card); };
    stack.prepend(card);
    while (stack.children.length > 4) stack.lastElementChild.remove();
    report();
  });
})();
