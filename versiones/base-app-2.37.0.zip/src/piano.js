// Piano y sintetizador de Base (Sala de juegos > Mini juegos).
// Todo el sonido se arma con Web Audio: no usa archivos ni internet.
(() => {
  'use strict';
  if (!window.BaseMini || !window.BaseMini.util) return;
  const { h, btn } = window.BaseMini.util;

  // ---------- Instrumentos ----------
  const INST = {
    piano: { n: 'Piano', c: '#f5b52e' },
    electrico: { n: 'Piano eléctrico', c: '#ff7a59' },
    organo: { n: 'Órgano', c: '#c0392b' },
    sinte: { n: 'Sintetizador', c: '#8e5cf7' },
    pad: { n: 'Colchón (pad)', c: '#3d9bff' },
    cuerdas: { n: 'Cuerdas', c: '#27ae60' },
    bajo: { n: 'Bajo', c: '#e64980' },
    campanas: { n: 'Campanitas', c: '#14b8a6' },
    retro: { n: '8 bits', c: '#94a3b8' }
  };
  const NAMES_DO = ['Do', 'Do#', 'Re', 'Re#', 'Mi', 'Fa', 'Fa#', 'Sol', 'Sol#', 'La', 'La#', 'Si'];
  const NAMES_C = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const BLACK = [1, 3, 6, 8, 10];
  // teclado de la compu (por posición física, sirve con cualquier distribución)
  const PC_LOW = ['KeyZ', 'KeyS', 'KeyX', 'KeyD', 'KeyC', 'KeyV', 'KeyG', 'KeyB', 'KeyH', 'KeyN', 'KeyJ', 'KeyM', 'Comma', 'KeyL', 'Period'];
  const PC_HIGH = ['KeyQ', 'Digit2', 'KeyW', 'Digit3', 'KeyE', 'KeyR', 'Digit5', 'KeyT', 'Digit6', 'KeyY', 'Digit7', 'KeyU', 'KeyI', 'Digit9', 'KeyO', 'Digit0', 'KeyP'];
  const PC_LABEL = { Comma: ',', Period: '.' };
  const pcLabel = (code) => PC_LABEL[code] || code.replace(/^Key|^Digit/, '');
  const freqOf = (m) => 440 * Math.pow(2, (m - 69) / 12);

  let AC = null, OUT = null;
  function audio() {
    if (AC) { if (AC.state === 'suspended') AC.resume(); return AC; }
    AC = new (window.AudioContext || window.webkitAudioContext)();
    const master = AC.createGain(); master.gain.value = 0.8;
    const comp = AC.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    const dry = AC.createGain();
    // reverb: respuesta de sala generada con ruido que se apaga
    const rev = AC.createConvolver(), revGain = AC.createGain();
    const len = AC.sampleRate * 2.6, ir = AC.createBuffer(2, len, AC.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    rev.buffer = ir;
    // eco
    const dly = AC.createDelay(1.5), fb = AC.createGain(), dlyGain = AC.createGain(), dlyTone = AC.createBiquadFilter();
    dly.delayTime.value = 0.32; fb.gain.value = 0.35; dlyTone.type = 'lowpass'; dlyTone.frequency.value = 3200;
    dly.connect(dlyTone); dlyTone.connect(fb); fb.connect(dly); dlyTone.connect(dlyGain);
    const bus = AC.createGain();
    bus.connect(dry); bus.connect(rev); bus.connect(dly);
    rev.connect(revGain);
    dry.connect(master); revGain.connect(master); dlyGain.connect(master);
    master.connect(comp); comp.connect(AC.destination);
    OUT = { bus, master, revGain, dlyGain, dly };
    return AC;
  }
  function noiseBuf() {
    if (noiseBuf.b) return noiseBuf.b;
    const b = AC.createBuffer(1, AC.sampleRate * 0.1, AC.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return (noiseBuf.b = b);
  }

  // Arma una voz. Devuelve { off(t) } para soltar la nota.
  function voice(kind, midi, vel, bright) {
    const ac = AC, t = ac.currentTime, f = freqOf(midi);
    const out = ac.createGain(); out.gain.value = 0;
    const filt = ac.createBiquadFilter(); filt.type = 'lowpass';
    filt.connect(out); out.connect(OUT.bus);
    const nodes = [];
    const osc = (type, freq, gain, det = 0) => { const o = ac.createOscillator(); o.type = type; o.frequency.value = freq; o.detune.value = det; const g = ac.createGain(); g.gain.value = gain; o.connect(g); g.connect(filt); o.start(t); nodes.push(o); return o; };
    const fm = (ratio, index, gain, decay) => {
      const car = ac.createOscillator(), mod = ac.createOscillator(), mg = ac.createGain(), g = ac.createGain();
      car.frequency.value = f; mod.frequency.value = f * ratio; mg.gain.setValueAtTime(f * index, t); mg.gain.exponentialRampToValueAtTime(f * index * 0.05 + 0.01, t + decay);
      mod.connect(mg); mg.connect(car.frequency); car.connect(g); g.gain.value = gain; g.connect(filt); car.start(t); mod.start(t); nodes.push(car, mod);
    };
    const v = 0.25 + vel * 0.75, b = 0.15 + bright * 0.85;
    let rel = 0.25, sustainLevel = 0, decay = 1;
    const G = out.gain;
    switch (kind) {
      case 'piano': {
        decay = Math.max(1.2, 6 - (midi - 36) * 0.07);
        osc('triangle', f, 0.55); osc('sine', f * 2, 0.22 * b); osc('sine', f * 3, 0.08 * b); osc('sine', f, 0.3, 4);
        filt.frequency.setValueAtTime(800 + 7000 * b * v, t); filt.frequency.exponentialRampToValueAtTime(400 + 1600 * b, t + decay * 0.6);
        // golpecito del martillo
        const n = ac.createBufferSource(), ng = ac.createGain(), nf = ac.createBiquadFilter(); n.buffer = noiseBuf(); nf.type = 'bandpass'; nf.frequency.value = Math.min(6000, f * 4);
        ng.gain.setValueAtTime(0.12 * v, t); ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.05); n.connect(nf); nf.connect(ng); ng.connect(out); n.start(t);
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.42 * v, t + 0.005); G.exponentialRampToValueAtTime(0.0008, t + decay);
        rel = 0.35; break;
      }
      case 'electrico': {
        decay = 3.2; fm(1, 1.6 * b + 0.3, 0.5, 0.9); osc('sine', f * 2, 0.06);
        filt.frequency.value = 5000;
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.45 * v, t + 0.008); G.exponentialRampToValueAtTime(0.002, t + decay);
        rel = 0.4; break;
      }
      case 'organo': {
        [[0.5, 0.25], [1, 0.4], [2, 0.3 * b + 0.05], [3, 0.16 * b], [4, 0.12 * b]].forEach(([r, g]) => osc('sine', f * r, g));
        const lfo = ac.createOscillator(), lg = ac.createGain(); lfo.frequency.value = 6; lg.gain.value = 4; lfo.connect(lg); nodes.forEach(o => lg.connect(o.detune)); lfo.start(t); nodes.push(lfo);
        filt.frequency.value = 6000;
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.32 * v, t + 0.02); sustainLevel = 0.32 * v; rel = 0.08; decay = 0; break;
      }
      case 'sinte': {
        osc('sawtooth', f, 0.3, -7); osc('sawtooth', f, 0.3, 7); osc('square', f / 2, 0.12);
        filt.Q.value = 6; filt.frequency.setValueAtTime(300, t); filt.frequency.linearRampToValueAtTime(600 + 6500 * b, t + 0.03); filt.frequency.exponentialRampToValueAtTime(400 + 2200 * b, t + 0.6);
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.3 * v, t + 0.01); G.linearRampToValueAtTime(0.22 * v, t + 0.3); sustainLevel = 0.22 * v; rel = 0.25; decay = 0; break;
      }
      case 'pad': {
        [-12, -4, 4, 12].forEach(d => osc('sawtooth', f, 0.14, d)); osc('sine', f / 2, 0.2);
        filt.frequency.setValueAtTime(400, t); filt.frequency.linearRampToValueAtTime(900 + 3000 * b, t + 1.2);
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.28 * v, t + 0.6); sustainLevel = 0.28 * v; rel = 1.4; decay = 0; break;
      }
      case 'cuerdas': {
        const a = osc('sawtooth', f, 0.25, -5), c = osc('sawtooth', f, 0.25, 6);
        const lfo = ac.createOscillator(), lg = ac.createGain(); lfo.frequency.value = 5.2; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(9, t + 0.6); lfo.connect(lg); lg.connect(a.detune); lg.connect(c.detune); lfo.start(t); nodes.push(lfo);
        filt.frequency.value = 1200 + 3800 * b;
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.3 * v, t + 0.18); sustainLevel = 0.3 * v; rel = 0.6; decay = 0; break;
      }
      case 'bajo': {
        osc('sawtooth', f, 0.35); osc('sine', f / 2, 0.45);
        filt.Q.value = 4; filt.frequency.setValueAtTime(200 + 2200 * b * v, t); filt.frequency.exponentialRampToValueAtTime(180 + 500 * b, t + 0.35);
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.5 * v, t + 0.005); G.exponentialRampToValueAtTime(0.18 * v, t + 0.5); sustainLevel = 0.18 * v; rel = 0.12; decay = 0; break;
      }
      case 'campanas': {
        decay = 4.5; fm(3.5, 2.2 * b + 0.4, 0.4, 2.5); osc('sine', f * 2, 0.08);
        filt.frequency.value = 9000;
        G.setValueAtTime(0, t); G.linearRampToValueAtTime(0.38 * v, t + 0.003); G.exponentialRampToValueAtTime(0.001, t + decay);
        rel = 1.2; break;
      }
      default: { // retro
        osc('square', f, 0.22); filt.frequency.value = 1500 + 8000 * b;
        G.setValueAtTime(0.26 * v, t); G.setValueAtTime(0.2 * v, t + 0.08); sustainLevel = 0.2 * v; rel = 0.05; decay = 0;
      }
    }
    let stopped = false;
    const kill = (when) => { for (const o of nodes) { try { o.stop(when); } catch {} } setTimeout(() => { try { out.disconnect(); } catch {} }, (when - ac.currentTime + 0.3) * 1000); };
    if (decay) setTimeout(() => { if (!stopped) { stopped = true; kill(ac.currentTime + 0.05); } }, decay * 1000 + 200);
    return {
      off() {
        if (stopped) return; stopped = true;
        const n = ac.currentTime;
        G.cancelScheduledValues(n);
        const cur = Math.max(0.0001, G.value || sustainLevel || 0.0001);
        G.setValueAtTime(cur, n); G.exponentialRampToValueAtTime(0.0001, n + rel);
        kill(n + rel + 0.05);
      }
    };
  }

  // ---------- El instrumento ----------
  function piano(H) {
    const st = Object.assign({ inst: 'piano', vol: 0.8, bright: 0.6, rev: 0.3, echo: 0, chord: 'no', names: 'do', oct: 4, bpm: 90, sustain: false }, H.get().cfg || {});
    const saveCfg = () => { const s = H.get(); s.cfg = st; H.set(s); };
    const root = h('div', { class: 'mg-piano' });
    const panel = h('div', { class: 'pn-panel' });
    const kb = h('div', { class: 'pn-kb' });
    const foot = h('div', { class: 'pn-foot' });
    root.append(panel, kb, foot);

    const held = new Map(); // nota -> voz
    const sources = new Map(); // quién la toca (tecla, puntero o MIDI) -> notas
    let count = H.get().notes || 0;
    const saveCount = () => { const s = H.get(); s.notes = count; H.set(s); };
    let pedal = false, rec = null, take = null, playT = [], metro = null, midiName = '';
    const lit = (m, on) => { const k = kb.querySelector(`[data-m="${m}"]`); if (k) k.classList.toggle('on', on); };
    function applyFx() {
      if (!OUT) return;
      OUT.master.gain.setTargetAtTime(st.vol, AC.currentTime, 0.02);
      OUT.revGain.gain.setTargetAtTime(st.rev * 1.4, AC.currentTime, 0.05);
      OUT.dlyGain.gain.setTargetAtTime(st.echo * 0.9, AC.currentTime, 0.05);
    }
    const chordOf = (m) => st.chord === 'mayor' ? [m, m + 4, m + 7] : st.chord === 'menor' ? [m, m + 3, m + 7] : st.chord === 'septima' ? [m, m + 4, m + 7, m + 10] : [m];
    function noteOn(m, vel = 0.8, who = 'x', fromRec) {
      audio(); applyFx();
      const list = chordOf(m);
      sources.set(who, list);
      for (const n of list) {
        if (n < 21 || n > 108) continue;
        const old = held.get(n); if (old) old.off();
        held.set(n, voice(st.inst, n, vel, st.bright)); lit(n, true);
      }
      if (rec && !fromRec) rec.ev.push([performance.now() - rec.t0, 1, m, vel]);
      if (!fromRec && ++count % 50 === 0) saveCount();
    }
    function noteOff(who, fromRec) {
      const list = sources.get(who); if (!list) return;
      sources.delete(who);
      if (rec && !fromRec) rec.ev.push([performance.now() - rec.t0, 0, list[0]]);
      for (const n of list) {
        // si otra fuente sigue tocando esa nota, no se suelta
        if ([...sources.values()].some(l => l.includes(n))) continue;
        lit(n, false);
        if (pedal || st.sustain) continue;
        const v = held.get(n); if (v) { v.off(); held.delete(n); }
      }
    }
    function releasePedal() { for (const [n, v] of held) { if (![...sources.values()].some(l => l.includes(n))) { v.off(); held.delete(n); } } }
    function allOff() { sources.clear(); for (const [n, v] of held) { v.off(); lit(n, false); } held.clear(); kb.querySelectorAll('.on').forEach(k => k.classList.remove('on')); }

    // ---------- teclado en pantalla ----------
    let lo = 48, hi = 84;
    function buildKb() {
      const w = kb.clientWidth || 900;
      const octs = Math.max(2, Math.min(5, Math.floor(w / 330)));
      lo = 12 * (st.oct - (octs >= 4 ? 1 : 0)) + 12; hi = lo + octs * 12;
      kb.replaceChildren();
      const whites = []; for (let m = lo; m <= hi; m++) if (!BLACK.includes(m % 12)) whites.push(m);
      const ww = 100 / whites.length;
      const pcMap = {};
      PC_LOW.forEach((c, i) => { pcMap[st.oct * 12 + 12 + i] = c; });
      PC_HIGH.forEach((c, i) => { pcMap[st.oct * 12 + 24 + i] = pcMap[st.oct * 12 + 24 + i] || c; });
      let wi = 0;
      for (let m = lo; m <= hi; m++) {
        const black = BLACK.includes(m % 12);
        const nm = st.names === 'do' ? NAMES_DO[m % 12] : st.names === 'c' ? NAMES_C[m % 12] : st.names === 'teclas' ? (pcMap[m] ? pcLabel(pcMap[m]) : '') : '';
        const k = h('div', { class: 'pn-k ' + (black ? 'b' : 'w') + (m % 12 === 0 ? ' c' : ''), 'data-m': m });
        if (black) k.style.left = `calc(${wi * ww}% - ${ww * 0.31}%)`, k.style.width = ww * 0.62 + '%';
        else { k.style.left = wi * ww + '%'; k.style.width = ww + '%'; wi++; }
        if (nm && (!black || st.names === 'teclas')) k.append(h('span', { class: 'pn-n', text: nm + (st.names !== 'teclas' && m % 12 === 0 ? Math.floor(m / 12) - 1 : '') }));
        if (held.has(m)) k.classList.add('on');
        kb.append(k);
      }
      kb.style.setProperty('--ac', INST[st.inst].c);
    }
    const ptr = new Map();
    const velAt = (k, y) => { const r = k.getBoundingClientRect(); return Math.max(0.3, Math.min(1, 0.35 + (y - r.top) / r.height * 0.75)); };
    kb.addEventListener('pointerdown', (e) => {
      const k = e.target.closest('.pn-k'); if (!k) return;
      e.preventDefault();
      // sin "captura" del puntero, así deslizando el dedo o el mouse se tocan las teclas de al lado
      try { if (e.target.hasPointerCapture && e.target.hasPointerCapture(e.pointerId)) e.target.releasePointerCapture(e.pointerId); } catch {}
      const m = +k.dataset.m; ptr.set(e.pointerId, m); noteOn(m, velAt(k, e.clientY), 'p' + e.pointerId);
    });
    kb.addEventListener('pointerover', (e) => {
      if (!ptr.has(e.pointerId)) return;
      const k = e.target.closest('.pn-k'); if (!k) return;
      const m = +k.dataset.m; if (ptr.get(e.pointerId) === m) return;
      noteOff('p' + e.pointerId); ptr.set(e.pointerId, m); noteOn(m, velAt(k, e.clientY), 'p' + e.pointerId);
    });
    const up = (e) => { if (!ptr.has(e.pointerId)) return; ptr.delete(e.pointerId); noteOff('p' + e.pointerId); };
    addEventListener('pointerup', up); addEventListener('pointercancel', up);
    kb.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && e.buttons === 0) up(e); });

    // ---------- teclado de la compu ----------
    function pcNote(code) {
      let i = PC_LOW.indexOf(code); if (i >= 0) return st.oct * 12 + 12 + i;
      i = PC_HIGH.indexOf(code); if (i >= 0) return st.oct * 12 + 24 + i;
      return null;
    }
    const visible = () => root.isConnected && root.offsetParent !== null;
    const key = (e) => {
      if (e.ctrlKey || e.altKey || e.metaKey) return false;
      if (e.code === 'Space') { if (!e.repeat) { pedal = true; paintPanel(); } return true; }
      if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') { setOct(st.oct + (e.code === 'ArrowLeft' ? -1 : 1)); return true; }
      const m = pcNote(e.code); if (m == null) return false;
      if (!e.repeat) noteOn(m, 0.8, 'k' + e.code);
      return true;
    };
    const keyUp = (e) => {
      if (!visible()) return;
      if (e.code === 'Space') { pedal = false; releasePedal(); paintPanel(); return; }
      if (pcNote(e.code) != null) noteOff('k' + e.code);
    };
    addEventListener('keyup', keyUp);
    addEventListener('blur', () => { if (visible()) { pedal = false; allOff(); } });

    // ---------- teclado MIDI (si conectás uno por USB) ----------
    if (navigator.requestMIDIAccess) {
      navigator.requestMIDIAccess().then((acc) => {
        const hook = () => {
          const names = [];
          for (const inp of acc.inputs.values()) {
            names.push(inp.name);
            inp.onmidimessage = (ev) => {
              if (!visible()) return;
              const [s, n, v] = ev.data, cmd = s & 0xf0;
              if (cmd === 0x90 && v > 0) noteOn(n, v / 127, 'm' + n);
              else if (cmd === 0x80 || (cmd === 0x90 && v === 0)) noteOff('m' + n);
              else if (cmd === 0xb0 && n === 64) { pedal = v >= 64; if (!pedal) releasePedal(); paintPanel(); }
            };
          }
          midiName = names[0] || ''; paintFoot();
        };
        hook(); acc.onstatechange = hook;
      }).catch(() => {});
    }

    // ---------- grabar y escuchar ----------
    function recToggle() {
      if (rec) { take = { ev: rec.ev, len: performance.now() - rec.t0 }; rec = null; }
      else { stopPlay(); rec = { t0: performance.now(), ev: [] }; }
      paintPanel(); paintFoot();
    }
    function stopPlay() { playT.forEach(clearTimeout); playT = []; for (const w of [...sources.keys()]) if (String(w).startsWith('r')) noteOff(w, true); paintPanel(); }
    function play() {
      if (!take || !take.ev.length) return;
      if (playT.length) return stopPlay();
      for (const [t, on, m, vel] of take.ev) playT.push(setTimeout(() => on ? noteOn(m, vel, 'r' + m, true) : noteOff('r' + m, true), t));
      playT.push(setTimeout(() => { playT = []; paintPanel(); }, take.len + 50));
      paintPanel();
    }

    // ---------- metrónomo ----------
    function metroToggle() {
      if (metro) { clearInterval(metro.t); metro = null; paintPanel(); return; }
      audio(); let beat = 0;
      const tick = () => {
        const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
        o.frequency.value = beat % 4 === 0 ? 1600 : 1000; g.gain.setValueAtTime(0.25, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
        o.connect(g); g.connect(OUT.master); o.start(t); o.stop(t + 0.06);
        const dot = panel.querySelector('.pn-beat'); if (dot) { dot.classList.toggle('one', beat % 4 === 0); dot.classList.remove('go'); void dot.offsetWidth; dot.classList.add('go'); }
        beat++;
      };
      metro = { t: setInterval(tick, 60000 / st.bpm) }; tick(); paintPanel();
    }

    function setOct(o) { st.oct = Math.max(1, Math.min(6, o)); saveCfg(); allOff(); buildKb(); paintPanel(); }

    // ---------- panel de controles ----------
    const slider = (label, k, min, max, step, fmt) => {
      const inp = h('input', { type: 'range', min, max, step, value: st[k] });
      const val = h('b', { text: fmt(st[k]) });
      inp.oninput = () => { st[k] = +inp.value; val.textContent = fmt(st[k]); applyFx(); saveCfg(); if (k === 'bpm' && metro) { metroToggle(); metroToggle(); } };
      return h('label', { class: 'pn-sl' }, h('span', {}, label, val), inp);
    };
    const chip = (on, text, fn, cls = '') => { const b = h('button', { type: 'button', class: 'pn-chip ' + cls + (on ? ' on' : ''), text }); b.onclick = fn; return b; };
    const pct = (v) => Math.round(v * 100) + '%';
    function paintPanel() {
      const insts = h('div', { class: 'pn-insts' });
      for (const [k, v] of Object.entries(INST)) {
        const b = h('button', { type: 'button', class: 'pn-inst' + (st.inst === k ? ' on' : ''), style: `--ic:${v.c}`, text: v.n });
        b.onclick = () => { st.inst = k; saveCfg(); H.status([v.n]); allOff(); kb.style.setProperty('--ac', v.c); paintPanel(); noteOn(60 + 12 * (k === 'bajo' ? -2 : 0), 0.7, 'demo'); setTimeout(() => noteOff('demo'), 350); };
        insts.append(b);
      }
      const knobs = h('div', { class: 'pn-knobs' },
        slider('Volumen', 'vol', 0, 1, 0.01, pct), slider('Brillo', 'bright', 0, 1, 0.01, pct),
        slider('Reverb', 'rev', 0, 1, 0.01, pct), slider('Eco', 'echo', 0, 1, 0.01, pct));
      const oct = h('div', { class: 'pn-group' }, h('small', { text: 'Octava' }), chip(false, '−', () => setOct(st.oct - 1)), h('b', { class: 'pn-oct', text: String(st.oct) }), chip(false, '+', () => setOct(st.oct + 1)));
      const chords = h('div', { class: 'pn-group' }, h('small', { text: 'Acordes' }),
        ...[['no', 'No'], ['mayor', 'Mayor'], ['menor', 'Menor'], ['septima', '7ª']].map(([k, t]) => chip(st.chord === k, t, () => { st.chord = k; saveCfg(); allOff(); paintPanel(); })));
      const sus = h('div', { class: 'pn-group' }, h('small', { text: 'Pedal' }), chip(st.sustain || pedal, st.sustain ? 'Fijo' : pedal ? 'Apretado' : 'Espacio', () => { st.sustain = !st.sustain; saveCfg(); if (!st.sustain) releasePedal(); paintPanel(); }));
      const names = h('div', { class: 'pn-group' }, h('small', { text: 'Nombres' }),
        ...[['do', 'Do Re Mi'], ['c', 'C D E'], ['teclas', 'Teclas'], ['nada', 'Sin']].map(([k, t]) => chip(st.names === k, t, () => { st.names = k; saveCfg(); buildKb(); paintPanel(); })));
      const recG = h('div', { class: 'pn-group' }, h('small', { text: 'Grabar' }),
        chip(!!rec, rec ? '■ Parar' : '● Grabar', recToggle, 'rec'),
        chip(playT.length > 0, playT.length ? '■ Parar' : '▶ Escuchar', play, take && take.ev.length ? '' : 'off'));
      const met = h('div', { class: 'pn-group' }, h('small', { text: 'Metrónomo' }), chip(!!metro, metro ? '■' : '▶', metroToggle), h('i', { class: 'pn-beat' }), slider('', 'bpm', 40, 200, 1, (v) => v + ' bpm'));
      panel.replaceChildren(insts, h('div', { class: 'pn-row' }, knobs, oct, chords, sus, names, recG, met));
    }
    function paintFoot() {
      foot.textContent = (rec ? '● Grabando… ' : '') + 'Tocá con el mouse (más abajo en la tecla = más fuerte) o con el teclado: fila Z X C V… y Q W E R… · ← → cambian la octava · Espacio es el pedal' + (midiName ? ` · Teclado MIDI: ${midiName}` : '');
    }

    let lastW = 0, rf = 0;
    new ResizeObserver(() => { const w = kb.clientWidth; if (Math.abs(w - lastW) < 20) return; lastW = w; cancelAnimationFrame(rf); rf = requestAnimationFrame(buildKb); }).observe(kb);
    paintPanel(); paintFoot();
    requestAnimationFrame(buildKb);
    H.status([INST[st.inst].n]);
    return {
      el: root, key,
      tools: [btn('Silencio', () => { pedal = false; allOff(); })],
      help: 'Elegí el sonido arriba. Tocá con el mouse, con el teclado de la compu o con un teclado MIDI por USB.',
      hide: () => { pedal = false; allOff(); stopPlay(); if (metro) metroToggle(); saveCount(); },
      show: () => buildKb()
    };
  }

  window.BaseMini.GAMES.push({
    id: 'piano', n: 'Piano y sintetizador', d: 'Tocá piano, órgano, sintetizador y más. Grabá y escuchá lo que tocaste.', c: '#7b4fc9', create: piano,
    art: '<svg viewBox="0 0 64 64"><rect width="64" height="64" rx="8" fill="#2b2140"/><rect x="6" y="20" width="52" height="34" rx="3" fill="#fff"/><g fill="#1b1528"><rect x="12" y="20" width="5" height="20" rx="1"/><rect x="20" y="20" width="5" height="20" rx="1"/><rect x="34" y="20" width="5" height="20" rx="1"/><rect x="42" y="20" width="5" height="20" rx="1"/><rect x="50" y="20" width="5" height="20" rx="1"/></g><g stroke="#cfc8dc" stroke-width="1"><path d="M13.4 40v14M20.8 40v14M28.2 40v14M35.6 40v14M43 40v14M50.4 40v14"/></g><rect x="28.6" y="40" width="7" height="14" fill="#a77bff"/><circle cx="14" cy="11" r="3" fill="#f5b52e"/><circle cx="26" cy="11" r="3" fill="#ff7a59"/><circle cx="38" cy="11" r="3" fill="#8e5cf7"/><circle cx="50" cy="11" r="3" fill="#14b8a6"/></svg>',
    best: (s) => s.notes ? `${s.notes.toLocaleString('es-AR')} notas tocadas` : 'Nunca tocaste'
  });
})();
