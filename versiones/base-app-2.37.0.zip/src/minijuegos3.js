// Mini juegos de Base con movimiento: Carreras y Vuelo.
(() => {
  'use strict';
  if (!window.BaseMini || !window.BaseMini.util) return;
  const { h, rnd, seg, btn, overlay, confetti } = window.BaseMini.util;
  const closeOver = (root) => { const o = root.querySelector('.mg-over'); if (o) o.remove(); };
  // lienzo que se adapta al espacio (sin avisos de "ResizeObserver loop")
  function stageCanvas(root, onSize) {
    const cv = h('canvas', { class: 'mv-cv' });
    root.append(cv);
    const ctx = cv.getContext('2d');
    const S = { W: 800, H: 500, cv, ctx };
    let last = '', rf = 0;
    const fit = () => {
      const W = Math.max(320, root.clientWidth), H = Math.max(240, root.clientHeight);
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      cv.style.width = W + 'px'; cv.style.height = H + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      S.W = W; S.H = H; onSize && onSize();
    };
    new ResizeObserver(() => { const k = root.clientWidth + 'x' + root.clientHeight; if (k === last) return; last = k; cancelAnimationFrame(rf); rf = requestAnimationFrame(fit); }).observe(root);
    S.fit = fit;
    return S;
  }
  function loop(step) {
    let raf = 0, lastT = 0, on = false;
    const frame = (t) => { if (!on) return; const dt = Math.min(0.05, lastT ? (t - lastT) / 1000 : 0.016); lastT = t; step(dt); raf = requestAnimationFrame(frame); };
    return { start() { if (on) return; on = true; lastT = 0; raf = requestAnimationFrame(frame); }, stop() { on = false; cancelAnimationFrame(raf); }, get on() { return on; } };
  }

  // =====================================================================
  // CARRERAS (ruta en pseudo 3D, esquivando autos)
  // =====================================================================
  const CAR_COL = { rojo: '#e8202a', azul: '#1f5fe0', amarillo: '#f5c518', verde: '#1e9e4a', negro: '#23262d', blanco: '#f2f2f2', rosa: '#ff4fa3' };
  function carreras(H) {
    const root = h('div', { class: 'mg-move' });
    const hud = h('div', { class: 'mv-hud' });
    const msg = h('div', { class: 'sn-msg', text: 'Flecha ↑ para arrancar' });
    const S = stageCanvas(root, () => draw());
    root.append(hud, msg);
    const ctx = S.ctx;
    const SEG = 200, ROADW = 2000, RUMBLE = 3, LANES = 3, DRAW = 260, CAMH = 1000, FOV = 100;
    const CAMD = 1 / Math.tan((FOV / 2) * Math.PI / 180);
    const MAXSPD = SEG / (1 / 60), ACC = MAXSPD / 5, BREAK = -MAXSPD, DECEL = -MAXSPD / 5, OFFDEC = -MAXSPD / 2, OFFLIM = MAXSPD / 4, CENTRI = 0.3;
    let segs = [], trackLen = 0, cars = [];
    let pos, pX, speed, time, dist, nextCheck, over, started, keys = {}, checkFlash = 0;
    const playerZ = CAMH * CAMD;
    const status = () => H.status([`${Math.round(dist / 1000 * 10) / 10} km`, `Mejor ${H.get().best ? (H.get().best / 1000).toFixed(1) + ' km' : '—'}`]);
    const ease = { in: (a, b, p) => a + (b - a) * p * p, inOut: (a, b, p) => a + (b - a) * ((-Math.cos(p * Math.PI) / 2) + 0.5) };
    const lastY = () => segs.length ? segs[segs.length - 1].p2.world.y : 0;
    function addSeg(curve, y) {
      const n = segs.length;
      segs.push({ i: n, curve, cars: [], p1: { world: { y: lastY(), z: n * SEG }, camera: {}, screen: {} }, p2: { world: { y, z: (n + 1) * SEG }, camera: {}, screen: {} }, dark: Math.floor(n / RUMBLE) % 2 });
    }
    function addRoad(enter, hold, leave, curve, hill) {
      const sy = lastY(), ey = sy + hill * SEG, total = enter + hold + leave;
      for (let n = 0; n < enter; n++) addSeg(ease.in(0, curve, n / enter), ease.inOut(sy, ey, n / total));
      for (let n = 0; n < hold; n++) addSeg(curve, ease.inOut(sy, ey, (enter + n) / total));
      for (let n = 0; n < leave; n++) addSeg(ease.inOut(curve, 0, n / leave), ease.inOut(sy, ey, (enter + hold + n) / total));
    }
    function build() {
      segs = [];
      const L = { s: 25, m: 50, l: 100 }, C = { e: 2, m: 4, h: 6 }, Hh = { l: 20, m: 40, h: 60 };
      addRoad(L.m, L.m, L.m, 0, 0);
      addRoad(L.m, L.m, L.m, 0, Hh.l / 2);
      addRoad(L.m, L.m, L.m, -C.m, 0);
      addRoad(L.l, L.l, L.l, C.m, Hh.m);
      addRoad(L.s, L.s, L.s, 0, -Hh.l);
      addRoad(L.m, L.m, L.m, -C.h, Hh.l);
      addRoad(L.l, L.l, L.l, 0, -Hh.m);
      addRoad(L.m, L.m, L.m, C.e, 0);
      for (let i = 0; i < 4; i++) addRoad(L.s, L.s, L.s, (i % 2 ? 1 : -1) * C.m, (i % 2 ? 1 : -1) * Hh.l);
      addRoad(L.l, L.l, L.l, -C.e, Hh.h);
      addRoad(L.m, L.m, L.m, C.h, -Hh.m);
      addRoad(L.l, L.m, L.l, 0, -lastY() / SEG); // vuelve a la altura inicial para que la vuelta cierre
      trackLen = segs.length * SEG;
      cars = [];
      const colors = ['#2f6fed', '#f5b52e', '#27ae60', '#8e44ad', '#ecf0f1', '#16a085', '#e67e22', '#34495e'];
      for (let n = 0; n < 34; n++) {
        const z = Math.floor(Math.random() * segs.length) * SEG;
        if (z < 30 * SEG) continue;
        const car = { offset: [-0.66, 0, 0.66][rnd(3)] + (Math.random() - 0.5) * 0.1, z, speed: MAXSPD / 4 + Math.random() * MAXSPD / 3, c: colors[rnd(colors.length)], w: 0.34 };
        cars.push(car); findSeg(car.z).cars.push(car);
      }
    }
    const findSeg = (z) => segs[Math.floor(z / SEG) % segs.length];
    const wrap = (v) => { while (v >= trackLen) v -= trackLen; while (v < 0) v += trackLen; return v; };
    function newGame() {
      closeOver(root);
      build();
      pos = 0; pX = 0; speed = 0; time = 45; dist = 0; nextCheck = 1500; over = false; started = false; keys = {};
      msg.hidden = false; msg.textContent = 'Flecha ↑ para arrancar';
      L.stop(); draw(); status(); hudPaint();
    }
    function hudPaint() {
      hud.innerHTML = `<span class="mv-big">${Math.round(speed / MAXSPD * 220)}<small> km/h</small></span><span class="mv-t${time < 10 ? ' low' : ''}">${Math.max(0, time).toFixed(1)} s</span><span>${(dist / 1000).toFixed(2)} km</span>` + (checkFlash > 0 ? '<span class="mv-check">¡Control! +15 s</span>' : '');
    }
    function update(dt) {
      const pSeg = findSeg(pos + playerZ), sp = speed / MAXSPD, dx = dt * 2 * sp;
      // autos de la ruta
      for (const car of cars) {
        const old = findSeg(car.z);
        car.z = wrap(car.z + dt * car.speed);
        const nw = findSeg(car.z);
        if (old !== nw) { old.cars.splice(old.cars.indexOf(car), 1); nw.cars.push(car); }
      }
      pos = wrap(pos + dt * speed);
      dist += dt * (speed / MAXSPD) * 61; // metros (a fondo son 220 km/h)
      if (keys.left) pX -= dx; else if (keys.right) pX += dx;
      pX -= dx * sp * pSeg.curve * CENTRI;
      if (keys.up) speed += ACC * dt; else if (keys.down) speed += BREAK * dt; else speed += DECEL * dt;
      if ((pX < -1 || pX > 1) && speed > OFFLIM) speed += OFFDEC * dt;
      pX = Math.max(-2.2, Math.min(2.2, pX));
      speed = Math.max(0, Math.min(MAXSPD, speed));
      // choques
      for (const car of pSeg.cars) {
        if (speed > car.speed && Math.abs(pX - car.offset) < (0.32 + car.w) / 2) {
          speed = car.speed * (car.speed / speed) * 0.8;
          pos = wrap(car.z - playerZ - SEG * 0.3);
          shake = 0.35;
          break;
        }
      }
      if (shake > 0) shake -= dt;
      time -= dt;
      if (checkFlash > 0) checkFlash -= dt;
      if (dist >= nextCheck) { time += 15; nextCheck += 1500; checkFlash = 2; }
      if (time <= 0) return end();
    }
    let shake = 0;
    const L = loop((dt) => { update(dt); draw(); hudPaint(); if (Math.random() < 0.1) status(); });
    function end() {
      over = true; L.stop(); time = 0; hudPaint();
      const s = H.get(); const rec = dist > (s.best || 0); if (rec) s.best = Math.round(dist); s.games = (s.games || 0) + 1; H.set(s); status();
      if (rec) confetti(root);
      overlay(root, rec ? '¡Nuevo récord!' : 'Se acabó el tiempo', `Recorriste ${(dist / 1000).toFixed(2)} km`, [btn('Otra vez', newGame, 'primary')]);
    }
    function project(p, cx, cy, cz) {
      p.camera.x = (p.world.x || 0) - cx; p.camera.y = p.world.y - cy; p.camera.z = p.world.z - cz;
      p.screen.scale = CAMD / p.camera.z;
      p.screen.x = Math.round(S.W / 2 + p.screen.scale * p.camera.x * S.W / 2);
      p.screen.y = Math.round(S.H / 2 - p.screen.scale * p.camera.y * S.H / 2);
      p.screen.w = Math.round(p.screen.scale * ROADW * S.W / 2);
    }
    function poly(x1, y1, x2, y2, x3, y3, x4, y4, c) { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.lineTo(x4, y4); ctx.closePath(); ctx.fill(); }
    function drawCar(x, y, w, c, isPlayer) {
      const hh = w * 0.55;
      ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fillRect(x - w * 0.52, y - hh * 0.12, w * 1.04, hh * 0.18);
      ctx.fillStyle = c;
      ctx.beginPath(); ctx.moveTo(x - w / 2, y - hh * 0.15); ctx.lineTo(x - w / 2, y - hh * 0.62); ctx.lineTo(x - w * 0.36, y - hh); ctx.lineTo(x + w * 0.36, y - hh); ctx.lineTo(x + w / 2, y - hh * 0.62); ctx.lineTo(x + w / 2, y - hh * 0.15); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(20,30,45,.85)'; ctx.fillRect(x - w * 0.3, y - hh * 0.93, w * 0.6, hh * 0.28);
      ctx.fillStyle = isPlayer && keys.down ? '#ff2a2a' : '#c0392b'; ctx.fillRect(x - w * 0.46, y - hh * 0.5, w * 0.16, hh * 0.12); ctx.fillRect(x + w * 0.3, y - hh * 0.5, w * 0.16, hh * 0.12);
      ctx.fillStyle = '#111'; ctx.fillRect(x - w * 0.46, y - hh * 0.16, w * 0.14, hh * 0.18); ctx.fillRect(x + w * 0.32, y - hh * 0.16, w * 0.14, hh * 0.18);
    }
    function draw() {
      if (!segs.length) return;
      const W = S.W, Hh = S.H;
      // cielo y montañas
      const g = ctx.createLinearGradient(0, 0, 0, Hh); g.addColorStop(0, '#2c6fbf'); g.addColorStop(0.55, '#9fd0f0'); g.addColorStop(0.56, '#9fd0f0'); g.addColorStop(1, '#9fd0f0');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, Hh);
      const base = findSeg(pos), bp = (pos % SEG) / SEG, pSeg = findSeg(pos + playerZ), pp = ((pos + playerZ) % SEG) / SEG;
      const pY = pSeg.p1.world.y + (pSeg.p2.world.y - pSeg.p1.world.y) * pp;
      const off = (base.i / segs.length) * W * 2.5 % W;
      ctx.fillStyle = '#6a8fb5';
      for (let k = -1; k < 3; k++) { const ox = k * W - off * 0.3; ctx.beginPath(); ctx.moveTo(ox, Hh * 0.56); for (let i = 0; i <= 8; i++) ctx.lineTo(ox + i * W / 8, Hh * 0.56 - (i % 2 ? Hh * 0.16 : Hh * 0.05) - (i % 3 ? 0 : Hh * 0.06)); ctx.lineTo(ox + W, Hh * 0.56); ctx.fill(); }
      ctx.fillStyle = '#4c7a4f';
      for (let k = -1; k < 3; k++) { const ox = k * W - off * 0.6; ctx.beginPath(); ctx.moveTo(ox, Hh * 0.57); for (let i = 0; i <= 12; i++) ctx.lineTo(ox + i * W / 12, Hh * 0.57 - (i % 2 ? Hh * 0.07 : Hh * 0.02)); ctx.lineTo(ox + W, Hh * 0.57); ctx.fill(); }
      let maxy = Hh, x = 0, dx = -(base.curve * bp);
      const shk = shake > 0 ? (Math.random() - 0.5) * 8 : 0;
      for (let n = 0; n < DRAW; n++) {
        const sg = segs[(base.i + n) % segs.length];
        const looped = sg.i < base.i;
        project(sg.p1, pX * ROADW - x, pY + CAMH, pos - (looped ? trackLen : 0));
        project(sg.p2, pX * ROADW - x - dx, pY + CAMH, pos - (looped ? trackLen : 0));
        x += dx; dx += sg.curve;
        sg.clip = maxy;
        if (sg.p1.camera.z <= CAMD || sg.p2.screen.y >= sg.p1.screen.y || sg.p2.screen.y >= maxy) continue;
        const a = sg.p1.screen, b = sg.p2.screen;
        ctx.fillStyle = sg.dark ? '#3f8f3a' : '#4aa244'; ctx.fillRect(0, b.y, W, a.y - b.y);
        const r1 = a.w / Math.max(6, 2 * LANES), r2 = b.w / Math.max(6, 2 * LANES);
        poly(a.x - a.w - r1, a.y, a.x - a.w, a.y, b.x - b.w, b.y, b.x - b.w - r2, b.y, sg.dark ? '#d8d8d8' : '#c0392b');
        poly(a.x + a.w + r1, a.y, a.x + a.w, a.y, b.x + b.w, b.y, b.x + b.w + r2, b.y, sg.dark ? '#d8d8d8' : '#c0392b');
        poly(a.x - a.w, a.y, a.x + a.w, a.y, b.x + b.w, b.y, b.x - b.w, b.y, sg.dark ? '#5d6066' : '#64676d');
        if (sg.dark) {
          const l1 = a.w / 40, l2 = b.w / 40;
          for (let ln = 1; ln < LANES; ln++) { const ax = a.x - a.w + 2 * a.w * ln / LANES, bx = b.x - b.w + 2 * b.w * ln / LANES; poly(ax - l1, a.y, ax + l1, a.y, bx + l2, b.y, bx - l2, b.y, '#f2f2f2'); }
        }
        maxy = b.y;
      }
      // autos (de atrás para adelante)
      for (let n = DRAW - 1; n > 0; n--) {
        const sg = segs[(base.i + n) % segs.length];
        for (const car of sg.cars) {
          const pc = (car.z % SEG) / SEG;
          const sc = sg.p1.screen.scale + (sg.p2.screen.scale - sg.p1.screen.scale) * pc;
          if (!(sc > 0)) continue;
          const cx = sg.p1.screen.x + (sg.p2.screen.x - sg.p1.screen.x) * pc + sc * car.offset * ROADW * W / 2;
          const cy = sg.p1.screen.y + (sg.p2.screen.y - sg.p1.screen.y) * pc;
          const w = sc * ROADW * W / 2 * car.w;
          if (cy > sg.clip + 2 || w < 2) continue;
          ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, sg.clip); ctx.clip(); drawCar(cx, cy, w, car.c, false); ctx.restore();
        }
      }
      const pw = Math.min(W * 0.2, 190), steer = keys.left ? -1 : keys.right ? 1 : 0;
      ctx.save(); ctx.translate(W / 2 + shk, Hh - 18); ctx.rotate(steer * 0.04 * (speed / MAXSPD));
      drawCar(0, 0, pw, CAR_COL[H.get().skin] || '#e8202a', true); ctx.restore();
    }
    const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right' };
    const keyUp = (e) => { const k = KEYS[e.key]; if (k) keys[k] = false; };
    addEventListener('keyup', keyUp);
    const key = (e) => {
      const k = KEYS[e.key];
      if (e.key === ' ' || e.key === 'p' || e.key === 'P') { if (started && !over) { if (L.on) { L.stop(); msg.hidden = false; msg.textContent = 'En pausa · P para seguir'; } else { msg.hidden = true; L.start(); } } return true; }
      if (!k || over) return false;
      keys[k] = true;
      if (!started) { started = true; msg.hidden = true; L.start(); }
      return true;
    };
    // tocando la pantalla: mitad izquierda/derecha para doblar (acelera solo)
    S.cv.addEventListener('pointerdown', (e) => { if (over) return; const r = S.cv.getBoundingClientRect(); keys.up = true; keys.left = e.clientX - r.left < r.width / 2; keys.right = !keys.left; if (!started) { started = true; msg.hidden = true; L.start(); } });
    addEventListener('pointerup', () => { keys.left = keys.right = false; });
    requestAnimationFrame(() => { S.fit(); newGame(); });
    return { el: root, tools: [btn('Nueva', newGame)], key, setSkin: () => draw(), help: 'Flechas: ↑ acelera, ↓ frena, ← → doblás. Esquivá los autos y pasá por los controles para sumar tiempo. P pausa.', hide: () => { if (L.on) { L.stop(); msg.hidden = false; msg.textContent = 'En pausa · P para seguir'; } keys = {}; } };
  }

  // =====================================================================
  // VUELO (avioneta: subí, bajá, juntá estrellas y nafta)
  // =====================================================================
  const PLANE_COL = { rojo: ['#c0392b', '#e74c3c'], amarillo: ['#d4a017', '#f5c518'], azul: ['#1f4fa8', '#3d7bf7'], verde: ['#1e7a3c', '#2fb35a'], plata: ['#8a929c', '#c3c9d1'], negro: ['#1d2026', '#3a3f48'] };
  function vuelo(H) {
    const root = h('div', { class: 'mg-move' });
    const hud = h('div', { class: 'mv-hud' });
    const msg = h('div', { class: 'sn-msg', text: 'Mantené ↑ (o tocá) para subir' });
    const S = stageCanvas(root, () => draw());
    root.append(hud, msg);
    const ctx = S.ctx;
    let plane, objs, clouds, x, spd, score, stars, fuel, over, started, up, t, groundSeed;
    const status = () => H.status([`${score} puntos`, `Mejor ${H.get().best || 0}`]);
    const ground = (wx) => { const k = wx / 260; return 0.13 + 0.07 * Math.sin(k + groundSeed) + 0.05 * Math.sin(k * 2.3 + 1.7 * groundSeed) + 0.06 * Math.max(0, Math.sin(k * 0.37 + groundSeed)) ** 6 * 3; };
    function newGame() {
      closeOver(root);
      groundSeed = Math.random() * 10;
      plane = { y: 0.45, vy: 0, a: 0 }; objs = []; clouds = [];
      for (let i = 0; i < 7; i++) clouds.push({ x: Math.random() * 1.6, y: 0.08 + Math.random() * 0.4, s: 0.6 + Math.random() * 0.8, p: 0.2 + Math.random() * 0.5 });
      x = 0; spd = 0.32; score = 0; stars = 0; fuel = 1; over = false; started = false; up = false; t = 0;
      msg.hidden = false; msg.textContent = 'Mantené ↑ o espacio (o tocá la pantalla) para subir';
      L.stop(); draw(); status(); hudPaint();
    }
    function hudPaint() {
      hud.innerHTML = `<span class="mv-big">${score}<small> puntos</small></span><span>★ ${stars}</span><span class="mv-fuel${fuel < 0.25 ? ' low' : ''}"><i style="width:${Math.max(0, fuel) * 100}%"></i></span>`;
    }
    function spawn() {
      const ax = 1.15;
      const r = Math.random();
      if (r < 0.42) objs.push({ k: 'star', x: ax, y: 0.15 + Math.random() * 0.55 });
      else if (r < 0.58) objs.push({ k: 'fuel', x: ax, y: 0.15 + Math.random() * 0.5 });
      else if (r < 0.82) objs.push({ k: 'bird', x: ax, y: 0.12 + Math.random() * 0.5, ph: Math.random() * 6, vy: (Math.random() - 0.5) * 0.08 });
      else objs.push({ k: 'balloon', x: ax, y: 0.2 + Math.random() * 0.45, c: ['#e74c3c', '#f1c40f', '#9b59b6', '#3498db'][rnd(4)] });
    }
    let spawnT = 0;
    function update(dt) {
      t += dt;
      spd = Math.min(0.75, 0.32 + t * 0.006);
      x += spd * dt;
      fuel -= dt * 0.028;
      const thrust = up && fuel > 0 ? -1.25 : 0;
      plane.vy += (thrust + 0.62) * dt;
      plane.vy = Math.max(-0.55, Math.min(0.6, plane.vy));
      plane.y += plane.vy * dt;
      plane.a = Math.max(-0.5, Math.min(0.6, plane.vy * 0.8));
      if (plane.y < 0.03) { plane.y = 0.03; plane.vy = 0; }
      score = Math.floor(x * 100) + stars * 50;
      spawnT -= dt; if (spawnT <= 0) { spawn(); spawnT = 0.55 + Math.random() * 0.7 - Math.min(0.3, t * 0.004); }
      for (const c of clouds) { c.x -= spd * dt * c.p; if (c.x < -0.3) { c.x = 1.3; c.y = 0.08 + Math.random() * 0.4; } }
      const px = 0.24, py = plane.y;
      for (const o of objs) {
        o.x -= spd * dt * (o.k === 'bird' ? 1.35 : 1);
        if (o.k === 'bird') { o.ph += dt * 10; o.y += o.vy * dt; }
        if (o.got) continue;
        const ar = S.W / S.H;
        const d = Math.hypot((o.x - px) * ar, o.y - py);
        if (o.k === 'star' && d < 0.06) { o.got = true; stars++; }
        else if (o.k === 'fuel' && d < 0.065) { o.got = true; fuel = Math.min(1, fuel + 0.35); }
        else if ((o.k === 'bird' && d < 0.045) || (o.k === 'balloon' && d < 0.06)) return crash();
      }
      objs = objs.filter(o => o.x > -0.2 && !(o.got && o.k !== 'bird'));
      const gy = 1 - ground(x * S.W + px * S.W);
      if (py > gy - 0.03) return crash();
    }
    const L = loop((dt) => { update(dt); draw(); hudPaint(); if (Math.random() < 0.1) status(); });
    function crash() {
      over = true; L.stop(); draw(true);
      const s = H.get(); const rec = score > (s.best || 0); if (rec) s.best = score; s.games = (s.games || 0) + 1; H.set(s); status(); hudPaint();
      if (rec) confetti(root);
      overlay(root, rec ? '¡Nuevo récord!' : (fuel <= 0 ? 'Te quedaste sin nafta' : '¡Choque!'), `${score} puntos · ${stars} estrellas`, [btn('Otra vez', newGame, 'primary')]);
    }
    function drawPlane(cx, cy, s, ang, boom) {
      const PC = PLANE_COL[H.get().skin] || PLANE_COL.rojo;
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang);
      ctx.fillStyle = PC[0]; ctx.beginPath(); ctx.ellipse(0, 0, s * 1.1, s * 0.32, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = PC[1]; ctx.beginPath(); ctx.moveTo(-s * 0.2, 0); ctx.lineTo(s * 0.35, 0); ctx.lineTo(s * 0.1, s * 0.75); ctx.lineTo(-s * 0.3, s * 0.75); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-s * 0.85, 0); ctx.lineTo(-s * 1.15, -s * 0.55); ctx.lineTo(-s * 0.95, -s * 0.55); ctx.lineTo(-s * 0.6, -s * 0.05); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#9fd3f5'; ctx.beginPath(); ctx.ellipse(s * 0.25, -s * 0.2, s * 0.28, s * 0.16, 0, Math.PI, 0); ctx.fill();
      ctx.fillStyle = '#333'; ctx.fillRect(s * 1.08, -s * 0.06, s * 0.1, s * 0.12);
      ctx.fillStyle = 'rgba(60,60,60,.7)'; const pr = Math.abs(Math.sin(performance.now() / 30)); ctx.fillRect(s * 1.17, -s * 0.5 * pr, s * 0.05, s * pr);
      if (boom) { ctx.fillStyle = 'rgba(255,140,40,.85)'; ctx.beginPath(); ctx.arc(s * 0.2, 0, s * 0.9, 0, Math.PI * 2); ctx.fill(); }
      ctx.restore();
    }
    function draw(boom) {
      if (!plane) return;
      const W = S.W, Hh = S.H;
      const dusk = Math.min(1, x / 25);
      const g = ctx.createLinearGradient(0, 0, 0, Hh);
      const mix = (a, b) => `rgb(${a.map((v, i) => Math.round(v + (b[i] - v) * dusk)).join(',')})`;
      g.addColorStop(0, mix([58, 135, 220], [40, 30, 90])); g.addColorStop(1, mix([180, 225, 250], [250, 150, 90]));
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, Hh);
      ctx.fillStyle = mix([255, 240, 160], [255, 200, 120]); ctx.beginPath(); ctx.arc(W * 0.82, Hh * (0.18 + dusk * 0.35), Math.min(W, Hh) * 0.07, 0, Math.PI * 2); ctx.fill();
      for (const c of clouds) {
        ctx.fillStyle = 'rgba(255,255,255,.85)';
        const cx = c.x * W, cy = c.y * Hh, r = 26 * c.s * Math.min(1.4, W / 900);
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.arc(cx + r, cy + r * 0.2, r * 0.8, 0, Math.PI * 2); ctx.arc(cx - r, cy + r * 0.25, r * 0.7, 0, Math.PI * 2); ctx.fill();
      }
      // montañas lejanas
      ctx.fillStyle = mix([120, 160, 200], [110, 80, 130]);
      ctx.beginPath(); ctx.moveTo(0, Hh);
      for (let i = 0; i <= W; i += 8) { const wx = x * W * 0.35 + i; ctx.lineTo(i, Hh * (0.62 - 0.12 * Math.abs(Math.sin(wx / 210)) - 0.06 * Math.sin(wx / 77))); }
      ctx.lineTo(W, Hh); ctx.fill();
      // suelo
      ctx.fillStyle = mix([86, 160, 70], [70, 110, 60]);
      ctx.beginPath(); ctx.moveTo(0, Hh);
      for (let i = 0; i <= W; i += 6) ctx.lineTo(i, Hh * (1 - ground(x * W + i)));
      ctx.lineTo(W, Hh); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,.08)';
      ctx.beginPath(); ctx.moveTo(0, Hh);
      for (let i = 0; i <= W; i += 6) ctx.lineTo(i, Hh * (1 - ground(x * W + i) + 0.04));
      ctx.lineTo(W, Hh); ctx.fill();
      const u = Math.min(W, Hh) / 22;
      for (const o of objs) {
        if (o.got) continue;
        const ox = o.x * W, oy = o.y * Hh;
        if (o.k === 'star') { ctx.fillStyle = '#ffd43b'; ctx.strokeStyle = '#e8a800'; ctx.lineWidth = 2; ctx.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? u * 0.42 : u * 0.95, a = -Math.PI / 2 + i * Math.PI / 5; ctx.lineTo(ox + Math.cos(a) * r, oy + Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.stroke(); }
        else if (o.k === 'fuel') { ctx.fillStyle = '#e67e22'; ctx.fillRect(ox - u * 0.6, oy - u * 0.8, u * 1.2, u * 1.6); ctx.fillStyle = '#fff'; ctx.font = `800 ${u * 0.8}px system-ui`; ctx.textAlign = 'center'; ctx.fillText('N', ox, oy + u * 0.3); ctx.fillStyle = '#c0601a'; ctx.fillRect(ox - u * 0.25, oy - u * 1.05, u * 0.5, u * 0.3); }
        else if (o.k === 'bird') { ctx.strokeStyle = '#2c3e50'; ctx.lineWidth = Math.max(2, u * 0.16); ctx.beginPath(); const f = Math.sin(o.ph) * u * 0.5; ctx.moveTo(ox - u, oy - f); ctx.quadraticCurveTo(ox - u * 0.4, oy - u * 0.2, ox, oy); ctx.quadraticCurveTo(ox + u * 0.4, oy - u * 0.2, ox + u, oy - f); ctx.stroke(); }
        else { ctx.fillStyle = o.c; ctx.beginPath(); ctx.ellipse(ox, oy, u * 0.95, u * 1.15, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(ox, oy + u * 1.15); ctx.lineTo(ox, oy + u * 2.2); ctx.stroke(); ctx.fillStyle = '#8d6e63'; ctx.fillRect(ox - u * 0.3, oy + u * 2.2, u * 0.6, u * 0.45); }
      }
      drawPlane(0.24 * W, plane.y * Hh, u * 1.25, plane.a, boom);
    }
    const key = (e) => {
      if (e.key === 'p' || e.key === 'P') { if (started && !over) { if (L.on) { L.stop(); msg.hidden = false; msg.textContent = 'En pausa · P para seguir'; } else { msg.hidden = true; L.start(); } } return true; }
      if (e.key === 'ArrowUp' || e.key === ' ' || e.key === 'w' || e.key === 'W') { if (over) return true; up = true; if (!started) { started = true; msg.hidden = true; L.start(); } return true; }
      return false;
    };
    const keyUp = (e) => { if (e.key === 'ArrowUp' || e.key === ' ' || e.key === 'w' || e.key === 'W') up = false; };
    addEventListener('keyup', keyUp);
    S.cv.addEventListener('pointerdown', () => { if (over) return; up = true; if (!started) { started = true; msg.hidden = true; L.start(); } });
    addEventListener('pointerup', () => { up = false; });
    requestAnimationFrame(() => { S.fit(); newGame(); });
    return { el: root, tools: [btn('Nueva', newGame)], key, setSkin: () => draw(), help: 'Mantené ↑ o espacio para subir; soltá para bajar. Juntá estrellas y bidones de nafta, esquivá pájaros, globos y el suelo. P pausa.', hide: () => { if (L.on) { L.stop(); msg.hidden = false; msg.textContent = 'En pausa · P para seguir'; } up = false; } };
  }

  window.BaseMini.GAMES.push(
    { id: 'carreras', n: 'Carreras', d: 'Manejá por la ruta, esquivá autos y ganale al reloj.', c: '#c0392b', create: carreras, skinLabel: 'Auto',
      skins: [['rojo', 'Rojo', '#e8202a'], ['azul', 'Azul', '#1f5fe0'], ['amarillo', 'Amarillo', '#f5c518'], ['verde', 'Verde', '#1e9e4a'], ['negro', 'Negro', '#23262d'], ['blanco', 'Blanco', '#f2f2f2'], ['rosa', 'Rosa', '#ff4fa3']],
      art: '<svg viewBox="0 0 64 64"><rect x="0" y="0" width="64" height="30" fill="#7cc4ef"/><rect x="0" y="30" width="64" height="34" fill="#4aa244"/><path d="M26 30h12l18 34H8z" fill="#5d6066"/><path d="M31 30h2l2 34h-6z" fill="#f2f2f2"/><path d="M18 52h28l3 8H15z" fill="#e8202a"/><rect x="22" y="48" width="20" height="5" rx="1.5" fill="#1d2633"/><rect x="16" y="56" width="6" height="2" fill="#ffd166"/><rect x="42" y="56" width="6" height="2" fill="#ffd166"/></svg>',
      best: (s) => s.best ? `Mejor: ${(s.best / 1000).toFixed(1)} km` : 'Nunca jugaste' },
    { id: 'vuelo', n: 'Vuelo', d: 'Pilotá la avioneta, juntá estrellas y no te quedes sin nafta.', c: '#2e86de', create: vuelo, skinLabel: 'Avioneta',
      skins: [['rojo', 'Roja', '#e74c3c'], ['amarillo', 'Amarilla', '#f5c518'], ['azul', 'Azul', '#3d7bf7'], ['verde', 'Verde', '#2fb35a'], ['plata', 'Plateada', '#c3c9d1'], ['negro', 'Negra', '#3a3f48']],
      art: '<svg viewBox="0 0 64 64"><rect width="64" height="64" fill="#8fd0f5"/><circle cx="50" cy="14" r="6" fill="#fff3a0"/><path d="M0 52c10-6 18-6 26-2s18 4 38-4v18H0z" fill="#56a046"/><g transform="rotate(-12 30 30)"><ellipse cx="30" cy="30" rx="14" ry="4.5" fill="#c0392b"/><path d="M27 30h7l-3 10h-6z" fill="#e74c3c"/><path d="M18 30l-4-7h3l5 6z" fill="#e74c3c"/><path d="M31 27a4 2.5 0 0 1 7 0z" fill="#9fd3f5"/></g><path d="M44 18l1.5 3 3.3.5-2.4 2.3.6 3.3-3-1.6-3 1.6.6-3.3-2.4-2.3 3.3-.5z" fill="#ffd43b"/></svg>',
      best: (s) => s.best ? `Mejor: ${s.best} puntos` : 'Nunca jugaste' }
  );
})();
