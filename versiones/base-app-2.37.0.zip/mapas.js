// Mapas para el juego "Manejá por tu barrio": calles reales de OpenStreetMap.
// Se buscan con Nominatim, se bajan con Overpass, se pasan a un formato chico (metros) y se guardan en la compu.
'use strict';
const path = require('path');
const fs = require('fs');

const ROAD_KIND = {
  motorway: 0, trunk: 0, motorway_link: 1, trunk_link: 1,
  primary: 2, primary_link: 2, secondary: 3, secondary_link: 3, tertiary: 4, tertiary_link: 4,
  unclassified: 5, residential: 5, living_street: 6, service: 7, pedestrian: 8
};
// ancho de calzada en metros según el tipo
const ROAD_W = [22, 9, 15, 12, 10, 8, 6, 5, 6];

function overpassQuery(lat, lon, r, rb) {
  const a = `(around:${r},${lat},${lon})`, b = `(around:${rb},${lat},${lon})`;
  return `[out:json][timeout:170][maxsize:268435456];
(
  way["highway"~"^(${Object.keys(ROAD_KIND).join('|')})$"]${a};
  node["highway"="traffic_signals"]${a};
  node["amenity"="fuel"]${a};
  way["amenity"="fuel"]${a};
  way["leisure"~"^(park|garden|playground|pitch|golf_course)$"]${a};
  way["landuse"~"^(grass|forest|recreation_ground|cemetery|meadow|village_green|railway)$"]${a};
  way["natural"~"^(water|wood|scrub)$"]${a};
  way["waterway"~"^(river|stream|canal)$"]${a};
  way["railway"="rail"]${a};
  way["building"]${b};
);
out body geom qt;`;
}

// Pasa la respuesta de Overpass al formato del juego (coordenadas en medios metros, relativas al centro)
function compact(osm, center, meta) {
  const [lat0, lon0] = center;
  const kx = 111320 * Math.cos(lat0 * Math.PI / 180), ky = 110540;
  const P = (lat, lon) => [Math.round((lon - lon0) * kx * 2), Math.round(-(lat - lat0) * ky * 2)];
  const nodeIdx = new Map();
  let nodeCount = 0;
  const idx = (id) => { let i = nodeIdx.get(id); if (i == null) { i = nodeCount++; nodeIdx.set(id, i); } return i; };
  const out = { v: 1, name: meta.name || '', center, r: meta.r, at: Date.now(), roads: [], signals: [], fuel: [], parks: [], water: [], rivers: [], rails: [], buildings: [] };
  const flat = (geom) => { const a = []; for (const g of geom) { const [x, y] = P(g.lat, g.lon); a.push(x, y); } return a; };
  for (const el of osm.elements || []) {
    const t = el.tags || {};
    if (el.type === 'node') { if (t.highway === 'traffic_signals') out.signals.push(P(el.lat, el.lon)); else if (t.amenity === 'fuel') out.fuel.push(P(el.lat, el.lon)); continue; }
    if (el.type === 'way' && t.amenity === 'fuel' && el.geometry && el.geometry.length) { let la = 0, lo = 0; for (const g of el.geometry) { la += g.lat; lo += g.lon; } out.fuel.push(P(la / el.geometry.length, lo / el.geometry.length)); continue; }
    if (el.type !== 'way' || !el.geometry || el.geometry.length < 2) continue;
    if (t.highway && ROAD_KIND[t.highway] != null) {
      if (t.area === 'yes') continue;
      const k = ROAD_KIND[t.highway];
      let w = ROAD_W[k];
      const lanes = parseInt(t.lanes, 10);
      if (lanes > 0 && lanes < 9) w = Math.max(w * 0.7, lanes * 3.4 + 1);
      const ow = t.oneway === 'yes' || t.oneway === '1' || t.junction === 'roundabout' || t.highway === 'motorway' ? 1 : t.oneway === '-1' ? -1 : 0;
      if (ow === 0 && k <= 4 && !(lanes > 0)) w = Math.max(w, 11);
      out.roads.push({ n: t.name || '', k, w: Math.round(w * 2) / 2, o: ow, p: flat(el.geometry), nd: (el.nodes || []).map(idx) });
    } else if (t.building) {
      if (el.geometry.length >= 4) out.buildings.push(flat(el.geometry));
    } else if (t.waterway) out.rivers.push(flat(el.geometry));
    else if (t.railway === 'rail') out.rails.push(flat(el.geometry));
    else if (t.natural === 'water') out.water.push(flat(el.geometry));
    else if (t.landuse === 'railway') continue;
    else out.parks.push(flat(el.geometry));
  }
  out.nodes = nodeCount;
  return out;
}

function create({ fetch, userDir, log }) {
  const dir = () => { const d = path.join(userDir(), 'mapas'); fs.mkdirSync(d, { recursive: true }); return d; };
  const UA = { 'User-Agent': 'Base-escritorio/2 (juego de manejo personal)', 'Accept-Language': 'es' };
  async function search(q) {
    q = String(q || '').trim().slice(0, 160);
    if (q.length < 3) return [];
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&addressdetails=0&q=' + encodeURIComponent(q), { headers: UA });
    if (!r.ok) throw new Error('El buscador de mapas no respondió (' + r.status + ')');
    const j = await r.json();
    return j.map(x => ({ name: x.display_name, lat: +x.lat, lon: +x.lon }));
  }
  async function download({ lat, lon, r, name }, progress) {
    lat = +lat; lon = +lon; r = Math.max(800, Math.min(5000, +r || 3000));
    if (!isFinite(lat) || !isFinite(lon)) throw new Error('Ubicación inválida');
    const rb = Math.min(r, 1800); // edificios solo cerca del centro (si no, el mapa pesa demasiado)
    const q = overpassQuery(lat.toFixed(6), lon.toFixed(6), Math.round(r), Math.round(rb));
    const servers = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter'];
    let osm = null, lastErr = null;
    for (const s of servers) {
      try {
        progress && progress('Bajando las calles de tu zona… (puede tardar un minuto)');
        const res = await fetch(s, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/x-www-form-urlencoded' }, UA), body: 'data=' + encodeURIComponent(q) });
        if (!res.ok) throw new Error('El servidor de mapas respondió ' + res.status);
        progress && progress('Armando el mapa…');
        osm = await res.json();
        break;
      } catch (e) { lastErr = e; log && log('Mapa: ' + s + ' falló: ' + e.message); }
    }
    if (!osm) throw new Error((lastErr && lastErr.message) || 'No pude bajar el mapa');
    const m = compact(osm, [lat, lon], { name, r });
    if (m.roads.length < 5) throw new Error('No encontré calles en esa zona');
    const id = 'm' + Date.now().toString(36);
    m.id = id;
    fs.writeFileSync(path.join(dir(), id + '.json'), JSON.stringify(m));
    log && log(`Mapa guardado: ${m.roads.length} calles, ${m.signals.length} semáforos, ${m.buildings.length} edificios`);
    return { id, name: m.name, roads: m.roads.length, signals: m.signals.length };
  }
  function list() {
    const out = [];
    for (const f of fs.readdirSync(dir())) {
      if (!/^m[a-z0-9]+\.json$/.test(f)) continue;
      try {
        const st = fs.statSync(path.join(dir(), f));
        // el nombre y la fecha están al principio del archivo, no hace falta leerlo entero
        const fd = fs.openSync(path.join(dir(), f), 'r'); const buf = Buffer.alloc(700); const n = fs.readSync(fd, buf, 0, 700, 0); fs.closeSync(fd); const head = buf.slice(0, n).toString('utf8');
        const name = (/"name":"((?:[^"\\]|\\.)*)"/.exec(head) || [])[1] || 'Mapa';
        out.push({ id: f.slice(0, -5), name: JSON.parse('"' + name + '"'), size: st.size, at: st.mtimeMs });
      } catch {}
    }
    return out.sort((a, b) => b.at - a.at);
  }
  const okId = (id) => /^m[a-z0-9]{4,20}$/.test(String(id));
  function get(id) { if (!okId(id)) return null; try { return JSON.parse(fs.readFileSync(path.join(dir(), id + '.json'), 'utf8')); } catch { return null; } }
  function remove(id) { if (!okId(id)) return false; try { fs.unlinkSync(path.join(dir(), id + '.json')); return true; } catch { return false; } }
  return { search, download, list, get, remove };
}

module.exports = { create, compact, overpassQuery };
