// Puente de la ventanita de avisos flotantes
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('avisos', {
  onAdd: (cb) => ipcRenderer.on('fnotif:add', (_e, n) => cb(n)),
  click: (id) => ipcRenderer.send('fnotif:click', id),
  size: (h) => ipcRenderer.send('fnotif:size', h)
});
