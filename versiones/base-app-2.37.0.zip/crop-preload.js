// Ventanita para recortar una captura de pantalla
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('crop', {
  onImg: (cb) => ipcRenderer.on('crop:img', (_e, src) => cb(src)),
  done: (r) => ipcRenderer.invoke('crop:done', r)
});
