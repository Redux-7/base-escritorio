// Lamparitas Smart Life / Tuya por la red de casa (sin pasar por internet).
// Protocolos 3.1 a 3.5. Las claves (local key) se consiguen una sola vez desde la nube de Tuya.
'use strict';
const net = require('net');
const dgram = require('dgram');
const crypto = require('crypto');
const https = require('https');

const CMD = { NEG_START: 3, NEG_RESP: 4, NEG_FINISH: 5, CONTROL: 7, STATUS: 8, HEART_BEAT: 9, DP_QUERY: 10, CONTROL_NEW: 13, DP_QUERY_NEW: 16 };
const NO_HEADER = new Set([CMD.DP_QUERY, CMD.DP_QUERY_NEW, 18, CMD.HEART_BEAT, CMD.NEG_START, CMD.NEG_RESP, CMD.NEG_FINISH, 64]);
const UDP_KEY = crypto.createHash('md5').update('yGAdlopoPVldABfn').digest();

// ---------- utilidades ----------
const CRC_TABLE = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
function crc32(buf) { let c = -1; for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ -1) >>> 0; }
function ecbEnc(key, data, pad = true) { const c = crypto.createCipheriv('aes-128-ecb', key, null); c.setAutoPadding(pad); return Buffer.concat([c.update(data), c.final()]); }
function ecbDec(key, data) { const c = crypto.createDecipheriv('aes-128-ecb', key, null); c.setAutoPadding(true); return Buffer.concat([c.update(data), c.final()]); }
function gcmEnc(key, iv, data, aad) { const c = crypto.createCipheriv('aes-128-gcm', key, iv); if (aad) c.setAAD(aad); const ct = Buffer.concat([c.update(data), c.final()]); return { ct, tag: c.getAuthTag() }; }
function gcmDec(key, iv, data, tag, aad) { const c = crypto.createDecipheriv('aes-128-gcm', key, iv); if (aad) c.setAAD(aad); c.setAuthTag(tag); return Buffer.concat([c.update(data), c.final()]); }
const hmac = (key, data) => crypto.createHmac('sha256', key).update(data).digest();
const keyBuf = (k) => { const b = Buffer.from(String(k || ''), 'latin1'); if (b.length !== 16) throw new Error('La clave local tiene que tener 16 caracteres'); return b; };
const verHeader = (ver) => Buffer.concat([Buffer.from(ver), Buffer.alloc(12)]);

// ---------- armado y lectura de mensajes ----------
function pack55(seq, cmd, payload, key /* hmac (3.4) o null (crc) */) {
  const endLen = key ? 36 : 8;
  const head = Buffer.alloc(16);
  head.writeUInt32BE(0x000055AA, 0); head.writeUInt32BE(seq >>> 0, 4); head.writeUInt32BE(cmd, 8); head.writeUInt32BE(payload.length + endLen, 12);
  const body = Buffer.concat([head, payload]);
  const check = key ? hmac(key, body) : (() => { const b = Buffer.alloc(4); b.writeUInt32BE(crc32(body), 0); return b; })();
  const tail = Buffer.alloc(4); tail.writeUInt32BE(0x0000AA55, 0);
  return Buffer.concat([body, check, tail]);
}
function pack66(seq, cmd, payload, key) {
  const head = Buffer.alloc(18);
  head.writeUInt32BE(0x00006699, 0); head.writeUInt16BE(0, 4); head.writeUInt32BE(seq >>> 0, 6); head.writeUInt32BE(cmd, 10); head.writeUInt32BE(payload.length + 28, 14);
  const iv = crypto.randomBytes(12);
  const { ct, tag } = gcmEnc(key, iv, payload, head.subarray(4));
  const tail = Buffer.alloc(4); tail.writeUInt32BE(0x00009966, 0);
  return Buffer.concat([head, iv, ct, tag, tail]);
}
// abre un mensaje 3.5 (se descifra recién al procesarlo, por si cambió la clave de sesión)
function open66(fr, key) {
  const len = fr.readUInt32BE(14);
  try { return gcmDec(key, fr.subarray(18, 30), fr.subarray(30, 18 + len - 16), fr.subarray(18 + len - 16, 18 + len), fr.subarray(4, 18)); } catch { return null; }
}
// saca de buf todos los mensajes completos; devuelve { msgs, rest }
function unpackAll(buf) {
  const msgs = [];
  for (;;) {
    const i55 = buf.indexOf(Buffer.from([0, 0, 0x55, 0xAA])), i66 = buf.indexOf(Buffer.from([0, 0, 0x66, 0x99]));
    const cands = [i55, i66].filter(i => i >= 0);
    if (!cands.length) return { msgs, rest: Buffer.alloc(0) };
    const at = Math.min(...cands);
    if (at > 0) buf = buf.subarray(at);
    if (at === i66 && i66 >= 0 && (i55 < 0 || i66 < i55)) {
      if (buf.length < 18) return { msgs, rest: buf };
      const len = buf.readUInt32BE(14), total = 18 + len + 4;
      if (buf.length < total) return { msgs, rest: buf };
      const fr = buf.subarray(0, total); buf = buf.subarray(total);
      msgs.push({ seq: fr.readUInt32BE(6), cmd: fr.readUInt32BE(10), raw: fr, len, v35: true });
    } else {
      if (buf.length < 16) return { msgs, rest: buf };
      const len = buf.readUInt32BE(12), total = 16 + len;
      if (len > 0x10000) { buf = buf.subarray(4); continue; }
      if (buf.length < total) return { msgs, rest: buf };
      const fr = buf.subarray(0, total); buf = buf.subarray(total);
      msgs.push({ seq: fr.readUInt32BE(4), cmd: fr.readUInt32BE(8), raw: fr, len });
    }
  }
}

// ---------- una lamparita ----------
class Device {
  constructor(o) {
    this.id = String(o.id); this.key = keyBuf(o.key); this.ip = o.ip; this.ver = String(o.ver || '3.3');
    this.sock = null; this.buf = Buffer.alloc(0); this.seq = 1; this.sess = null; this.waiters = []; this.idle = null; this.dps = {}; this.onDps = null;
  }
  get v() { return parseFloat(this.ver) || 3.3; }
  log() {}
  close() { clearTimeout(this.idle); clearInterval(this.hb); try { this.sock && this.sock.destroy(); } catch {} this.sock = null; this.sess = null; for (const w of this.waiters.splice(0)) w.reject(new Error('Se cortó la conexión')); }
  touch() { clearTimeout(this.idle); this.idle = setTimeout(() => this.close(), 25000); }
  connect() {
    if (this.sock && this.ready) return this.ready;
    this.close();
    this.ready = new Promise((resolve, reject) => {
      const s = net.createConnection({ host: this.ip, port: 6668 });
      this.sock = s;
      const to = setTimeout(() => { s.destroy(); reject(new Error('La lamparita no respondió (¿está prendida y en la misma red?)')); }, 5000);
      s.on('connect', async () => {
        clearTimeout(to);
        s.setNoDelay(true);
        try {
          if (this.v >= 3.4) await this.negotiate();
          this.hb = setInterval(() => { this.send(CMD.HEART_BEAT, Buffer.from('{}')).catch(() => {}); }, 10000);
          resolve(true);
        } catch (e) { this.close(); reject(e); }
      });
      s.on('data', (d) => this.onData(d));
      s.on('error', (e) => { clearTimeout(to); const err = new Error(e.code === 'ECONNREFUSED' ? 'La lamparita rechazó la conexión (puede que la app Smart Life la esté usando)' : 'No pude conectarme a la lamparita (' + (e.code || e.message) + ')'); for (const w of this.waiters.splice(0)) w.reject(err); reject(err); this.sock = null; this.ready = null; });
      s.on('close', () => { this.sock = null; this.ready = null; this.sess = null; clearInterval(this.hb); });
    });
    this.ready.catch(() => { this.ready = null; });
    return this.ready;
  }
  curKey() { return this.sess || this.key; }
  frame(cmd, payload) {
    const seq = this.seq++;
    if (this.v >= 3.5) return pack66(seq, cmd, payload, this.curKey());
    if (this.v >= 3.4) return pack55(seq, cmd, ecbEnc(this.curKey(), payload), this.curKey());
    return pack55(seq, cmd, payload, null);
  }
  writeRaw(cmd, payload) { if (!this.sock) throw new Error('Sin conexión'); this.sock.write(this.frame(cmd, payload)); }
  waitFor(test, ms = 4000) {
    const p = new Promise((resolve, reject) => {
      const w = { test, resolve: (m) => { clearTimeout(w.t); resolve(m); }, reject: (e) => { clearTimeout(w.t); reject(e); } };
      w.t = setTimeout(() => { const i = this.waiters.indexOf(w); if (i >= 0) this.waiters.splice(i, 1); reject(new Error('La lamparita no contestó')); }, ms);
      this.waiters.push(w);
    });
    p.catch(() => {}); // si nadie la espera (porque falló el envío) no queda un error suelto
    return p;
  }
  async negotiate() {
    const local = crypto.randomBytes(8).toString('hex').slice(0, 16); // 16 caracteres
    const ln = Buffer.from(local, 'latin1');
    this.sess = null;
    const p = this.waitFor(m => m.cmd === CMD.NEG_RESP, 5000);
    this.writeRaw(CMD.NEG_START, ln);
    const m = await p;
    const pl = m.data;
    if (!pl || pl.length < 48) throw new Error('La lamparita no aceptó la clave (revisá la clave local y la versión)');
    const remote = pl.subarray(pl.length - 48, pl.length - 32), mac = pl.subarray(pl.length - 32);
    if (!hmac(this.key, ln).equals(mac)) throw new Error('La clave local no coincide');
    this.writeRaw(CMD.NEG_FINISH, hmac(this.key, remote));
    const x = Buffer.alloc(16); for (let i = 0; i < 16; i++) x[i] = ln[i] ^ remote[i];
    this.sess = this.v >= 3.5 ? gcmEnc(this.key, ln.subarray(0, 12), x).ct : ecbEnc(this.key, x, false);
  }
  onData(d) {
    this.buf = Buffer.concat([this.buf, d]);
    const { msgs, rest } = unpackAll(this.buf);
    this.buf = rest;
    for (const m of msgs) {
      m.data = this.decode(m);
      const txt = m.data && m.cmd !== CMD.NEG_RESP ? m.data.toString('utf8') : '';
      if (txt && txt.trim().startsWith('{')) {
        try { const j = JSON.parse(txt.slice(txt.indexOf('{'))); m.json = j; const dps = j.dps || (j.data && j.data.dps); if (dps) { Object.assign(this.dps, dps); if (this.onDps) this.onDps(this.dps); } } catch {}
      } else if (txt) m.text = txt;
      const w = this.waiters.find(x => x.test(m));
      if (w) { this.waiters.splice(this.waiters.indexOf(w), 1); w.resolve(m); }
    }
  }
  decode(m) {
    try {
      let pl;
      if (m.v35) {
        pl = open66(m.raw, this.curKey()); if (!pl) return null;
        // los mensajes del dispositivo traen un código de 4 bytes adelante
        if (pl.length >= 4 && (pl.readUInt32BE(0) & 0xFFFFFF00) === 0 && pl[0] === 0) pl = pl.subarray(4);
      } else {
        const fr = m.raw, endLen = this.v >= 3.4 ? 36 : 8;
        pl = fr.subarray(16, 16 + m.len - endLen);
        if (pl.length >= 4 && (pl.readUInt32BE(0) & 0xFFFFFF00) === 0) pl = pl.subarray(4);
        if (!pl.length) return Buffer.alloc(0);
        if (this.v >= 3.4) pl = ecbDec(this.curKey(), pl);
        else if (this.v >= 3.2) {
          if (pl.subarray(0, 3).toString() === this.ver.slice(0, 3) || /^3\.\d/.test(pl.subarray(0, 3).toString())) pl = pl.subarray(15);
          if (pl.length && pl.length % 16 === 0) pl = ecbDec(this.key, pl);
        } else if (pl.subarray(0, 3).toString() === '3.1') {
          pl = Buffer.from(pl.subarray(19).toString(), 'base64'); pl = ecbDec(this.key, pl);
        }
      }
      if (pl.length >= 15 && /^3\.\d/.test(pl.subarray(0, 3).toString()) && pl[3] === 0) pl = pl.subarray(15);
      return pl;
    } catch { return null; }
  }
  async send(cmd, payloadBuf) {
    await this.connect();
    let pl = payloadBuf;
    if (this.v >= 3.4) { if (!NO_HEADER.has(cmd)) pl = Buffer.concat([verHeader(this.ver), pl]); }
    else if (this.v >= 3.2) { pl = ecbEnc(this.key, pl); if (!NO_HEADER.has(cmd)) pl = Buffer.concat([verHeader(this.ver), pl]); }
    else if (cmd === CMD.CONTROL) { // 3.1
      const b64 = ecbEnc(this.key, pl).toString('base64');
      const md5 = crypto.createHash('md5').update('data=' + b64 + '||lpv=3.1||' + this.key.toString('latin1')).digest('hex').slice(8, 24);
      pl = Buffer.from('3.1' + md5 + b64);
    }
    this.touch();
    this.writeRaw(cmd, pl);
  }
  async status() {
    await this.connect();
    const t = String(Math.floor(Date.now() / 1000));
    if (this.v >= 3.4) {
      const p = this.waitFor(m => m.json && (m.json.dps || (m.json.data && m.json.data.dps)), 4000);
      await this.send(CMD.DP_QUERY_NEW, Buffer.from('{}'));
      await p;
    } else {
      const p = this.waitFor(m => (m.json && m.json.dps) || (m.text && /unvalid/i.test(m.text)), 4000);
      await this.send(CMD.DP_QUERY, Buffer.from(JSON.stringify({ gwId: this.id, devId: this.id, uid: this.id, t })));
      const m = await p;
      if (!m.json) { // algunos equipos piden la consulta como un "control" vacío
        const p2 = this.waitFor(x => x.json && x.json.dps, 4000);
        const dps = {}; for (const k of ['1', '2', '3', '4', '5', '20', '21', '22', '23', '24']) dps[k] = null;
        await this.send(CMD.CONTROL_NEW, Buffer.from(JSON.stringify({ devId: this.id, uid: this.id, t, dps })));
        await p2;
      }
    }
    return Object.assign({}, this.dps);
  }
  async set(dps) {
    await this.connect();
    const t = Math.floor(Date.now() / 1000);
    const body = this.v >= 3.4 ? { protocol: 5, t, data: { dps } } : { devId: this.id, uid: this.id, t: String(t), dps };
    // esperamos el aviso de estado que manda la lamparita después de cambiar (si no llega, seguimos igual)
    const p = this.waitFor(m => m.cmd === CMD.STATUS && m.json, 1500).catch(() => null);
    await this.send(this.v >= 3.4 ? CMD.CONTROL_NEW : CMD.CONTROL, Buffer.from(JSON.stringify(body)));
    await p;
    Object.assign(this.dps, dps);
    return Object.assign({}, this.dps);
  }
}

// ---------- varias lamparitas, conexiones reutilizadas ----------
const POOL = new Map();
function dev(o) {
  const k = o.id + '|' + o.ip + '|' + o.ver + '|' + o.key;
  let d = POOL.get(o.id);
  if (d && d._k !== k) { d.close(); d = null; }
  if (!d) { d = new Device(o); d._k = k; POOL.set(o.id, d); }
  return d;
}
async function withRetry(o, fn) {
  const d = dev(o);
  try { return await fn(d); } catch (e) { d.close(); return await fn(dev(o)); }
}
async function status(o) { return withRetry(o, d => d.status()); }
async function set(o, dps) { return withRetry(o, d => d.set(dps)); }
// prueba las versiones hasta que una contesta
async function detect(o) {
  const vers = o.ver && o.ver !== 'auto' ? [o.ver] : ['3.3', '3.4', '3.5', '3.1'];
  let last;
  for (const ver of vers) {
    const d = new Device(Object.assign({}, o, { ver }));
    try { const dps = await d.status(); d.close(); return { ver, dps }; } catch (e) { last = e; d.close(); }
  }
  throw last || new Error('No pude hablar con la lamparita');
}
function closeAll() { for (const d of POOL.values()) d.close(); POOL.clear(); }

// ---------- buscar lamparitas en la red (avisos UDP) ----------
function scan(ms = 6000) {
  return new Promise((resolve) => {
    const found = new Map();
    const socks = [];
    const add = (j, ip) => {
      if (!j || !(j.gwId || j.devId)) return;
      const id = j.gwId || j.devId;
      found.set(id, { id, ip: j.ip || ip, ver: String(j.version || '3.3'), product: j.productKey || '' });
    };
    for (const port of [6666, 6667, 7000]) {
      const s = dgram.createSocket({ type: 'udp4', reuseAddr: true });
      s.on('error', () => { try { s.close(); } catch {} });
      s.on('message', (msg, rinfo) => {
        try {
          if (msg.readUInt32BE(0) === 0x00006699) {
            const len = msg.readUInt32BE(14);
            const iv = msg.subarray(18, 30), ct = msg.subarray(30, 18 + len - 16), tag = msg.subarray(18 + len - 16, 18 + len);
            let pl = gcmDec(UDP_KEY, iv, ct, tag, msg.subarray(4, 18));
            if (pl[0] === 0) pl = pl.subarray(4);
            add(JSON.parse(pl.toString().slice(pl.toString().indexOf('{'))), rinfo.address);
          } else {
            const len = msg.readUInt32BE(12);
            let pl = msg.subarray(16, 16 + len - 8);
            if ((pl.readUInt32BE(0) & 0xFFFFFF00) === 0) pl = pl.subarray(4);
            let txt;
            try { txt = ecbDec(UDP_KEY, pl).toString(); } catch { txt = pl.toString(); }
            add(JSON.parse(txt.slice(txt.indexOf('{'))), rinfo.address);
          }
        } catch {}
      });
      try { s.bind(port); socks.push(s); } catch {}
    }
    setTimeout(() => { for (const s of socks) { try { s.close(); } catch {} } resolve([...found.values()]); }, ms);
  });
}

// ---------- nube de Tuya: solo para conseguir las claves una vez ----------
const REGIONS = [
  { id: 'us', n: 'América (oeste)', host: 'openapi.tuyaus.com' },
  { id: 'ue', n: 'América (este)', host: 'openapi-ueaz.tuyaus.com' },
  { id: 'eu', n: 'Europa central', host: 'openapi.tuyaeu.com' },
  { id: 'we', n: 'Europa (oeste)', host: 'openapi-weaz.tuyaeu.com' },
  { id: 'in', n: 'India', host: 'openapi.tuyain.com' },
  { id: 'cn', n: 'China', host: 'openapi.tuyacn.com' }
];
function cloudReq(host, method, pathq, cid, secret, token) {
  return new Promise((resolve, reject) => {
    const t = String(Date.now()), nonce = '';
    const bodyHash = crypto.createHash('sha256').update('').digest('hex');
    const strToSign = [method, bodyHash, '', pathq].join('\n');
    const sign = crypto.createHmac('sha256', secret).update(cid + (token || '') + t + nonce + strToSign).digest('hex').toUpperCase();
    const headers = { client_id: cid, sign, t, sign_method: 'HMAC-SHA256', nonce };
    if (token) headers.access_token = token;
    const rq = https.request({ host, path: pathq, method, headers, timeout: 10000 }, (res) => {
      let b = ''; res.setEncoding('utf8'); res.on('data', c => { b += c; });
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch { reject(new Error('Respuesta rara de Tuya')); } });
    });
    rq.on('timeout', () => rq.destroy(new Error('Tuya no respondió')));
    rq.on('error', reject);
    rq.end();
  });
}
const LIGHT_CATS = new Set(['dj', 'dd', 'fwd', 'xdd', 'dc', 'fwl', 'tyndj', 'gyd', 'tgq', 'tgkg', 'sxd']);
async function cloudDevices(cid, secret, region) {
  cid = String(cid || '').trim(); secret = String(secret || '').trim();
  if (!cid || !secret) throw new Error('Faltan el Access ID y el Access Secret');
  const regs = region && region !== 'auto' ? REGIONS.filter(r => r.id === region) : REGIONS;
  let lastErr = 'No encontré dispositivos';
  for (const r of regs) {
    let tok;
    try { tok = await cloudReq(r.host, 'GET', '/v1.0/token?grant_type=1', cid, secret); } catch (e) { lastErr = e.message; continue; }
    if (!tok.success) { lastErr = tok.code === 1004 ? 'El Access Secret no es correcto' : (tok.msg || 'Tuya rechazó las claves'); if (tok.code === 1004 || tok.code === 1106) continue; continue; }
    const token = tok.result.access_token;
    const list = [];
    let lastRow = '';
    for (let page = 0; page < 10; page++) {
      // la firma exige los parámetros en orden alfabético
      const q = '/v1.0/iot-01/associated-users/devices?' + (lastRow ? 'last_row_key=' + encodeURIComponent(lastRow) + '&' : '') + 'size=100';
      let res; try { res = await cloudReq(r.host, 'GET', q, cid, secret, token); } catch (e) { lastErr = e.message; break; }
      if (!res.success) { lastErr = res.code === 1106 || res.code === 28841105 ? 'Falta vincular tu cuenta de Smart Life al proyecto (paso 3)' : (res.msg || 'Error de Tuya'); break; }
      const rr = res.result || {};
      list.push(...(rr.devices || []));
      if (!rr.has_more || !rr.last_row_key) break;
      lastRow = rr.last_row_key;
    }
    if (list.length) {
      return {
        region: r.id,
        devices: list.map(d => ({ id: d.id, name: d.name, key: d.local_key, cat: d.category, product: d.product_name, online: !!d.online, light: LIGHT_CATS.has(d.category), icon: d.icon ? 'https://images.tuyaus.com/' + d.icon : '' }))
      };
    }
  }
  throw new Error(lastErr);
}

// ---------- traducir entre "lo que entiende la lamparita" y algo simple ----------
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
function hsv2hex(h, s, v) {
  s = clamp(s, 0, 1); v = clamp(v, 0, 1);
  const f = (n) => { const k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
  return '#' + [f(5), f(3), f(1)].map(x => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
}
function hex2hsv(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return { h: 0, s: 0, v: 1 };
  const n = parseInt(m[1], 16), r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0;
  if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  h = Math.round(h * 60); if (h < 0) h += 360;
  return { h, s: mx ? d / mx : 0, v: mx };
}
const hx = (n, w) => Math.round(n).toString(16).padStart(w, '0');
function lampSchema(dps) { return dps && ('20' in dps || '21' in dps || '22' in dps) ? 'v2' : 'v1'; }
function lampState(dps, schema) {
  schema = schema || lampSchema(dps);
  const st = { schema, on: false, mode: 'white', bright: 100, temp: 50, color: '#ffffff', hasColor: false, hasTemp: false };
  if (schema === 'v2') {
    st.on = !!dps['20']; st.mode = dps['21'] || 'white';
    if (dps['22'] != null) st.bright = Math.round(clamp((dps['22'] - 10) / 990 * 100, 1, 100));
    if (dps['23'] != null) { st.temp = Math.round(dps['23'] / 10); st.hasTemp = true; }
    if (typeof dps['24'] === 'string' && dps['24'].length >= 12) {
      st.hasColor = true;
      const h = parseInt(dps['24'].slice(0, 4), 16), sa = parseInt(dps['24'].slice(4, 8), 16) / 1000, v = parseInt(dps['24'].slice(8, 12), 16) / 1000;
      st.color = hsv2hex(h, sa, 1);
      if (st.mode === 'colour') st.bright = Math.round(clamp(v * 100, 1, 100));
    }
  } else {
    st.on = !!dps['1']; st.mode = dps['2'] || 'white';
    if (dps['3'] != null) st.bright = Math.round(clamp((dps['3'] - 25) / 230 * 100, 1, 100));
    if (dps['4'] != null) { st.temp = Math.round(dps['4'] / 2.55); st.hasTemp = true; }
    if (typeof dps['5'] === 'string' && dps['5'].length >= 6) {
      st.hasColor = true; st.color = '#' + dps['5'].slice(0, 6);
      if (st.mode === 'colour' && dps['5'].length >= 14) st.bright = Math.round(clamp(parseInt(dps['5'].slice(12, 14), 16) / 255 * 100, 1, 100));
    }
  }
  if (st.mode !== 'colour' && st.mode !== 'white') st.mode = st.mode === 'colour' ? 'colour' : st.mode;
  return st;
}
// a = { on, bright (1-100), temp (0-100), color '#rrggbb' } -> dps
function lampDps(st, a) {
  const v2 = st.schema === 'v2', d = {};
  if (a.on !== undefined) d[v2 ? '20' : '1'] = !!a.on;
  const colourOut = (hex, bright) => {
    const c = hex2hsv(hex), v = clamp(bright, 1, 100) / 100;
    if (v2) { d['21'] = 'colour'; d['24'] = hx(c.h, 4) + hx(c.s * 1000, 4) + hx(v * 1000, 4); }
    else { d['2'] = 'colour'; d['5'] = hsv2hex(c.h, c.s, v).slice(1) + hx(c.h, 4) + hx(c.s * 255, 2) + hx(v * 255, 2); }
  };
  if (a.color) { colourOut(a.color, a.bright != null ? a.bright : st.mode === 'colour' ? st.bright : 100); if (a.on === undefined) d[v2 ? '20' : '1'] = true; return d; }
  if (a.temp != null) {
    d[v2 ? '21' : '2'] = 'white';
    d[v2 ? '23' : '4'] = v2 ? Math.round(clamp(a.temp, 0, 100) * 10) : Math.round(clamp(a.temp, 0, 100) * 2.55);
  }
  if (a.bright != null) {
    if (st.mode === 'colour' && a.temp == null) colourOut(st.color, a.bright);
    else d[v2 ? '22' : '3'] = v2 ? Math.round(10 + clamp(a.bright, 1, 100) * 9.9) : Math.round(25 + clamp(a.bright, 1, 100) * 2.3);
  }
  if ((a.temp != null || a.bright != null) && a.on === undefined) d[v2 ? '20' : '1'] = true;
  return d;
}
const AMBIENTES = [
  { id: 'pelicula', n: 'Película', color: '#2f3cff', bright: 15 },
  { id: 'leer', n: 'Leer', temp: 75, bright: 100 },
  { id: 'gaming', n: 'Gaming', color: '#8a2cff', bright: 70 },
  { id: 'noche', n: 'Noche', temp: 0, bright: 5 },
  { id: 'relax', n: 'Relax', temp: 15, bright: 45 },
  { id: 'atardecer', n: 'Atardecer', color: '#ff6a1f', bright: 70 }
];
async function lampAction(o, a) {
  if (a.scene) { const sc = AMBIENTES.find(x => x.id === a.scene); if (!sc) throw new Error('Ambiente desconocido'); a = { on: true, temp: sc.temp, bright: sc.bright, color: sc.color }; if (!a.color) delete a.color; else delete a.temp; }
  const d = dev(o);
  let dps = Object.keys(d.dps).length ? d.dps : await status(o);
  const st = lampState(dps, o.schema);
  if (a.toggle) a = { on: !st.on };
  const res = await set(o, lampDps(st, a));
  return lampState(res, o.schema);
}
async function lampStatus(o) { return lampState(await status(o), o.schema); }

module.exports = { lampAction, lampStatus, lampState, lampDps, lampSchema, AMBIENTES, hsv2hex, hex2hsv, status, set, detect, scan, cloudDevices, closeAll, REGIONS, _test: { pack55, pack66, unpackAll, open66, ecbEnc, ecbDec, gcmEnc, gcmDec, hmac, crc32, verHeader, Device } };
