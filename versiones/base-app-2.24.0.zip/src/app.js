(() => {
'use strict';
// red de seguridad: nunca mostrar "null" o "undefined" como texto al armar la pantalla
for (const proto of [Element.prototype, DocumentFragment.prototype]) for (const fn of ['replaceChildren', 'append', 'prepend']) {
  const orig = proto[fn];
  proto[fn] = function (...kids) { return orig.apply(this, kids.filter(k => k != null && k !== false)); };
}
/* Base — escritorio personal (interfaz) */

// ---------- Si algo falla, lo mostramos en pantalla y lo anotamos ----------
function showFatal(msg) {
  try { window.baseApi && window.baseApi.reportError && window.baseApi.reportError(msg); } catch {}
  let box = document.getElementById('fatal');
  if (!box) {
    box = document.createElement('div');
    box.id = 'fatal';
    box.style.cssText = 'position:fixed;left:20px;right:20px;bottom:20px;z-index:99;padding:14px 18px;border-radius:12px;' +
      'background:#b4322b;color:#fff;font:14px/1.45 system-ui,sans-serif;white-space:pre-wrap;user-select:text;box-shadow:0 10px 40px rgba(0,0,0,.4)';
    document.body.append(box);
  }
  box.textContent += (box.textContent ? '\n' : 'Base encontró un error. Sacale una captura y pasásela a Claude:\n') + msg;
}
window.addEventListener('error', (e) => /ResizeObserver loop/i.test(e.message || '') ? e.stopImmediatePropagation() : showFatal(`${e.message} (${(e.filename || '').split('/').pop()}:${e.lineno}:${e.colno})`));
window.addEventListener('unhandledrejection', (e) => showFatal('Promesa: ' + (e.reason && (e.reason.stack || e.reason.message) || e.reason)));

// ---------- Puente con Windows (o simulación para probar en un navegador) ----------
const api = window.baseApi || (() => {
  const KEY = 'base-demo';
  return {
    load: async () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } },
    save: (d) => { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch {} },
    minimize() {}, hide() {}, quit() {},
    pickTarget: async (k) => k === 'folder' ? 'C:\\Users\\Vos\\Documentos' : 'C:\\Program Files\\Programa\\programa.exe',
    iconFor: async () => null,
    open: async (it) => { console.log('abrir', it); return ''; },
    pathForFile: () => '',
    pickBackground: async () => null,
    applySettings: async () => ({ hotkeyOk: true }),
    luces: window.__fakeLuces || null,
    store: window.__fakeStore || null,
    quick: window.__fakeQuick || null,
    deskFiles: window.__fakeDesk ? async () => window.__fakeDesk : null,
    deskImport: window.__fakeDesk ? async (l) => ({ ok: true, done: l.map(x => x.split(/[\\/]/).pop()), errs: [] }) : null,
    panel: window.__fakePanel || null,
    update: {
      check: async () => (window.__fakeUpd ? window.__fakeUpd.check() : { ok: true, none: true, current: '2.18.0' }),
      install: async () => (window.__fakeUpd ? window.__fakeUpd.install() : { ok: false, error: 'Solo en Windows' }),
      info: async () => ({ current: '2.18.0', latest: null, updated: false }),
      onAvailable: (cb) => { window.__updAvail = cb; },
      onProgress: (cb) => { window.__updProg = cb; }
    },
    notify: (t, b) => console.log('aviso', t, b),
    get: async (u) => (window.__fakeGet ? window.__fakeGet(u) : { ok: false, error: 'Sin conexión' }),
    openUrl: async (u) => console.log('abrir', u),
    google: window.__fakeGoogle || {
      status: async () => ({ ok: true, data: { configured: false, accounts: { casa: null, trabajo: null } } }),
      setConfig: async () => ({ ok: true }), link: async () => ({ ok: false, error: 'simulación' }), unlink: async () => ({ ok: true }),
      events: async () => ({ ok: true, data: [] }), createEvent: async () => ({ ok: false, error: 'simulación' }),
      deleteEvent: async () => ({ ok: true }), mail: async () => ({ ok: false, error: 'simulación' }),
      openMail: async () => {}, open: async (u) => console.log('abrir', u)
    },
    taskbar: async () => (window.__fakeTaskbar || []),
    systemShortcuts: async () => ({ taskbar: window.__fakeTaskbar || [], desktop: window.__fakeDesktop || [] }),
    windows: window.__fakeWindows || null,
    dock: window.__fakeDock || null,
    fx: window.__fakeFx || null,
    sm: window.__fakeSm || null,
    games: async () => (window.__fakeGames || { steam: { ok: false, games: [] }, xbox: { ok: false, games: [] } }),
    startApps: async () => (window.__fakeStartApps || []),
    launchSpecial: async (k, id) => { (window.__launches = window.__launches || []).push([k, id]); return ''; },
    edition: window.__fakeEdition || { edicion: 'completa' },
    media: window.__fakeMedia || null,
    stats: window.__fakeStats || null,
    recentFiles: async () => (window.__fakeRecent || []),
    fileSearch: async (q) => (window.__fakeFiles ? window.__fakeFiles(q) : null),
    clip: window.__fakeClip || null,
    shotCrop: window.__fakeClip ? async () => ({ ok: true }) : null,
    onShotDone: window.__fakeClip ? (cb) => { window.__shotDone = cb; } : null,
    fileSearchAll: async (q) => { console.log('searchAll', q); return true; },
    article: async (u) => (window.__fakeArticle ? window.__fakeArticle(u) : { ok: false, error: 'Sin conexión' }),
    luma: window.__fakeLuma || null,
    backup: window.__fakeBackup || null,
    floatNotify: window.__fakeFloat || null,
    dealsEpic: window.__fakeDealsEpic || null,
    floatPlayer: window.__fakeFloatPlayer || null,
    openDrive: async () => '',
    onSearch() {},
    locate: async () => (window.__fakeLocation ? { ok: true, data: window.__fakeLocation } : { ok: false }),
    onModeSet() {},
    platform: 'browser'
  };
})();

// ---------- Utilidades ----------
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseYmd = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const fmt = (d, o) => d.toLocaleDateString('es-AR', o);
function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === false || v == null) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null) e.append(k);
  return e;
}
function svg(path, extra = '') {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = path + extra;
  return s;
}
const ICON = {
  x: '<path d="M7 7l10 10M17 7 7 17"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15zM10 20a2 2 0 0 0 4 0"/>',
  plus: '<path d="M12 5v14M5 12h14"/>'
};

// ---------- Estética ----------
const ACCENTS = [
  { c: '#1f6f78', n: 'Petróleo' },
  { c: '#3557c7', n: 'Azul' },
  { c: '#7b4fc9', n: 'Jacarandá' },
  { c: '#b8325a', n: 'Frambuesa' },
  { c: '#c25410', n: 'Naranja' },
  { c: '#9a7410', n: 'Mostaza' },
  { c: '#2f7d4f', n: 'Verde' },
  { c: '#3f4b5c', n: 'Pizarra' }
];
const BACKGROUNDS = [
  { id: 'jacaranda', n: 'Jacarandá',
    light: 'radial-gradient(1100px 700px at 8% 0%, #b89ced 0%, transparent 62%), radial-gradient(900px 700px at 100% 100%, #a9c8f2 0%, transparent 60%), radial-gradient(700px 500px at 70% 20%, #f1d6ef 0%, transparent 60%), #e3dbf3',
    dark: 'radial-gradient(1100px 700px at 8% 0%, #3d2a6b 0%, transparent 62%), radial-gradient(900px 700px at 100% 100%, #1d3a63 0%, transparent 60%), #17142a' },
  { id: 'atardecer', n: 'Atardecer',
    light: 'radial-gradient(1100px 700px at 0% 0%, #ffc59a 0%, transparent 60%), radial-gradient(1000px 700px at 100% 30%, #f5a9bf 0%, transparent 62%), radial-gradient(900px 600px at 40% 100%, #c6b2ec 0%, transparent 60%), #f6d9cf',
    dark: 'radial-gradient(1100px 700px at 0% 0%, #5a2a2a 0%, transparent 60%), radial-gradient(1000px 700px at 100% 30%, #4a1f3d 0%, transparent 62%), radial-gradient(900px 600px at 40% 100%, #26214f 0%, transparent 60%), #1a1424' },
  { id: 'yerba', n: 'Yerba',
    light: 'radial-gradient(1100px 700px at 0% 0%, #cfe3b5 0%, transparent 60%), radial-gradient(1000px 700px at 100% 100%, #b5d8cc 0%, transparent 62%), #e9eedb',
    dark: 'radial-gradient(1100px 700px at 0% 0%, #23361f 0%, transparent 60%), radial-gradient(1000px 700px at 100% 100%, #133129 0%, transparent 62%), #141c17' },
  { id: 'rio', n: 'Río',
    light: 'linear-gradient(170deg, #d5e0e6 0%, #e8e4da 55%, #cdd8d6 100%)',
    dark: 'linear-gradient(170deg, #17252e 0%, #1f2a2c 55%, #26271f 100%)' },
  { id: 'niebla', n: 'Niebla',
    light: 'radial-gradient(1400px 800px at 12% 0%, #f6f7f9 0%, transparent 70%), linear-gradient(180deg, #e3e7ec, #d6dce3)',
    dark: 'radial-gradient(1400px 800px at 12% 0%, #252d37 0%, transparent 70%), linear-gradient(180deg, #181d24, #12161b)' },
  { id: 'grafito', n: 'Grafito',
    light: '#dde1e6',
    dark: '#16191e' },
  { id: 'aurora', n: 'Aurora',
    light: 'radial-gradient(1200px 600px at 20% -10%, #a8f0d4 0%, transparent 60%), radial-gradient(1000px 700px at 90% 10%, #b9c6ff 0%, transparent 60%), radial-gradient(900px 600px at 50% 110%, #f3c6f0 0%, transparent 60%), #e6eef3',
    dark: 'radial-gradient(1200px 600px at 20% -10%, #0f6e5a 0%, transparent 60%), radial-gradient(1000px 700px at 90% 10%, #2b2f8a 0%, transparent 60%), radial-gradient(900px 600px at 50% 110%, #5a1f6b 0%, transparent 60%), #071018' },
  { id: 'oceano', n: 'Océano',
    light: 'linear-gradient(180deg, #d9f1fb 0%, #b7e0f2 45%, #8fc9e3 100%)',
    dark: 'radial-gradient(1200px 700px at 50% -20%, #134a6b 0%, transparent 65%), linear-gradient(180deg, #08202f, #031019)' },
  { id: 'durazno', n: 'Durazno',
    light: 'radial-gradient(1100px 700px at 100% 0%, #ffd3b5 0%, transparent 60%), radial-gradient(900px 600px at 0% 100%, #ffc2c7 0%, transparent 60%), #fbe7da',
    dark: 'radial-gradient(1100px 700px at 100% 0%, #5c2f1f 0%, transparent 60%), radial-gradient(900px 600px at 0% 100%, #4f1f2b 0%, transparent 60%), #1c1214' },
  { id: 'cereza', n: 'Cerezo',
    light: 'radial-gradient(900px 600px at 15% 10%, #ffd6e4 0%, transparent 60%), radial-gradient(900px 600px at 85% 90%, #f7c1d9 0%, transparent 60%), radial-gradient(700px 500px at 70% 20%, #fff0f5 0%, transparent 60%), #f8e1ea',
    dark: 'radial-gradient(900px 600px at 15% 10%, #5e1f3a 0%, transparent 60%), radial-gradient(900px 600px at 85% 90%, #3d1a3f 0%, transparent 60%), #1b1018' },
  { id: 'bosque', n: 'Bosque',
    light: 'linear-gradient(165deg, #dfe9d6 0%, #c3d8bd 50%, #a9c6aa 100%)',
    dark: 'radial-gradient(1100px 700px at 30% 0%, #1f4a2c 0%, transparent 65%), linear-gradient(180deg, #0f1f15, #08120c)' },
  { id: 'arena', n: 'Médano',
    light: 'linear-gradient(175deg, #f6ead5 0%, #ecd5b0 55%, #dcbf92 100%)',
    dark: 'linear-gradient(175deg, #2a2117 0%, #3a2b1a 55%, #24190f 100%)' },
  { id: 'galaxia', n: 'Galaxia',
    light: 'radial-gradient(1.5px 1.5px at 20px 30px, #7d6bc7, transparent) 0 0 / 160px 160px, radial-gradient(1px 1px at 90px 110px, #9a8bd6, transparent) 0 0 / 160px 160px, radial-gradient(1000px 700px at 80% 20%, #d9cdfb 0%, transparent 60%), radial-gradient(900px 600px at 10% 90%, #c9e0fb 0%, transparent 60%), #ece8f8',
    dark: 'radial-gradient(1.5px 1.5px at 20px 30px, #fff, transparent) 0 0 / 160px 160px, radial-gradient(1px 1px at 90px 110px, #cfd8ff, transparent) 0 0 / 160px 160px, radial-gradient(1.2px 1.2px at 130px 60px, #ffe7b3, transparent) 0 0 / 200px 200px, radial-gradient(1000px 700px at 80% 20%, #3b1f6e 0%, transparent 60%), radial-gradient(900px 600px at 10% 90%, #12305e 0%, transparent 60%), #070712' },
  { id: 'neon', n: 'Neón',
    light: 'radial-gradient(900px 600px at 0% 0%, #c8f7dc 0%, transparent 60%), radial-gradient(900px 600px at 100% 100%, #d9c8ff 0%, transparent 60%), #eef0f6',
    dark: 'radial-gradient(900px 600px at 0% 0%, rgba(34,197,94,.35) 0%, transparent 60%), radial-gradient(900px 600px at 100% 100%, rgba(168,85,247,.38) 0%, transparent 60%), linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px) 0 0 / 44px 44px, linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px) 0 0 / 44px 44px, #090b12' },
  { id: 'cine', n: 'Cine',
    light: 'radial-gradient(1000px 600px at 50% -10%, #ffe1d6 0%, transparent 60%), linear-gradient(180deg, #f6e9e4, #ecd5cf)',
    dark: 'radial-gradient(1000px 600px at 50% -10%, #6b1a1a 0%, transparent 60%), repeating-linear-gradient(90deg, rgba(0,0,0,.18) 0 18px, rgba(255,255,255,.02) 18px 36px), #170909' },
  { id: 'cuaderno', n: 'Cuaderno',
    light: 'linear-gradient(rgba(58,111,216,.10) 1px, transparent 1px) 0 0 / 28px 28px, linear-gradient(90deg, rgba(58,111,216,.10) 1px, transparent 1px) 0 0 / 28px 28px, #f7f6f1',
    dark: 'linear-gradient(rgba(140,170,255,.08) 1px, transparent 1px) 0 0 / 28px 28px, linear-gradient(90deg, rgba(140,170,255,.08) 1px, transparent 1px) 0 0 / 28px 28px, #13161d' },
  { id: 'cancha', n: 'Cancha',
    light: 'repeating-linear-gradient(90deg, #cfe8c4 0 90px, #c2e0b6 90px 180px)',
    dark: 'radial-gradient(1200px 600px at 50% 0%, rgba(255,255,255,.08), transparent 60%), repeating-linear-gradient(90deg, #11301c 0 90px, #0e2a18 90px 180px)' },
  { id: 'menta', n: 'Menta',
    light: 'radial-gradient(1100px 700px at 0% 0%, #c9f2e3 0%, transparent 60%), radial-gradient(900px 600px at 100% 100%, #d7eefc 0%, transparent 60%), #e8f5f0',
    dark: 'radial-gradient(1100px 700px at 0% 0%, #0f4a3a 0%, transparent 60%), radial-gradient(900px 600px at 100% 100%, #123a52 0%, transparent 60%), #0a1714' },
  { id: 'lavanda', n: 'Lavanda',
    light: 'linear-gradient(160deg, #ece6fb 0%, #ddd3f6 50%, #e9e1f4 100%)',
    dark: 'linear-gradient(160deg, #1d1830 0%, #241c3b 50%, #18142a 100%)' }
];

// Accesos de trabajo a los artefactos de Claude
const WORK_LINKS = []; // los accesos personales quedan en los datos de cada uno, no en el programa
const ED = (api.edition) || { edicion: 'completa' };
const SINGLE = ED.edicion === 'compartir'; // edición para compartir: solo modo Casa
if (SINGLE) document.documentElement.classList.add('single');
const DEFAULT_CITY = { name: 'Buenos Aires', detail: 'Argentina', lat: -34.6037, lon: -58.3816 };

function defaultMode(kind) {
  const casa = kind === 'casa';
  return {
    weather: { ...DEFAULT_CITY },
    f1: casa ? { alert: '15', notified: [] } : undefined,
    theme: casa
      ? { scheme: 'light', accent: '#7b4fc9', bg: { kind: 'preset', value: 'jacaranda' }, glass: 35 }
      : { scheme: 'light', accent: '#1f6f78', bg: { kind: 'preset', value: 'niebla' }, glass: 15 },
    shortcuts: casa
      ? [
          { id: uid(), type: 'web', name: 'YouTube', target: 'https://www.youtube.com' },
          { id: uid(), type: 'web', name: 'Mercado Libre', target: 'https://www.mercadolibre.com.ar' },
          { id: uid(), type: 'web', name: 'Gmail', target: 'https://mail.google.com' }
        ]
      : [
          ...(SINGLE ? [] : WORK_LINKS.map(l => ({ id: uid(), ...l }))),
          { id: uid(), type: 'web', name: 'Gmail', target: 'https://mail.google.com' },
          { id: uid(), type: 'web', name: 'Google Drive', target: 'https://drive.google.com' },
          { id: uid(), type: 'web', name: 'Calendario', target: 'https://calendar.google.com' }
        ],
    tasks: [],
    notes: [],
    events: []
  };
}
function defaultData() {
  return {
    version: 2,
    activeMode: 'casa',
    cache: {},
    settings: { name: '', startWithWindows: true, fullscreen: false, hotkey: 'Control+Alt+Space', startMode: 'last' },
    modes: { casa: defaultMode('casa'), trabajo: defaultMode('trabajo') }
  };
}

// ---------- Estado ----------
let S = null;                 // datos guardados
const ui = {                  // estado de pantalla (no se guarda)
  taskFilter: 'pending',
  taskPrio: false,
  note: { casa: null, trabajo: null },
  calMonth: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
  sel: ymd(new Date()),
  editingLaunch: false,
  scEditing: null,
  scKind: 'app'
};
const M = () => S.modes[S.activeMode];

let saveTimer = null;
let canSave = false;
function save(now) {
  if (!canSave) return;
  if (S && S.settings && S.settings.panelOn) panelPush();
  clearTimeout(saveTimer);
  if (now) api.save(S);
  else saveTimer = setTimeout(() => api.save(S), 300);
}

// ---------- Toast con deshacer ----------
let toastTimer = null;
function toast(msg, action) {
  const t = $('#toast');
  t.replaceChildren(msg);
  if (action) {
    const b = el('button', { class: 'text-btn', style: 'margin-left:10px;color:inherit;text-decoration:underline', text: action.label });
    b.onclick = () => { action.fn(); t.classList.remove('on'); };
    t.append(b);
    t.style.pointerEvents = 'auto';
  } else t.style.pointerEvents = 'none';
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.classList.remove('on'); t.style.pointerEvents = 'none'; }, action ? 6000 : 3200);
}

// ---------- Tema ----------
function hexToRgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
function luminance(h) {
  const [r, g, b] = hexToRgb(h).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; });
  return .2126 * r + .7152 * g + .0722 * b;
}
function applyTheme() {
  const t = M().theme;
  const root = document.documentElement;
  root.dataset.scheme = t.scheme;
  root.dataset.mode = S.activeMode;
  root.style.setProperty('--accent', t.accent);
  root.style.setProperty('--accent-ink', luminance(t.accent) > .45 ? '#141a21' : '#ffffff');
  root.style.setProperty('--surface-a', (0.94 - (t.glass / 100) * 0.62).toFixed(3));
  let bg, overlay, photo = '';
  const bing = t.bg.kind === 'bing' && S.cache.bing && S.cache.bing.data;
  if (bing) {
    bg = `url("${bing.url}") center / cover no-repeat`;
    photo = bing.url;
    overlay = t.scheme === 'dark' ? 'rgba(6,9,14,.5)' : 'rgba(255,255,255,.3)';
  } else if (t.bg.kind === 'auto' || t.bg.kind === 'bing') {
    bg = AUTO_BG[autoBgKey()][t.scheme];
    overlay = 'transparent';
  } else if (t.bg.kind === 'image' && t.bg.value) {
    bg = `url("${t.bg.value}") center / cover no-repeat`;
    photo = t.bg.value;
    overlay = t.scheme === 'dark' ? 'rgba(6,9,14,.45)' : 'rgba(255,255,255,.28)';
  } else {
    const p = BACKGROUNDS.find(b => b.id === t.bg.value) || BACKGROUNDS[0];
    bg = p[t.scheme];
    overlay = 'transparent';
  }
  root.style.setProperty('--bg-image', bg);
  root.classList.toggle('bg-photo', !!photo);
  // velo para que se lea: automático según qué tan clara u oscura es la foto
  const veil = t.veil == null ? 'auto' : String(t.veil);
  root.classList.remove('bg-darkphoto');
  if (photo) {
    const L = (S.cache['luma:' + photo] || {}).data;
    let a;
    if (veil !== 'auto') a = Number(veil);
    else if (L) {
      const l = Math.max(L.top, L.all * 0.6 + L.top * 0.4);
      a = t.scheme === 'dark'
        ? Math.min(.8, Math.max(.3, (l - 0.22) / Math.max(l, .01) + .1))
        : Math.min(.42, Math.max(.1, (0.6 - Math.min(L.top, L.all)) / (1 - Math.min(L.top, L.all) + .001)));
    } else a = t.scheme === 'dark' ? .5 : .3;
    overlay = t.scheme === 'dark' ? `rgba(6,9,14,${a.toFixed(2)})` : `rgba(250,250,252,${a.toFixed(2)})`;
    // en modo claro, si la foto es oscura, en vez de lavarla ponemos placas de vidrio detrás del texto
    root.classList.toggle('bg-darkphoto', t.scheme !== 'dark' && !!L && Math.min(L.top, L.all) < .45);
    if (!L && veil === 'auto') measureBg(photo);
  } else if (veil !== 'auto' && Number(veil) > 0) {
    overlay = t.scheme === 'dark' ? `rgba(6,9,14,${veil})` : `rgba(250,250,252,${veil})`;
  }
  root.style.setProperty('--overlay', overlay);
  $('#btn-scheme').title = t.scheme === 'dark' ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro';
  applyCursor();
}

async function measureBg(src) {
  if (!api.luma || ui.lumaBusy === src) return;
  ui.lumaBusy = src;
  const r = await safeCall(() => api.luma(src));
  ui.lumaBusy = null;
  if (r && typeof r.top === 'number') { S.cache['luma:' + src] = { at: Date.now(), data: r }; save(); applyTheme(); }
}

// ---------- Copia de seguridad (exportar / importar) ----------
async function exportBackup() {
  if (!api.backup) return toast('Disponible en la app instalada');
  save(true);
  const r = await safeCall(() => api.backup.export(S, { google: $('#bk-google').checked }));
  if (!r || r.canceled) return;
  if (!r.ok) return toast('No se pudo exportar: ' + (r.error || 'error'));
  toast(`Copia guardada: ${r.summary.file}. Llevala a la otra compu y tocá “Importar una copia…”.`);
}
function showImport(sum, fromInstaller) {
  ui.impFromInstaller = !!fromInstaller;
  const d = sum.at ? new Date(sum.at) : null;
  const parts = [plural(sum.tasks, 'tarea', 'tareas'), plural(sum.notes, 'nota', 'notas'), plural(sum.events, 'evento', 'eventos'), plural(sum.shortcuts, 'acceso', 'accesos')];
  $('#imp-summary').replaceChildren(
    el('div', { class: 'imp-ico' }, svg('<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>')),
    el('div', {},
      el('b', { text: fromInstaller ? 'Encontré una copia junto al instalador' : (sum.file || 'Copia de Base') }),
      el('span', { text: [sum.from ? `De la compu “${sum.from}”` : '', d ? `${fmt(d, { day: 'numeric', month: 'long' })} ${pad(d.getHours())}:${pad(d.getMinutes())}` : ''].filter(Boolean).join(' · ') }),
      el('span', { text: parts.join(' · ') + (sum.images ? ` · ${plural(sum.images, 'fondo propio', 'fondos propios')}` : '') + (sum.google ? ' · configuración de Google' : '') })));
  for (const r of $$('input[name="imp-which"]')) { r.checked = r.value === 'all'; r.disabled = r.value !== 'all' && !sum.modes.includes(r.value); }
  $('#dlg-import').showModal();
}
async function pickImport() {
  if (!api.backup) return toast('Disponible en la app instalada');
  const r = await safeCall(() => api.backup.pick());
  if (!r || r.canceled) return;
  if (!r.ok) return toast(r.error || 'No se pudo leer la copia');
  showImport(r.summary, false);
}
async function applyImport(e) {
  e.preventDefault();
  const which = (SINGLE ? 'all' : ($$('input[name="imp-which"]').find(x => x.checked) || {}).value) || 'all';
  $('#imp-go').disabled = true;
  save(true);
  const r = await safeCall(() => api.backup.apply(which, S));
  $('#imp-go').disabled = false;
  if (!r || !r.ok) return toast('No se pudo importar: ' + ((r && r.error) || 'error'));
  $('#dlg-import').close();
  closeWidget(true);
  S = migrate(r.data);
  if (SINGLE) S.activeMode = 'casa';
  canSave = true;
  save(true);
  try { await refreshGStatus(); } catch {}
  renderAll(); commitSettings();
  loadTaskbar(); loadNewCards(false); loadTopicData(false); refreshOnline(true);
  toast(which === 'all' ? '¡Listo! Base quedó igual que en la otra compu.' : `¡Listo! Importaste ${which === 'casa' ? 'Casa' : 'Trabajo'}.`);
}
async function autoBkPaint() {
  const info = $('#bk-auto-info');
  $('#bk-auto').checked = S.settings.autoBackup !== false;
  if (!api.backup || !api.backup.autoInfo) return;
  const r = await safeCall(() => api.backup.autoInfo());
  if (!r) return;
  const d = r.last ? new Date(r.last) : null;
  info.textContent = (d ? `La última fue el ${fmt(d, { weekday: 'long', day: 'numeric', month: 'long' })} a las ${pad(d.getHours())}:${pad(d.getMinutes())}. ` : 'Todavía no se hizo ninguna. ') + `Se guardan en Documentos › Base › Copias (quedan las últimas 4${r.files.length ? `; hay ${r.files.length}` : ''}).`;
}
function setupBackup() {
  autoBkPaint();
  $('#bk-auto').onchange = (e) => { S.settings.autoBackup = e.target.checked; save(true); toast(e.target.checked ? 'Base va a hacer una copia cada semana' : 'Listo, sin copias automáticas'); };
  $('#bk-auto-now').onclick = async () => {
    if (!api.backup || !api.backup.autoNow) return toast('Disponible en la app instalada');
    save(true);
    const r = await safeCall(() => api.backup.autoNow());
    toast(r && r.ok ? 'Copia hecha en Documentos › Base › Copias' : 'No se pudo hacer la copia' + (r && r.error ? ': ' + r.error : ''));
    autoBkPaint();
  };
  $('#bk-auto-open').onclick = () => api.backup && api.backup.autoOpen ? api.backup.autoOpen() : toast('Disponible en la app instalada');
  $('#bk-export').onclick = exportBackup;
  $('#bk-import').onclick = pickImport;
  $('#import-form').onsubmit = applyImport;
  $('#imp-later').onclick = () => { $('#dlg-import').close(); if (ui.impFromInstaller) { api.backup.dismiss(); toast('Si la querés después: Personalizar > Importar una copia.'); } };
}
async function checkPendingImport() {
  if (!api.backup) return;
  const r = await safeCall(() => api.backup.pending());
  if (r && r.ok) showImport(r.summary, true);
}

// ---------- Modo ----------
function setMode(m) {
  if (!S.modes[m] || (SINGLE && m === 'trabajo')) return;
  S.activeMode = m;
  closeWidget(true);
  closeFolder();
  if (ui.mailView) closeMailView();
  if (document.documentElement.classList.contains('desk-edit')) setDeskEdit(false);
  save();
  renderAll();
  refreshOnline(false);
  loadDolar(false); loadSistema(); loadGames(false);
  if (ui.nwRead != null) closeNewsReader();
  loadNewCards(false);
}
// ---------- Tableros extra (además de Casa y Trabajo) ----------
const BOARD_ICONS = {
  home: '<path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>',
  work: '<path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M4 8h16a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1zM3 13h18"/>',
  game: '<rect x="2.5" y="7" width="19" height="11" rx="5.5"/><path d="M7 10.5v4M5 12.5h4"/><circle cx="15.5" cy="11.5" r="1" fill="currentColor"/><circle cx="17.5" cy="13.8" r="1" fill="currentColor"/>',
  tv: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8M9 2l3 4 3-4"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M8 7h7"/>',
  ball: '<circle cx="12" cy="12" r="9"/><path d="m12 7 4 3-1.5 4.5h-5L8 10z"/>',
  money: '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 9v.01M18 15v.01"/>',
  music: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  heart: '<path d="M12 20s-7-4.4-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.6-9 9-9 9z"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
  plane: '<path d="M10 14 3 11l1-2 8 1 5-6h2l-3 7 4 1 1 2-6 1-3 6h-2l1-6z"/>',
  code: '<path d="M8 6l-6 6 6 6M16 6l6 6-6 6"/>',
  paw: '<circle cx="7" cy="9" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="17" cy="9" r="2"/><path d="M12 12c-3 0-5 3-5 5.5S9 20 12 19s5 1 5-1.5S15 12 12 12z"/>',
  cart: '<path d="M3 4h2l2.5 11h11L21 7H6.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 10h8M8 13h5"/>'
};
const web = (name, target) => ({ type: 'web', name, target });
const BOARD_TPL = [
  { id: 'juegos', n: 'Juegos', icon: 'game', d: 'Tu biblioteca, streaming, redes y rendimiento.', scheme: 'dark', accent: '#22c55e', bg: 'neon',
    widgets: ['games', 'stream', 'social', 'sistema', 'news', 'notes'], news: ['Videojuegos', 'Steam', 'Xbox Game Pass'],
    links: [web('Steam', 'https://store.steampowered.com'), web('Epic Games', 'https://store.epicgames.com'), web('Twitch', 'https://www.twitch.tv'), web('Discord', 'https://discord.com/app')] },
  { id: 'streaming', n: 'Streaming', icon: 'tv', d: 'Series, pelis y música, con estrenos.', scheme: 'dark', accent: '#e0533d', bg: 'cine',
    widgets: ['stream', 'news', 'social', 'agenda', 'cuenta', 'notes'], news: ['Estrenos de series', 'Netflix', 'Cine'],
    links: [web('YouTube', 'https://www.youtube.com'), web('Netflix', 'https://www.netflix.com'), web('Disney+', 'https://www.disneyplus.com'), web('Spotify', 'https://open.spotify.com')] },
  { id: 'estudio', n: 'Estudio', icon: 'book', d: 'Pomodoro, tareas, hábitos y fechas de entrega.', scheme: 'light', accent: '#3a6fd8', bg: 'cuaderno',
    widgets: ['tasks', 'pomodoro', 'notes', 'agenda', 'habitos', 'cuenta', 'pronostico'], news: ['Educación', 'Ciencia'],
    links: [web('Google Drive', 'https://drive.google.com'), web('Classroom', 'https://classroom.google.com'), web('Wikipedia', 'https://es.wikipedia.org'), web('Traductor', 'https://translate.google.com')] },
  { id: 'deportes', n: 'Deportes', icon: 'ball', d: 'Tu sección de deportes, noticias y fechas.', scheme: 'dark', accent: '#2f9e44', bg: 'cancha',
    widgets: ['f1', 'news', 'agenda', 'feriados', 'relojes', 'cuenta'], news: ['Fútbol argentino', 'Selección Argentina', 'Fórmula 1'],
    links: [web('Olé', 'https://www.ole.com.ar'), web('TyC Sports', 'https://www.tycsports.com'), web('ESPN', 'https://www.espn.com.ar'), web('Fórmula 1', 'https://www.formula1.com')] },
  { id: 'finanzas', n: 'Finanzas', icon: 'money', d: 'Dólar, cripto, economía y pendientes.', scheme: 'light', accent: '#1f9d6b', bg: 'menta',
    widgets: ['dolar', 'cripto', 'news', 'tasks', 'notes', 'agenda'], news: ['Economía argentina', 'Mercados', 'Dólar'],
    links: [web('Mercado Pago', 'https://www.mercadopago.com.ar'), web('Rava', 'https://www.rava.com'), web('AFIP / ARCA', 'https://www.afip.gob.ar')] },
  { id: 'redes', n: 'Redes', icon: 'chat', d: 'Correo, WhatsApp y todas tus redes a mano.', scheme: 'light', accent: '#d6336c', bg: 'durazno',
    widgets: ['agenda', 'tasks', 'notes', 'news'], news: ['Tendencias', 'Redes sociales'], links: [] },
  { id: 'blanco', n: 'En blanco', icon: 'star', d: 'Empezá de cero y armalo a tu gusto.', scheme: 'light', accent: '#7b4fc9', bg: 'lavanda',
    widgets: ['tasks', 'notes', 'agenda'], news: null, links: [] }
];
const MAX_BOARDS = 8;
const boards = () => (Array.isArray(S.boards) ? S.boards : (S.boards = []));
const isBoard = (m) => m !== 'casa' && m !== 'trabajo';
const allModes = () => ['casa', ...(SINGLE ? [] : ['trabajo']), ...boards().map(b => b.id).filter(id => S.modes[id])];
function modeName(m) { return m === 'casa' ? 'Casa' : m === 'trabajo' ? 'Trabajo' : ((boards().find(b => b.id === m) || {}).name || 'Tablero'); }
// la cuenta de Google que usa cada tablero (los extra usan la de Casa o la de Trabajo)
function gmode(m) { return isBoard(m) ? ((S.modes[m] && S.modes[m].gFrom) || 'casa') : m; }
const G = {
  link: (m) => api.google.link(gmode(m)), unlink: (m) => api.google.unlink(gmode(m)),
  events: (m, a, b) => api.google.events(gmode(m), a, b), createEvent: (m, e) => api.google.createEvent(gmode(m), e),
  deleteEvent: (m, id) => api.google.deleteEvent(gmode(m), id), mail: (m) => api.google.mail(gmode(m)),
  message: (m, id) => api.google.message(gmode(m), id), markRead: (m, ids) => api.google.markRead(gmode(m), ids)
};
function renderModeTabs() {
  const box = $('.modes');
  if (!box) return;
  box.replaceChildren();
  for (const m of allModes()) {
    const b = boards().find(x => x.id === m);
    const btn = el('button', { role: 'tab', 'data-mode': m, id: 'tab-' + m, 'aria-selected': String(m === S.activeMode), title: b ? `${b.name} · clic derecho para editar` : modeName(m) },
      svg(BOARD_ICONS[b ? b.icon : m === 'casa' ? 'home' : 'work'] || BOARD_ICONS.star), el('span', { text: modeName(m) }));
    btn.onclick = () => setMode(m);
    if (b) btn.oncontextmenu = (e) => { e.preventDefault(); openBoardDialog(b.id); };
    box.append(btn);
  }
  if (boards().length < MAX_BOARDS) {
    const add = el('button', { class: 'mode-add', title: 'Nuevo tablero', 'aria-label': 'Nuevo tablero' }, svg(ICON.plus));
    add.onclick = () => openBoardDialog(null);
    box.append(add);
  }
  $('#d-mode-name').textContent = modeName(S.activeMode);
  box.classList.toggle('tight', allModes().length > 4);
  if (WINS.ok != null) requestAnimationFrame(renderSwitcher);
}
function bgPreview(id, scheme) { const p = BACKGROUNDS.find(b => b.id === id) || BACKGROUNDS[0]; return p[scheme] || p.light; }
function openBoardDialog(id) {
  const b = id ? boards().find(x => x.id === id) : null;
  ui.boardEdit = { id, tpl: b ? null : 'juegos', icon: b ? b.icon : 'game' };
  $('#board-title').textContent = b ? `Editar “${b.name}”` : 'Nuevo tablero';
  $('#board-ok').textContent = b ? 'Guardar' : 'Crear tablero';
  $('#board-del').hidden = !b;
  $('#board-tpl-wrap').hidden = !!b;
  $('#board-name').value = b ? b.name : BOARD_TPL[0].n;
  $('#board-g').value = b ? (S.modes[b.id].gFrom || 'casa') : 'casa';
  $('#board-special').checked = b ? b.special !== false : true;
  const syncSpecial = () => { const tpl = b ? b.tpl : ui.boardEdit.tpl; $('#board-special-row').hidden = !['streaming', 'juegos', 'redes'].includes(tpl); };
  ui.boardEdit.sync = syncSpecial; syncSpecial();
  const grid = $('#tpl-grid');
  grid.replaceChildren(...BOARD_TPL.map(t => {
    const card = el('button', { type: 'button', class: 'tpl' + (ui.boardEdit.tpl === t.id ? ' on' : ''), style: `--tc:${t.accent}` },
      el('span', { class: 'tpl-prev', style: `background:${bgPreview(t.bg, t.scheme)}` },
        el('span', { class: 'tpl-ico' }, svg(BOARD_ICONS[t.icon])),
        el('span', { class: 'tpl-cards' }, t.widgets.slice(0, 6).map(() => el('i')))),
      el('b', { text: t.n }), el('span', { text: t.d }));
    card.onclick = () => {
      const prevTpl = BOARD_TPL.find(x => x.id === ui.boardEdit.tpl);
      ui.boardEdit.tpl = t.id; ui.boardEdit.icon = t.icon;
      if (!$('#board-name').value.trim() || (prevTpl && $('#board-name').value === prevTpl.n)) $('#board-name').value = t.n;
      for (const c of grid.children) c.classList.toggle('on', c === card);
      renderBoardIcons();
      ui.boardEdit.sync && ui.boardEdit.sync();
    };
    return card;
  }));
  renderBoardIcons();
  $('#dlg-board').showModal();
  setTimeout(() => $('#board-name').select(), 50);
}
function renderBoardIcons() {
  const box = $('#board-icons');
  box.replaceChildren(...Object.keys(BOARD_ICONS).filter(k => k !== 'home' && k !== 'work').map(k => {
    const b = el('button', { type: 'button', class: 'ico-pick' + (ui.boardEdit.icon === k ? ' on' : ''), 'aria-label': k }, svg(BOARD_ICONS[k]));
    b.onclick = () => { ui.boardEdit.icon = k; renderBoardIcons(); };
    return b;
  }));
}
function saveBoard(e) {
  e.preventDefault();
  const ed = ui.boardEdit;
  const name = $('#board-name').value.trim().slice(0, 24) || 'Tablero';
  if (ed.id) {
    const b = boards().find(x => x.id === ed.id);
    b.name = name; b.icon = ed.icon;
    b.special = $('#board-special').checked;
    S.modes[b.id].gFrom = $('#board-g').value;
    save(); $('#dlg-board').close(); renderModeTabs(); renderStage(); refreshGStatus().then(() => { renderMail(); renderPeeks(); });
    return toast('Tablero actualizado');
  }
  const t = BOARD_TPL.find(x => x.id === ed.tpl) || BOARD_TPL[0];
  const id = 'tb-' + Date.now().toString(36);
  const m = defaultMode('casa');
  delete m.f1;
  m.theme = { scheme: t.scheme, accent: t.accent, bg: { kind: 'preset', value: t.bg }, glass: 30, clock: { ...(S.modes.casa.theme.clock || {}) } };
  m.weather = { ...S.modes.casa.weather };
  m.widgets = t.widgets.slice(0, MAX_WIDGETS);
  if (t.news) m.newsTopics = t.news.slice();
  m.shortcuts = t.links.length ? [{ id: uid(), type: 'group', name: t.n, items: t.links.map(l => ({ id: uid(), ...l })) }] : [];
  m.mail = { notify: false, seen: null };
  m.gcalNotify = '10'; m.gNotified = [];
  m.gFrom = $('#board-g').value;
  S.modes[id] = m;
  boards().push({ id, name, icon: ed.icon, tpl: t.id, special: $('#board-special').checked });
  $('#dlg-board').close();
  setMode(id);
  toast(`Listo: creaste el tablero “${name}”. Clic derecho en la pestaña para editarlo.`);
}
function deleteBoard() {
  const id = ui.boardEdit && ui.boardEdit.id;
  const b = id && boards().find(x => x.id === id);
  if (!b || !confirm(`¿Eliminar el tablero “${b.name}” con sus tareas, notas y accesos?`)) return;
  $('#dlg-board').close();
  if (S.activeMode === id) setMode('casa');
  S.boards = boards().filter(x => x.id !== id);
  delete S.modes[id];
  for (const k of Object.keys(S.cache)) if (k.endsWith(':' + id)) delete S.cache[k];
  save(); renderModeTabs();
  toast(`Eliminaste “${b.name}”`);
}
function setupBoards() {
  $('#board-form').onsubmit = saveBoard;
  $('#board-cancel').onclick = () => $('#dlg-board').close();
  $('#board-del').onclick = deleteBoard;
}

// ---------- Tableros con diseño propio (Streaming y Juegos) ----------
function stageKind(mode = S.activeMode) {
  const b = boards().find(x => x.id === mode);
  return b && b.special !== false && ['streaming', 'juegos', 'redes'].includes(b.tpl) ? b.tpl : '';
}
function renderStage() {
  const kind = stageKind();
  const root = document.documentElement;
  if (root.dataset.stage !== kind) { if (kind) root.dataset.stage = kind; else delete root.dataset.stage; }
  const box = $('#stage');
  if (!kind) { if (box.dataset.k) { box.replaceChildren(); box.dataset.k = ''; } return; }
  if (box.dataset.k !== kind + ':' + S.activeMode) {
    box.dataset.k = kind + ':' + S.activeMode;
    box.className = 'stage st-' + kind;
    if (kind === 'streaming') buildStream(box); else if (kind === 'redes') buildRedes(box); else buildGamesStage(box);
  } else if (kind === 'juegos') refreshGamesStage();
  else if (kind === 'streaming') renderStreamStage();
  else if (kind === 'redes') { renderRedesMail(); renderRedesNets(); }
}

// ----- Streaming: reproduciendo ahora + servicios + ventanitas flotantes -----
const FLOAT_BTNS = [
  { k: 'youtube', n: 'YouTube', c: '#e62117', g: 'play' },
  { k: 'ytmusic', n: 'YouTube Music', c: '#b3170f', g: 'note' },
  { k: 'twitch', n: 'Twitch', c: '#6c2bd9', g: 'live' }
];
function buildStream(box) {
  const np = el('section', { class: 'sx-card np', id: 'np' },
    el('div', { class: 'np-bg', id: 'np-bg' }),
    el('div', { class: 'sx-h' }, svg('<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>'), el('b', { text: 'Reproduciendo ahora' }), el('span', { class: 'np-apps', id: 'np-apps' })),
    el('div', { class: 'np-body', id: 'np-body' }));
  const floats = el('div', { class: 'fl-row' }, FLOAT_BTNS.map(f => {
    const b = el('button', { class: 'fl-btn', style: `--fc:${f.c}`, title: `Abrir ${f.n} en una ventanita que queda arriba de todo` },
      el('span', { class: 'fl-ico' }, svg(GLYPH[f.g] || GLYPH.play)), el('span', {}, el('b', { text: f.n }), el('small', { text: 'Ventana flotante' })));
    b.onclick = async () => { if (!api.floatPlayer) return toast('Disponible en la app instalada'); const r = await api.floatPlayer(f.k, S.settings.floatBrowser || ''); if (r) toast(r); };
    return b;
  }));
  const services = el('section', { class: 'sx-card svc' },
    el('div', { class: 'sx-h' }, svg('<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8M9 2l3 4 3-4"/>'), el('b', { text: 'Mirar y escuchar' }), el('span', { class: 'spacer' }),
      Object.assign(el('button', { class: 'text-btn', id: 'svc-edit', text: 'Elegir servicios' }), { onclick: () => { ui.svcEdit = !ui.svcEdit; renderStreamStage(); } })),
    el('div', { class: 'svc-grid', id: 'svc-grid' }),
    el('div', { class: 'sx-sub', text: 'Para mirar mientras hacés otra cosa' }),
    floats);
  box.replaceChildren(np, services);
  renderStreamStage(); renderNowPlaying(true);
}
function renderStreamStage() {
  const grid = $('#svc-grid');
  if (!grid) return;
  const casa = S.modes.casa;
  const chosen = casa.streaming || STREAM_DEFAULT;
  const editing = !!ui.svcEdit;
  setText('svc-edit', editing ? 'Listo' : 'Elegir servicios');
  grid.classList.toggle('editing', editing);
  const list = editing ? STREAMING : chosen.map(id => STREAMING.find(x => x.id === id)).filter(Boolean);
  grid.replaceChildren(...list.map(svc => {
    const on = chosen.includes(svc.id);
    const app = streamApp(svc);
    const b = serviceTile(svc, { off: editing && !on, how: editing ? (on ? '✓ En tu lista' : '+ Sumar') : app ? 'App' : 'Web', title: editing ? (on ? 'Tocá para sacarlo' : 'Tocá para sumarlo') : `Abrir ${svc.n}` });
    b.onclick = () => {
      if (!editing) return openStream(svc);
      const cur = (casa.streaming || STREAM_DEFAULT).slice();
      const i = cur.indexOf(svc.id);
      if (i >= 0) cur.splice(i, 1); else cur.push(svc.id);
      casa.streaming = cur; save(); renderStreamStage(); renderStreaming(); renderPeeks();
    };
    return b;
  }));
}
// reproduciendo ahora: lo que suena en Windows
const NP = { app: null, key: '' };
async function loadNowPlaying() {
  if (stageKind() !== 'streaming' || document.hidden) return;
  await loadMedia();
  renderNowPlaying();
}
function npSession() {
  const list = MEDIA.list || [];
  return list.find(x => x.app === NP.app) || list.find(x => x.status === 'Playing') || list.find(x => x.cur) || list[0] || null;
}
async function renderNowPlaying(force) {
  const body = $('#np-body');
  if (!body) return;
  const s = npSession();
  const apps = $('#np-apps');
  const list = MEDIA.list || [];
  apps.replaceChildren(...(list.length > 1 ? list.map(x => {
    const b = el('button', { class: 'np-app' + (s && x.app === s.app ? ' on' : ''), text: appLabel(x.app) });
    b.onclick = () => { NP.app = x.app; renderNowPlaying(true); };
    return b;
  }) : []));
  if (!s || (!s.title && s.status !== 'Playing')) {
    if (body.dataset.state !== 'empty') {
      body.dataset.state = 'empty'; NP.key = '';
      body.replaceChildren(el('div', { class: 'np-empty' }, svg('<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>'),
        el('b', { text: MEDIA.ok === false ? 'Disponible en la app instalada' : 'No suena nada' }),
        el('span', { text: 'Poné play en Spotify, en YouTube desde el navegador o en cualquier reproductor y lo controlás desde acá.' })));
      $('#np-bg').style.backgroundImage = '';
    }
    return;
  }
  const key = s.app + '|' + s.title + '|' + s.artist;
  if (force || body.dataset.state !== 'on' || NP.key !== key) {
    body.dataset.state = 'on'; NP.key = key;
    const cover = el('div', { class: 'np-cover' }, svg('<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>'));
    const seek = el('input', { type: 'range', class: 'seekbar', id: 'np-seek', min: 0, max: 100, step: 0.5, value: 0, 'aria-label': 'Posición' });
    const btn = (act, icon, cls, title) => { const b = el('button', { class: 'icon-btn ' + (cls || ''), title, 'aria-label': title }, svg(icon)); b.onclick = async () => { const ss = npSession(); if (!ss) return; if (act === 'toggle') { ss.status = ss.status === 'Playing' ? 'Paused' : 'Playing'; renderNowPlaying(); } await api.media.act(ss.app, act); setTimeout(loadNowPlaying, 400); }; return b; };
    const key2 = (k, icon, title) => { const b = el('button', { class: 'icon-btn sm', title, 'aria-label': title }, svg(icon)); b.onclick = () => api.media.key(k); return b; };
    body.replaceChildren(cover,
      el('div', { class: 'np-info' }, el('span', { class: 'np-src', text: appLabel(s.app) }), el('b', { class: 'np-t', text: s.title || 'Sin título' }), el('span', { class: 'np-a', text: [s.artist, s.album].filter(Boolean).join(' · ') })),
      el('div', { class: 'np-seek' }, el('span', { 'data-cur': '', id: 'np-cur', text: '0:00' }), seek, el('span', { id: 'np-end' })),
      el('div', { class: 'np-ctrls' },
        key2('voldown', '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 12h4"/>', 'Bajar volumen'),
        btn('prev', '<path d="M6 5v14M18 6l-9 6 9 6z"/>', 'sm', 'Anterior'),
        btn('toggle', PLAY_ICON, 'np-play', 'Pausar o reproducir'),
        btn('next', '<path d="M18 5v14M6 6l9 6-9 6z"/>', 'sm', 'Siguiente'),
        key2('volup', '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 12h4M19 10v4"/>', 'Subir volumen')));
    bindSeek(seek, npSession);
    mediaThumb(s).then(async (u) => {
      if (!u && s.artist && s.title) u = await coverFor(s.artist, s.title); // Spotify a veces no pasa la tapa: la buscamos
      if (NP.key !== key) return;
      if (u) { cover.replaceChildren(el('img', { src: u, alt: '' })); $('#np-bg').style.backgroundImage = `url("${u}")`; }
      else $('#np-bg').style.backgroundImage = '';
    });
  }
  const play = body.querySelector('.np-play');
  if (play) play.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${s.status === 'Playing' ? PAUSE_ICON : PLAY_ICON}</svg>`;
  $('#np').classList.toggle('paused', s.status !== 'Playing');
  const sr = body.querySelector('.np-seek');
  if (sr) { sr.hidden = !(mediaLen(s) > 0); paintSeek($('#np-seek'), $('#np-cur'), $('#np-end'), s); }
}

// ----- Juegos: seguir jugando, mini juegos, biblioteca y ofertas -----
function buildGamesStage(box) {
  const sec = (title, btn) => el('div', { class: 'gx-sec' }, el('b', { text: title }), btn || null);
  const link = (text, fn) => Object.assign(el('button', { class: 'text-btn', text }), { onclick: fn });
  box.replaceChildren(
    el('div', { class: 'gx-top' },
      el('div', { class: 'gx-hero', id: 'gx-hero' }),
      el('section', { class: 'sx-card gx-minis-card' }, sec('Mini juegos', link('Sala de juegos', () => openArcade('home'))), el('div', { class: 'gx-minis', id: 'gx-minis' }))),
    sec('Tu biblioteca', link('Ver todos', () => openArcade('lib'))),
    el('div', { class: 'gx-lib', id: 'gx-lib' }),
    sec('Ofertas en Steam', link('Ver más', () => api.openUrl('https://store.steampowered.com/specials'))),
    el('div', { class: 'gx-row', id: 'gx-steam' }),
    el('div', { class: 'gx-two' },
      el('section', {}, sec('Gratis en Epic Games', link('Ver en Epic', () => api.openUrl('https://store.epicgames.com/es-ES/free-games'))), el('div', { class: 'gx-row', id: 'gx-epic' })),
      el('section', {}, sec('Xbox', null), el('div', { class: 'gx-xbox' },
        xboxLink('Ofertas de Xbox', 'Descuentos de la semana en la tienda', 'https://www.xbox.com/es-AR/promotions/sales/sales-and-specials'),
        xboxLink('Game Pass', 'Lo que llega y lo que se va', 'https://www.xbox.com/es-AR/xbox-game-pass/games'),
        xboxLink('Abrir la app de Xbox', 'Tu biblioteca y Game Pass', null)))));
  refreshGamesStage();
  renderDeals();
  loadDeals(false);
}
function xboxLink(t, d, url) {
  const b = el('button', { class: 'xb-link' }, el('span', { class: 'xb-ico' }, svg('<circle cx="12" cy="12" r="9"/><path d="M6.5 6.5c2.5 1.5 4.3 3.6 5.5 5.5 1.2-1.9 3-4 5.5-5.5M5.5 17c1.5-3 3.8-5.3 6.5-7 2.7 1.7 5 4 6.5 7"/>')), el('span', {}, el('b', { text: t }), el('small', { text: d })));
  b.onclick = () => (url ? api.openUrl(url) : api.launchSpecial('xbox-app'));
  return b;
}
function refreshGamesStage() {
  const hero = $('#gx-hero');
  if (!hero) return;
  const all = gameList();
  const top = all.find(x => x.last);
  if (top) {
    const play = el('button', { class: 'ar-play', text: '▶ Jugar' });
    play.onclick = (e) => { e.stopPropagation(); playGame(top); };
    const card = el('div', { class: 'g-hero-card gx-card ' + top.src },
      gameBanner(top),
      el('div', { class: 'g-hero-info' }, el('span', { class: 'g-hero-k', text: 'Seguir jugando' }), el('span', { class: 'g-hero-n', text: top.name }),
        el('span', { class: 'g-hero-s', text: [libName(top.src), playedText(top.minutes), `última vez ${ago(top.last)}`].filter(Boolean).join(' · ') })), play);
    card.onclick = () => playGame(top);
    if (hero.dataset.k !== top.key + top.last) { hero.dataset.k = top.key + top.last; hero.replaceChildren(card); }
  } else if (hero.dataset.k !== 'none') {
    hero.dataset.k = 'none';
    const b = el('button', { class: 'ar-play', text: 'Sala de juegos' }); b.onclick = () => openArcade('home');
    hero.replaceChildren(el('div', { class: 'g-hero-card gx-card empty' }, el('div', { class: 'g-hero-info' }, el('span', { class: 'g-hero-k', text: 'Juegos' }), el('span', { class: 'g-hero-n', text: '¿Una partidita?' }), el('span', { class: 'g-hero-s', text: all.length ? 'Elegí de tu biblioteca o un mini juego.' : 'Probá un mini juego mientras tanto.' })), b));
  }
  const minis = $('#gx-minis');
  if (!minis.childElementCount) minis.replaceChildren(...MINI().map(g => {
    const art = el('span', { class: 'gm-art' }); art.innerHTML = g.art;
    const b = el('button', { class: 'gm', style: `--gc:${g.c}`, title: g.d }, art, el('span', { text: g.n }));
    b.onclick = () => openArcade('game', g.id);
    return b;
  }));
  const lib = $('#gx-lib');
  const list = all.slice(0, 16);
  const sig = list.map(x => x.key + x.last).join();
  if (lib.dataset.sig !== sig) {
    lib.dataset.sig = sig;
    lib.replaceChildren(...(list.length ? list.map(arCover) : [el('p', { class: 'gx-none', text: 'Cuando instales juegos de Steam o Xbox aparecen acá.' })]));
  }
}
async function loadDeals(force) {
  const epicParse = (t) => {
    const j = JSON.parse(t);
    const els = (((j.data || {}).Catalog || {}).searchStore || {}).elements || [];
    const now = Date.now();
    const out = [];
    for (const g of els) {
      const pr = g.promotions || {};
      const offer = (arr) => { for (const p of arr || []) for (const o of p.promotionalOffers || []) if (o.discountSetting && o.discountSetting.discountPercentage === 0) return o; return null; };
      const curO = offer(pr.promotionalOffers), next = offer(pr.upcomingPromotionalOffers);
      const o = curO || next;
      if (!o) continue;
      const img = (g.keyImages || []).find(k => k.type === 'OfferImageWide') || (g.keyImages || []).find(k => k.type === 'DieselStoreFrontWide') || (g.keyImages || []).find(k => k.type === 'Thumbnail') || (g.keyImages || [])[0];
      const slug = (g.catalogNs && g.catalogNs.mappings && g.catalogNs.mappings[0] && g.catalogNs.mappings[0].pageSlug) || (g.offerMappings && g.offerMappings[0] && g.offerMappings[0].pageSlug) || g.productSlug || g.urlSlug || '';
      out.push({ title: g.title, img: img ? img.url : '', url: slug ? `https://store.epicgames.com/es-ES/p/${String(slug).replace(/\/home$/, '')}` : 'https://store.epicgames.com/es-ES/free-games',
        now: !!curO && Date.parse(o.startDate) <= now, start: Date.parse(o.startDate) || 0, end: Date.parse(o.endDate) || 0 });
    }
    return out.length ? out.sort((a, b) => (b.now - a.now) || a.start - b.start) : null;
  };
  const steamParse = (t) => {
    const j = JSON.parse(t);
    const items = ((j.specials || {}).items || []).filter(x => x.discount_percent > 0);
    const seen = new Set();
    return items.filter(x => !seen.has(x.id) && seen.add(x.id)).slice(0, 10).map(x => ({ id: x.id, name: x.name, pct: x.discount_percent, was: x.original_price, now: x.final_price, cur: x.currency || 'USD', img: x.large_capsule_image || x.header_image || '' }));
  };
  const gpParse = (t) => {
    const j = JSON.parse(t);
    if (!Array.isArray(j)) return null;
    const out = j.filter(x => x && x.title && x.status !== 'Expired').slice(0, 8).map(x => ({
      title: String(x.title).replace(/\s*\((Epic Games|Epic)[^)]*\)\s*Giveaway$/i, '').replace(/\s*Giveaway$/i, ''),
      img: x.image || x.thumbnail || '', url: x.open_giveaway_url || x.gamerpower_url || 'https://store.epicgames.com/es-ES/free-games',
      now: true, start: Date.parse(x.published_date) || 0, end: x.end_date && x.end_date !== 'N/A' ? Date.parse(x.end_date.replace(' ', 'T')) || 0 : 0 }));
    return out.length ? out : null;
  };
  const epicTask = (async () => {
    const c = S.cache['deals:epic'];
    if (!force && c && Date.now() - c.at < 180 * 60000) return;
    if (!api.dealsEpic) return cached('deals:epic', 180, 'https://store-site-backend-static.epicgames.com/freeGamesPromotions?locale=es-ES&country=AR&allowCountries=AR', epicParse, force);
    const r = await safeCall(() => api.dealsEpic());
    if (!r || !r.ok) return;
    let data = null;
    try { data = r.kind === 'gp' ? gpParse(r.text) : epicParse(r.text); } catch {}
    if (data) { S.cache['deals:epic'] = { at: Date.now(), data }; save(); }
  })();
  await Promise.all([
    epicTask,
    cached('deals:steam', 120, 'https://store.steampowered.com/api/featuredcategories?cc=ar&l=spanish', steamParse, force)
  ]);
  ui.dealsTried = true;
  renderDeals();
}
function renderDeals() {
  const ep = $('#gx-epic'), st = $('#gx-steam');
  if (!ep) return;
  const e = (S.cache['deals:epic'] || {}).data, s2 = (S.cache['deals:steam'] || {}).data;
  const dm = (ts) => fmt(new Date(ts), { day: 'numeric', month: 'short' }).replace('.', '');
  const failed = (what, url) => el('div', { class: 'gx-none' }, ui.dealsTried ? `No se pudo cargar ${what} ahora. ` : 'Cargando… ', ui.dealsTried ? Object.assign(el('button', { class: 'text-btn', text: 'Abrir la página' }), { onclick: () => api.openUrl(url) }) : null);
  ep.replaceChildren(...(e && e.length ? e.slice(0, 4).map(g => {
    const b = el('button', { class: 'deal-card' + (g.now ? ' now' : ''), title: g.title },
      el('span', { class: 'dc-img' }, g.img ? el('img', { src: g.img, alt: '', loading: 'lazy' }) : null, el('span', { class: 'dc-badge' + (g.now ? ' free' : ''), text: g.now ? 'GRATIS' : 'PRONTO' })),
      el('b', { text: g.title }),
      el('span', { class: 'dc-sub', text: g.now ? (g.end ? `Gratis hasta el ${dm(g.end)}` : 'Gratis por tiempo limitado') : `Desde el ${dm(g.start)}` }));
    b.onclick = () => api.openUrl(g.url);
    return b;
  }) : [failed('los juegos gratis de Epic', 'https://store.epicgames.com/es-ES/free-games')]));
  const money2 = (c, cur) => (cur === 'USD' ? 'US$ ' : cur + ' ') + (c / 100).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  st.replaceChildren(...(s2 && s2.length ? s2.slice(0, 10).map(g => {
    const b = el('button', { class: 'deal-card', title: g.name },
      el('span', { class: 'dc-img' }, g.img ? el('img', { src: g.img, alt: '', loading: 'lazy' }) : null, el('span', { class: 'dc-badge off', text: `-${g.pct}%` })),
      el('b', { text: g.name }),
      el('span', { class: 'dc-price' }, el('s', { text: money2(g.was, g.cur) }), el('b', { text: money2(g.now, g.cur) })));
    b.onclick = () => api.openUrl(`https://store.steampowered.com/app/${g.id}/`);
    return b;
  }) : [failed('las ofertas de Steam', 'https://store.steampowered.com/specials')]));
}

// ----- Redes: correo, WhatsApp y accesos a tus redes -----
function buildRedes(box) {
  const mail = el('section', { class: 'sx-card rx-mail' },
    el('div', { class: 'sx-h' }, svg('<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/>'), el('b', { id: 'rx-mail-t', text: 'Correo' }), el('span', { class: 'spacer' }),
      Object.assign(el('button', { class: 'icon-btn sm', title: 'Actualizar', 'aria-label': 'Actualizar' }, svg('<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>')), { onclick: () => loadMail(true).then(renderRedesMail) }),
      Object.assign(el('button', { class: 'text-btn', text: 'Abrir Gmail' }), { onclick: () => { const a = acct(); if (a) api.google.openMail(a.email); else api.openUrl('https://mail.google.com'); } })),
    el('div', { class: 'rx-list', id: 'rx-list' }),
    el('div', { class: 'rx-read', id: 'rx-read', hidden: true }));
  const wa = el('section', { class: 'sx-card rx-wa' },
    el('div', { class: 'sx-h' }, brandLogo('whatsapp.com', 'chat', 'rx-logo'), el('b', { text: 'WhatsApp' }), el('span', { class: 'spacer' }),
      Object.assign(el('button', { class: 'icon-btn sm', title: 'Letra más chica', 'aria-label': 'Achicar WhatsApp' }, svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M8 11h6"/>')), { onclick: () => { S.settings.waZoom = Math.max(0.6, Math.round(((S.settings.waZoom || 1) - 0.1) * 10) / 10); save(); toast(`WhatsApp al ${Math.round(S.settings.waZoom * 100)}% del tamaño justo`); } }),
      Object.assign(el('button', { class: 'icon-btn sm', title: 'Letra más grande', 'aria-label': 'Agrandar WhatsApp' }, svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M8 11h6M11 8v6"/>')), { onclick: () => { S.settings.waZoom = Math.min(1.5, Math.round(((S.settings.waZoom || 1) + 0.1) * 10) / 10); save(); toast(`WhatsApp al ${Math.round(S.settings.waZoom * 100)}% del tamaño justo`); } }),
      Object.assign(el('button', { class: 'icon-btn sm', title: 'Recargar', 'aria-label': 'Recargar WhatsApp' }, svg('<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>')), { onclick: () => api.waReload && api.waReload() }),
      Object.assign(el('button', { class: 'text-btn', text: 'Abrir la app' }), { onclick: () => { const n = SOCIALS.find(x => x.id === 'whatsapp'); if (n) openSocial(n); } })),
    el('div', { class: 'rx-wa-slot', id: 'rx-wa-slot' },
      el('div', { class: 'rx-wa-ph' }, svg(GLYPH.chat), el('b', { text: api.waBounds ? 'Cargando WhatsApp…' : 'WhatsApp se ve en la app instalada' }),
        el('span', { text: 'La primera vez escaneá el código con tu celular: WhatsApp > Dispositivos vinculados > Vincular un dispositivo.' }))));
  const nets = el('section', { class: 'sx-card rx-nets', id: 'rx-nets', 'aria-label': 'Tus redes' },
    el('div', { class: 'sx-h' }, svg('<path d="M8 12h8M12 8v8"/><circle cx="12" cy="12" r="9"/>'), el('b', { text: 'Tus redes' }), el('span', { class: 'spacer' }),
      Object.assign(el('button', { class: 'icon-btn sm rx-pen', id: 'rx-edit', title: 'Elegir qué redes ver', 'aria-label': 'Elegir qué redes ver' }), { onclick: () => { ui.rxEdit = !ui.rxEdit; renderRedesNets(); } })),
    el('div', { class: 'rx-grid', id: 'rx-grid' }));
  box.replaceChildren(wa, mail, nets);
  renderRedesMail(); renderRedesNets();
  if (acct()) loadMail(false).then(renderRedesMail);
  requestAnimationFrame(syncWa);
}
function renderRedesNets() {
  const grid = $('#rx-grid');
  if (!grid) return;
  const chosen = S.settings.socials || SOCIAL_DEFAULT;
  const editing = !!ui.rxEdit;
  const pen = $('#rx-edit'), card = $('#rx-nets');
  if (pen) { pen.className = editing ? 'text-btn rx-pen' : 'icon-btn sm rx-pen'; pen.replaceChildren(editing ? document.createTextNode('Listo') : svg('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>')); pen.title = editing ? 'Terminar' : 'Elegir qué redes ver'; }
  if (card) { card.classList.toggle('slim', !editing); card.classList.toggle('wide', editing); }
  grid.classList.toggle('editing', editing);
  const list = editing ? SOCIALS : socialChosen();
  grid.replaceChildren(...list.map(net => {
    const on = chosen.includes(net.id);
    const b = el('button', { class: 'rx-net' + (editing && !on ? ' off' : ''), style: `--sc:${net.c}`, title: editing ? (on ? 'Tocá para sacarla' : 'Tocá para sumarla') : `Abrir ${net.n}` },
      brandLogo(LOGO_DOMAIN[net.id] || net.d, net.g, 'rx-ico'), el('span', { text: net.n }), editing ? el('i', { text: on ? '✓' : '+' }) : null);
    b.onclick = () => {
      if (!editing) return openSocial(net);
      const cur = (S.settings.socials || SOCIAL_DEFAULT).slice();
      const i = cur.indexOf(net.id);
      if (i >= 0) cur.splice(i, 1); else cur.push(net.id);
      S.settings.socials = cur; save(); renderRedesNets(); renderSocial(); renderPeeks();
    };
    return b;
  }));
}
function renderRedesMail() {
  const list = $('#rx-list');
  if (!list) return;
  const a = acct();
  const c = S.cache['gmail:' + S.activeMode];
  const data = c && c.data;
  setText('rx-mail-t', a ? `Correo · ${a.email}` : 'Correo');
  if (!a) {
    const b = el('button', { class: 'btn', text: 'Vincular cuenta de Google' }); b.onclick = () => linkGoogle(S.activeMode);
    list.replaceChildren(el('div', { class: 'rx-empty' }, el('b', { text: 'Tus mails, acá' }), el('span', { text: 'Vinculá tu Gmail para ver y leer los mails sin leer.' }), b));
    return;
  }
  if (!data) { list.replaceChildren(el('p', { class: 'gx-none', text: c && (c.error || c.code) ? 'No se pudieron traer los mails. Tocá actualizar.' : 'Cargando mails…' })); return; }
  if (!data.messages.length) { list.replaceChildren(el('div', { class: 'rx-empty' }, el('b', { text: 'Bandeja al día' }), el('span', { text: 'No tenés mails sin leer.' }))); return; }
  list.replaceChildren(...data.messages.slice(0, 30).map(m => {
    const d = new Date(m.date);
    const row = el('button', { class: 'rx-m' }, mailAvatar(m),
      el('span', { class: 'rx-m-b' }, el('span', { class: 'rx-m-top' }, el('b', { text: (m.from || '').replace(/<.*>/, '').replace(/"/g, '').trim() || m.addr }), el('small', { text: ymd(d) === ymd(new Date()) ? `${pad(d.getHours())}:${pad(d.getMinutes())}` : fmt(d, { day: 'numeric', month: 'short' }) })),
        el('span', { class: 'rx-m-s', text: m.subject || '(sin asunto)' }), el('span', { class: 'rx-m-p', text: m.snippet || '' })));
    row.onclick = () => openRedesMail(m.id);
    return row;
  }));
}
async function openRedesMail(id) {
  const box = $('#rx-read');
  $('#rx-list').hidden = true; box.hidden = false;
  const back = el('button', { class: 'text-btn', text: '← Volver' }); back.onclick = () => { box.hidden = true; $('#rx-list').hidden = false; };
  box.replaceChildren(el('div', { class: 'rx-bar' }, back), el('p', { class: 'gx-none', text: 'Abriendo…' }));
  const r = await safeCall(() => G.message(S.activeMode, id));
  if (!r || !r.ok) { box.replaceChildren(el('div', { class: 'rx-bar' }, back), el('p', { class: 'gx-none', text: 'No se pudo abrir el mail.' })); return; }
  const m = r.data;
  const read = el('button', { class: 'text-btn', text: 'Marcar como leído' });
  read.onclick = async () => { if (await markMailRead(id)) { back.click(); renderRedesMail(); } };
  const frame = el('iframe', { class: 'rx-frame', title: 'Mail', sandbox: 'allow-popups allow-popups-to-escape-sandbox' });
  frame.srcdoc = mailFrameDoc(m, false);
  box.replaceChildren(el('div', { class: 'rx-bar' }, back, el('span', { class: 'spacer' }), m.unread ? read : null),
    el('b', { class: 'rx-subj', text: m.subject }), el('span', { class: 'rx-from', text: m.from }), frame);
}
// WhatsApp va en una "ventanita" nativa encima del tablero: la escondemos cuando algo se le pone adelante
function waCovered() {
  return stageKind() !== 'redes' || document.hidden || !!W.open || $('#drawer').classList.contains('on') || !!document.querySelector('dialog[open]')
    || !$('#arcade').hidden || !$('#search').hidden || !$('#notif-panel').hidden || !$('#brief').hidden || !$('#folder-pop').hidden
    || ($('#win-ctx') && !$('#win-ctx').hidden) || !$('#mpop').hidden || !$('#fx').hidden || !$('#sm').hidden || document.documentElement.classList.contains('desk-edit');
}
let waLast = '';
function syncWa() {
  if (!api.waBounds || !S) return;
  const slot = $('#rx-wa-slot');
  if (!slot || waCovered()) { if (waLast !== 'hide') { waLast = 'hide'; api.waBounds({ show: false }); } return; }
  const r = slot.getBoundingClientRect();
  const key = [r.x, r.y, r.width, r.height].map(Math.round).join(',') + '|' + (S.settings.waZoom || 1);
  if (key === waLast || r.width < 50 || r.height < 50) return;
  waLast = key;
  api.waBounds({ show: true, x: r.x, y: r.y, w: r.width, h: r.height, adj: S.settings.waZoom || 1 });
}
setInterval(syncWa, 250);

// ---------- Espacio libre del escritorio (Casa, Trabajo y tableros comunes) ----------
const ZONE_MODS = [
  { id: 'app', n: 'Tu programa', d: 'Un programa tuyo (como Recepciones) en grande, adentro del tablero', w: 4, ico: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M7 6.5h.01M10 6.5h.01M8 13h8M8 16h5"/>' },
  { id: 'dia', n: 'Tu día', d: 'Las próximas 12 horas: clima, eventos y lo que vence hoy', w: 2.1, ico: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>' },
  { id: 'semana', n: 'Esta semana', d: 'Siete días con el clima, tus eventos y tus tareas', w: 2.3, ico: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>' },
  { id: 'notas', n: 'Notas pegadas', d: 'Papelitos de colores para lo que no querés olvidar', w: 1.3, ico: '<path d="M5 4h14v11l-5 5H5z"/><path d="M14 20v-5h5"/>' },
  { id: 'fotos', n: 'Marco de fotos', d: 'Las fotos de una carpeta tuya, pasando de a una', w: 1.25, ico: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>' },
  { id: 'tareas', n: 'Para hoy', d: 'Las tareas de hoy y las atrasadas, para tildar al toque', w: 1.15, ico: '<path d="M9 11l2 2 4-4"/><rect x="4" y="4" width="16" height="16" rx="3"/>' },
  { id: 'mes', n: 'Calendario', d: 'El mes entero con puntitos en los días con eventos', w: 1.2, ico: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>' },
  { id: 'cuenta', n: 'Cuenta regresiva', d: 'Los días que faltan para lo que esperás', w: 1.2, ico: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9.5 3h5"/>' },
  { id: 'dolar', n: 'Dólar', d: 'Blue, oficial, MEP y tarjeta, al día', w: 1.1, ico: '<path d="M12 3v18M16.5 7.5C16 6 14.3 5 12 5c-2.8 0-4.5 1.4-4.5 3.3 0 4.4 9 2.4 9 7 0 2-1.9 3.4-4.5 3.4-2.4 0-4.2-1.1-4.6-2.8"/>' },
  { id: 'mundo', n: 'Relojes del mundo', d: 'La hora en otras ciudades', w: 1.1, ico: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>' },
  { id: 'frase', n: 'Frase del día', d: 'Una frase linda para arrancar, en grande', w: 1.3, ico: '<path d="M7 7h4v4c0 3-2 5-4 6M14 7h4v4c0 3-2 5-4 6"/>' },
  { id: 'super', n: 'Supermercado', d: 'La lista de lo que falta en casa', w: 1.3, ico: '<circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/><path d="M3 4h2l2.5 11h11l2-8H7"/>' },
  { id: 'escritorio', n: 'Escritorio de Windows', d: 'Los archivos y carpetas de tu escritorio de Windows', w: 1.6, ico: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4M7 8h3v3H7zM14 8h3v3h-3z"/>' },
  { id: 'calc', n: 'Calculadora', d: 'Cuentas rápidas: sumar, restar, multiplicar, dividir y porcentaje', w: 1.15, ico: '<rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8 7h8M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 15.5h.01M12 15.5h.01M15.5 15.5h.01M8.5 18.5h.01M12 18.5h3.5"/>' },
  { id: 'pc', n: 'La compu', d: 'Procesador, memoria, disco y red en vivo', w: 1.3, ico: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>' }
];
const ZONE_MAX = 3;
const STICKY_COLORS = ['#ffe58a', '#ffb8c9', '#a9dcff', '#bdf0b2', '#d9c6ff', '#ffcf9e'];
function zoneMods(m = S.activeMode) {
  const md = S.modes[m];
  if (!md) return [];
  if (!Array.isArray(md.zone)) md.zone = m === 'casa' ? ['semana', 'notas', 'fotos'] : m === 'trabajo' ? ['dia', 'tareas', 'notas'] : [];
  if (m === 'trabajo' && !S.settings.dockIntro) { S.settings.dockIntro = true; md.zone = md.zone.includes('tareas') ? ['app', 'tareas'] : ['app']; save(); }
  return md.zone.filter(id => ZONE_MODS.some(z => z.id === id)).slice(0, ZONE_MAX);
}
function zoneOn(id) { return !stageKind() && zoneMods().includes(id); }
function znCard(id, title, ...kids) {
  const z = ZONE_MODS.find(x => x.id === id);
  return el('section', { class: 'zn zn-' + id, 'data-zn': id, 'aria-label': z.n },
    el('div', { class: 'zn-h' }, svg(z.ico), el('b', { text: title || z.n })), ...kids);
}
function renderZone() {
  const box = $('#zone');
  if (!box || !S) return;
  if (stageKind()) { box.hidden = true; return; }
  box.hidden = false;
  const mods = zoneMods();
  const editing = !!ui.zoneEdit;
  box.classList.toggle('empty', !mods.length && !editing);
  const kids = [];
  if (editing) {
    const chips = ZONE_MODS.map(z => {
      const on = mods.includes(z.id);
      const b = el('button', { class: 'zn-chip' + (on ? ' on' : ''), title: z.d, 'aria-pressed': String(on) }, svg(z.ico), el('span', { text: z.n }), el('i', { text: on ? '✓' : '+' }));
      b.onclick = () => {
        const cur = zoneMods().slice();
        const i = cur.indexOf(z.id);
        if (i >= 0) cur.splice(i, 1);
        else if (cur.length >= ZONE_MAX) return toast(`Entran hasta ${ZONE_MAX}. Sacá uno para sumar “${z.n}”.`);
        else cur.push(z.id);
        M().zone = cur; save(); renderZone(); renderZonePick();
      };
      return b;
    });
    const done = el('button', { class: 'btn', text: 'Listo' }); done.onclick = () => { ui.zoneEdit = false; renderZone(); };
    kids.push(el('div', { class: 'zn-edit' }, el('span', { class: 'zn-edit-t', text: `Qué mostrar en este espacio (hasta ${ZONE_MAX}):` }), ...chips, el('span', { class: 'spacer' }), done));
  }
  if (mods.length) {
    const grid = el('div', { class: 'zn-grid', style: `grid-template-columns:${mods.map(id => `minmax(0, ${ZONE_MODS.find(z => z.id === id).w}fr)`).join(' ')}` });
    for (const id of mods) { try { grid.append(ZONE_RENDER[id]()); } catch (e) { console.error(e); } }
    kids.push(grid);
  } else if (!editing) {
    const b = el('button', { class: 'zn-empty' }, svg('<path d="M12 5v14M5 12h14"/>'), el('span', { text: 'Usar este espacio: tu semana, notas pegadas, fotos…' }));
    b.onclick = () => { ui.zoneEdit = true; renderZone(); };
    kids.push(b);
  }
  if (mods.length && !editing) {
    const ed = el('button', { class: 'text-btn zn-cfg', title: 'Elegir qué se muestra en este espacio' }, svg('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>'), el('span', { text: 'Cambiar' }));
    ed.onclick = () => { ui.zoneEdit = true; renderZone(); };
    kids.push(ed);
  }
  box.replaceChildren(...kids);
  if ((mods.includes('dia') || mods.includes('semana')) && !prData()) loadZoneWx();
}
// vuelve a dibujar solo algunos módulos (para no pisar lo que estás escribiendo en las notas)
function zoneRefresh(...ids) {
  if (!S || stageKind()) return;
  for (const id of ids) {
    const old = document.querySelector(`#zone [data-zn="${id}"]`);
    if (old) { try { old.replaceWith(ZONE_RENDER[id]()); } catch (e) { console.error(e); } }
  }
}
let zoneWxBusy = false;
async function loadZoneWx(force) {
  if (zoneWxBusy) return;
  zoneWxBusy = true;
  try {
    const w = M().weather;
    await cached(`pr:${w.lat.toFixed(3)},${w.lon.toFixed(3)}`, 30, prUrl(w), (t) => { const j = JSON.parse(t); return j.hourly && j.daily ? { hourly: j.hourly, daily: j.daily } : null; }, force);
  } finally { zoneWxBusy = false; }
  zoneRefresh('dia', 'semana');
}
function zoneTasksOn(date) { return M().tasks.filter(t => !t.done && t.due === date); }

// --- Tu día: línea de tiempo de las próximas horas
function znDia() {
  const now = new Date();
  const start = new Date(now); start.setMinutes(0, 0, 0);
  const SPAN = 12;
  const end = new Date(+start + SPAN * 36e5);
  const d = prData();
  const hours = el('div', { class: 'zd-hours' });
  for (let i = 0; i < SPAN; i++) {
    const t = new Date(+start + i * 36e5);
    let ico = null, temp = '', rain = '';
    if (d && d.hourly) {
      const k = d.hourly.time.findIndex(x => +new Date(x) === +t);
      if (k >= 0) {
        const [desc, ic] = wmo(d.hourly.weather_code[k], d.hourly.is_day[k] !== 0);
        ico = el('span', { class: 'zd-ic', title: desc }, svg(WX[ic]));
        temp = `${Math.round(d.hourly.temperature_2m[k])}°`;
        const p = d.hourly.precipitation_probability ? d.hourly.precipitation_probability[k] : null;
        rain = p != null && p >= 20 ? `${p}%` : '';
      }
    }
    hours.append(el('div', { class: 'zd-h' + (i === 0 ? ' now' : '') + (t.getHours() === 0 ? ' midnight' : '') },
      el('span', { class: 'zd-t', text: i === 0 ? 'Ahora' : `${pad(t.getHours())} h` }), ico || el('span', { class: 'zd-ic' }),
      el('b', { text: temp }), el('span', { class: 'zd-rain', text: rain })));
  }
  const evs = allEvents().filter(e => e.time).map(e => ({ e, ts: e.startTs || +new Date(`${e.date}T${e.time}`) }))
    .filter(x => x.ts >= +start && x.ts < +end).sort((a, b) => a.ts - b.ts);
  const track = el('div', { class: 'zd-track' });
  const lanes = [];
  for (const { e, ts } of evs) {
    const left = ((ts - start) / (SPAN * 36e5)) * 100;
    let lane = lanes.findIndex(l => left - l > 17);
    if (lane < 0) lane = lanes.length;
    lanes[lane] = left;
    if (lane > 2) continue;
    const chip = el('button', { class: 'zd-ev' + (e.g ? ' g' : ''), style: `left:${left}%;top:${lane * 30}px`, title: `${e.time} · ${e.title}` },
      el('b', { text: e.time }), el('span', { text: e.title }));
    chip.onclick = () => { ui.sel = e.date; const dd = parseYmd(e.date); ui.calMonth = new Date(dd.getFullYear(), dd.getMonth(), 1); renderAgenda(); openWidget('agenda', true); };
    track.append(chip);
  }
  if (!evs.length) track.append(el('span', { class: 'zd-free', text: 'Sin eventos en las próximas horas' }));
  const today = ymd(now);
  const allDay = allEvents().filter(e => e.date === today && !e.time);
  const due = M().tasks.filter(t => !t.done && t.due && t.due <= today);
  const extra = el('div', { class: 'zd-extra' },
    allDay.map(e => el('span', { class: 'zd-tag', text: e.title })),
    due.length ? el('span', { class: 'zd-tag task', text: due.length === 1 ? `Tarea: ${due[0].text}` : `${due.length} tareas para hoy` }) : null);
  const later = allEvents().map(e => ({ e, ts: e.time ? (e.startTs || +new Date(`${e.date}T${e.time}`)) : +parseYmd(e.date) }))
    .filter(x => x.ts >= +end || (!x.e.time && x.e.date > today)).sort((a, b) => a.ts - b.ts).slice(0, 4);
  const next = later.length ? el('div', { class: 'zd-next' }, el('span', { class: 'zd-next-t', text: 'Después' }),
    el('ul', {}, later.map(({ e }) => {
      const dd = parseYmd(e.date);
      const when = e.date === ymd(addDays(now, 1)) ? 'Mañana' : fmt(dd, { weekday: 'short', day: 'numeric' }).replace('.', '');
      const li = el('li', { title: e.title }, el('b', { text: when + (e.time ? ` ${e.time}` : '') }), el('span', { text: e.title }));
      li.onclick = () => { ui.sel = e.date; ui.calMonth = new Date(dd.getFullYear(), dd.getMonth(), 1); renderAgenda(); openWidget('agenda', true); };
      return li;
    }))) : null;
  return znCard('dia', null,
    el('div', { class: 'zd-body' }, hours, track, (allDay.length || due.length) ? extra : null, next));
}

// --- Esta semana: siete columnas
function znSemana() {
  const d = prData();
  const cols = el('div', { class: 'zw-days' });
  const today = new Date();
  for (let i = 0; i < 7; i++) {
    const day = addDays(today, i);
    const key = ymd(day);
    const evs = eventsOn(key);
    const tasks = zoneTasksOn(key);
    let wx = null;
    if (d && d.daily) {
      const k = d.daily.time.indexOf(key);
      if (k >= 0) {
        const [desc, ic] = wmo(d.daily.weather_code[k]);
        const p = d.daily.precipitation_probability_max ? d.daily.precipitation_probability_max[k] : null;
        wx = el('span', { class: 'zw-wx', title: desc + (p >= 30 ? ` · lluvia ${p}%` : '') }, svg(WX[ic]),
          el('b', { text: `${Math.round(d.daily.temperature_2m_max[k])}°` }), el('small', { text: `${Math.round(d.daily.temperature_2m_min[k])}°` }));
      }
    }
    const items = [
      ...evs.map(e => el('li', { class: 'zw-ev' + (e.g ? ' g' : ''), title: (e.time ? e.time + ' · ' : '') + e.title }, e.time ? el('b', { text: e.time }) : null, el('span', { text: e.title }))),
      ...tasks.map(t => el('li', { class: 'zw-task', title: 'Tarea: ' + t.text }, svg('<rect x="4" y="4" width="16" height="16" rx="4"/>'), el('span', { text: t.text })))
    ];
    const MAXI = 4;
    const col = el('button', { class: 'zw-day' + (i === 0 ? ' today' : '') + ([0, 6].includes(day.getDay()) ? ' we' : ''), title: 'Ver este día en la agenda' },
      el('span', { class: 'zw-n' }, el('b', { text: i === 0 ? 'Hoy' : i === 1 ? 'Mañana' : fmt(day, { weekday: 'short' }).replace('.', '') }), el('small', { text: String(day.getDate()) })),
      wx,
      el('ul', { class: 'zw-list' }, items.slice(0, MAXI), items.length > MAXI ? el('li', { class: 'zw-more', text: `+${items.length - MAXI} más` }) : null,
        !items.length ? el('li', { class: 'zw-none', text: '—' }) : null));
    col.onclick = () => { ui.sel = key; ui.calMonth = new Date(day.getFullYear(), day.getMonth(), 1); renderAgenda(); openWidget('agenda', true); };
    cols.append(col);
  }
  return znCard('semana', null, cols);
}

// --- Notas pegadas
function stickies() { const m = M(); if (!Array.isArray(m.stickies)) m.stickies = []; return m.stickies; }
let stickyT = 0;
function znNotas() {
  const list = stickies();
  const wrap = el('div', { class: 'zs-wall' });
  list.forEach((n, i) => {
    const ta = el('textarea', { class: 'zs-text', 'aria-label': 'Nota pegada', maxlength: '400', spellcheck: 'true', placeholder: 'Escribí acá…' });
    ta.value = n.text || '';
    ta.oninput = () => { n.text = ta.value; clearTimeout(stickyT); stickyT = setTimeout(save, 400); };
    const color = el('button', { class: 'zs-b', title: 'Cambiar el color', 'aria-label': 'Cambiar el color' }, svg('<circle cx="12" cy="12" r="6"/>'));
    color.onclick = () => { n.c = STICKY_COLORS[(STICKY_COLORS.indexOf(n.c) + 1) % STICKY_COLORS.length]; save(); zoneRefresh('notas'); };
    const del = el('button', { class: 'zs-b', title: 'Despegar (borrar)', 'aria-label': 'Borrar la nota' }, svg(ICON.x));
    del.onclick = () => {
      if (n.text && n.text.trim() && !confirm('¿Despegar esta nota? Se borra.')) return;
      list.splice(list.indexOf(n), 1); save(); zoneRefresh('notas');
    };
    wrap.append(el('div', { class: 'zs-note', style: `--nc:${n.c || STICKY_COLORS[0]};--rot:${[-1.6, 1.2, -.6, 1.8, -1.2, .7][i % 6]}deg` }, el('div', { class: 'zs-tools' }, color, del), ta));
  });
  if (list.length < 6) {
    const add = el('button', { class: 'zs-add', title: 'Pegar una nota nueva' }, svg('<path d="M12 5v14M5 12h14"/>'), list.length ? null : el('span', { text: 'Pegá una nota' }));
    add.onclick = () => {
      list.push({ id: uid(), text: '', c: STICKY_COLORS[list.length % STICKY_COLORS.length], at: Date.now() });
      save(); zoneRefresh('notas');
      const tas = $$('#zone .zs-text'); if (tas.length) tas[tas.length - 1].focus();
    };
    wrap.append(add);
  }
  return znCard('notas', null, wrap);
}

// --- Marco de fotos
const PHOTOS = { dir: '', list: [], i: 0, t: 0 };
async function photosLoad() {
  const dir = M().photoDir || '';
  if (dir === PHOTOS.dir && PHOTOS.list.length) return;
  PHOTOS.dir = dir; PHOTOS.list = [];
  if (!dir || !api.photos) return;
  const list = await safeCall(() => api.photos.list(dir));
  if (dir !== M().photoDir) return;
  PHOTOS.list = shuffle(list || []);
  PHOTOS.i = 0;
  zoneRefresh('fotos');
}
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function photoStep(n) {
  if (!PHOTOS.list.length) return;
  PHOTOS.i = (PHOTOS.i + n + PHOTOS.list.length) % PHOTOS.list.length;
  const fr = $('#zone .zf-frame');
  if (!fr) return;
  const img = el('img', { class: 'zf-img', alt: '', src: PHOTOS.list[PHOTOS.i] });
  img.onload = () => { fr.append(img); requestAnimationFrame(() => img.classList.add('in')); const olds = fr.querySelectorAll('.zf-img'); if (olds.length > 1) setTimeout(() => { for (const o of [...olds].slice(0, -1)) o.remove(); }, 900); };
  img.onerror = () => { PHOTOS.list.splice(PHOTOS.i, 1); };
}
async function pickPhotoDir() {
  if (!api.photos) return toast('El marco de fotos funciona en la app instalada');
  const r = await safeCall(() => api.photos.pick());
  if (!r) return;
  if (!r.list || !r.list.length) return toast('No encontré fotos en esa carpeta (JPG, PNG o WebP)');
  M().photoDir = r.dir; save();
  PHOTOS.dir = r.dir; PHOTOS.list = shuffle(r.list); PHOTOS.i = 0;
  zoneRefresh('fotos');
}
function znFotos() {
  const dir = M().photoDir;
  const change = el('button', { class: 'icon-btn sm', title: 'Elegir otra carpeta', 'aria-label': 'Elegir otra carpeta' }, svg('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'));
  change.onclick = pickPhotoDir;
  if (!dir || !PHOTOS.list.length) {
    if (dir && !PHOTOS.list.length) photosLoad();
    const pick = el('button', { class: 'zf-pick' }, svg(ZONE_MODS.find(z => z.id === 'fotos').ico),
      el('b', { text: dir ? 'Buscando tus fotos…' : 'Elegí una carpeta de fotos' }),
      el('span', { text: dir ? dir : 'Van pasando solas, de a una. Por ejemplo, la carpeta Imágenes.' }));
    pick.onclick = pickPhotoDir;
    return znCard('fotos', null, pick);
  }
  const frame = el('div', { class: 'zf-frame', title: 'Clic: siguiente · Doble clic: ver en la carpeta' });
  const first = el('img', { class: 'zf-img in', alt: '', src: PHOTOS.list[PHOTOS.i] });
  first.onerror = () => { PHOTOS.list.splice(PHOTOS.i, 1); photoStep(0); };
  frame.append(first);
  frame.onclick = () => photoStep(1);
  frame.ondblclick = () => api.photos && api.photos.show(PHOTOS.list[PHOTOS.i]);
  const prev = el('button', { class: 'zf-nav l', 'aria-label': 'Foto anterior' }, svg('<path d="m15 6-6 6 6 6"/>'));
  prev.onclick = (e) => { e.stopPropagation(); photoStep(-1); };
  const next = el('button', { class: 'zf-nav r', 'aria-label': 'Foto siguiente' }, svg('<path d="m9 6 6 6-6 6"/>'));
  next.onclick = (e) => { e.stopPropagation(); photoStep(1); };
  const card = znCard('fotos', null, el('div', { class: 'zf-wrap' }, frame, prev, next));
  card.querySelector('.zn-h').append(el('span', { class: 'spacer' }), change);
  return card;
}
setInterval(() => { if (!document.hidden && S && zoneOn('fotos') && !document.querySelector('#zone .zf-frame:hover')) photoStep(1); }, 25000);

// --- Escritorio de Windows: tus archivos de siempre, adentro de Base
const DESKF = { dir: '', items: null, at: 0, icons: new Map(), loading: false };
async function deskLoad(force) {
  if (!api.deskFiles || DESKF.loading || (!force && DESKF.items && Date.now() - DESKF.at < 20000)) return;
  DESKF.loading = true;
  const r = await safeCall(() => api.deskFiles());
  DESKF.loading = false;
  if (r && r.items) { DESKF.dir = r.dir; DESKF.items = r.items.sort((a, b) => (b.d - a.d) || a.n.localeCompare(b.n, 'es')); DESKF.at = Date.now(); zoneRefresh('escritorio'); }
}
function deskIcon(x, box) {
  const set = (u) => { if (u) box.replaceChildren(el('img', { src: u, alt: '', draggable: 'false' })); };
  if (DESKF.icons.has(x.p)) return set(DESKF.icons.get(x.p));
  box.replaceChildren(svg(x.d ? FX_ICO.dir : FX_ICO.file));
  if (!api.fx) return;
  const isImg = /^(jpe?g|png|gif|webp|bmp)$/i.test(x.x);
  (isImg ? api.fx.thumb(x.p).then(u => u || api.fx.icon(x.p)) : api.fx.icon(x.p)).then(u => { if (u) { DESKF.icons.set(x.p, u); set(u); } }).catch(() => {});
}
function deskMenu(e, x) {
  e.preventDefault();
  const m = $('#fx-ctx');
  const mk = (t, fn) => { const b = el('button', { class: 'fx-ctx-i', text: t }); b.onclick = () => { m.hidden = true; fn(); }; return b; };
  m.replaceChildren(el('span', { class: 'fx-ctx-h', text: x.n }),
    mk('Abrir', () => api.fx.open(x.p)),
    mk('Mostrar en la carpeta', () => api.fx.reveal(x.p)),
    mk('Abrir el Escritorio en Archivos', () => fxOpen(DESKF.dir)),
    x.pub ? null : mk('Mandar a la papelera', async () => { const err = await safeCall(() => api.fx.trash([x.p])); toast(err || `${x.n} fue a la papelera`); deskLoad(true); }));
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(e.clientX, innerWidth - r.width - 8) + 'px'; m.style.top = Math.min(e.clientY, innerHeight - r.height - 8) + 'px';
  const close = (ev) => { if (!ev.target.closest('#fx-ctx')) { m.hidden = true; document.removeEventListener('pointerdown', close, true); } };
  setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
}
function znEscritorio() {
  if (!DESKF.items) deskLoad(false);
  const open = el('button', { class: 'icon-btn sm', title: 'Abrir el Escritorio en Archivos', 'aria-label': 'Abrir el Escritorio en Archivos' }, svg('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'));
  open.onclick = () => fxOpen(DESKF.dir);
  const grid = el('div', { class: 'zd-grid' });
  const items = DESKF.items || [];
  for (const x of items) {
    const ico = el('span', { class: 'zd-ico' });
    deskIcon(x, ico);
    const b = el('button', { class: 'zd-it', title: x.n + (x.pub ? ' (escritorio compartido)' : '') }, ico, el('span', { class: 'zd-n', text: x.n }));
    b.ondblclick = () => api.fx.open(x.p);
    b.onkeydown = (e) => { if (e.key === 'Enter') api.fx.open(x.p); };
    b.oncontextmenu = (e) => deskMenu(e, x);
    b.draggable = true;
    grid.append(b);
  }
  const body = items.length ? grid : el('div', { class: 'zd-empty' }, el('b', { text: DESKF.items ? 'Tu escritorio está vacío' : 'Buscando…' }), el('span', { text: 'Arrastrá archivos acá (o a cualquier parte de Base) y se guardan en el Escritorio.' }));
  const card = znCard('escritorio', null, body);
  card.querySelector('.zn-h').append(el('span', { class: 'spacer' }), open);
  return card;
}
setInterval(() => { if (!document.hidden && S && zoneOn('escritorio')) deskLoad(true); }, 30000);

// --- Para hoy
function znTareas() {
  const today = ymd(new Date());
  const all = M().tasks;
  const items = sortTasks(all.filter(t => !t.done && ((t.due && t.due <= today) || (!t.due && t.prio))));
  const doneToday = all.filter(t => t.done && t.doneAt && ymd(new Date(t.doneAt)) === today).length;
  const list = el('ul', { class: 'zt-list' });
  for (const t of items.slice(0, 12)) {
    const c = el('input', { type: 'checkbox', class: 'check', 'aria-label': `Marcar “${t.text}” como hecha` });
    c.onchange = () => { t.done = c.checked; t.doneAt = t.done ? Date.now() : null; save(); setTimeout(() => { renderTasks(); renderSummary(); renderPeeks(); }, 260); };
    list.append(el('li', { class: 'zt-row' }, c, el('span', { class: 'zt-t', text: t.text }), t.due && t.due < today ? el('span', { class: 'chip late', text: 'Atrasada' }) : t.prio ? el('span', { class: 'prio-dot', title: 'Importante' }, svg(ICON.flag)) : null));
  }
  if (!items.length) list.append(el('li', { class: 'zt-none', text: doneToday ? `¡Listo por hoy! Terminaste ${doneToday}.` : 'Nada para hoy. Sumá algo abajo.' }));
  const input = el('input', { class: 'zt-in', placeholder: 'Algo para hoy + Enter', maxlength: '300', 'aria-label': 'Nueva tarea para hoy' });
  input.onkeydown = (e) => {
    if (e.key !== 'Enter' || !input.value.trim()) return;
    all.push({ id: uid(), text: input.value.trim(), done: false, prio: false, due: today, created: Date.now() });
    save(); renderTasks(); renderSummary(); renderPeeks();
    const z = $('#zone .zt-in'); if (z) z.focus();
  };
  const card = znCard('tareas', null, list, input);
  if (doneToday && items.length) card.querySelector('.zn-h').append(el('span', { class: 'spacer' }), el('small', { class: 'zt-done', text: `${doneToday} hecha${doneToday > 1 ? 's' : ''} hoy` }));
  return card;
}
// --- Calendario del mes
function znMes() {
  ui.znMonth = ui.znMonth || new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const first = ui.znMonth;
  const nav = (n) => { const b = el('button', { class: 'icon-btn sm', 'aria-label': n < 0 ? 'Mes anterior' : 'Mes siguiente' }, svg(n < 0 ? '<path d="m15 6-6 6 6 6"/>' : '<path d="m9 6 6 6-6 6"/>')); b.onclick = () => { ui.znMonth = new Date(first.getFullYear(), first.getMonth() + n, 1); zoneRefresh('mes'); }; return b; };
  const grid = el('div', { class: 'zm-grid' }, DOW.map(d => el('span', { class: 'zm-dow', text: d })));
  const offset = first.getDay();
  const start = addDays(first, -offset);
  const today = ymd(new Date());
  const evCount = {};
  for (const e of allEvents()) evCount[e.date] = (evCount[e.date] || 0) + 1;
  const taskDays = new Set(M().tasks.filter(t => !t.done && t.due).map(t => t.due));
  for (let i = 0; i < 42; i++) {
    const d = addDays(start, i);
    if (i >= 35 && d.getMonth() !== first.getMonth()) break;
    const key = ymd(d);
    const n = evCount[key] || 0;
    const b = el('button', { class: 'zm-d' + (d.getMonth() !== first.getMonth() ? ' out' : '') + (key === today ? ' today' : '') + ([0, 6].includes(d.getDay()) ? ' we' : '') + (n ? ' has' : '') + (n > 1 ? ' many' : ''),
      title: fmt(d, { weekday: 'long', day: 'numeric', month: 'long' }) + (n ? ` · ${n} evento${n > 1 ? 's' : ''}` : '') + (taskDays.has(key) ? ' · con tareas' : '') },
      el('span', { text: String(d.getDate()) }), el('i', {}, taskDays.has(key) ? el('b', { class: 'tk' }) : null));
    b.onclick = () => { ui.sel = key; ui.calMonth = new Date(d.getFullYear(), d.getMonth(), 1); renderAgenda(); openWidget('agenda', true); };
    grid.append(b);
  }
  const mt = fmt(first, { month: 'long', year: 'numeric' });
  const card = znCard('mes', mt.charAt(0).toUpperCase() + mt.slice(1), grid);
  card.querySelector('.zn-h').append(el('span', { class: 'spacer' }), nav(-1), nav(1));
  return card;
}

// --- Cuenta regresiva
function znCuenta() {
  const items = countdowns().filter(c => daysUntil(c.d) >= 0).sort((a, b) => daysUntil(a.d) - daysUntil(b.d));
  const list = el('div', { class: 'zc-list' });
  for (const c of items.slice(0, 4)) {
    const n = daysUntil(c.d);
    const total = Math.max(1, Math.round((parseYmd(c.d) - new Date(c.at || Date.now())) / 864e5));
    const pct = n <= 0 ? 100 : Math.min(100, Math.max(3, 100 - (n / total) * 100));
    const del = el('button', { class: 'icon-btn sm zc-x', title: 'Quitar', 'aria-label': `Quitar ${c.n}` }, svg(ICON.x));
    del.onclick = () => { const all = countdowns(); all.splice(all.indexOf(c), 1); save(); zoneRefresh('cuenta'); renderPeeks(); };
    list.append(el('div', { class: 'zc-it' + (n === 0 ? ' now' : '') },
      el('b', { class: 'zc-n', text: n === 0 ? '¡Hoy!' : String(n) }), n ? el('span', { class: 'zc-u', text: n === 1 ? 'día' : 'días' }) : null,
      el('span', { class: 'zc-t' }, el('b', { text: c.n }), el('small', { text: fmt(parseYmd(c.d), { weekday: 'long', day: 'numeric', month: 'long' }) })),
      el('span', { class: 'zc-bar' }, el('i', { style: `width:${pct}%` })), del));
  }
  if (!items.length) list.append(el('p', { class: 'zc-none', text: 'Sumá algo que estés esperando: vacaciones, un cumple, un partido…' }));
  const name = el('input', { placeholder: '¿Qué esperás?', maxlength: '40', 'aria-label': 'Qué esperás' });
  const date = el('input', { type: 'date', 'aria-label': 'Fecha', min: ymd(new Date()) });
  const add = el('button', { class: 'btn', text: 'Sumar' });
  add.onclick = () => {
    const n = name.value.trim(), d = date.value;
    if (!n || !d) return toast('Poné un nombre y una fecha');
    countdowns().push({ id: 'cd' + Date.now().toString(36), n, d, at: Date.now() });
    save(); zoneRefresh('cuenta'); renderPeeks();
  };
  return znCard('cuenta', null, list, items.length < 4 ? el('div', { class: 'zc-add' }, name, date, add) : null);
}

// --- Dólar
function znDolar() {
  const data = dolarData();
  if (!data.length) loadDolar(false, true).then(() => zoneRefresh('dolar'));
  const pick = ['blue', 'oficial', 'bolsa', 'tarjeta'];
  const rows = pick.map(k => data.find(d => d.casa === k)).filter(Boolean);
  const box = el('div', { class: 'zl-grid' }, rows.length ? rows.map(d => el('div', { class: 'zl-it' + (d.casa === 'blue' ? ' main' : '') },
    el('span', { class: 'zl-n', text: DOLAR_NAME[d.casa] || d.nombre }),
    el('b', { class: 'zl-v', text: money(d.venta) }),
    el('small', { text: d.compra != null ? `Compra ${money(d.compra)}` : 'Venta' }))) : el('p', { class: 'zc-none', text: 'Cargando cotizaciones…' }));
  const upd = data.map(d => Date.parse(d.fechaActualizacion)).filter(Boolean).sort((a, b) => b - a)[0];
  const card = znCard('dolar', null, box, upd ? el('small', { class: 'zl-upd', text: `Actualizado ${ago(upd)} · DolarApi` }) : null);
  return card;
}
setInterval(() => { if (!document.hidden && S && zoneOn('dolar')) loadDolar(false, true).then(() => zoneRefresh('dolar')); }, 15 * 60 * 1000);

// --- Relojes del mundo
function znMundo() {
  const zones = tzList().slice(0, 6).map(z => CITIES.find(c => c[0] === z) || [z, z.split('/').pop().replace(/_/g, ' ')]);
  const now = new Date();
  const list = el('div', { class: 'zr-list' }, el('div', { class: 'zr-it here' },
    el('span', { class: 'zr-n' }, el('b', { text: M().weather.name || 'Acá' }), el('small', { text: 'Tu hora' })), el('b', { class: 'zr-t', text: `${pad(now.getHours())}:${pad(now.getMinutes())}` })),
  zones.map(([zone, name]) => {
    const i = tzInfo(zone, now);
    return el('div', { class: 'zr-it' + (i.night ? ' night' : '') },
      el('span', { class: 'zr-ico' }, svg(i.night ? WX.moon : WX.sun)),
      el('span', { class: 'zr-n' }, el('b', { text: name }), el('small', { text: `${i.wd.replace('.', '').replace(/^./, c => c.toUpperCase())} · ${i.diff === 0 ? 'misma hora' : (i.diff > 0 ? '+' : '') + i.diff + ' h'}` })),
      el('b', { class: 'zr-t', text: i.time }));
  }));
  const card = znCard('mundo', null, list);
  if (widgetOn('relojes')) {
    const ed = el('button', { class: 'text-btn', text: 'Ciudades' }); ed.onclick = () => { openWidget('relojes', true); };
    card.querySelector('.zn-h').append(el('span', { class: 'spacer' }), ed);
  }
  return card;
}
setInterval(() => { if (!document.hidden && S && zoneOn('mundo')) zoneRefresh('mundo'); }, 20000);

// --- Frase del día
function znFrase() {
  const f = fraseDelDia(7 + (ui.znFraseN || 0));
  const other = el('button', { class: 'icon-btn sm', title: 'Ver otra', 'aria-label': 'Ver otra frase' }, svg('<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>'));
  other.onclick = () => { ui.znFraseN = (ui.znFraseN || 0) + 1; zoneRefresh('frase'); };
  const card = znCard('frase', null, el('blockquote', { class: 'zq-q' }, el('p', { text: `“${f[0]}”` }), el('cite', { text: f[1] })));
  card.querySelector('.zn-h').append(el('span', { class: 'spacer' }), other);
  return card;
}

// --- La compu (rendimiento)
function znPc() {
  const s2 = sysStats;
  if (!s2) {
    if (S && api.stats && !ui.pcAsked) { ui.pcAsked = true; setTimeout(() => loadSistema(), 50); }
    return znCard('pc', null, el('p', { class: 'zc-none', text: api.stats ? 'Midiendo…' : 'Disponible en la app instalada.' }));
  }
  const memPct = Math.round(100 * (s2.mem.total - s2.mem.free) / s2.mem.total);
  const gauge = (pct, label, sub) => el('div', { class: 'zp-g' + (pct >= 90 ? ' hi' : pct >= 70 ? ' mid' : '') },
    el('span', { class: 'zp-ring', style: `--v:${pct == null ? 0 : pct}` }, el('b', { text: pct == null ? '—' : pct + '%' })),
    el('span', { class: 'zp-l' }, el('b', { text: label }), el('small', { text: sub })));
  const sys = (s2.drives || []).find(d => /^C/i.test(d.name)) || (s2.drives || [])[0];
  const dPct = sys && sys.total ? Math.round(100 * (1 - sys.free / sys.total)) : null;
  const nt = s2.net;
  return znCard('pc', null, el('div', { class: 'zp-grid' },
    gauge(s2.cpu, 'Procesador', s2.mhz ? `${(s2.mhz / 1000).toLocaleString('es-AR', { maximumFractionDigits: 1 })} GHz` : ''),
    gauge(memPct, 'Memoria', `${GB(s2.mem.total - s2.mem.free)} de ${GB(s2.mem.total)}`),
    sys ? gauge(dPct, `Disco ${sys.name}`, `${GB(sys.free)} libres`) : null,
    el('div', { class: 'zp-net' }, el('span', {}, svg('<path d="M12 4v14M6 12l6 6 6-6"/>'), el('b', { text: RATE(nt && nt.down) })), el('span', {}, svg('<path d="M12 20V6M6 12l6-6 6 6"/>'), el('b', { text: RATE(nt && nt.up) })))));
}
// --- Tu programa: un .exe (por ejemplo Recepciones) acoplado en grande adentro del tablero
const exeName = (p) => String(p || '').split(/[\\/]/).pop().replace(/\.exe$/i, '');
function znApp() {
  const d = M().dock || {};
  const name = d.name || (d.exe ? exeName(d.exe) : 'Tu programa');
  const card = znCard('app', name);
  const h = card.querySelector('.zn-h');
  const body = el('div', { class: 'za-body' });
  card.append(body);
  if (!api.dock) {
    body.append(el('div', { class: 'za-msg' }, svg(ZONE_MODS.find(z => z.id === 'app').ico), el('b', { text: 'Tu programa, en grande' }), el('span', { text: 'Funciona en la app instalada en Windows.' })));
    return card;
  }
  const pick = el('button', { class: 'btn ghost', text: d.exe ? 'Cambiar de programa…' : 'Elegir el programa…' });
  pick.onclick = async () => {
    const f = await safeCall(() => api.dock.pick());
    if (!f) return;
    M().dock = { exe: f, name: exeName(f) }; save(); dockLast = ''; zoneRefresh('app');
  };
  if (!d.exe) {
    if (ui.dockFound === undefined) {
      ui.dockFound = null;
      safeCall(() => api.dock.find('Recepciones')).then(f => { ui.dockFound = f || ''; zoneRefresh('app'); });
    }
    if (ui.dockFound === null) body.append(el('div', { class: 'za-msg' }, el('b', { text: 'Buscando Recepciones.exe…' })));
    else if (ui.dockFound) {
      const use = el('button', { class: 'btn', text: 'Usar este' });
      use.onclick = () => { M().dock = { exe: ui.dockFound, name: exeName(ui.dockFound) }; save(); dockLast = ''; zoneRefresh('app'); };
      body.append(el('div', { class: 'za-msg' }, svg(ZONE_MODS.find(z => z.id === 'app').ico), el('b', { text: `Encontré ${exeName(ui.dockFound)}` }), el('span', { class: 'za-path', text: ui.dockFound }), el('div', { class: 'row' }, use, pick)));
    } else {
      body.append(el('div', { class: 'za-msg' }, svg(ZONE_MODS.find(z => z.id === 'app').ico), el('b', { text: 'Elegí el programa que querés ver acá' }),
        el('span', { text: 'Por ejemplo Recepciones.exe. Se abre solo y queda en grande adentro de este tablero.' }), pick));
    }
    return card;
  }
  const out = el('button', { class: 'text-btn', title: 'Sacarlo de Base y dejarlo como una ventana común' }, svg('<path d="M14 4h6v6M20 4l-8 8M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'), el('span', { text: 'Abrir aparte' }));
  out.onclick = async () => { d.detached = true; save(); await safeCall(() => api.dock.release()); dockLast = ''; zoneRefresh('app'); };
  const chg = el('button', { class: 'icon-btn sm', title: 'Cambiar de programa', 'aria-label': 'Cambiar de programa' }, svg('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>'));
  chg.onclick = pick.onclick;
  h.append(el('span', { class: 'spacer' }), d.detached ? null : out, chg);
  if (d.detached) {
    const back = el('button', { class: 'btn', text: `Volver a poner ${name} acá` });
    back.onclick = () => { d.detached = false; save(); dockLast = ''; zoneRefresh('app'); };
    body.append(el('div', { class: 'za-msg' }, svg(ZONE_MODS.find(z => z.id === 'app').ico), el('b', { text: `${name} está abierto aparte` }), back));
    return card;
  }
  body.append(el('div', { class: 'za-slot', id: 'dock-slot' },
    el('div', { class: 'za-msg', id: 'dock-msg' }, el('span', { class: 'za-spin' }), el('b', { text: `Abriendo ${name}…` }), el('span', { text: 'La primera vez puede tardar unos segundos.' }))));
  return card;
}
function dockPickBtn(primary) {
  const b = el('button', { class: primary ? 'btn' : 'btn ghost', text: 'Elegir la ventana' });
  b.onclick = () => openDockPicker();
  return b;
}
async function openDockPicker() {
  const msg = $('#dock-msg');
  if (!msg || !api.dock.windows) return;
  const d = M().dock || {};
  dockLast = 'picking';
  api.dock.bounds({ show: false });
  msg.replaceChildren(el('b', { text: 'Buscando ventanas abiertas…' }));
  const list = (await safeCall(() => api.dock.windows())) || [];
  const back = el('button', { class: 'text-btn', text: 'Cancelar' }); back.onclick = () => { dockLast = ''; zoneRefresh('app'); };
  msg.replaceChildren(el('b', { text: `¿Cuál es ${exeName(d.exe)}?` }), el('span', { text: 'Tocá su ventana. Si no está, abrí el programa y tocá Actualizar.' }),
    el('ul', { class: 'za-wins' }, list.length ? list.map(w => {
      const li = el('li', {}, el('button', { class: 'za-win' }, el('b', { text: w.t || '(sin título)' }), el('small', { text: w.exe })));
      li.firstChild.onclick = async () => {
        const m = await safeCall(() => api.dock.adopt(w.h));
        if (!m) return toast('Esa ventana ya no está abierta');
        d.match = m; d.detached = false; save(); dockLast = ''; dockRetry = 0;
        msg.replaceChildren(el('span', { class: 'za-spin' }), el('b', { text: 'Acomodándolo…' }));
      };
      return li;
    }) : el('li', { class: 'za-none', text: 'No hay ventanas abiertas.' })),
    el('div', { class: 'row' }, Object.assign(el('button', { class: 'btn ghost', text: 'Actualizar' }), { onclick: openDockPicker }), back));
  dockLast = 'picking';
}
let dockLast = '', dockRetry = 0;
function dockCovered() {
  return !zoneOn('app') || document.hidden || !!W.open || !!ui.zoneEdit || $('#drawer').classList.contains('on') || !!document.querySelector('dialog[open]')
    || !$('#arcade').hidden || !$('#search').hidden || !$('#notif-panel').hidden || !$('#brief').hidden || !$('#folder-pop').hidden
    || ($('#win-ctx') && !$('#win-ctx').hidden) || !$('#mpop').hidden || !$('#fx').hidden || !$('#sm').hidden || document.documentElement.classList.contains('desk-edit');
}
function syncDock() {
  if (!api.dock || !S) return;
  const d = M().dock || {};
  const slot = $('#dock-slot');
  if (!slot || !d.exe || d.detached || dockCovered()) {
    if (dockLast !== 'hide') { dockLast = 'hide'; api.dock.bounds({ show: false }); }
    return;
  }
  if (dockLast === 'picking') return;
  const r = slot.getBoundingClientRect();
  if (r.width < 80 || r.height < 60) return;
  const key = [d.exe, ...[r.x, r.y, r.width, r.height].map(Math.round)].join('|');
  if (key === dockLast) return;
  dockLast = key;
  api.dock.bounds({ show: true, exe: d.exe, match: d.match || null, x: r.x, y: r.y, w: r.width, h: r.height }).then(res => {
    const msg = $('#dock-msg');
    if (res && res.match && JSON.stringify(res.match) !== JSON.stringify(d.match || null)) { d.match = res.match; save(); }
    if (res && res.ok) { dockRetry = 0; if (msg) msg.replaceChildren(el('b', { text: `${exeName(d.exe)} está acá` }), el('span', { text: 'Si no lo ves, tocá “Elegir la ventana”.' }), dockPickBtn()); return; }
    if (msg && dockLast === key) {
      const again = el('button', { class: 'btn ghost', text: 'Probar de nuevo' }); again.onclick = () => { dockLast = ''; };
      msg.replaceChildren(el('b', { text: res && res.exists === false ? `No encuentro ${exeName(d.exe)}` : `No reconocí la ventana de ${exeName(d.exe)}` }),
        el('span', { text: res && res.exists === false ? 'Puede que se haya movido de carpeta. Elegilo de nuevo con el lápiz.' : 'Si ya se abrió aparte, tocá “Elegir la ventana” y elegila de la lista: la próxima vez la reconozco sola.' }),
        el('div', { class: 'row' }, dockPickBtn(true), again));
    }
    if (++dockRetry < 4) setTimeout(() => { if (dockLast === key) dockLast = ''; }, 10000);
  });
}
setInterval(syncDock, 250);

const ZONE_RENDER = { dia: znDia, semana: znSemana, notas: znNotas, fotos: znFotos, tareas: znTareas, mes: znMes, cuenta: znCuenta, dolar: znDolar, mundo: znMundo, frase: znFrase, pc: znPc, app: znApp, super: znSuper, calc: znCalc, escritorio: znEscritorio };
setInterval(() => { if (!document.hidden && S && zoneOn('dia')) zoneRefresh('dia'); }, 5 * 60 * 1000);

// ---------- Botón de sonido y apagado (barra de arriba) ----------
const MP = { vol: null, confirm: '', confirmT: 0 };
// ---------- Botones rápidos: Wi-Fi, Bluetooth, brillo y batería ----------
const QK = { data: null, bat: null, nets: null, netsBusy: false, brT: 0 };
const WIFI_ICO = (on, sig) => !on ? '<path d="M2 8.5a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/><path d="M3 3l18 18"/>'
  : '<path d="M2 8.5a15 15 0 0 1 20 0"' + (sig != null && sig < 60 ? ' opacity=".3"' : '') + '/><path d="M5 12a10 10 0 0 1 14 0"' + (sig != null && sig < 30 ? ' opacity=".3"' : '') + '/><path d="M8.5 15.5a5 5 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/>';
const BT_ICO = '<path d="M7 7l10 10-5 4V3l5 4L7 17"/>';
const SUN_ICO = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
const BAT_ICO = (lvl, ch) => `<rect x="2" y="7" width="18" height="10" rx="2.5"/><path d="M22 10.5v3"/><rect x="4" y="9" width="${Math.max(1, Math.round(14 * lvl))}" height="6" rx="1" fill="currentColor" stroke="none"/>` + (ch ? '<path d="M11.5 7.5 9 12h4l-2.5 4.5" stroke="#fff" stroke-width="1.6"/>' : '');
async function qkLoad() {
  if (!api.quick) return;
  const d = await safeCall(() => api.quick.get());
  if (d) QK.data = d;
  qkPaintBtn();
  if (!$('#qpop').hidden) renderQpop();
}
function qkPaintBtn() {
  const d = QK.data, ico = $('#qk-ico'), bat = $('#qk-bat');
  if (!ico) return;
  const wifi = d && d.radios.find(r => r.kind === 'WiFi');
  if (d && (wifi || d.wifi.ssid)) ico.innerHTML = WIFI_ICO(!wifi || wifi.on, d.wifi.signal);
  const b = QK.bat;
  bat.textContent = b && b.has ? Math.round(b.level * 100) + '%' + (b.charging ? '⚡' : '') : '';
  $('#btn-quick').classList.toggle('labeled', !!(b && b.has));
  $('#btn-quick').hidden = !api.quick && !(b && b.has);
}
function qkOpen(on) {
  const pop = $('#qpop'), btn = $('#btn-quick');
  if (on == null) on = pop.hidden;
  pop.hidden = !on; btn.setAttribute('aria-expanded', String(on)); btn.classList.toggle('on', on);
  if (!on) return;
  const r = btn.getBoundingClientRect();
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.right = Math.max(10, innerWidth - r.right - 60) + 'px';
  renderQpop(); qkLoad();
}
function renderQpop() {
  const pop = $('#qpop'), d = QK.data, kids = [];
  const tile = (ico, title, sub, on, fn, more) => {
    const b = el('button', { class: 'qk-tile' + (on ? ' on' : '') }, svg(ico), el('span', {}, el('b', { text: title }), el('small', { text: sub })));
    b.onclick = fn;
    return more ? el('div', { class: 'qk-split' }, b, more) : b;
  };
  if (!d) kids.push(el('p', { class: 'hint', text: 'Cargando…' }));
  else {
    const wifi = d.radios.find(r => r.kind === 'WiFi'), bt = d.radios.find(r => r.kind === 'Bluetooth');
    const tiles = [];
    if (wifi || d.wifi.has) {
      const on = wifi ? wifi.on : !!d.wifi.ssid;
      const more = el('button', { class: 'qk-more', title: 'Elegir red', 'aria-label': 'Elegir red' }, svg('<path d="m9 6 6 6-6 6"/>'));
      more.onclick = () => { QK.showNets = !QK.showNets; if (QK.showNets) qkNets(); renderQpop(); };
      tiles.push(tile(WIFI_ICO(on, d.wifi.signal), 'Wi-Fi', on ? (d.wifi.ssid || 'Sin conectar') + (d.wifi.signal != null && d.wifi.ssid ? ` · ${d.wifi.signal}%` : '') : 'Apagado', on, async () => {
        if (!wifi) return api.winSettings && api.winSettings('ms-settings:network-wifi');
        const ok = await safeCall(() => api.quick.radio('WiFi', !on)); if (!ok) toast('Windows no dejó cambiar el Wi-Fi'); setTimeout(qkLoad, 1500);
      }, more));
    }
    if (bt) tiles.push(tile(BT_ICO, 'Bluetooth', bt.on ? 'Prendido' : 'Apagado', bt.on, async () => { const ok = await safeCall(() => api.quick.radio('Bluetooth', !bt.on)); if (!ok) toast('Windows no dejó cambiar el Bluetooth'); setTimeout(qkLoad, 1200); }));
    if (tiles.length) kids.push(el('div', { class: 'qk-tiles' }, ...tiles));
    if (QK.showNets) {
      const list = el('div', { class: 'qk-nets' });
      if (!QK.nets) list.append(el('p', { class: 'hint', text: 'Buscando redes…' }));
      else if (!QK.nets.length) list.append(el('p', { class: 'hint', text: 'No veo redes Wi-Fi cerca.' }));
      else for (const n of QK.nets) {
        const b = el('button', { class: 'qk-net' + (d.wifi.ssid === n.n ? ' on' : '') }, svg(WIFI_ICO(true)), el('span', { text: n.n }), el('small', { text: d.wifi.ssid === n.n ? 'Conectado' : n.saved ? 'Conectar' : 'Nueva' }));
        b.onclick = async () => {
          if (d.wifi.ssid === n.n) return;
          if (!n.saved) { toast('Para una red nueva te abro la configuración de Windows (pide la contraseña)'); return api.winSettings && api.winSettings('ms-settings:network-wifi'); }
          toast('Conectando a ' + n.n + '…');
          const err = await safeCall(() => api.quick.wifiConnect(n.n));
          toast(err ? 'No se pudo: ' + err : 'Conectado a ' + n.n); setTimeout(qkLoad, 2500);
        };
        list.append(b);
      }
      kids.push(list);
    }
    for (const m of d.bright) {
      const r = el('input', { type: 'range', class: 'mp-range', min: '5', max: '100', step: '1', value: String(m.v), 'aria-label': 'Brillo' });
      const val = el('b', { class: 'mp-val', text: m.v + '%' });
      const paint = () => { r.style.setProperty('--p', r.value + '%'); val.textContent = r.value + '%'; };
      paint();
      r.oninput = () => { paint(); clearTimeout(QK.brT); QK.brT = setTimeout(() => api.quick.bright(m.i, r.value).then(() => { m.v = Number(r.value); }), 120); };
      kids.push(el('div', { class: 'mp-sec' }, el('span', { class: 'mp-h', text: d.bright.length > 1 ? `Brillo (${m.k === 'interna' ? 'pantalla de la notebook' : 'monitor ' + (m.i + 1)})` : 'Brillo' }), el('div', { class: 'mp-vol' }, svg(SUN_ICO), r, val)));
    }
  }
  if (api.clip || api.shotCrop) {
    const t2 = [];
    if (api.shotCrop) t2.push(tile(CROP_ICO, 'Recortar', 'Ctrl + Alt + S', false, () => { qkOpen(false); cropNow(); }));
    if (api.clip) t2.push(tile(CLIP_ICO, 'Portapapeles', CLIPS.items ? `${CLIPS.items.length} guardados` : 'Lo que copiaste', false, () => { qkOpen(false); clipOpen(true); }));
    kids.push(el('div', { class: 'qk-tiles' }, ...t2));
  }
  const b = QK.bat;
  if (b && b.has) kids.push(el('div', { class: 'qk-bat' }, svg(BAT_ICO(b.level, b.charging)), el('b', { text: Math.round(b.level * 100) + '%' }), el('span', { text: b.charging ? (b.chargingTime && isFinite(b.chargingTime) && b.chargingTime > 0 ? `Cargando · lista en ${Math.round(b.chargingTime / 60)} min` : 'Cargando') : (b.dischargingTime && isFinite(b.dischargingTime) ? `Quedan unas ${Math.floor(b.dischargingTime / 3600)} h ${Math.round(b.dischargingTime % 3600 / 60)} min` : 'Con batería') })));
  const links = el('div', { class: 'qk-links' });
  for (const [t, k] of [['Redes', 'ms-settings:network'], ['Bluetooth', 'ms-settings:bluetooth'], ['Pantalla', 'ms-settings:display']]) {
    const a = el('button', { class: 'text-btn', text: t + '…' }); a.onclick = () => { qkOpen(false); api.winSettings && api.winSettings(k); }; links.append(a);
  }
  kids.push(links);
  pop.replaceChildren(...kids);
}
async function qkNets() { QK.nets = null; QK.nets = await safeCall(() => api.quick.wifiList()) || []; if (!$('#qpop').hidden) renderQpop(); }
// ---------- Botones de Windows enrollados en un solo botón ----------
function wtCollapsed() { return S.settings.sysOpen !== true; }
function wtApply() {
  const on = !!api.windows;
  $('#btn-wintools').hidden = !on || !wtCollapsed();
  document.documentElement.classList.toggle('sys-collapsed', on && wtCollapsed());
  if (WINS.ok != null) renderSwitcher();
}
function wtOpen(on) {
  const pop = $('#wtpop'), btn = $('#btn-wintools');
  if (on == null) on = pop.hidden;
  pop.hidden = !on; btn.setAttribute('aria-expanded', String(on)); btn.classList.toggle('on', on);
  if (!on) return;
  const items = $$('#sysbtns [data-sys]').map(o => {
    const b = el('button', { class: 'wt-i', role: 'menuitem' });
    b.innerHTML = o.innerHTML; b.append(el('span', { text: o.getAttribute('title').replace(/ \(.*\)$/, '') }));
    b.onclick = () => { wtOpen(false); o.click(); };
    return b;
  });
  const keep = el('label', { class: 'switch wt-keep' }, el('input', { type: 'checkbox' }), el('span'), ' Dejarlos siempre a la vista arriba');
  keep.querySelector('input').onchange = (e) => { S.settings.sysOpen = e.target.checked; save(); wtOpen(false); wtApply(); };
  pop.replaceChildren(el('div', { class: 'wt-grid' }, ...items), keep);
  const r = btn.getBoundingClientRect();
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.right = Math.max(10, innerWidth - r.right - 40) + 'px';
}
function setupWinTools() {
  $('#btn-wintools').onclick = () => wtOpen();
  document.addEventListener('pointerdown', (e) => { if (!$('#wtpop').hidden && !e.target.closest('#wtpop, #btn-wintools')) wtOpen(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#wtpop').hidden) wtOpen(false); });
  wtApply();
}
// ---------- Portapapeles y recortes ----------
const CROP_ICO = '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M8.1 8.1 20 20M8.1 15.9 20 4"/>';
const CLIP_ICO = '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h3"/>';
const CLIPS = { items: null, q: '' };
async function cropNow() {
  if (!api.shotCrop) return toast('Los recortes funcionan en la app instalada');
  closeSearch();
  await new Promise(r => setTimeout(r, 260)); // que se cierren los menús antes de sacar la foto
  const r = await safeCall(() => api.shotCrop());
  if (!r || !r.ok) toast('No pude sacar la captura' + (r && r.error ? ': ' + r.error : ''));
}
async function clipLoadList() { const r = await safeCall(() => api.clip.list()); CLIPS.items = r ? r.items : []; return CLIPS.items; }
function clipAgo(t) { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'recién' : m < 60 ? `hace ${m} min` : m < 1440 ? `hace ${Math.round(m / 60)} h` : fmt(new Date(t), { day: 'numeric', month: 'short' }); }
function clipOpen(on) {
  let pop = $('#clip-pop');
  if (!pop) {
    pop = el('div', { id: 'clip-pop', class: 'mpop clip-pop', hidden: true, role: 'dialog', 'aria-label': 'Portapapeles' });
    document.body.append(pop);
    document.addEventListener('pointerdown', (e) => { if (!pop.hidden && !e.target.closest('#clip-pop, #qpop, #btn-quick')) clipOpen(false); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !pop.hidden) clipOpen(false); });
  }
  if (on == null) on = pop.hidden;
  pop.hidden = !on;
  if (!on) return;
  const btn = $('#btn-quick'), r = btn && !btn.hidden ? btn.getBoundingClientRect() : { bottom: 60, right: innerWidth - 20 };
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.right = Math.max(10, innerWidth - r.right - 60) + 'px';
  CLIPS.q = '';
  renderClip(true);
  clipLoadList().then(() => renderClip());
}
function renderClip(first) {
  const pop = $('#clip-pop'); if (!pop || pop.hidden) return;
  const q = norm(CLIPS.q);
  const head = el('div', { class: 'cl-head' }, el('b', { text: 'Portapapeles' }));
  const clear = el('button', { class: 'text-btn', text: 'Borrar todo' });
  clear.onclick = async () => { await safeCall(() => api.clip.clear()); await clipLoadList(); renderClip(); toast('Listo, quedaron solo los fijados'); };
  head.append(clear);
  let find = pop.querySelector('.cl-find');
  if (!find) { find = el('input', { class: 'cl-find', type: 'search', placeholder: 'Buscar en lo copiado…' }); find.oninput = () => { CLIPS.q = find.value; renderClip(); }; }
  const list = el('div', { class: 'cl-list' });
  const items = (CLIPS.items || []).filter(x => !q || (x.t === 'text' && norm(x.text).includes(q)));
  if (!CLIPS.items) list.append(el('p', { class: 'hint', text: 'Cargando…' }));
  else if (!items.length) list.append(el('p', { class: 'cl-empty', text: q ? 'Nada coincide.' : 'Todavía no copiaste nada. Lo que copies (texto o imágenes) va a aparecer acá, y con un clic lo volvés a copiar.' }));
  for (const x of items) {
    const body = x.t === 'text' ? el('div', { class: 'cl-text', text: x.text.length > 600 ? x.text.slice(0, 600) + '…' : x.text }) : el('img', { class: 'cl-img', src: x.thumb, alt: 'Imagen copiada' });
    const pin = el('span', { class: 'cl-act' + (x.pin ? ' on' : ''), role: 'button', title: x.pin ? 'Desfijar' : 'Fijar (no se borra)' }); pin.innerHTML = '<svg viewBox="0 0 24 24"><path d="M9 3h6l-1 6 4 4H6l4-4zM12 13v8"/></svg>';
    const del = el('span', { class: 'cl-act', role: 'button', title: 'Quitar' }); del.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>';
    pin.onclick = async (e) => { e.stopPropagation(); await safeCall(() => api.clip.pin(x.id)); await clipLoadList(); renderClip(); };
    del.onclick = async (e) => { e.stopPropagation(); await safeCall(() => api.clip.del(x.id)); await clipLoadList(); renderClip(); };
    const it = el('button', { class: 'cl-item' + (x.pin ? ' pin' : ''), title: 'Clic: copiar de nuevo' }, body,
      el('div', { class: 'cl-meta' }, el('span', { text: x.t === 'img' ? `Imagen ${x.w}×${x.h} · ${clipAgo(x.at)}` : clipAgo(x.at) }), pin, del));
    it.onclick = async () => { await safeCall(() => api.clip.use(x.id)); clipOpen(false); toast('Copiado. Pegalo con Ctrl + V'); };
    list.append(it);
  }
  const off = el('label', { class: 'switch' }, el('input', { type: 'checkbox', checked: S.settings.clipOff ? null : true }), el('span'), ' Guardar lo que copio');
  off.querySelector('input').onchange = (e) => { S.settings.clipOff = !e.target.checked; save(); api.clip.set(e.target.checked); toast(e.target.checked ? 'Base va a guardar lo que copies' : 'Listo, Base deja de guardar lo que copiás'); };
  const foot = el('div', { class: 'cl-foot' }, off, el('small', { text: 'Lo que copian los gestores de contraseñas no se guarda.' }));
  pop.replaceChildren(head, find, list, foot);
  if (first) setTimeout(() => find.focus(), 30);
}
function setupClip() {
  if (api.clip) {
    api.clip.set(!S.settings.clipOff);
    api.clip.onChange(() => { CLIPS.items = null; const p = $('#clip-pop'); if (p && !p.hidden) clipLoadList().then(() => renderClip()); else clipLoadList(); });
    clipLoadList();
  }
  if (api.onShotDone) api.onShotDone((r) => {
    const t = el('div', { class: 'shot-toast' }, el('img', { src: r.preview, alt: '' }), el('div', {}, el('b', { text: 'Recorte copiado y guardado' }), el('span', { text: 'Pegalo con Ctrl + V. Está en Imágenes › Capturas de Base.' })));
    const open = el('button', { class: 'btn ghost', text: 'Ver carpeta' }); open.onclick = () => { api.open({ type: 'folder', target: r.dir }); t.remove(); };
    t.append(open); document.body.append(t);
    setTimeout(() => t.classList.add('out'), 6000); setTimeout(() => t.remove(), 6600);
  });
}
// ---------- Modo descanso (para la tele) ----------
const REST = { on: false, tick: 0, slide: 0, moveFrom: null, drift: 0 };
function restCfg() { const r = S.settings.rest || (S.settings.rest = {}); if (r.min == null) r.min = 10; if (r.photos == null) r.photos = true; return r; }
function restPaint() {
  const box = $('#rest'); if (!box || box.hidden) return;
  const now = new Date();
  const cfg = M().clock || {};
  let h = now.getHours(); const m = String(now.getMinutes()).padStart(2, '0');
  if (cfg.h12) h = h % 12 || 12;
  box.querySelector('.rs-time').textContent = `${String(h).padStart(cfg.h12 ? 1 : 2, '0')}:${m}`;
  const d = fmt(now, { weekday: 'long', day: 'numeric', month: 'long' });
  box.querySelector('.rs-date').textContent = d.charAt(0).toUpperCase() + d.slice(1);
  const wx = box.querySelector('.rs-wx');
  if (PN.wx) wx.replaceChildren(svg(PN.wx.ic || WX.sun), el('b', { text: `${PN.wx.t}°` }), el('span', { text: `${PN.wx.d} · ${PN.wx.max}° / ${PN.wx.min}°${PN.wx.city ? ' · ' + PN.wx.city : ''}` }));
  else wx.replaceChildren();
}
function restSlide() {
  const box = $('#rest'); if (!box || box.hidden) return;
  const layer = box.querySelector('.rs-photos');
  if (!restCfg().photos || !PHOTOS.list.length) { layer.replaceChildren(); return; }
  PHOTOS.i = (PHOTOS.i + 1) % PHOTOS.list.length;
  const img = el('img', { alt: '', src: PHOTOS.list[PHOTOS.i], class: 'kb' + (REST.slide++ % 2) });
  img.onload = () => { layer.append(img); requestAnimationFrame(() => img.classList.add('in')); const olds = layer.querySelectorAll('img'); if (olds.length > 1) setTimeout(() => [...olds].slice(0, -1).forEach(o => o.remove()), 2000); };
  img.onerror = () => { PHOTOS.list.splice(PHOTOS.i, 1); };
}
async function enterRest() {
  if (REST.on) return;
  const box = $('#rest');
  REST.on = true; REST.moveFrom = null;
  closeSearch(); closeWidget(true);
  box.replaceChildren(el('div', { class: 'rs-photos' }), el('div', { class: 'rs-shade' }),
    el('div', { class: 'rs-main' }, el('div', { class: 'rs-time' }), el('div', { class: 'rs-date' }), el('div', { class: 'rs-wx' })),
    el('div', { class: 'rs-hint', text: 'Mové el mouse para volver' }));
  box.hidden = false;
  document.documentElement.classList.add('resting');
  restPaint();
  if (restCfg().photos) { await photosLoad(); restSlide(); }
  clearInterval(REST.tick);
  let n = 0;
  REST.tick = setInterval(() => {
    restPaint(); n++;
    if (n % 15 === 0) restSlide();
    // mueve el reloj despacito para no marcar la pantalla
    if (n % 60 === 0) { REST.drift = (REST.drift + 1) % 6; const mn = box.querySelector('.rs-main'); if (mn) mn.style.transform = `translate(${[0, 3, -3, 2, -2, 1][REST.drift]}vw, ${[0, -2, 2, 3, -3, -1][REST.drift]}vh)`; }
  }, 1000);
}
function exitRest() {
  if (!REST.on) return;
  REST.on = false; clearInterval(REST.tick);
  const box = $('#rest'); box.classList.add('out');
  setTimeout(() => { box.hidden = true; box.classList.remove('out'); box.replaceChildren(); }, 350);
  document.documentElement.classList.remove('resting');
  REST.lastExit = Date.now();
}
function setupRest() {
  const cfg = restCfg();
  const on = $('#rest-on'), mn = $('#rest-min'), ph = $('#rest-photos');
  const paint = () => { on.checked = !!cfg.on; mn.value = String(cfg.min); ph.checked = !!cfg.photos; mn.disabled = ph.disabled = !cfg.on; };
  paint();
  on.onchange = () => { cfg.on = on.checked; save(); paint(); };
  mn.onchange = () => { cfg.min = Number(mn.value) || 10; save(); };
  ph.onchange = () => { cfg.photos = ph.checked; save(); };
  $('#rest-try').onclick = () => { openDrawer(false); setTimeout(enterRest, 250); };
  const wake = (e) => {
    if (!REST.on) return;
    if (e.type === 'pointermove') {
      if (!REST.moveFrom) { REST.moveFrom = [e.clientX, e.clientY]; return; }
      if (Math.hypot(e.clientX - REST.moveFrom[0], e.clientY - REST.moveFrom[1]) < 12) return;
    }
    if (e.type === 'keydown' || e.type === 'pointerdown') { e.preventDefault(); e.stopPropagation(); }
    exitRest();
  };
  for (const t of ['pointermove', 'pointerdown', 'keydown', 'wheel', 'touchstart']) window.addEventListener(t, wake, { capture: true, passive: t !== 'keydown' && t !== 'pointerdown' });
  setInterval(async () => {
    if (REST.on || !cfg.on || !api.idle || document.querySelector('dialog[open]')) return;
    if (REST.lastExit && Date.now() - REST.lastExit < 60000) return;
    const r = await safeCall(() => api.idle());
    if (r && r.focused && r.idle >= cfg.min * 60) enterRest();
  }, 15000);
}
async function setupQuick() {
  const btn = $('#btn-quick'); if (!btn) return;
  btn.onclick = (e) => { e.stopPropagation(); qkOpen(); };
  document.addEventListener('pointerdown', (e) => { if (!$('#qpop').hidden && !e.target.closest('#qpop, #btn-quick')) qkOpen(false); });
  try {
    if (navigator.getBattery) {
      const bt = await navigator.getBattery();
      const upd = () => { QK.bat = { has: !(bt.charging && bt.level === 1 && bt.chargingTime === 0) || false, level: bt.level, charging: bt.charging, chargingTime: bt.chargingTime, dischargingTime: bt.dischargingTime }; if (bt.chargingTime === 0 && bt.level === 1 && bt.charging && bt.dischargingTime === Infinity) QK.bat.has = false; qkPaintBtn(); if (!$('#qpop').hidden) renderQpop(); };
      upd(); ['levelchange', 'chargingchange', 'chargingtimechange', 'dischargingtimechange'].forEach(ev => bt.addEventListener(ev, upd));
    }
  } catch {}
  if (!api.quick && !(QK.bat && QK.bat.has)) btn.hidden = true;
  qkLoad();
  setInterval(() => { if (!document.hidden) qkLoad(); }, 60000);
}
function mpOpen(on) {
  const pop = $('#mpop'), btn = $('#btn-media');
  if (on == null) on = pop.hidden;
  pop.hidden = !on;
  btn.setAttribute('aria-expanded', String(on));
  btn.classList.toggle('on', on);
  if (!on) { MP.confirm = ''; return; }
  const r = btn.getBoundingClientRect();
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.right = Math.max(10, innerWidth - r.right - 60) + 'px';
  renderMpop();
  mpRefresh();
}
async function mpRefresh() {
  const jobs = [];
  if (api.media && api.media.vol) jobs.push(safeCall(() => api.media.vol()).then(v => { MP.vol = v && typeof v.level === 'number' ? v : null; }));
  if (api.media && api.media.sessions) jobs.push(loadMedia());
  await Promise.all(jobs);
  if (!$('#mpop').hidden) renderMpop();
}
const VOL_ICON = (lvl, muted) => muted || lvl === 0 ? '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="m17 9 5 6M22 9l-5 6"/>'
  : lvl < 40 ? '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 9.5a3.5 3.5 0 0 1 0 5"/>'
  : '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>';
function renderMpop() {
  const pop = $('#mpop');
  const kids = [];
  // lo que suena
  const s = typeof npSession === 'function' ? npSession() : null;
  if (s && (s.title || s.status === 'Playing')) {
    const playing = s.status === 'Playing';
    const ctl = (act, icon, title) => { const b = el('button', { class: 'icon-btn sm', title, 'aria-label': title }, svg(icon)); b.onclick = async () => { await safeCall(() => api.media.act(s.app, act)); setTimeout(mpRefresh, 400); }; return b; };
    kids.push(el('div', { class: 'mp-now' },
      el('span', { class: 'mp-app', text: appLabel(s.app) }),
      el('b', { class: 'mp-t', text: s.title || 'Reproduciendo' }), s.artist ? el('span', { class: 'mp-a', text: s.artist }) : null,
      el('div', { class: 'mp-ctl' }, ctl('prev', '<path d="M6 5v14M18 6l-9 6 9 6z"/>', 'Anterior'),
        ctl('toggle', playing ? PAUSE_ICON : PLAY_ICON, playing ? 'Pausar' : 'Reproducir'),
        ctl('next', '<path d="M18 5v14M6 6l9 6-9 6z"/>', 'Siguiente'))));
  }
  // volumen
  const v = MP.vol;
  const muteBtn = el('button', { class: 'icon-btn mp-mute' + (v && v.muted ? ' on' : ''), title: v && v.muted ? 'Quitar el silencio' : 'Silenciar', 'aria-label': 'Silenciar' }, svg(VOL_ICON(v ? v.level : 50, v && v.muted)));
  muteBtn.onclick = async () => {
    if (v && api.media.volMute) { const r = await safeCall(() => api.media.volMute(!v.muted)); if (r) MP.vol = r; renderMpop(); }
    else { await safeCall(() => api.media.key('mute')); }
  };
  let volRow;
  if (v) {
    const range = el('input', { type: 'range', class: 'mp-range', min: '0', max: '100', step: '1', value: String(v.level), 'aria-label': 'Volumen' });
    const val = el('b', { class: 'mp-val', text: v.muted ? 'Mudo' : v.level + '%' });
    const paint = () => range.style.setProperty('--p', range.value + '%');
    paint();
    let t = 0;
    range.oninput = () => {
      paint(); val.textContent = range.value + '%';
      clearTimeout(t); t = setTimeout(async () => { const r = await safeCall(() => api.media.volSet(Number(range.value))); if (r) { MP.vol = r; muteBtn.classList.toggle('on', r.muted); muteBtn.replaceChildren(svg(VOL_ICON(r.level, r.muted))); } }, 60);
    };
    range.addEventListener('wheel', (e) => { e.preventDefault(); range.value = Math.max(0, Math.min(100, Number(range.value) + (e.deltaY < 0 ? 2 : -2))); range.oninput(); }, { passive: false });
    volRow = el('div', { class: 'mp-vol' }, muteBtn, range, val);
  } else {
    const step = (k, icon, title) => { const b = el('button', { class: 'btn ghost mp-step', title }, svg(icon), el('span', { text: title })); b.onclick = () => safeCall(() => api.media.key(k)); return b; };
    volRow = el('div', { class: 'mp-vol keys' }, muteBtn,
      step('voldown', '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 12h4"/>', 'Bajar'),
      step('volup', '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 12h4M19 10v4"/>', 'Subir'));
  }
  const out = el('button', { class: 'text-btn mp-link', text: 'Elegir parlantes o auriculares…' });
  out.onclick = () => { mpOpen(false); api.windows && api.windows.system('sound'); };
  kids.push(el('div', { class: 'mp-sec' }, el('span', { class: 'mp-h', text: 'Volumen' }), volRow, out));
  // energía
  const POWER = [
    { k: 'lock', n: 'Bloquear', ico: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>' },
    { k: 'sleep', n: 'Suspender', ico: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>' },
    { k: 'restart', n: 'Reiniciar', ico: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>', ask: true },
    { k: 'shutdown', n: 'Apagar', ico: '<path d="M12 3v8"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>', ask: true }
  ];
  const grid = el('div', { class: 'mp-power' }, POWER.map(p => {
    const asking = MP.confirm === p.k;
    const b = el('button', { class: 'mp-pw' + (p.k === 'shutdown' ? ' off' : '') + (asking ? ' ask' : ''), title: p.n }, svg(p.ico), el('span', { text: asking ? '¿Seguro? Tocá de nuevo' : p.n }));
    b.onclick = async () => {
      if (p.ask && MP.confirm !== p.k) {
        MP.confirm = p.k; clearTimeout(MP.confirmT);
        MP.confirmT = setTimeout(() => { MP.confirm = ''; if (!$('#mpop').hidden) renderMpop(); }, 4000);
        renderMpop(); return;
      }
      MP.confirm = ''; mpOpen(false);
      if (!api.windows) return toast('Esto funciona en la app instalada');
      if (p.k === 'shutdown' || p.k === 'restart') { save(true); await new Promise(r => setTimeout(r, 500)); }
      const r = await safeCall(() => api.windows.system(p.k));
      if (!r || r.ok === false) toast('Windows no dejó hacerlo');
    };
    return b;
  }));
  kids.push(el('div', { class: 'mp-sec' }, el('span', { class: 'mp-h', text: 'Compu' }), grid));
  pop.replaceChildren(...kids);
}
function setupMpop() {
  $('#btn-media').onclick = (e) => { e.stopPropagation(); mpOpen(); };
  setupQuick();
  setupRest();
  setupWinTools();
  setupClip();
  $('#btn-media').addEventListener('wheel', async (e) => {
    e.preventDefault();
    if (MP.vol && api.media.volSet) { const r = await safeCall(() => api.media.volSet(MP.vol.level + (e.deltaY < 0 ? 4 : -4))); if (r) MP.vol = r; if (!$('#mpop').hidden) renderMpop(); }
    else if (api.media) api.media.key(e.deltaY < 0 ? 'volup' : 'voldown');
  }, { passive: false });
  document.addEventListener('pointerdown', (e) => { if (!$('#mpop').hidden && !e.target.closest('#mpop, #btn-media')) mpOpen(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#mpop').hidden) mpOpen(false); });
  setInterval(() => { if (!$('#mpop').hidden && !document.hidden && !$('#mpop').matches(':active')) mpRefresh(); }, 3000);
  if (api.media && api.media.vol) safeCall(() => api.media.vol()).then(v => { MP.vol = v && typeof v.level === 'number' ? v : null; });
}

// ---------- Explorador de archivos de Base ----------
const FX = { dir: '', hist: [], fut: [], items: [], sel: new Set(), clip: null, places: null, q: '', anchor: null };
const FX_IMG = new Set(['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'heic', 'mp4', 'mkv', 'mov', 'avi', 'wmv', 'pdf']);
const FX_ICO = {
  dir: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  file: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>',
  desktop: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  downloads: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  documents: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  pictures: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>',
  music: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  videos: '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-2v8l-4-2"/>',
  home: '<path d="M4 11 12 4l8 7v9H4z"/><path d="M10 20v-6h4v6"/>',
  drive: '<rect x="3" y="13" width="18" height="7" rx="2"/><path d="M5 13 7 5h10l2 8M7 16.5h.01"/>'
};
const fxSize = (b) => !b ? '' : b < 1024 ? `${b} B` : b < 1048576 ? `${Math.round(b / 1024)} KB` : b < 1073741824 ? `${(b / 1048576).toLocaleString('es-AR', { maximumFractionDigits: 1 })} MB` : `${(b / 1073741824).toLocaleString('es-AR', { maximumFractionDigits: 1 })} GB`;
function fxOpen(dir) {
  if (!api.fx) return toast('El explorador funciona en la app instalada');
  const box = $('#fx');
  if (box.hidden) { box.hidden = false; buildFx(); }
  if (dir) fxGo(dir);
  else if (!FX.dir) api.fx.places().then(pl => { FX.places = pl; renderFxSide(); const st = S.settings.fxStart || 'downloads'; fxGo(st === 'last' && S.settings.fxLast ? S.settings.fxLast : (pl.places.find(x => x.k === st) || pl.places.find(x => x.k === 'downloads') || pl.places[0] || pl.drives[0]).p); });
  else fxGo(FX.dir, true);
  setTimeout(() => { const q = $('#fx-q'); if (q) q.focus(); }, 60);
}
function fxClose() { $('#fx').hidden = true; fxCtx(false); }
function buildFx() {
  const box = $('#fx');
  if (box.dataset.built) return;
  box.dataset.built = '1';
  const btn = (id, title, ico) => el('button', { class: 'icon-btn', id, title, 'aria-label': title }, svg(ico));
  box.append(
    el('header', { class: 'fx-head' },
      btn('fx-back', 'Atrás (Alt+←)', '<path d="m15 6-6 6 6 6"/>'), btn('fx-fwd', 'Adelante (Alt+→)', '<path d="m9 6 6 6-6 6"/>'), btn('fx-up', 'Subir una carpeta', '<path d="M12 19V5M6 11l6-6 6 6"/>'),
      el('nav', { class: 'fx-crumbs', id: 'fx-crumbs', 'aria-label': 'Ubicación' }),
      el('label', { class: 'fx-search' }, svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'), el('input', { id: 'fx-q', placeholder: 'Buscar en esta carpeta', 'aria-label': 'Buscar en esta carpeta' })),
      btn('fx-view', 'Cambiar vista', '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>'),
      btn('fx-opts', 'Personalizar el explorador', '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1"/>'),
      btn('fx-new', 'Nueva carpeta', '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v5M9.5 13.5h5"/>'),
      btn('fx-close', 'Cerrar (Esc)', ICON.x)),
    el('div', { class: 'fx-main' },
      el('aside', { class: 'fx-side', id: 'fx-side' }),
      el('div', { class: 'fx-list', id: 'fx-list', tabindex: '0' }),
      el('aside', { class: 'fx-prev', id: 'fx-prev' })),
    el('div', { class: 'fx-optp', id: 'fx-optp', hidden: true }),
    el('footer', { class: 'fx-foot' }, el('span', { id: 'fx-status' }), el('span', { class: 'spacer' }),
      Object.assign(el('button', { class: 'text-btn', text: 'Abrir en el Explorador de Windows' }), { onclick: () => api.fx.winExplorer(FX.dir) })));
  $('#fx-back').onclick = () => { if (FX.hist.length) { FX.fut.push(FX.dir); fxGo(FX.hist.pop(), true); } };
  $('#fx-fwd').onclick = () => { if (FX.fut.length) { FX.hist.push(FX.dir); fxGo(FX.fut.pop(), true); } };
  $('#fx-up').onclick = () => { if (FX.parent) fxGo(FX.parent); };
  $('#fx-close').onclick = fxClose;
  $('#fx-view').onclick = () => { S.settings.fxView = S.settings.fxView === 'list' ? 'grid' : 'list'; save(); renderFxList(); };
  $('#fx-new').onclick = fxNewFolder;
  $('#fx-opts').onclick = (e) => { e.stopPropagation(); const p = $('#fx-optp'); p.hidden = !p.hidden; if (!p.hidden) renderFxOpts(); };
  box.addEventListener('pointerdown', (e) => { const p = $('#fx-optp'); if (!p.hidden && !e.target.closest('#fx-optp, #fx-opts')) p.hidden = true; });
  applyFxLook();
  $('#fx-q').oninput = (e) => { FX.q = e.target.value.trim().toLowerCase(); renderFxList(); };
  const list = $('#fx-list');
  list.addEventListener('contextmenu', (e) => { if (e.target === list || e.target.classList.contains('fx-grid')) { e.preventDefault(); FX.sel.clear(); paintFxSel(); fxCtx(true, e.clientX, e.clientY, null); } });
  list.addEventListener('pointerdown', (e) => { if (e.target === list || e.target.classList.contains('fx-grid')) { FX.sel.clear(); paintFxSel(); } });
  box.addEventListener('keydown', fxKeys);
}
function renderFxSide() {
  const side = $('#fx-side');
  if (!side || !FX.places) return;
  const item = (x) => {
    const b = el('button', { class: 'fx-place' + (FX.dir === x.p ? ' on' : ''), title: x.p }, svg(FX_ICO[x.k] || FX_ICO.dir), el('span', { text: x.n }));
    b.onclick = () => fxGo(x.p);
    b.ondragover = (e) => { if (FX.drag) { e.preventDefault(); b.classList.add('drop'); } };
    b.ondragleave = () => b.classList.remove('drop');
    b.ondrop = (e) => { e.preventDefault(); b.classList.remove('drop'); fxDropTo(x.p, e.ctrlKey); };
    return b;
  };
  const pins = (S.settings.fxPins || []).map(p => ({ k: 'dir', n: p.split(/[\\/]/).filter(Boolean).pop() || p, p }));
  side.replaceChildren(
    el('span', { class: 'fx-sh', text: 'Accesos rápidos' }), ...FX.places.places.map(item),
    pins.length ? el('span', { class: 'fx-sh', text: 'Fijadas' }) : null, ...pins.map(item),
    el('span', { class: 'fx-sh', text: 'Unidades' }), ...FX.places.drives.map(item));
}
async function fxGo(dir, noHist) {
  if (!dir) return;
  const r = await safeCall(() => api.fx.list(dir, !!S.settings.fxHidden));
  if (!r || !r.ok) return toast((r && r.error) || 'No se pudo abrir esa carpeta');
  if (!noHist && FX.dir && FX.dir !== r.dir) { FX.hist.push(FX.dir); FX.fut = []; if (FX.hist.length > 60) FX.hist.shift(); }
  FX.dir = r.dir; FX.parent = r.parent; S.settings.fxLast = r.dir; FX.items = r.items; FX.sel.clear(); FX.q = ''; FX.anchor = null;
  const q = $('#fx-q'); if (q) q.value = '';
  $('#fx-back').disabled = !FX.hist.length; $('#fx-fwd').disabled = !FX.fut.length; $('#fx-up').disabled = !FX.parent;
  renderFxCrumbs(); renderFxSide(); renderFxList(); renderFxPreview();
  $('#fx-list').scrollTop = 0;
}
function renderFxCrumbs() {
  const sep = (FX.places && FX.places.sep) || '\\';
  const parts = FX.dir.split(/[\\/]/).filter(Boolean);
  const out = [];
  let acc = FX.dir.startsWith('/') ? '/' : '';
  parts.forEach((p, i) => {
    acc = i === 0 ? (acc + p + (/:$/.test(p) ? sep : '')) : (acc.endsWith(sep) ? acc + p : acc + sep + p);
    const target = acc;
    if (i) out.push(el('span', { class: 'fx-sep', text: '›' }));
    const b = el('button', { class: 'fx-crumb', text: i === 0 && /:$/.test(p) ? `Disco ${p}` : p });
    b.onclick = () => fxGo(target);
    out.push(b);
  });
  const box = $('#fx-crumbs');
  box.replaceChildren(...out);
  box.scrollLeft = box.scrollWidth;
}
function fxSorted() {
  const by = S.settings.fxSort || 'name';
  const list = FX.items.filter(x => !FX.q || x.n.toLowerCase().includes(FX.q));
  const ff = S.settings.fxFoldersFirst !== false;
  return list.sort((a, b) => (ff ? (b.d - a.d) : 0) || (by === 'date' ? b.m - a.m : by === 'size' ? b.s - a.s : a.n.localeCompare(b.n, 'es', { numeric: true })));
}
function renderFxList() {
  const list = $('#fx-list');
  const view = S.settings.fxView === 'list' ? 'list' : 'grid';
  const items = fxSorted();
  FX.shown = items;
  let body;
  if (view === 'list') {
    const head = el('div', { class: 'fx-row head' }, ...[['name', 'Nombre'], ['date', 'Modificado'], ['size', 'Tamaño']].map(([k, n]) => {
      const b = el('button', { class: (S.settings.fxSort || 'name') === k ? 'on' : '', text: n }); b.onclick = () => { S.settings.fxSort = k; save(); renderFxList(); }; return b;
    }));
    body = el('div', { class: 'fx-rows' }, head, items.slice(0, 1500).map(fxRow));
  } else body = el('div', { class: 'fx-grid' }, items.slice(0, 1500).map(fxTile));
  list.replaceChildren(body, !items.length ? el('p', { class: 'fx-empty', text: FX.q ? 'Nada coincide con la búsqueda.' : 'Esta carpeta está vacía.' }) : null);
  list.dataset.view = view;
  list.dataset.size = S.settings.fxSize || 'm';
  fxStatus();
  fxLazyIcons();
}
function fxIconEl(x, big) {
  const fc = x.d && (S.settings.fxColors || {})[x.p];
  const box = el('span', { class: 'fx-ico' + (x.d ? ' dir' : ''), style: fc ? `--fc:${fc}` : null }, svg(x.d ? FX_ICO.dir : FX_ICO.file));
  if (!x.d) { box.dataset.p = x.p; box.dataset.t = big && FX_IMG.has(x.x) ? '1' : ''; }
  return box;
}
const fxShown = (x) => (S.settings.fxExt === false && !x.d && x.n.lastIndexOf('.') > 0 ? x.n.slice(0, x.n.lastIndexOf('.')) : x.n);
function fxTile(x) {
  const t = el('button', { class: 'fx-tile', 'data-p': x.p, title: `${x.n}${x.d ? '' : '\n' + fxSize(x.s)}${x.m ? '\n' + new Date(x.m).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) : ''}`, draggable: 'true' },
    fxIconEl(x, true), el('span', { class: 'fx-n', text: fxShown(x) }));
  fxBind(t, x);
  return t;
}
function fxRow(x) {
  const r = el('button', { class: 'fx-row', 'data-p': x.p, draggable: 'true' },
    el('span', { class: 'fx-rn' }, fxIconEl(x, false), el('span', { text: fxShown(x) })),
    el('span', { text: x.m ? new Date(x.m).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) : '' }),
    el('span', { text: x.d ? '' : fxSize(x.s) }));
  fxBind(r, x);
  return r;
}
function fxBind(node, x) {
  node.onclick = (e) => {
    if (e.ctrlKey) { FX.sel.has(x.p) ? FX.sel.delete(x.p) : FX.sel.add(x.p); FX.anchor = x.p; }
    else if (e.shiftKey && FX.anchor) {
      const ps = FX.shown.map(i => i.p); const a = ps.indexOf(FX.anchor), b = ps.indexOf(x.p);
      FX.sel = new Set(ps.slice(Math.min(a, b), Math.max(a, b) + 1));
    } else { FX.sel = new Set([x.p]); FX.anchor = x.p; }
    paintFxSel();
  };
  node.ondblclick = () => fxActivate(x);
  node.oncontextmenu = (e) => { e.preventDefault(); if (!FX.sel.has(x.p)) { FX.sel = new Set([x.p]); paintFxSel(); } fxCtx(true, e.clientX, e.clientY, x); };
  node.ondragstart = (e) => { if (!FX.sel.has(x.p)) { FX.sel = new Set([x.p]); paintFxSel(); } FX.drag = [...FX.sel]; e.dataTransfer.effectAllowed = 'copyMove'; e.dataTransfer.setData('text/plain', x.p); };
  node.ondragend = () => { FX.drag = null; };
  if (x.d) {
    node.ondragover = (e) => { if (FX.drag && !FX.drag.includes(x.p)) { e.preventDefault(); node.classList.add('drop'); } };
    node.ondragleave = () => node.classList.remove('drop');
    node.ondrop = (e) => { e.preventDefault(); node.classList.remove('drop'); fxDropTo(x.p, e.ctrlKey); };
  }
}
async function fxDropTo(dir, copy) {
  const list = FX.drag; FX.drag = null;
  if (!list || !list.length) return;
  const err = await safeCall(() => api.fx.paste(list, dir, !copy));
  toast(err || `${copy ? 'Copiado' : 'Movido'} a ${dir.split(/[\\/]/).filter(Boolean).pop()}`);
  fxGo(FX.dir, true);
}
function paintFxSel() {
  for (const n of $$('#fx-list [data-p]')) n.classList.toggle('sel', FX.sel.has(n.dataset.p));
  fxStatus();
  renderFxPreview();
}
function fxStatus() {
  const n = FX.shown ? FX.shown.length : 0;
  const sel = [...FX.sel].map(p => FX.items.find(i => i.p === p)).filter(Boolean);
  const size = sel.reduce((a, i) => a + (i.s || 0), 0);
  setText('fx-status', sel.length ? `${plural(sel.length, 'elemento seleccionado', 'elementos seleccionados')}${size ? ' · ' + fxSize(size) : ''}` : plural(n, 'elemento', 'elementos'));
}

function applyFxLook() {
  const box = $('#fx');
  if (!box) return;
  box.dataset.bg = S.settings.fxBg || 'vidrio';
  box.classList.toggle('with-prev', !!S.settings.fxPreview);
}
function renderFxOpts() {
  const p = $('#fx-optp');
  const st = S.settings;
  const seg = (key, def, opts) => el('div', { class: 'seg small' }, opts.map(([v, n]) => { const b = el('button', { type: 'button', class: (st[key] || def) === v ? 'on' : '', text: n }); b.onclick = () => { st[key] = v; save(); renderFxOpts(); applyFxLook(); renderFxList(); }; return b; }));
  const sw = (key, label, def) => { const lab = el('label', { class: 'switch' }, el('input', { type: 'checkbox' }), el('span'), ' ' + label); const inp = lab.querySelector('input'); inp.checked = def ? st[key] !== false : !!st[key]; inp.onchange = () => { st[key] = inp.checked; save(); applyFxLook(); if (key === 'fxHidden') fxGo(FX.dir, true); else { renderFxList(); renderFxPreview(); } }; return lab; };
  const start = el('select', { 'aria-label': 'Al abrir' }, [['downloads', 'Descargas'], ['desktop', 'Escritorio'], ['documents', 'Documentos'], ['pictures', 'Imágenes'], ['last', 'La última carpeta que usé']].map(([v, n]) => el('option', { value: v, text: n })));
  start.value = st.fxStart || 'downloads'; start.onchange = () => { st.fxStart = start.value; save(); };
  p.replaceChildren(
    el('b', { class: 'fx-opt-t', text: 'Personalizar el explorador' }),
    el('span', { class: 'fx-opt-l', text: 'Tamaño de los íconos' }), seg('fxSize', 'm', [['s', 'Chicos'], ['m', 'Medianos'], ['l', 'Grandes'], ['xl', 'Enormes']]),
    el('span', { class: 'fx-opt-l', text: 'Fondo' }), seg('fxBg', 'vidrio', [['vidrio', 'Vidrio'], ['solido', 'Sólido'], ['color', 'Del color principal'], ['oscuro', 'Oscuro']]),
    sw('fxPreview', 'Panel de vista previa a la derecha'), sw('fxExt', 'Mostrar las extensiones (.pdf, .jpg…)', true), sw('fxFoldersFirst', 'Carpetas primero', true), sw('fxHidden', 'Mostrar archivos ocultos'),
    el('span', { class: 'fx-opt-l', text: 'Al abrir, empezar en' }), start,
    el('p', { class: 'hint', text: 'Clic derecho en una carpeta para pintarla de un color o fijarla al costado.' }));
}
async function renderFxPreview() {
  const box = $('#fx-prev');
  if (!box || !S.settings.fxPreview) return;
  const items = fxSelItems();
  if (items.length !== 1) {
    const all = FX.items || [];
    box.replaceChildren(el('div', { class: 'fx-pv-empty' }, svg(FX_ICO.dir), el('b', { text: (FX.dir.split(/[\\/]/).filter(Boolean).pop() || FX.dir) }),
      el('span', { text: items.length ? `${plural(items.length, 'elemento seleccionado', 'elementos seleccionados')}` : `${plural(all.filter(i => i.d).length, 'carpeta', 'carpetas')} · ${plural(all.filter(i => !i.d).length, 'archivo', 'archivos')}` })));
    return;
  }
  const x = items[0];
  const pic = el('div', { class: 'fx-pv-pic' }, fxIconEl(x, true));
  const open = el('button', { class: 'btn', text: x.d ? 'Abrir carpeta' : 'Abrir' }); open.onclick = () => fxActivate(x);
  const show = el('button', { class: 'btn ghost', text: 'Ver en Windows' }); show.onclick = () => api.fx.reveal(x.p);
  const kind = x.d ? 'Carpeta' : (x.x ? `Archivo ${x.x.toUpperCase()}` : 'Archivo');
  const meta = el('dl', { class: 'fx-pv-meta' }, el('dt', { text: 'Tipo' }), el('dd', { text: kind }),
    x.d ? null : el('dt', { text: 'Tamaño' }), x.d ? null : el('dd', { text: fxSize(x.s) || '0 B' }),
    el('dt', { text: 'Modificado' }), el('dd', { text: x.m ? new Date(x.m).toLocaleString('es-AR', { dateStyle: 'medium', timeStyle: 'short' }) : '—' }));
  const text = el('pre', { class: 'fx-pv-text', hidden: true });
  box.replaceChildren(pic, el('b', { class: 'fx-pv-n', text: x.n }), meta, text, el('div', { class: 'row' }, open, show));
  const ico = pic.querySelector('.fx-ico[data-p]');
  if (ico) {
    const u = (ico.dataset.t ? await safeCall(() => api.fx.thumb(x.p)) : null) || await safeCall(() => api.fx.icon(x.p));
    if (u && ico.isConnected) { ico.replaceChildren(el('img', { src: u, alt: '' })); ico.classList.toggle('thumb', !!ico.dataset.t); }
  }
  if (!x.d && api.fx.peek) { const t = await safeCall(() => api.fx.peek(x.p)); if (t && text.isConnected) { text.textContent = t; text.hidden = false; } }
}
let fxIconObs = null;
function fxLazyIcons() {
  if (fxIconObs) fxIconObs.disconnect();
  fxIconObs = new IntersectionObserver((ents) => {
    for (const en of ents) {
      if (!en.isIntersecting) continue;
      const box = en.target; fxIconObs.unobserve(box);
      const p = box.dataset.p;
      const pr = box.dataset.t ? api.fx.thumb(p).then(u => u || api.fx.icon(p)) : api.fx.icon(p);
      pr.then(u => { if (u && box.isConnected) { box.replaceChildren(el('img', { src: u, alt: '', draggable: 'false' })); box.classList.toggle('thumb', !!box.dataset.t); } }).catch(() => {});
    }
  }, { root: $('#fx-list'), rootMargin: '200px' });
  for (const b of $$('#fx-list .fx-ico[data-p]')) fxIconObs.observe(b);
}
async function fxActivate(x) {
  if (x.d) return fxGo(x.p);
  const err = await safeCall(() => api.fx.open(x.p));
  if (err) toast('No se pudo abrir: ' + err);
}
function fxSelItems() { return [...FX.sel].map(p => FX.items.find(i => i.p === p)).filter(Boolean); }
async function fxRename(x) {
  const node = document.querySelector(`#fx-list [data-p="${CSS.escape(x.p)}"] .fx-n, #fx-list [data-p="${CSS.escape(x.p)}"] .fx-rn > span:last-child`);
  if (!node) return;
  const inp = el('input', { class: 'fx-ren', value: x.n, 'aria-label': 'Nuevo nombre' });
  node.replaceWith(inp);
  inp.focus();
  const dot = x.d ? -1 : x.n.lastIndexOf('.');
  inp.setSelectionRange(0, dot > 0 ? dot : x.n.length);
  let done = false;
  const finish = async (ok) => {
    if (done) return; done = true;
    const v = inp.value.trim();
    if (ok && v && v !== x.n) { const err = await safeCall(() => api.fx.rename(x.p, v)); if (err) toast(err); }
    fxGo(FX.dir, true);
  };
  inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter') finish(true); if (e.key === 'Escape') finish(false); };
  inp.onblur = () => finish(true);
  inp.onclick = (e) => e.stopPropagation();
  inp.ondblclick = (e) => e.stopPropagation();
}
async function fxTrash(items) {
  if (!items.length) return;
  const err = await safeCall(() => api.fx.trash(items.map(i => i.p)));
  toast(err || `${items.length === 1 ? `“${items[0].n}”` : plural(items.length, 'elemento', 'elementos')} a la papelera`);
  fxGo(FX.dir, true);
}
async function fxNewFolder() {
  const r = await safeCall(() => api.fx.mkdir(FX.dir, 'Nueva carpeta'));
  if (!r || r.error) return toast((r && r.error) || 'No se pudo crear la carpeta');
  await fxGo(FX.dir, true);
  const x = FX.items.find(i => i.p === r.path);
  if (x) { FX.sel = new Set([x.p]); paintFxSel(); fxRename(x); }
}
async function fxPaste() {
  if (!FX.clip) return;
  const err = await safeCall(() => api.fx.paste(FX.clip.list, FX.dir, FX.clip.move));
  if (FX.clip.move) FX.clip = null;
  if (err) toast(err);
  fxGo(FX.dir, true);
}
async function fxToLauncher(items) {
  for (const x of items.slice(0, 12)) {
    const sc = { id: uid(), type: x.d ? 'folder' : 'app', name: x.d ? x.n : x.n.replace(/\.(lnk|exe|url)$/i, ''), target: x.p };
    sc.icon = await safeCall(() => api.iconFor(x.p));
    M().shortcuts.push(sc);
  }
  save(); refreshLaunch();
  toast(items.length === 1 ? `“${items[0].n}” quedó en tus accesos` : 'Quedaron en tus accesos');
}
function fxCtx(on, x, y, item) {
  const m = $('#fx-ctx');
  if (!on) { m.hidden = true; return; }
  const items = fxSelItems();
  const one = items.length === 1 ? items[0] : null;
  const it = (label, fn, ico, danger) => { const b = el('button', { role: 'menuitem', class: danger ? 'danger' : '' }, ico ? svg(ico) : el('i'), el('span', { text: label })); b.onclick = () => { fxCtx(false); fn(); }; return b; };
  const sep = () => el('hr');
  const kids = [];
  if (item) {
    kids.push(it(one && one.d ? 'Abrir' : 'Abrir', () => items.forEach(fxActivate), '<path d="M14 4h6v6M20 4l-8 8"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'));
    if (one && one.d) {
      const cols = ['', '#e8a10c', '#e0533d', '#d6336c', '#7b4fc9', '#3557c7', '#1c9bd6', '#2f9e44', '#868e96'];
      kids.push(el('div', { class: 'fx-colors' }, el('span', { text: 'Color' }), ...cols.map(c => { const b = el('button', { class: 'fx-sw' + (((S.settings.fxColors || {})[one.p] || '') === c ? ' on' : ''), style: `--c:${c || '#e8a10c'}`, title: c ? 'Pintar la carpeta' : 'Color de siempre' }, c ? null : el('i', { text: '×' })); b.onclick = () => { fxCtx(false); const m2 = S.settings.fxColors = S.settings.fxColors || {}; if (c) m2[one.p] = c; else delete m2[one.p]; save(); renderFxList(); renderFxSide(); }; return b; })));
    }
    if (one && one.d) kids.push(it((S.settings.fxPins || []).includes(one.p) ? 'Quitar de Fijadas' : 'Fijar en el costado', () => { const pins = S.settings.fxPins = S.settings.fxPins || []; const i = pins.indexOf(one.p); if (i >= 0) pins.splice(i, 1); else pins.push(one.p); save(); renderFxSide(); }, '<path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v7"/>'));
    kids.push(it('Agregar a mis accesos de Base', () => fxToLauncher(items), '<path d="M12 5v14M5 12h14"/>'));
    kids.push(sep());
    kids.push(it('Cortar', () => { FX.clip = { list: items.map(i => i.p), move: true }; toast('Elegí la carpeta y tocá Pegar'); }, '<circle cx="6" cy="18" r="3"/><circle cx="18" cy="18" r="3"/><path d="M8.5 16 18 4M15.5 16 6 4"/>'));
    kids.push(it('Copiar', () => { FX.clip = { list: items.map(i => i.p), move: false }; toast('Copiado: elegí la carpeta y tocá Pegar'); }, '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>'));
  }
  if (FX.clip) kids.push(it(`Pegar ${plural(FX.clip.list.length, 'elemento', 'elementos')}`, fxPaste, '<rect x="6" y="5" width="12" height="16" rx="2"/><path d="M9 5V3h6v2"/>'));
  if (item) {
    if (one) kids.push(it('Cambiar el nombre', () => fxRename(one), '<path d="M4 20h4L19 9l-4-4L4 16z"/>'));
    kids.push(it('Copiar la ruta', () => api.fx.copyPath(one ? one.p : FX.dir), '<path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1"/>'));
    if (one) kids.push(it('Mostrar en el Explorador de Windows', () => api.fx.reveal(one.p), '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'));
    kids.push(sep());
    kids.push(it('Mandar a la papelera', () => fxTrash(items), ICON.trash, true));
  } else {
    kids.push(it('Nueva carpeta', fxNewFolder, '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v5M9.5 13.5h5"/>'));
    kids.push(it('Actualizar', () => fxGo(FX.dir, true), '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>'));
    kids.push(it('Abrir en el Explorador de Windows', () => api.fx.winExplorer(FX.dir), '<path d="M14 4h6v6M20 4l-8 8"/>'));
  }
  m.replaceChildren(...kids);
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
}
function fxKeys(e) {
  if (e.target.matches('input') && e.key !== 'Escape' && e.key !== 'Enter' && !(e.key === 'ArrowDown' && e.target.id === 'fx-q')) return;
  const items = fxSelItems();
  if (e.key === 'Escape') { e.stopPropagation(); if (!$('#fx-ctx').hidden) fxCtx(false); else if (e.target.id === 'fx-q' && FX.q) { e.target.value = ''; FX.q = ''; renderFxList(); } else fxClose(); return; }
  if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); $('#fx-back').click(); return; }
  if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); $('#fx-fwd').click(); return; }
  if (e.key === 'Backspace') { e.preventDefault(); $('#fx-up').click(); return; }
  if (e.key === 'Enter') { e.preventDefault(); if (items.length) items.forEach(fxActivate); else if (e.target.id === 'fx-q' && FX.shown && FX.shown[0]) fxActivate(FX.shown[0]); return; }
  if (e.key === 'Delete' && items.length) { e.preventDefault(); fxTrash(items); return; }
  if (e.key === 'F2' && items.length === 1) { e.preventDefault(); fxRename(items[0]); return; }
  if (e.ctrlKey && /^[cxva]$/i.test(e.key)) {
    e.preventDefault();
    const k = e.key.toLowerCase();
    if (k === 'a') { FX.sel = new Set((FX.shown || []).map(i => i.p)); paintFxSel(); }
    if (k === 'c' && items.length) FX.clip = { list: items.map(i => i.p), move: false };
    if (k === 'x' && items.length) FX.clip = { list: items.map(i => i.p), move: true };
    if (k === 'v') fxPaste();
    return;
  }
  if (/^Arrow(Up|Down|Left|Right)$/.test(e.key) && FX.shown && FX.shown.length) {
    e.preventDefault();
    const ps = FX.shown.map(i => i.p);
    let i = ps.indexOf(FX.anchor);
    const cols = S.settings.fxView === 'list' ? 1 : Math.max(1, Math.round($('#fx-list').clientWidth / 124));
    const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : e.key === 'ArrowDown' ? cols : -cols;
    i = i < 0 ? 0 : Math.max(0, Math.min(ps.length - 1, i + d));
    FX.anchor = ps[i]; FX.sel = new Set([ps[i]]); paintFxSel();
    const n = document.querySelector(`#fx-list [data-p="${CSS.escape(ps[i])}"]`); if (n) { n.scrollIntoView({ block: 'nearest' }); n.focus(); }
  }
}

// ---------- Inicio de Base (apps instaladas, fijadas, recientes y apagado) ----------
const SMN = { apps: null, recent: null, q: '', icons: {} };
function smOpen(on) {
  const box = $('#sm');
  if (on == null) on = box.hidden;
  if (!on) { box.hidden = true; $('[data-sys="start"]') && $('[data-sys="start"]').classList.remove('on'); return; }
  if (!api.sm) return toast('El Inicio de Base funciona en la app instalada');
  box.hidden = false;
  const b = $('[data-sys="start"]');
  if (b) { b.classList.add('on'); const r = b.getBoundingClientRect(); box.style.left = Math.max(10, Math.min(r.left - 8, innerWidth - 700)) + 'px'; box.style.top = (r.bottom + 8) + 'px'; }
  SMN.q = ''; SMN.cat = null; SMN.all = false;
  renderSm();
  const q = $('#sm-q'); if (q) { q.value = ''; q.focus(); }
  Promise.all([api.sm.apps(false), api.sm.recent()]).then(([a, r]) => { SMN.apps = a || []; SMN.recent = r || []; renderSm(); });
}
function smIcon(it) {
  const box = el('span', { class: 'sm-ico' }, el('b', { text: (it.n || '?').trim().charAt(0).toUpperCase() }));
  const key = it.p || it.aumid;
  const put = (u) => { if (u) box.replaceChildren(el('img', { src: u, alt: '', draggable: 'false' })); };
  if (SMN.icons[key] !== undefined) put(SMN.icons[key]);
  else if (it.p) api.sm.icon(it.p).then(u => { SMN.icons[key] = u || null; put(u); }).catch(() => {});
  return box;
}
function smLaunch(it) {
  smOpen(false);
  api.sm.open(it).then(err => { if (err) toast('No se pudo abrir: ' + err); });
}
function smPins() { return (S.settings.smPins || []).map(k => (SMN.apps || []).find(a => (a.p || a.aumid) === k)).filter(Boolean); }
const SM_CATS = [
  { id: 'juegos', n: 'Juegos', c: '#7b4fc9', ico: '<rect x="2.5" y="7" width="19" height="11" rx="5.5"/><path d="M7 10.5v4M5 12.5h4"/><circle cx="15.5" cy="11.5" r="1"/><circle cx="17.5" cy="13.8" r="1"/>',
    kw: /steam|epic games|xbox|ea app|origin|ubisoft|uplay|riot|battle\.net|gog galaxy|rockstar|minecraft|roblox|league of|valorant|fortnite|counter|dota|game|juego|launcher|playnite|retroarch|emulador|nintendo|playstation|solitaire|solitario/i, folders: /^(steam|epic games|games|juegos|rockstar games|ubisoft|ea|riot games)$/i },
  { id: 'internet', n: 'Internet y chats', c: '#1c9bd6', ico: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    kw: /chrome|firefox|edge|opera|brave|vivaldi|tor browser|whatsapp|telegram|discord|zoom|teams|skype|slack|messenger|outlook|thunderbird|mail|correo|signal|anydesk|teamviewer|filezilla|qbittorrent|utorrent/i },
  { id: 'media', n: 'Música y video', c: '#e0533d', ico: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
    kw: /spotify|vlc|netflix|disney|prime video|youtube|itunes|apple music|music|música|media player|reproductor|obs|audacity|kodi|plex|twitch|deezer|tidal|winamp|foobar|potplayer|mpc|streamlabs|películas|movies|tv/i },
  { id: 'oficina', n: 'Oficina y trabajo', c: '#2f9e44', ico: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
    kw: /word|excel|powerpoint|onenote|outlook|access|publisher|project|visio|acrobat|pdf|libreoffice|openoffice|notion|evernote|obsidian|calculadora|calculator|calendar|calendario|onedrive|google drive|dropbox|recepciones|office|sheets|docs|trello|todo|tareas|contabil|factur|afip|tango|sap/i, folders: /^(microsoft office|office|libreoffice)/i },
  { id: 'crear', n: 'Diseño y fotos', c: '#d6336c', ico: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>',
    kw: /photoshop|illustrator|lightroom|premiere|after effects|indesign|gimp|paint|canva|figma|blender|davinci|capcut|fotos|photos|clipchamp|inkscape|krita|affinity|corel|sketchup|autocad|cinema 4d|filmora|shotcut|kdenlive|audition/i, folders: /^(adobe|autodesk)/i },
  { id: 'dev', n: 'Programación', c: '#3557c7', ico: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 5l-4 14"/>',
    kw: /visual studio|vs code|\bcode\b|python|node|git|terminal|powershell|android studio|intellij|pycharm|webstorm|cmd|símbolo del sistema|wsl|ubuntu|docker|postman|sql|mysql|xampp|unity|unreal|sublime|notepad\+\+|cursor|claude/i },
  { id: 'sistema', n: 'Sistema y utilidades', c: '#868e96', ico: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1"/>',
    kw: /configuración|settings|panel de control|control panel|administrador|manager|explorador|explorer|bloc de notas|notepad|recortes|snipping|winrar|7-zip|ccleaner|nvidia|geforce|amd|radeon|intel|realtek|logitech|razer|corsair|steelseries|antivirus|defender|avast|norton|kaspersky|malwarebytes|herramientas|tools|accesibilidad|accessibility|windows|reloj|clock|alarm|cámara|camera|grabadora|recorder|mapas|maps|el tiempo|weather|store|tienda|copilot|teclado|keyboard|ayuda|tips|driver|bluetooth|printer|impresora|scanner|escáner|backup|update|actualiz|disk|disco|limpieza/i,
    folders: /^(accessories|accesorios|windows tools|herramientas de windows|system tools|herramientas del sistema|accessibility|accesibilidad|windows powershell|administrative tools|startup|inicio)$/i }
];
function smCatOf(a) {
  const key = a.p || a.aumid;
  const forced = (S.settings.smCat || {})[key];
  if (forced && (forced === 'otras' || SM_CATS.some(c => c.id === forced))) return forced;
  for (const c of SM_CATS) if (c.folders && a.cat && c.folders.test(a.cat)) return c.id;
  for (const c of SM_CATS) if (c.kw.test(a.n)) return c.id;
  return 'otras';
}
const SM_OTHER = { id: 'otras', n: 'Otras', c: '#adb5bd', ico: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>' };
function smCtx(e, it) {
  e.preventDefault();
  const m = $('#fx-ctx');
  const key = it.p || it.aumid;
  const pinned = (S.settings.smPins || []).includes(key);
  const btn = (label, fn, ico) => { const b = el('button', { role: 'menuitem' }, ico ? svg(ico) : el('i'), el('span', { text: label })); b.onclick = () => { m.hidden = true; fn(); }; return b; };
  const cur = smCatOf(it);
  m.replaceChildren(
    btn('Abrir', () => smLaunch(it), '<path d="M14 4h6v6M20 4l-8 8"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'),
    btn(pinned ? 'Quitar de Fijadas' : 'Fijar arriba', () => smTogglePin(it), '<path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v7"/>'),
    it.p ? btn('Agregar a mis accesos de Base', async () => { const sc = { id: uid(), type: 'app', name: it.n, target: it.p }; sc.icon = await safeCall(() => api.iconFor(it.p)); M().shortcuts.push(sc); save(); refreshLaunch(); toast(`${it.n} quedó en tus accesos`); }, '<path d="M12 5v14M5 12h14"/>') : null,
    el('hr'), el('span', { class: 'fx-ctx-h', text: 'Mover a la categoría' }),
    ...[...SM_CATS, SM_OTHER].map(c => { const b = btn(c.n, () => { const m2 = S.settings.smCat = S.settings.smCat || {}; m2[key] = c.id; save(); renderSm(); }, c.ico); if (c.id === cur) b.classList.add('on'); b.style.setProperty('--cc', c.c); return b; }));
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(e.clientX, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(e.clientY, innerHeight - r.height - 8) + 'px';
}
function smTogglePin(it) {
  const k = it.p || it.aumid;
  const pins = S.settings.smPins = S.settings.smPins || [];
  const i = pins.indexOf(k);
  if (i >= 0) pins.splice(i, 1); else pins.push(k);
  save(); renderSm();
}
function smAppBtn(it, big) {
  const b = el('button', { class: big ? 'sm-pin' : 'sm-app', title: it.n + (it.cat ? ` · ${it.cat}` : '') }, smIcon(it), el('span', { text: it.n }));
  b.onclick = () => smLaunch(it);
  b.oncontextmenu = (e) => smCtx(e, it);
  return b;
}
function renderSm() {
  const box = $('#sm');
  if (box.hidden) return;
  if (!box.dataset.built) {
    box.dataset.built = '1';
    const q = el('input', { id: 'sm-q', placeholder: 'Buscar apps, archivos recientes…', 'aria-label': 'Buscar' });
    q.oninput = () => { SMN.q = q.value.trim().toLowerCase(); renderSm(); };
    q.onkeydown = (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); smOpen(false); }
      if (e.key === 'Enter') { const first = $('#sm-body .sm-app, #sm-body .sm-pin, #sm-body .sm-rec'); if (first) first.click(); }
    };
    box.append(el('label', { class: 'sm-search' }, svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'), q), el('div', { class: 'sm-body', id: 'sm-body' }), el('footer', { class: 'sm-foot', id: 'sm-foot' }));
    box.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.stopPropagation(); smOpen(false); } });
  }
  const body = $('#sm-body');
  const apps = SMN.apps;
  const kids = [];
  if (!apps) kids.push(el('p', { class: 'sm-none', text: 'Cargando tus apps…' }));
  else if (SMN.q) {
    const qq = SMN.q;
    const hits = apps.filter(a => a.n.toLowerCase().includes(qq)).sort((a, b) => a.n.toLowerCase().indexOf(qq) - b.n.toLowerCase().indexOf(qq)).slice(0, 30);
    const rec = (SMN.recent || []).filter(r => r.n.toLowerCase().includes(qq)).slice(0, 6);
    if (hits.length) kids.push(el('span', { class: 'sm-h', text: 'Apps' }), el('div', { class: 'sm-list' }, hits.map(a => smAppBtn(a))));
    if (rec.length) kids.push(el('span', { class: 'sm-h', text: 'Recientes' }), el('div', { class: 'sm-recs' }, rec.map(smRecBtn)));
    if (!hits.length && !rec.length) kids.push(el('p', { class: 'sm-none', text: 'No encontré nada con ese nombre.' }));
  } else if (SMN.cat) {
    const c = [...SM_CATS, SM_OTHER].find(x => x.id === SMN.cat) || SM_OTHER;
    const back = el('button', { class: 'sm-back' }, svg('<path d="m15 6-6 6 6 6"/>'), el('span', { text: 'Categorías' }));
    back.onclick = () => { SMN.cat = null; renderSm(); };
    const list = apps.filter(a => smCatOf(a) === c.id);
    kids.push(el('div', { class: 'sm-cat-head', style: `--cc:${c.c}` }, back, el('span', { class: 'sm-cat-ico' }, svg(c.ico)), el('b', { text: c.n }), el('small', { text: plural(list.length, 'app', 'apps') })),
      list.length ? el('div', { class: 'sm-list' }, list.map(a => smAppBtn(a))) : el('p', { class: 'sm-none', text: 'No hay apps acá. Clic derecho en una app > Mover a la categoría.' }));
  } else if (SMN.all) {
    const back = el('button', { class: 'sm-back' }, svg('<path d="m15 6-6 6 6 6"/>'), el('span', { text: 'Volver' }));
    back.onclick = () => { SMN.all = false; renderSm(); };
    const groups = {};
    for (const a of apps) { const L = /^[a-zñ]/i.test(a.n) ? a.n.charAt(0).toUpperCase() : '#'; (groups[L] = groups[L] || []).push(a); }
    kids.push(el('div', { class: 'sm-cat-head' }, back, el('b', { text: 'Todas las apps' }), el('small', { text: plural(apps.length, 'app', 'apps') })),
      el('div', { class: 'sm-all' }, Object.entries(groups).sort((a, b) => a[0].localeCompare(b[0], 'es')).map(([L, list]) => el('div', { class: 'sm-grp' }, el('b', { class: 'sm-letter', text: L }), el('div', { class: 'sm-list' }, list.map(a => smAppBtn(a)))))));
  } else {
    const pins = smPins();
    kids.push(el('span', { class: 'sm-h', text: 'Fijadas' }), pins.length ? el('div', { class: 'sm-pins' }, pins.map(a => smAppBtn(a, true))) : el('p', { class: 'sm-none', text: 'Clic derecho en una app > Fijar arriba.' }));
    const byCat = {};
    for (const a of apps) (byCat[smCatOf(a)] = byCat[smCatOf(a)] || []).push(a);
    const allBtn = el('button', { class: 'text-btn sm-allbtn', text: `Todas las apps (${apps.length}) ›` }); allBtn.onclick = () => { SMN.all = true; renderSm(); };
    kids.push(el('div', { class: 'sm-hrow' }, el('span', { class: 'sm-h', text: 'Categorías' }), allBtn),
      el('div', { class: 'sm-cats' }, [...SM_CATS, SM_OTHER].filter(c => byCat[c.id] && byCat[c.id].length).map(c => {
        const list = byCat[c.id];
        const b = el('button', { class: 'sm-cat', style: `--cc:${c.c}` },
          el('span', { class: 'sm-cat-icons' }, list.slice(0, 4).map(a => smIcon(a))),
          el('span', { class: 'sm-cat-n' }, el('b', { text: c.n }), el('small', { text: plural(list.length, 'app', 'apps') })));
        b.onclick = () => { SMN.cat = c.id; renderSm(); $('#sm-body').scrollTop = 0; };
        return b;
      })));
  }
  body.replaceChildren(...kids);
  const foot = $('#sm-foot');
  const user = el('span', { class: 'sm-user' }, el('span', { class: 'sm-av', text: (S.settings.name || 'Vos').charAt(0).toUpperCase() }), el('b', { text: S.settings.name || 'Vos' }));
  const files = el('button', { class: 'text-btn', text: 'Archivos' }); files.onclick = () => { smOpen(false); fxOpen(); };
  const winStart = el('button', { class: 'text-btn', text: 'Inicio de Windows' }); winStart.onclick = () => { smOpen(false); api.windows && api.windows.system('start'); };
  const power = el('button', { class: 'icon-btn', title: 'Apagar, reiniciar, suspender', 'aria-label': 'Apagado' }, svg('<path d="M12 3v8"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>'));
  power.onclick = (e) => { e.stopPropagation(); smOpen(false); mpOpen(true); };
  const winDesk = el('button', { class: 'text-btn', text: 'Escritorio de Windows', title: 'Base se corre hasta que la vuelvas a abrir' }); winDesk.onclick = () => { smOpen(false); deskPeek(); };
  foot.replaceChildren(user, el('span', { class: 'spacer' }), files, winDesk, winStart, power);
}
function smRecBtn(r) {
  const b = el('button', { class: 'sm-rec', title: r.p }, el('span', { class: 'sm-ico' }, svg(r.d ? FX_ICO.dir : FX_ICO.file)), el('span', { class: 'sm-rn' }, el('b', { text: r.n }), el('small', { text: ago(r.m) })));
  api.fx.icon(r.p).then(u => { if (u) b.firstChild.replaceChildren(el('img', { src: u, alt: '' })); }).catch(() => {});
  b.onclick = () => { smOpen(false); if (r.d) fxOpen(r.p); else api.fx.open(r.p); };
  return b;
}
function setupFxSm() {
  const start = $('[data-sys="start"]'), exp = $('[data-sys="explorer"]');
  const mine = () => S.settings.baseShell !== false;
  if (start) {
    start.onclick = (e) => { e.stopPropagation(); if (mine() && api.sm) smOpen(); else api.windows && api.windows.system('start'); };
    start.title = 'Inicio (clic derecho: el de Windows)';
    start.oncontextmenu = (e) => { e.preventDefault(); api.windows && api.windows.system('start'); };
  }
  if (exp) {
    exp.onclick = (e) => { e.stopPropagation(); if (mine() && api.fx) fxOpen(); else api.windows && api.windows.system('explorer'); };
    exp.title = 'Archivos (clic derecho: el Explorador de Windows)';
    exp.oncontextmenu = (e) => { e.preventDefault(); api.windows && api.windows.system('explorer'); };
  }
  document.addEventListener('pointerdown', (e) => {
    if (!$('#fx-ctx').hidden && !e.target.closest('#fx-ctx')) fxCtx(false);
    if (!$('#sm').hidden && !e.target.closest('#sm, [data-sys="start"], #fx-ctx')) smOpen(false);
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (!$('#sm').hidden) smOpen(false); else if (!$('#fx').hidden && !document.querySelector('dialog[open]')) fxClose(); } });
  if (api.sm) setTimeout(() => api.sm.apps(false).then(a => { SMN.apps = a || []; }).catch(() => {}), 8000);
}

// ---------- Puntero del mouse (dentro de Base) ----------
const CURSORS = [
  { id: 'sistema', n: 'El de Windows' },
  { id: 'flecha', n: 'Flecha de color' },
  { id: 'grande', n: 'Flecha grande' },
  { id: 'punto', n: 'Punto' },
  { id: 'mira', n: 'Mira' },
  { id: 'contorno', n: 'Contorno' },
  { id: 'gota', n: 'Gota' },
  { id: 'neon', n: 'Neón' },
  { id: 'estrella', n: 'Estrella' },
  { id: 'pixel', n: 'Retro' }
];
function cursorSvg(kind, color, hand) {
  const c = color, o = '#ffffff';
  const enc = (svgText, x, y) => `url("data:image/svg+xml;utf8,${encodeURIComponent(svgText)}") ${x} ${y}`;
  if (kind === 'flecha' || kind === 'grande') {
    const s = kind === 'grande' ? 40 : 26;
    if (hand) return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='${s}' height='${s}' viewBox='0 0 26 26'><path d='M9 2.5a1.8 1.8 0 0 1 3.6 0V11l1-.2a1.8 1.8 0 0 1 2.2 1.3l.3-.1a1.8 1.8 0 0 1 2.3 1.5 1.8 1.8 0 0 1 2.4 1.7V18c0 3.5-2.6 6-6 6h-2.5c-2 0-3.6-1-4.6-2.6L4 15.8a1.8 1.8 0 0 1 3-2l2 2.4z' fill='${c}' stroke='${o}' stroke-width='1.4' stroke-linejoin='round'/></svg>`, Math.round(s * .38), 1);
    return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='${s}' height='${s}' viewBox='0 0 26 26'><path d='M3 2l17 9.5-7.2 1.6L9.2 20z' fill='${c}' stroke='${o}' stroke-width='1.6' stroke-linejoin='round'/></svg>`, Math.round(s * .1), Math.round(s * .07));
  }
  if (kind === 'punto') {
    return hand
      ? enc(`<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32'><circle cx='16' cy='16' r='11' fill='${c}' fill-opacity='.25' stroke='${c}' stroke-width='2'/><circle cx='16' cy='16' r='4' fill='${c}' stroke='${o}' stroke-width='1.5'/></svg>`, 16, 16)
      : enc(`<svg xmlns='http://www.w3.org/2000/svg' width='22' height='22'><circle cx='11' cy='11' r='6' fill='${c}' stroke='${o}' stroke-width='2'/></svg>`, 11, 11);
  }
  if (kind === 'contorno') {
    return hand
      ? enc(`<svg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 26 26'><path d='M9 2.5a1.8 1.8 0 0 1 3.6 0V11l1-.2a1.8 1.8 0 0 1 2.2 1.3l.3-.1a1.8 1.8 0 0 1 2.3 1.5 1.8 1.8 0 0 1 2.4 1.7V18c0 3.5-2.6 6-6 6h-2.5c-2 0-3.6-1-4.6-2.6L4 15.8a1.8 1.8 0 0 1 3-2l2 2.4z' fill='${o}' fill-opacity='.85' stroke='${c}' stroke-width='2' stroke-linejoin='round'/></svg>`, 10, 1)
      : enc(`<svg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 26 26'><path d='M3 2l17 9.5-7.2 1.6L9.2 20z' fill='${o}' fill-opacity='.85' stroke='${c}' stroke-width='2.2' stroke-linejoin='round'/></svg>`, 3, 2);
  }
  if (kind === 'gota') {
    return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28'><path d='M3 3l20 6.5c1.4.5 1.4 2.4 0 2.9l-7.2 2.4-2.4 7.2c-.5 1.4-2.4 1.4-2.9 0z' fill='${c}' stroke='${o}' stroke-width='1.6' stroke-linejoin='round'/>${hand ? `<circle cx='15' cy='15' r='3' fill='${o}'/>` : ''}</svg>`, 3, 3);
  }
  if (kind === 'neon') {
    return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='34' height='34' viewBox='0 0 34 34'><defs><filter id='g' x='-50%' y='-50%' width='200%' height='200%'><feGaussianBlur stdDeviation='1.8'/></filter></defs><path d='M6 5l17 9.5-7.2 1.6L12.2 23z' fill='none' stroke='${c}' stroke-width='3.4' filter='url(#g)' stroke-linejoin='round'/><path d='M6 5l17 9.5-7.2 1.6L12.2 23z' fill='${hand ? c : 'none'}' fill-opacity='.35' stroke='${o}' stroke-width='1.5' stroke-linejoin='round'/></svg>`, 6, 5);
  }
  if (kind === 'estrella') {
    const st = (cx, cy, r) => { let d = ''; for (let i = 0; i < 10; i++) { const a = Math.PI / 5 * i - Math.PI / 2, rr = i % 2 ? r * .45 : r; d += (i ? 'L' : 'M') + (cx + rr * Math.cos(a)).toFixed(1) + ' ' + (cy + rr * Math.sin(a)).toFixed(1); } return d + 'Z'; };
    return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' viewBox='0 0 30 30'><path d='${st(15, 15, hand ? 13 : 11)}' fill='${c}' stroke='${o}' stroke-width='1.6' stroke-linejoin='round'/></svg>`, 15, 15);
  }
  if (kind === 'pixel') {
    const px = hand
      ? ['....XX......', '...XooX.....', '...XooX.....', '...XooXXX...', '...XooXooXX.', 'XX.XooXooXoX', 'XoXXooooooX.', 'XooXoooooooX', '.XooooooooX.', '..XoooooooX.', '...XoooooX..', '....XXXXX...']
      : ['X...........', 'XX..........', 'XoX.........', 'XooX........', 'XoooX.......', 'XooooX......', 'XoooooX.....', 'XooooooX....', 'XoooXXXXX...', 'XooX........', 'XoX.........', 'XX..........'];
    let rects = '';
    px.forEach((row, y) => [...row].forEach((ch, x) => { if (ch !== '.') rects += `<rect x='${x * 2}' y='${y * 2}' width='2' height='2' fill='${ch === 'X' ? '#111' : c}'/>`; }));
    return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' shape-rendering='crispEdges'>${rects}</svg>`, hand ? 8 : 0, 0);
  }
  if (kind === 'mira') {
    return enc(`<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32'><circle cx='16' cy='16' r='${hand ? 11 : 9}' fill='none' stroke='${o}' stroke-width='4'/><circle cx='16' cy='16' r='${hand ? 11 : 9}' fill='none' stroke='${c}' stroke-width='2'/><path d='M16 2v8M16 22v8M2 16h8M22 16h8' stroke='${o}' stroke-width='4'/><path d='M16 2v8M16 22v8M2 16h8M22 16h8' stroke='${c}' stroke-width='2'/><circle cx='16' cy='16' r='1.6' fill='${c}'/></svg>`, 16, 16);
  }
  return '';
}
let trail = null;
function applyCursor() {
  const root = document.documentElement;
  const kind = S.settings.cursor || 'sistema';
  const color = S.settings.cursorColor || M().theme.accent;
  root.classList.toggle('cur-custom', kind !== 'sistema');
  if (kind !== 'sistema') {
    root.style.setProperty('--cur', cursorSvg(kind, color, false) + ', auto');
    root.style.setProperty('--cur-hand', cursorSvg(kind, color, true) + ', pointer');
  }
  // estela
  const want = !!S.settings.cursorTrail;
  if (want && !trail) trail = startTrail();
  if (!want && trail) { trail.stop(); trail = null; }
  if (trail) trail.color = color;
}
function startTrail() {
  const cv = el('canvas', { class: 'cursor-trail', 'aria-hidden': 'true' });
  document.body.append(cv);
  const ctx = cv.getContext('2d');
  const pts = [];
  let raf = 0, alive = true;
  const fit = () => { cv.width = innerWidth * devicePixelRatio; cv.height = innerHeight * devicePixelRatio; ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0); };
  fit();
  const mv = (e) => { pts.push({ x: e.clientX, y: e.clientY, t: performance.now() }); if (!raf) raf = requestAnimationFrame(draw); };
  function draw() {
    raf = 0;
    const now = performance.now();
    while (pts.length && now - pts[0].t > 350) pts.shift();
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    for (let i = 1; i < pts.length; i++) {
      const k = 1 - (now - pts[i].t) / 350;
      ctx.strokeStyle = obj.color; ctx.globalAlpha = k * .55; ctx.lineWidth = 2 + k * 6; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(pts[i - 1].x, pts[i - 1].y); ctx.lineTo(pts[i].x, pts[i].y); ctx.stroke();
    }
    if (pts.length && alive) raf = requestAnimationFrame(draw);
  }
  addEventListener('pointermove', mv, { passive: true });
  addEventListener('resize', fit);
  const obj = { color: '#7b4fc9', stop() { alive = false; removeEventListener('pointermove', mv); removeEventListener('resize', fit); cancelAnimationFrame(raf); cv.remove(); } };
  return obj;
}
function renderCursorPicker() {
  const box = $('#cursor-pick');
  if (!box) return;
  const kind = S.settings.cursor || 'sistema';
  const color = S.settings.cursorColor || M().theme.accent;
  box.replaceChildren(...CURSORS.map(c => {
    const prev = el('span', { class: 'cur-prev' });
    if (c.id === 'sistema') prev.append(svg('<path d="M5 3l14 8-6 1.5L9.5 19z" fill="#fff" stroke="#111" stroke-width="1.3"/>'));
    else { const u = cursorSvg(c.id, color, false).match(/url\("([^"]+)"\)/); if (u) prev.append(el('img', { src: u[1], alt: '' })); }
    const b = el('button', { type: 'button', class: 'cur-opt' + (kind === c.id ? ' on' : '') }, prev, el('span', { text: c.n }));
    b.onclick = () => { S.settings.cursor = c.id; save(); applyCursor(); renderCursorPicker(); };
    return b;
  }));
  $('#cursor-color').value = /^#[0-9a-f]{6}$/i.test(color) ? color : '#7b4fc9';
  $('#cursor-trail').checked = !!S.settings.cursorTrail;
  $('#cursor-color-row').hidden = kind === 'sistema';
}
function setupCursor() {
  $('#cursor-color').oninput = (e) => { S.settings.cursorColor = e.target.value; save(); applyCursor(); renderCursorPicker(); };
  $('#cursor-accent').onclick = () => { delete S.settings.cursorColor; save(); applyCursor(); renderCursorPicker(); };
  $('#cursor-trail').onchange = (e) => { S.settings.cursorTrail = e.target.checked; save(); applyCursor(); };
  $('#cursor-win').onclick = () => api.windows && api.windows.system('mouse');
}

// ---------- Animación según el clima (zona del reloj y el clima) ----------
const WxAnim = (() => {
  let canvas, ctx, W = 0, H = 0, dpr = 1, kind = null, raf = 0, last = 0;
  let parts = [], clouds = [], stars = [], flash = 0, nextFlash = 0, t0 = performance.now();
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const dark = () => document.documentElement.dataset.scheme === 'dark';
  const rnd = (a, b) => a + Math.random() * (b - a);
  // estilos: clásica, suave, intensa, ilustrada y ambiente
  const sty = () => (S && S.settings.wxStyle) || 'clasica';
  const MULT = { clasica: { d: 1, v: 1, a: 1 }, suave: { d: .45, v: .6, a: .6 }, intensa: { d: 1.9, v: 1.35, a: 1.15 }, ilustrada: { d: .7, v: .8, a: 1 }, ambiente: { d: 0, v: .5, a: 1 } };
  const mul = () => MULT[sty()] || MULT.clasica;

  function kindFrom(code, isDay) {
    const c = Number(code);
    if (c === 0 || c === 1) return isDay ? 'sun' : 'night';
    if (c === 2) return isDay ? 'sunCloud' : 'nightCloud';
    if (c === 3) return 'cloud';
    if (c === 45 || c === 48) return 'fog';
    if (c >= 51 && c <= 57) return 'drizzle';
    if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return 'rain';
    if ((c >= 71 && c <= 77) || c === 85 || c === 86) return 'snow';
    if (c >= 95) return 'storm';
    return null;
  }
  function resize() {
    const hero = document.querySelector('.hero');
    const bottom = hero ? hero.getBoundingClientRect().bottom + 90 : 380;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = Math.max(260, Math.round(bottom));
    canvas.width = W * dpr; canvas.height = H * dpr;
    canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function seed() {
    parts = []; clouds = []; stars = [];
    const k = kind;
    const area = W * H / 100000 * mul().d;
    if (k === 'rain' || k === 'storm' || k === 'drizzle') {
      const n = Math.round(area * (k === 'drizzle' ? 22 : k === 'storm' ? 70 : 45));
      for (let i = 0; i < n; i++) parts.push({ x: rnd(0, W), y: rnd(-H, H), v: rnd(k === 'drizzle' ? 4 : 9, k === 'drizzle' ? 7 : 15), l: rnd(k === 'drizzle' ? 4 : 10, k === 'drizzle' ? 8 : 22) });
    }
    if (k === 'snow') {
      for (let i = 0; i < Math.round(area * 30); i++) parts.push({ x: rnd(0, W), y: rnd(-H, H), r: rnd(1.2, 3.4), v: rnd(.4, 1.3), ph: rnd(0, 6.28) });
    }
    if (k === 'night' || k === 'nightCloud') {
      for (let i = 0; i < Math.round(area * 26); i++) stars.push({ x: rnd(0, W), y: rnd(0, H * .9), r: rnd(.5, 1.6), ph: rnd(0, 6.28), sp: rnd(.6, 2) });
    }
    const nCloud = sty() === 'ambiente' ? 0 : Math.round(({ sunCloud: 4, nightCloud: 4, cloud: 7, rain: 5, storm: 6, drizzle: 5, snow: 4, fog: 0 }[k] || 0) * (sty() === 'intensa' ? 1.4 : sty() === 'suave' ? .6 : 1));
    for (let i = 0; i < nCloud; i++) clouds.push({ x: rnd(-200, W), y: rnd(-30, H * .45), s: rnd(.7, 1.6), v: rnd(.08, .25) });
    if (k === 'fog' && sty() !== 'ambiente') for (let i = 0; i < 6; i++) clouds.push({ x: rnd(-W * .3, W), y: rnd(H * .1, H * .9), s: rnd(1.5, 3), v: rnd(.1, .3), band: true });
  }
  function drawCloud(c, alpha) {
    const s = c.s * 60;
    if (sty() === 'ilustrada') {
      // nube dibujada: plana, con sombra suave
      ctx.save();
      ctx.shadowColor = dark() ? 'rgba(0,0,0,.35)' : 'rgba(80,100,140,.18)'; ctx.shadowBlur = 14; ctx.shadowOffsetY = 6;
      ctx.fillStyle = dark() ? `rgba(120,135,165,${Math.min(1, alpha + .2)})` : `rgba(255,255,255,${Math.min(1, alpha + .35)})`;
      ctx.beginPath();
      ctx.arc(c.x + s * .25, c.y + s * .45, s * .42, 0, 6.29);
      ctx.arc(c.x + s * .75, c.y + s * .15, s * .6, 0, 6.29);
      ctx.arc(c.x + s * 1.3, c.y + s * .38, s * .48, 0, 6.29);
      ctx.rect(c.x + s * .25, c.y + s * .45, s * 1.05, s * .42);
      ctx.fill();
      ctx.restore();
      return;
    }
    ctx.fillStyle = dark() ? `rgba(200,212,232,${alpha * .22})` : `rgba(255,255,255,${alpha})`;
    ctx.filter = 'blur(2px)';
    ctx.beginPath();
    ctx.arc(c.x, c.y + s * .35, s * .55, 0, 6.29);
    ctx.arc(c.x + s * .6, c.y, s * .75, 0, 6.29);
    ctx.arc(c.x + s * 1.35, c.y + s * .2, s * .6, 0, 6.29);
    ctx.arc(c.x + s * .7, c.y + s * .5, s * .6, 0, 6.29);
    ctx.fill();
    ctx.filter = 'none';
  }
  function frame(now) {
    raf = requestAnimationFrame(frame);
    if (now - last < 33) return; // ~30 cuadros por segundo alcanzan
    const dt = Math.min(3, (now - last) / 16.7) * mul().v;
    const st = sty(), ill = st === 'ilustrada', amb = st === 'ambiente';
    const breathe = amb ? .75 + .25 * Math.sin((now - t0) / 2200) : 1;
    last = now;
    const t = (now - t0) / 1000;
    ctx.clearRect(0, 0, W, H);
    const k = kind;
    const d = dark();

    if ((k === 'sun' || k === 'sunCloud') && ill) {
      const cx = W - 170, cy = 70, r = 46;
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * .25);
      ctx.fillStyle = d ? 'rgba(255,200,90,.55)' : 'rgba(255,190,60,.85)';
      for (let i = 0; i < 12; i++) { ctx.rotate(Math.PI / 6); ctx.beginPath(); ctx.moveTo(r + 8, -7); ctx.lineTo(r + 30 + 6 * Math.sin(t * 2 + i), 0); ctx.lineTo(r + 8, 7); ctx.fill(); }
      ctx.restore();
      ctx.fillStyle = d ? 'rgba(255,214,110,.75)' : '#ffd25a';
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.29); ctx.fill();
      ctx.fillStyle = d ? 'rgba(255,240,190,.5)' : 'rgba(255,245,200,.9)';
      ctx.beginPath(); ctx.arc(cx - 12, cy - 12, r * .35, 0, 6.29); ctx.fill();
    } else if (k === 'sun' || k === 'sunCloud') {
      const cx = W - 140, cy = 40, R = Math.min(W, 900) * .55 * (amb ? 1.3 : 1);
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
      g.addColorStop(0, d ? 'rgba(255,214,120,.22)' : 'rgba(255,214,120,.55)');
      g.addColorStop(.4, d ? 'rgba(255,190,90,.08)' : 'rgba(255,200,110,.18)');
      g.addColorStop(1, 'rgba(255,200,110,0)');
      ctx.globalAlpha = breathe * mul().a; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
      if (!amb) { ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * .04);
      for (let i = 0; i < 12; i++) {
        ctx.rotate(Math.PI / 6);
        const rg = ctx.createLinearGradient(0, 0, R * .9, 0);
        rg.addColorStop(0, d ? 'rgba(255,220,140,.10)' : 'rgba(255,225,150,.28)');
        rg.addColorStop(1, 'rgba(255,225,150,0)');
        ctx.fillStyle = rg;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(R * .9, -18 - 8 * Math.sin(t + i)); ctx.lineTo(R * .9, 18 + 8 * Math.sin(t + i)); ctx.fill();
      }
      ctx.restore(); }
    }
    if (k === 'night' || k === 'nightCloud') {
      const cx = W - 160, cy = 50;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 260);
      g.addColorStop(0, d ? 'rgba(200,215,255,.14)' : 'rgba(120,130,200,.16)');
      g.addColorStop(1, 'rgba(200,215,255,0)');
      ctx.globalAlpha = breathe; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
      if (ill) {
        ctx.fillStyle = d ? 'rgba(250,240,200,.85)' : 'rgba(120,120,190,.6)';
        ctx.beginPath(); ctx.arc(cx, cy + 20, 34, 0, 6.29); ctx.fill();
        ctx.globalCompositeOperation = 'destination-out'; ctx.beginPath(); ctx.arc(cx + 16, cy + 8, 30, 0, 6.29); ctx.fill(); ctx.globalCompositeOperation = 'source-over';
      }
      for (const s of stars) {
        const a = (.35 + .65 * (.5 + .5 * Math.sin(t * s.sp + s.ph))) * mul().a;
        ctx.fillStyle = d ? `rgba(255,255,255,${a * .9})` : `rgba(70,70,130,${a * .55})`;
        if (ill) {
          const r = s.r * 3.2; ctx.beginPath();
          ctx.moveTo(s.x, s.y - r); ctx.quadraticCurveTo(s.x, s.y, s.x + r, s.y); ctx.quadraticCurveTo(s.x, s.y, s.x, s.y + r); ctx.quadraticCurveTo(s.x, s.y, s.x - r, s.y); ctx.quadraticCurveTo(s.x, s.y, s.x, s.y - r); ctx.fill();
        } else { ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 6.29); ctx.fill(); }
      }
    }
    if (k === 'storm' || k === 'rain' || k === 'cloud') {
      ctx.fillStyle = d ? `rgba(0,0,0,${.18 * breathe})` : `rgba(90,100,120,${(k === 'cloud' ? .06 : .12) * (amb ? 1.6 * breathe : 1)})`;
      ctx.fillRect(0, 0, W, H);
    }
    for (const c of clouds) {
      c.x += c.v * dt;
      if (c.x > W + 50) c.x = -c.s * 140 - (c.band ? W * .5 : 0);
      if (c.band) {
        // banco de niebla: elipse muy difuminada que se desliza
        ctx.filter = 'blur(28px)';
        ctx.fillStyle = d ? 'rgba(200,210,225,.14)' : 'rgba(255,255,255,.5)';
        ctx.beginPath(); ctx.ellipse(c.x + W * .25, c.y, W * .32, 26 * c.s, 0, 0, 6.29); ctx.fill();
        ctx.filter = 'none';
      } else drawCloud(c, k === 'cloud' || k === 'storm' || k === 'rain' ? .55 : .42);
    }
    if ((k === 'rain' || k === 'storm' || k === 'drizzle') && ill) {
      ctx.fillStyle = d ? 'rgba(150,190,255,.55)' : 'rgba(70,130,220,.45)';
      for (const p of parts) {
        p.y += p.v * .7 * dt;
        if (p.y > H) { p.y = rnd(-60, -10); p.x = rnd(0, W); }
        const r = k === 'drizzle' ? 2 : 3;
        ctx.beginPath(); ctx.moveTo(p.x, p.y - r * 3); ctx.quadraticCurveTo(p.x + r * 1.4, p.y, p.x, p.y + r); ctx.quadraticCurveTo(p.x - r * 1.4, p.y, p.x, p.y - r * 3); ctx.fill();
      }
    } else if (k === 'rain' || k === 'storm' || k === 'drizzle') {
      ctx.strokeStyle = d ? 'rgba(200,220,255,.35)' : 'rgba(60,80,120,.28)';
      ctx.lineWidth = k === 'drizzle' ? 1 : 1.3;
      ctx.beginPath();
      for (const p of parts) {
        p.y += p.v * dt; p.x -= p.v * .18 * dt;
        if (p.y > H) { p.y = rnd(-60, -10); p.x = rnd(0, W + 80); }
        ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + p.l * .18, p.y - p.l);
      }
      ctx.stroke();
    }
    if (k === 'snow') {
      ctx.fillStyle = d ? 'rgba(255,255,255,.8)' : 'rgba(255,255,255,.95)';
      for (const p of parts) {
        p.y += p.v * dt; p.x += Math.sin(t + p.ph) * .4 * dt;
        if (p.y > H) { p.y = -5; p.x = rnd(0, W); }
        if (ill) {
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(t * .5 + p.ph); ctx.strokeStyle = d ? 'rgba(255,255,255,.85)' : 'rgba(150,180,220,.9)'; ctx.lineWidth = 1.2;
          ctx.beginPath(); for (let a = 0; a < 3; a++) { ctx.rotate(Math.PI / 3); ctx.moveTo(-p.r * 2.2, 0); ctx.lineTo(p.r * 2.2, 0); } ctx.stroke(); ctx.restore();
        } else { ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.29); ctx.fill(); }
      }
    }
    if (k === 'storm') {
      if (now > nextFlash) { flash = st === 'suave' || amb ? .4 : 1; nextFlash = now + (st === 'intensa' ? rnd(2500, 6000) : rnd(5000, 12000)); }
      if (flash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${flash * (d ? .22 : .45)})`;
        ctx.fillRect(0, 0, W, H);
        flash = Math.max(0, flash - .08 * dt);
      }
    }
    if (reduce) { cancelAnimationFrame(raf); raf = 0; } // movimiento reducido: un solo cuadro quieto
  }
  function start() {
    stop();
    if (!kind || document.hidden) { ctx && ctx.clearRect(0, 0, W, H); return; }
    last = 0; nextFlash = performance.now() + 2500;
    raf = requestAnimationFrame(frame);
  }
  function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; }
  return {
    init() {
      canvas = document.getElementById('wx-anim');
      if (!canvas) return;
      ctx = canvas.getContext('2d');
      resize();
      window.addEventListener('resize', () => { resize(); seed(); });
      document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
    },
    set(code, isDay) {
      if (!canvas) return;
      const enabled = !S || S.settings.wxAnim !== false;
      const k = window.__wxForce || (enabled && code != null ? kindFrom(code, isDay) : null);
      if (k === kind && raf) return;
      kind = k;
      resize(); seed(); start();
    },
    refresh() { if (canvas) { kind = kind || null; resize(); seed(); start(); } }
  };
})();

// ---------- Reloj ----------
const CLOCK_STYLES = [
  { id: 'clasico', n: 'Clásico' },
  { id: 'fino', n: 'Fino' },
  { id: 'digital', n: 'Digital' },
  { id: 'analogico', n: 'Analógico' },
  { id: 'palabras', n: 'En palabras' },
  { id: 'flip', n: 'Persiana' },
  { id: 'neon', n: 'Neón' },
  { id: 'anillos', n: 'Anillos' },
  { id: 'lcd', n: 'Calculadora' },
  { id: 'apilado', n: 'Apilado' }
];
// siete segmentos: a b c d e f g
const SEG = { 0: 'abcdef', 1: 'bc', 2: 'abdeg', 3: 'abcdg', 4: 'bcfg', 5: 'acdfg', 6: 'acdefg', 7: 'abc', 8: 'abcdefg', 9: 'abcdfg' };
const SEG_PATH = { a: 'M3 1h10l-2 2H5z', b: 'M14 2v10l-2-1.6V4z', c: 'M14 14v10l-2-2V15.6z', d: 'M3 25h10l-2-2H5z', e: 'M2 14v10l2-2V15.6z', f: 'M2 2v10l2-1.6V4z', g: 'M3 13l2-1.2h6l2 1.2-2 1.2H5z' };
function lcdDigit(n) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 16 26'); s.setAttribute('class', 'lcd-d');
  s.innerHTML = Object.entries(SEG_PATH).map(([k, d]) => `<path d="${d}" class="${(SEG[n] || '').includes(k) ? 'on' : 'off'}"/>`).join('');
  return s;
}
function ringsSvg(d, cfg) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 200 200'); s.setAttribute('class', 'rings');
  const arc = (r, f, cls) => { const C = 2 * Math.PI * r; return `<circle cx="100" cy="100" r="${r}" class="rt"/><circle cx="100" cy="100" r="${r}" class="ra ${cls}" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - f)}"/>`; };
  const h = d.getHours() % 12 + d.getMinutes() / 60, m = d.getMinutes() + d.getSeconds() / 60, sec = d.getSeconds();
  let hh = d.getHours(); if (cfg.h12) hh = hh % 12 || 12;
  s.innerHTML = arc(92, h / 12, 'h') + arc(78, m / 60, 'm') + (cfg.seconds ? arc(64, sec / 60, 's') : '') +
    `<text x="100" y="${cfg.seconds ? 112 : 114}" text-anchor="middle" class="rtx">${cfg.h12 ? hh : pad(hh)}:${pad(d.getMinutes())}</text>`;
  return s;
}
const CLOCK_DEFAULT = { style: 'clasico', size: 'm', seconds: false, h12: false, accent: false };
const clockCfg = () => Object.assign({}, CLOCK_DEFAULT, (M().theme && M().theme.clock) || {});

const NUM = ['cero', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez', 'once', 'doce', 'trece',
  'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve', 'veinte', 'veintiuno', 'veintidós', 'veintitrés',
  'veinticuatro', 'veinticinco', 'veintiséis', 'veintisiete', 'veintiocho', 'veintinueve'];
const TENS = { 3: 'treinta', 4: 'cuarenta', 5: 'cincuenta' };
const numWords = (n) => n < 30 ? NUM[n] : TENS[Math.floor(n / 10)] + (n % 10 ? ' y ' + NUM[n % 10] : '');
const HOURW = ['doce', 'una', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez', 'once'];
function timeInWords(d) {
  let h = d.getHours(), m = d.getMinutes();
  let tail;
  if (m === 0) tail = 'en punto';
  else if (m === 15) tail = 'y cuarto';
  else if (m === 30) tail = 'y media';
  else if (m === 45) { h += 1; tail = 'menos cuarto'; }
  else tail = 'y ' + numWords(m);
  const hw = HOURW[h % 12];
  const pre = h % 12 === 1 ? 'Es la' : 'Son las';
  const hh = h % 24;
  const part = hh < 6 ? 'de la madrugada' : hh < 13 ? 'de la mañana' : hh < 20 ? 'de la tarde' : 'de la noche';
  return { lead: `${pre} ${hw}`, rest: `${tail}`, part };
}
function svgEl(tag, attrs) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
}
function buildAnalog(d, cfg) {
  const s = svgEl('svg', { viewBox: '0 0 200 200', class: 'analog', 'aria-hidden': 'true' });
  s.append(svgEl('circle', { cx: 100, cy: 100, r: 96, class: 'face' }));
  for (let i = 0; i < 60; i++) {
    const big = i % 5 === 0;
    const a = i * 6 * Math.PI / 180;
    const r1 = big ? 80 : 86, r2 = 91;
    s.append(svgEl('line', { x1: 100 + r1 * Math.sin(a), y1: 100 - r1 * Math.cos(a), x2: 100 + r2 * Math.sin(a), y2: 100 - r2 * Math.cos(a), class: big ? 'tick big' : 'tick' }));
  }
  const sec = d.getSeconds(), min = d.getMinutes() + sec / 60, hr = (d.getHours() % 12) + min / 60;
  const hand = (deg, len, cls, back = 12) => {
    const a = deg * Math.PI / 180;
    return svgEl('line', { x1: 100 - back * Math.sin(a), y1: 100 + back * Math.cos(a), x2: 100 + len * Math.sin(a), y2: 100 - len * Math.cos(a), class: cls });
  };
  s.append(hand(hr * 30, 48, 'hand h'), hand(min * 6, 72, 'hand m'));
  if (cfg.seconds) s.append(hand(sec * 6, 80, 'hand s', 18));
  s.append(svgEl('circle', { cx: 100, cy: 100, r: 5, class: 'pin' }));
  return s;
}
// arma el reloj en "box" según el modelo elegido (sirve también para las vistas previas)
function buildClock(box, d, cfg) {
  box.className = `clock cs-${cfg.style} size-${cfg.size}${cfg.accent ? ' accent' : ''}`;
  let h = d.getHours();
  const ampm = h < 12 ? 'a. m.' : 'p. m.';
  if (cfg.h12) h = h % 12 || 12;
  const H = cfg.h12 ? String(h) : pad(h);
  const Mi = pad(d.getMinutes());
  const label = `${H}:${Mi}${cfg.h12 ? ' ' + ampm : ''}`;
  box.setAttribute('aria-label', label);
  if (cfg.style === 'analogico') {
    box.replaceChildren(buildAnalog(d, cfg));
    return;
  }
  if (cfg.style === 'anillos') { box.replaceChildren(ringsSvg(d, cfg)); return; }
  if (cfg.style === 'lcd') {
    const digits = (H.length < 2 ? ' ' + H : H) + Mi;
    const kids = [...digits].map((c, i) => c === ' ' ? el('span', { class: 'lcd-blank' }) : lcdDigit(+c));
    kids.splice(2, 0, el('span', { class: 'lcd-colon' }, el('i'), el('i')));
    if (cfg.seconds) kids.push(el('span', { class: 'lcd-sec' }, lcdDigit(+pad(d.getSeconds())[0]), lcdDigit(+pad(d.getSeconds())[1])));
    if (cfg.h12) kids.push(el('span', { class: 'lcd-ap', text: ampm }));
    box.replaceChildren(...kids);
    return;
  }
  if (cfg.style === 'flip') {
    const prev = box.dataset.prev || '';
    const cur = H.padStart(2, '0') + Mi + (cfg.seconds ? pad(d.getSeconds()) : '');
    box.dataset.prev = cur;
    const card = (ch, i) => el('span', { class: 'fl' + (prev && prev[i] !== ch && !box.classList.contains('mini') ? ' go' : '') }, el('span', { text: ch }));
    const grp = (from, to) => el('span', { class: 'fl-grp' }, ...[...cur.slice(from, to)].map((ch, k) => card(ch, from + k)));
    const kids = [grp(0, 2), el('span', { class: 'fl-dots' }, el('i'), el('i')), grp(2, 4)];
    if (cfg.seconds) kids.push(el('span', { class: 'fl-sec' }, grp(4, 6)));
    if (cfg.h12) kids.push(el('span', { class: 'fl-ap', text: ampm }));
    box.replaceChildren(...kids);
    return;
  }
  if (cfg.style === 'apilado') {
    box.replaceChildren(...[el('span', { class: 'st-h', text: H }), el('span', { class: 'st-m', text: Mi }),
      cfg.seconds || cfg.h12 ? el('span', { class: 'st-x', text: [cfg.seconds ? pad(d.getSeconds()) + ' s' : '', cfg.h12 ? ampm : ''].filter(Boolean).join(' · ') }) : null].filter(Boolean));
    return;
  }
  if (cfg.style === 'palabras') {
    const w = timeInWords(d);
    box.replaceChildren(el('span', { class: 'w-lead', text: w.lead }), el('span', { class: 'w-rest', text: w.rest }), el('span', { class: 'w-part', text: w.part }));
    return;
  }
  const parts = [el('span', { class: 'hh', text: H }), el('span', { class: 'colon', text: ':' }), el('span', { class: 'mm', text: Mi })];
  const extra = [];
  if (cfg.seconds) extra.push(el('span', { class: 'ss', text: pad(d.getSeconds()) }));
  if (cfg.h12) extra.push(el('span', { class: 'ap', text: ampm }));
  if (extra.length) parts.push(el('span', { class: 'clock-extra' }, ...extra));
  box.replaceChildren(...parts);
}
let lastClockKey = '';
function renderClock(force) {
  const now = new Date();
  const cfg = clockCfg();
  const live = cfg.seconds || cfg.style === 'digital' || cfg.style === 'lcd' || cfg.style === 'anillos';
  const key = JSON.stringify(cfg) + (live ? now.getSeconds() : '') + now.getHours() + ':' + now.getMinutes();
  if (!force && key === lastClockKey) return;
  lastClockKey = key;
  buildClock($('#clock'), now, cfg);
  $('#clock').classList.toggle('blink', (cfg.style === 'digital' || cfg.style === 'lcd') && now.getSeconds() % 2 === 1);
}

let lastMinute = '';
function tick() {
  const now = new Date();
  if (widgetOn('f1')) renderF1Count();
  renderPeeks();
  renderClock();
  pomoTick();
  if (widgetOn('pomodoro') && W.open === 'pomodoro') renderPomo();
  if (widgetOn('relojes') && W.open === 'relojes' && now.getSeconds() === 0) renderRelojes();
  const hm = pad(now.getHours()) + ':' + pad(now.getMinutes());
  if (hm !== lastMinute) {
    const prevDay = lastMinute ? ui.today : null;
    lastMinute = hm;
    ui.today = ymd(now);
    $('#date').textContent = fmt(now, { weekday: 'long', day: 'numeric', month: 'long' });
    if (M().theme.bg.kind === 'auto' || M().theme.bg.kind === 'bing') applyTheme();
    if (prevDay && prevDay !== ui.today) { loadEfemeride(); if (M().theme.bg.kind === 'bing') loadBing(true).then(applyTheme); setTimeout(maybeAutoBrief, 1000); }
    renderGreeting();
    // cambio de día: refrescamos lo que depende de "hoy"
    if (prevDay && prevDay !== ui.today) { if (ui.sel === prevDay) ui.sel = ui.today; renderTasks(); renderAgenda(); }
    else renderDayEvents();
  }
}
function renderGreeting() {
  const h = new Date().getHours();
  const base = h >= 6 && h < 12 ? 'Buen día' : h >= 12 && h < 20 ? 'Buenas tardes' : 'Buenas noches';
  const name = (S.settings.name || '').trim();
  $('#greeting').textContent = name ? `${base}, ${name}` : base;
  renderSummary();
}
function plural(n, one, many) { return `${n} ${n === 1 ? one : many}`; }
function renderSummary() {
  const today = ymd(new Date());
  const m = M();
  const pending = m.tasks.filter(t => !t.done);
  const late = pending.filter(t => t.due && t.due < today).length;
  const dueToday = pending.filter(t => t.due === today).length;
  const evToday = allEvents().filter(e => e.date === today);
  const nowHM = pad(new Date().getHours()) + ':' + pad(new Date().getMinutes());
  const nextEv = evToday.filter(e => e.time && e.time >= nowHM).sort((a, b) => a.time.localeCompare(b.time))[0];

  const parts = [];
  const s = $('#summary');
  s.replaceChildren();
  if (!pending.length && !evToday.length) {
    s.textContent = gmode(S.activeMode) === 'trabajo'
      ? 'Nada agendado para hoy y la lista de tareas está vacía.'
      : 'Día libre: no hay tareas ni eventos para hoy.';
    return;
  }
  if (evToday.length) parts.push([el('b', { text: plural(evToday.length, 'evento', 'eventos') }), ' hoy']);
  if (pending.length) {
    const extra = [];
    if (dueToday) extra.push(`${dueToday} para hoy`);
    if (late) extra.push(`${plural(late, 'vencida', 'vencidas')}`);
    parts.push([el('b', { text: plural(pending.length, 'tarea pendiente', 'tareas pendientes') }), extra.length ? ` (${extra.join(', ')})` : '']);
  }
  s.append('Tenés ');
  parts.forEach((p, i) => { if (i) s.append(' y '); s.append(...p); });
  s.append('.');
  if (nextEv) s.append(' Lo próximo: ', el('b', { text: nextEv.title }), ` a las ${nextEv.time}.`);
}

// ---------- Accesos ----------
function letterFor(name) { return (name || '?').trim().charAt(0).toUpperCase() || '?'; }
function webIcon(target) {
  try {
    const u = new URL(/^https?:/i.test(target) ? target : 'https://' + target);
    return `${u.origin}/favicon.ico`;
  } catch { return null; }
}
function tileIcon(sc) {
  const box = el('span', { class: 'ico' });
  const fallback = () => box.replaceChildren(el('span', { class: 'letter', text: letterFor(sc.name) }));
  const src = sc.letter ? null : sc.icon || (sc.type === 'web' ? webIcon(sc.target) : null);
  if (src) {
    const img = el('img', { src, alt: '', draggable: 'false' });
    img.onerror = fallback;
    img.onload = () => { if (img.naturalWidth < 8) fallback(); };
    box.append(img);
  } else fallback();
  return box;
}
// ---------- Carpetas de accesos (como en Android) ----------
const isFolder = (x) => x && x.type === 'group';
const TB_ID = 'tb';
const DK_ID = 'desk';
// carpetas que arma Base solas a partir de Windows
const SYS = {
  taskbar: { id: TB_ID, prefix: 'tb:', name: 'Barra de tareas', where: 'tu barra de tareas', hint: 'Se actualiza sola con lo que anclás en la barra de Windows.' },
  desktop: { id: DK_ID, prefix: 'dk:', name: 'Escritorio', where: 'tu escritorio de Windows', hint: 'Se actualiza sola con los accesos del escritorio de Windows.' }
};
const sysOfFolder = (id) => Object.keys(SYS).find(k => SYS[k].id === id);
const isVirtualId = (id) => /^(tb|dk):/.test(String(id));
const hiddenSys = (src) => S.settings.hiddenSys[src];
function locate(id) {
  const top = M().shortcuts;
  let i = top.findIndex(x => x.id === id);
  if (i >= 0) return { arr: top, i, item: top[i], folder: null };
  for (const f of top.filter(isFolder)) {
    i = f.items.findIndex(x => x.id === id);
    if (i >= 0) return { arr: f.items, i, item: f.items[i], folder: f };
  }
  return null;
}
function sysItems(src) {
  const hidden = hiddenSys(src);
  return ((ui.sys && ui.sys[src]) || []).filter(t => !hidden.includes(t.name))
    .map(t => ({ id: SYS[src].prefix + t.name, type: 'app', name: t.name, target: t.target, icon: t.icon, tb: true, src }));
}
function folderById(id) {
  const src = sysOfFolder(id);
  if (src) return { id, type: 'group', name: SYS[src].name, items: sysItems(src), virtual: true, src };
  return M().shortcuts.find(x => isFolder(x) && x.id === id) || null;
}
function cleanupFolders() {
  const top = M().shortcuts;
  for (let i = top.length - 1; i >= 0; i--) if (isFolder(top[i]) && !top[i].items.length) top.splice(i, 1);
  if (ui.openFolder && !sysOfFolder(ui.openFolder) && !folderById(ui.openFolder)) closeFolder();
}
function refreshLaunch() { cleanupFolders(); save(); renderLaunch(); }

// saca un ícono de donde esté (o copia uno de la barra de tareas)
function takeItem(id) {
  if (isVirtualId(id)) {
    const t = sysItems(id.startsWith('tb:') ? 'taskbar' : 'desktop').find(x => x.id === id);
    return t ? { id: uid(), type: 'app', name: t.name, target: t.target, icon: t.icon } : null;
  }
  const loc = locate(id);
  if (!loc) return null;
  loc.arr.splice(loc.i, 1);
  return loc.item;
}
// mueve un ícono: a una carpeta (folderId) o al escritorio (null), antes/después de otro
function moveItem(id, folderId, refId, after) {
  if (id === refId) return;
  const dest = folderId ? folderById(folderId) : null;
  if (folderId && (!dest || dest.virtual)) return;
  const peek = isVirtualId(id) ? null : locate(id);
  if (peek && isFolder(peek.item) && folderId) return toast('Las carpetas no se pueden meter dentro de otra carpeta');
  const item = takeItem(id);
  if (!item) return;
  const arr = dest ? dest.items : M().shortcuts;
  let idx = refId ? arr.findIndex(x => x.id === refId) : -1;
  if (idx < 0) arr.push(item); else arr.splice(idx + (after ? 1 : 0), 0, item);
  refreshLaunch();
}
function makeFolder(targetId, draggedId) {
  const top = M().shortcuts;
  const ti = top.findIndex(x => x.id === targetId);
  if (ti < 0 || isFolder(top[ti])) return;
  const dragged = takeItem(draggedId);
  if (!dragged || isFolder(dragged)) return;
  const tIdx = top.findIndex(x => x.id === targetId);
  const target = top[tIdx];
  const folder = { id: uid(), type: 'group', name: 'Carpeta', items: [target, dragged] };
  top.splice(tIdx, 1, folder);
  refreshLaunch();
  openFolder(folder.id, true);
}
function dissolveFolder(id) {
  const top = M().shortcuts;
  const i = top.findIndex(x => x.id === id);
  if (i < 0) return;
  const f = top[i];
  top.splice(i, 1, ...f.items);
  if (ui.openFolder === id) closeFolder();
  save(); renderLaunch();
  toast(`Desarmaste la carpeta ${f.name}`, { label: 'Deshacer', fn: () => {
    const j = top.indexOf(f.items[0]);
    top.splice(j, f.items.length, f); save(); renderLaunch();
  } });
}

// íconos
function folderIcon(f) {
  const box = el('span', { class: 'ico fold' });
  const items = f.items.slice(0, 4);
  for (const it of items) {
    const m = tileIcon(it);
    m.className = 'mi';
    box.append(m);
  }
  if (!items.length) box.append(svg('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'));
  return box;
}

// arrastrar y soltar entre íconos, carpetas y escritorio
const DND = 'text/x-base-tile';
let dragId = null;
function clearDropMarks() { $$('.drop-into, .drop-before, .drop-after, .drop-merge').forEach(n => n.classList.remove('drop-into', 'drop-before', 'drop-after', 'drop-merge')); }
function dropZone(e, tile, item, ctxFolder) {
  if (!dragId || dragId === item.id) return null;
  if (isFolder(item)) return item.virtual ? null : 'into';
  const r = tile.getBoundingClientRect();
  const x = (e.clientX - r.left) / r.width;
  const draggedIsFolder = !isVirtualId(dragId) && isFolder((locate(dragId) || {}).item);
  if (!ctxFolder && !item.tb && !draggedIsFolder && x > .28 && x < .72) return 'merge';
  return x < .5 ? 'before' : 'after';
}
function wireTile(tile, item, ctxFolder) {
  tile.draggable = true;
  tile.addEventListener('dragstart', (e) => {
    dragId = item.id;
    e.dataTransfer.setData(DND, item.id);
    e.dataTransfer.effectAllowed = item.tb ? 'copy' : 'move';
    requestAnimationFrame(() => tile.classList.add('dragging'));
  });
  tile.addEventListener('dragend', () => { dragId = null; tile.classList.remove('dragging'); clearDropMarks(); });
  tile.addEventListener('dragover', (e) => {
    const types = e.dataTransfer.types;
    if (types.includes(DND)) {
      const z = dropZone(e, tile, item, ctxFolder);
      if (!z) return;
      e.preventDefault(); e.stopPropagation();
      clearDropMarks();
      tile.classList.add('drop-' + z);
    } else if (isFolder(item) && !item.virtual && types.includes('Files')) {
      e.preventDefault(); e.stopPropagation();
      clearDropMarks(); tile.classList.add('drop-into');
    }
  });
  tile.addEventListener('dragleave', () => tile.classList.remove('drop-into', 'drop-before', 'drop-after', 'drop-merge'));
  tile.addEventListener('drop', async (e) => {
    const id = e.dataTransfer.getData(DND);
    if (id) {
      const z = dropZone(e, tile, item, ctxFolder);
      clearDropMarks();
      if (!z) return;
      e.preventDefault(); e.stopPropagation();
      if (z === 'into') moveItem(id, item.id);
      else if (z === 'merge') makeFolder(item.id, id);
      else moveItem(id, ctxFolder, item.id, z === 'after');
      return;
    }
    if (isFolder(item) && !item.virtual && e.dataTransfer.files.length) {
      e.preventDefault(); e.stopPropagation(); clearDropMarks();
      for (const f of e.dataTransfer.files) { const p = api.pathForFile(f); if (p) await addShortcutFromPath(p, 'app', item.id); }
    }
  });
}
function wireDropArea(area, folderIdFn) {
  area.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes(DND)) { e.preventDefault(); } });
  area.addEventListener('drop', (e) => {
    const id = e.dataTransfer.getData(DND);
    if (!id) return;
    e.preventDefault(); e.stopPropagation(); clearDropMarks();
    const fid = folderIdFn();
    const loc = isVirtualId(id) ? null : locate(id);
    if (loc && ((loc.folder && loc.folder.id === fid) || (!loc.folder && !fid))) return; // ya está ahí
    moveItem(id, fid);
  });
}

function makeTile(sc, ctxFolder) {
  const remove = el('span', { class: 'remove', role: 'button', 'aria-label': `Quitar ${sc.name}`, title: sc.tb ? 'Ocultar de Base' : isFolder(sc) ? 'Desarmar carpeta' : 'Quitar' }, svg(ICON.x));
  remove.addEventListener('click', (e) => {
    e.stopPropagation();
    if (sc.tb) hideSysItem(sc.src, sc.name);
    else if (isFolder(sc)) dissolveFolder(sc.id);
    else removeShortcut(sc.id);
  });
  const tile = el('button', {
    class: 'tile' + (isFolder(sc) ? ' folder' : '') + (sc.tb ? ' tb' : ''),
    title: isFolder(sc) ? `Carpeta ${sc.name} · ${plural(sc.items.length, 'acceso', 'accesos')}` : sc.tb ? `${sc.name} · de ${SYS[sc.src].where}` : sc.target,
    'data-id': sc.id
  }, isFolder(sc) ? folderIcon(sc) : tileIcon(sc), el('span', { class: 'name', text: sc.name }), sc.virtual ? null : remove);
  tile.addEventListener('click', () => {
    if (isFolder(sc)) return ui.openFolder === sc.id ? closeFolder() : openFolder(sc.id);
    if (ui.editingLaunch && !sc.tb) return openShortcutDialog(sc);
    launch(sc);
  });
  tile.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    if (sc.tb) hideSysItem(sc.src, sc.name);
    else if (isFolder(sc)) openFolder(sc.id, true);
    else openShortcutDialog(sc);
  });
  wireTile(tile, sc, ctxFolder);
  return tile;
}
function renderLaunch() {
  const list = $('#tiles');
  const sec = $('.launcher');
  sec.classList.toggle('editing', ui.editingLaunch);
  $('#btn-edit-launch').textContent = ui.editingLaunch ? 'Listo' : 'Ordenar y quitar';
  list.replaceChildren();
  const add = el('button', { class: 'tile add', title: 'Agregar un programa, carpeta o sitio' },
    el('span', { class: 'ico' }, svg(ICON.plus)), el('span', { class: 'name', text: 'Agregar' }));
  add.onclick = () => openShortcutDialog(null);
  list.append(el('li', {}, add));
  for (const sc of M().shortcuts) list.append(el('li', {}, makeTile(sc, null)));
  const sysFolders = ['desktop', 'taskbar'].filter(src => ui.sys && (ui.sys[src] || []).length);
  if (sysFolders.length) {
    list.append(el('li', { class: 'tb-sep', 'aria-hidden': 'true' }));
    for (const src of sysFolders) list.append(el('li', {}, makeTile(folderById(SYS[src].id), null)));
  }
  if (ui.openFolder) renderFolderPop();
}

// ventana de la carpeta abierta
function openFolder(id, rename) {
  ui.openFolder = id;
  renderFolderPop();
  const pop = $('#folder-pop');
  pop.hidden = false;
  positionFolderPop();
  if (rename && !sysOfFolder(id)) { const n = $('#fp-name'); n.focus(); n.select(); }
}
function closeFolder() {
  ui.openFolder = null;
  const pop = $('#folder-pop');
  if (pop) pop.hidden = true;
}
function positionFolderPop() {
  // la carpeta flota sobre todo (fija a la ventana), así nunca queda tapada ni cortada
  const pop = $('#folder-pop');
  const tile = document.querySelector(`#tiles .tile[data-id="${ui.openFolder}"]`);
  if (!tile || pop.hidden) return;
  if (pop.parentElement !== document.body) document.body.append(pop);
  const r = tile.getBoundingClientRect();
  pop.style.maxHeight = '';
  const w = pop.offsetWidth;
  let left = r.left + r.width / 2 - w / 2;
  left = Math.max(16, Math.min(left, innerWidth - 16 - w));
  const below = innerHeight - r.bottom - 26, above = r.top - 26;
  const natural = pop.scrollHeight;
  let top;
  if (natural <= below || below >= above) { top = r.bottom + 10; pop.style.maxHeight = Math.max(200, below) + 'px'; }
  else { const h = Math.min(natural, above); top = r.top - 10 - h; pop.style.maxHeight = h + 'px'; }
  pop.style.left = left + 'px';
  pop.style.top = Math.max(12, top) + 'px';
}
function renderFolderPop() {
  const f = folderById(ui.openFolder);
  if (!f) return closeFolder();
  const name = $('#fp-name');
  if (document.activeElement !== name) name.value = f.name;
  name.readOnly = !!f.virtual;
  $('#fp-dissolve').hidden = !!f.virtual;
  const grid = $('#fp-grid');
  grid.replaceChildren();
  const n = f.items.length + (f.virtual ? 0 : 1);
  $('#folder-pop').dataset.size = n > 15 ? 'xl' : n > 8 ? 'l' : 'm';
  for (const sc of f.items) grid.append(el('li', {}, makeTile(sc, f.virtual ? null : f.id)));
  if (!f.virtual) {
    const add = el('button', { class: 'tile add', title: 'Agregar un acceso a esta carpeta' },
      el('span', { class: 'ico' }, svg(ICON.plus)), el('span', { class: 'name', text: 'Agregar' }));
    add.onclick = () => openShortcutDialog(null, f.id);
    grid.append(el('li', {}, add));
  }
  const foot = $('#fp-foot');
  foot.replaceChildren();
  if (f.virtual) {
    const hidden = hiddenSys(f.src);
    foot.append(SYS[f.src].hint + ' Arrastrá un ícono afuera para copiarlo a tus accesos.');
    if (hidden.length) {
      const b = el('button', { class: 'text-btn', text: `Mostrar ocultos (${hidden.length})` });
      b.onclick = () => { hidden.length = 0; save(); renderLaunch(); };
      foot.append(' ', b);
    }
  } else {
    foot.append('Arrastrá íconos afuera para sacarlos, o soltá otros acá para sumarlos.');
  }
  positionFolderPop();
}
function hideSysItem(src, name) {
  const hidden = hiddenSys(src);
  hidden.push(name); save(); renderLaunch();
  toast(`Ocultaste ${name} de Base (sigue en ${SYS[src].where})`, { label: 'Deshacer', fn: () => { hidden.splice(hidden.indexOf(name), 1); save(); renderLaunch(); } });
}
function setupFolderPop() {
  const name = $('#fp-name');
  name.addEventListener('input', () => {
    const f = folderById(ui.openFolder);
    if (f && !f.virtual) { f.name = name.value.trim() || 'Carpeta'; save(); }
  });
  name.addEventListener('change', () => renderLaunch());
  name.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); name.blur(); renderLaunch(); } });
  $('#fp-dissolve').onclick = () => dissolveFolder(ui.openFolder);
  wireDropArea($('#fp-grid'), () => (sysOfFolder(ui.openFolder) ? null : ui.openFolder));
  wireDropArea($('#tiles'), () => null);
  document.addEventListener('pointerdown', (e) => {
    if (!ui.openFolder) return;
    if (e.target.closest('#folder-pop, .tile.folder, dialog, .toast')) return;
    closeFolder();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ui.openFolder && !document.querySelector('dialog[open]')) closeFolder(); });
  window.addEventListener('resize', () => { if (ui.openFolder) positionFolderPop(); });
  window.addEventListener('scroll', (e) => { if (ui.openFolder && !(e.target.closest && e.target.closest('#folder-pop'))) positionFolderPop(); }, true);
}

async function launch(sc) {
  const err = await api.open(sc);
  if (err) toast(`No se pudo abrir ${sc.name}. ${err}`);
}
function removeShortcut(id) {
  const loc = locate(id);
  if (!loc) return;
  const { arr, i } = loc;
  const [gone] = arr.splice(i, 1);
  const folder = loc.folder;
  refreshLaunch();
  toast(`Quitaste ${gone.name}`, { label: 'Deshacer', fn: () => {
    if (folder && !M().shortcuts.includes(folder)) M().shortcuts.push(folder);
    arr.splice(i, 0, gone); save(); renderLaunch();
  } });
}
function baseName(p) {
  const n = p.replace(/[\\/]+$/, '').split(/[\\/]/).pop() || p;
  return n.replace(/\.(exe|lnk|url|bat|cmd|appref-ms|msc)$/i, '');
}
async function addShortcutFromPath(p, kind = 'app', folderId = null) {
  const sc = { id: uid(), type: kind, name: baseName(p), target: p };
  sc.icon = await api.iconFor(p);
  const f = folderId ? folderById(folderId) : null;
  (f && !f.virtual ? f.items : M().shortcuts).push(sc);
  save(); renderLaunch();
  toast(`Agregaste ${sc.name}${f ? ' a ' + f.name : ''}`);
}

// diálogo de acceso
function setScKind(kind) {
  ui.scKind = kind;
  for (const b of $$('#sc-form .seg button')) b.classList.toggle('on', b.dataset.kind === kind);
  const t = $('#sc-target');
  t.placeholder = kind === 'web' ? 'Dirección, por ejemplo mercadolibre.com.ar' : kind === 'folder' ? 'Elegí una carpeta' : 'Elegí un programa';
  $('#sc-browse').style.display = kind === 'web' ? 'none' : '';
}
function fillFolderSelect(current) {
  const sel = $('#sc-folder');
  sel.replaceChildren(el('option', { value: '', text: 'Ninguna (suelto en el escritorio)' }));
  for (const f of M().shortcuts.filter(isFolder)) sel.append(el('option', { value: f.id, text: f.name }));
  sel.append(el('option', { value: '__new', text: 'Nueva carpeta…' }));
  sel.value = current || '';
  $('#sc-newfolder').hidden = true;
}
function openShortcutDialog(sc, folderId) {
  ui.scEditing = sc;
  const loc = sc ? locate(sc.id) : null;
  $('#dlg-sc-title').textContent = sc ? 'Editar acceso' : 'Nuevo acceso';
  $('#sc-target').value = sc ? sc.target : '';
  $('#sc-name').value = sc ? sc.name : '';
  $('#sc-error').textContent = '';
  $('#sc-delete').style.display = sc ? '' : 'none';
  fillFolderSelect(loc && loc.folder ? loc.folder.id : (folderId || ''));
  $('#sc-newfolder').value = '';
  setScKind(sc ? sc.type : 'app');
  $('#dlg-shortcut').showModal();
  (sc ? $('#sc-name') : (ui.scKind === 'web' ? $('#sc-target') : $('#sc-browse'))).focus();
}
async function saveShortcutDialog() {
  const kind = ui.scKind;
  let target = $('#sc-target').value.trim();
  let name = $('#sc-name').value.trim();
  const err = $('#sc-error');
  if (!target) { err.textContent = kind === 'web' ? 'Escribí la dirección del sitio.' : 'Elegí qué querés abrir con “Buscar…”.'; return; }
  if (kind === 'web') {
    if (!/^https?:\/\//i.test(target)) target = 'https://' + target;
    try { new URL(target); } catch { err.textContent = 'Esa dirección no parece válida.'; return; }
    if (!name) name = new URL(target).hostname.replace(/^www\./, '');
  }
  if (!name) name = baseName(target);
  let folderId = $('#sc-folder').value;
  if (folderId === '__new') {
    const fname = $('#sc-newfolder').value.trim() || 'Carpeta';
    const f = { id: uid(), type: 'group', name: fname, items: [] };
    M().shortcuts.push(f);
    folderId = f.id;
  }
  const prev = ui.scEditing;
  const sc = prev || { id: uid() };
  const changed = !prev || prev.target !== target || prev.type !== kind;
  Object.assign(sc, { type: kind, name, target });
  if (changed) { sc.icon = kind === 'web' ? null : await api.iconFor(target); delete sc.letter; }
  if (prev) {
    const loc = locate(sc.id);
    const curFolder = loc && loc.folder ? loc.folder.id : '';
    if (curFolder !== folderId) { takeItem(sc.id); (folderId ? folderById(folderId).items : M().shortcuts).push(sc); }
  } else {
    (folderId ? folderById(folderId).items : M().shortcuts).push(sc);
  }
  $('#dlg-shortcut').close();
  refreshLaunch();
}

// arrastrar archivos o links desde Windows / el navegador
function setupLaunchDrop() {
  const sec = $('.launcher');
  let depth = 0;
  const external = (e) => e.dataTransfer && !e.dataTransfer.types.includes(DND) &&
    (e.dataTransfer.types.includes('Files') || e.dataTransfer.types.includes('text/uri-list'));
  sec.addEventListener('dragenter', (e) => { if (external(e)) { depth++; sec.classList.add('dropping'); } });
  sec.addEventListener('dragleave', (e) => { if (external(e) && --depth <= 0) { depth = 0; sec.classList.remove('dropping'); } });
  sec.addEventListener('dragover', (e) => { if (external(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
  sec.addEventListener('drop', async (e) => {
    if (!external(e)) return;
    e.preventDefault(); depth = 0; sec.classList.remove('dropping');
    const inFolder = e.target.closest('#folder-pop') && !sysOfFolder(ui.openFolder) ? ui.openFolder : null;
    const files = [...e.dataTransfer.files];
    if (files.length) {
      for (const f of files) {
        const p = api.pathForFile(f);
        if (p) await addShortcutFromPath(p, 'app', inFolder);
      }
      return;
    }
    const url = (e.dataTransfer.getData('text/uri-list') || '').split('\n').find(l => /^https?:/i.test(l.trim()));
    if (url) {
      const u = new URL(url.trim());
      const f = inFolder ? folderById(inFolder) : null;
      (f ? f.items : M().shortcuts).push({ id: uid(), type: 'web', name: u.hostname.replace(/^www\./, ''), target: u.href });
      save(); renderLaunch();
      toast('Agregaste el sitio. Hacé clic derecho para cambiarle el nombre.');
    }
  });
  // soltar archivos en cualquier otra parte de Base: se guardan en el Escritorio de Windows
  const hint = el('div', { class: 'drop-desk', hidden: true }, svg('<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>'), el('span', { text: 'Soltalo y lo guardo en tu Escritorio' }));
  document.body.append(hint);
  let dd = 0;
  const filesDrag = (e) => e.dataTransfer && e.dataTransfer.types.includes('Files') && !e.dataTransfer.types.includes(DND) && !FX.drag;
  const where = (e) => !e.target.closest('.launcher, #fx, #folder-pop, input, textarea');
  window.addEventListener('dragenter', (e) => { if (filesDrag(e) && api.deskImport) { dd++; hint.hidden = false; } });
  window.addEventListener('dragleave', () => { if (--dd <= 0) { dd = 0; hint.hidden = true; } });
  window.addEventListener('dragover', (e) => { e.preventDefault(); if (filesDrag(e)) hint.classList.toggle('off', !where(e)); });
  window.addEventListener('drop', async (e) => {
    e.preventDefault(); dd = 0; hint.hidden = true;
    if (!filesDrag(e) || !where(e) || !api.deskImport) return;
    const paths = [...e.dataTransfer.files].map(f => api.pathForFile(f)).filter(Boolean);
    if (!paths.length) return;
    const r = await safeCall(() => api.deskImport(paths));
    if (r && r.done && r.done.length) toast(r.done.length === 1 ? `“${r.done[0]}” quedó en tu Escritorio` : `${r.done.length} archivos quedaron en tu Escritorio`);
    else if (r && r.errs && r.errs.length) toast('No se pudo guardar: ' + r.errs.slice(0, 3).join(', '));
    else toast('Ese archivo ya está en el Escritorio');
    deskLoad(true);
  });
}

// ---------- Tareas ----------
function dueChip(due) {
  if (!due) return null;
  const today = ymd(new Date());
  const tomorrow = ymd(addDays(new Date(), 1));
  const d = parseYmd(due);
  if (due < today) return el('span', { class: 'chip late', text: `Venció ${d.getDate()}/${d.getMonth() + 1}` });
  if (due === today) return el('span', { class: 'chip today', text: 'Hoy' });
  if (due === tomorrow) return el('span', { class: 'chip', text: 'Mañana' });
  const diff = Math.round((d - parseYmd(today)) / 864e5);
  if (diff < 7) return el('span', { class: 'chip', text: fmt(d, { weekday: 'long' }) });
  return el('span', { class: 'chip', text: `${d.getDate()}/${d.getMonth() + 1}` });
}
function sortTasks(list) {
  return list.sort((a, b) => {
    if (a.done) return (b.doneAt || 0) - (a.doneAt || 0);
    if (!!b.prio - !!a.prio) return !!b.prio - !!a.prio;
    if ((a.due || '9') !== (b.due || '9')) return (a.due || '9').localeCompare(b.due || '9');
    return a.created - b.created;
  });
}
function renderTasks() {
  const m = M();
  const pending = m.tasks.filter(t => !t.done);
  $('#count-pending').textContent = pending.length ? pending.length : '';
  for (const b of $$('.tasks .seg button')) b.classList.toggle('on', b.dataset.filter === ui.taskFilter);
  const list = $('#task-list');
  list.replaceChildren();
  const items = sortTasks(m.tasks.filter(t => ui.taskFilter === 'done' ? t.done : !t.done));
  if (!items.length) {
    list.append(el('li', { class: 'empty' }, ui.taskFilter === 'done'
      ? 'Todavía no terminaste ninguna tarea.'
      : 'No hay pendientes. Escribí una arriba y apretá Enter.'));
  }
  for (const t of items) {
    const check = el('input', { type: 'checkbox', class: 'check', 'aria-label': `Marcar “${t.text}” como ${t.done ? 'pendiente' : 'hecha'}` });
    check.checked = !!t.done;
    check.onchange = () => {
      t.done = check.checked; t.doneAt = t.done ? Date.now() : null;
      save();
      setTimeout(() => { renderTasks(); renderSummary(); }, t.done ? 280 : 0);
    };
    const text = el('span', { class: 't-text', text: t.text, title: 'Doble clic para editar' });
    text.ondblclick = () => editTaskText(t, text);
    const meta = el('span', { class: 't-meta' },
      t.prio ? el('span', { class: 'prio-dot', title: 'Importante' }, svg(ICON.flag)) : null,
      t.done ? null : dueChip(t.due));
    const del = el('button', { class: 'row-del', 'aria-label': 'Borrar tarea', title: 'Borrar' }, svg(ICON.trash));
    del.onclick = () => deleteTask(t);
    list.append(el('li', { class: 'task' + (t.done ? ' done' : '') }, check, text, meta, del));
  }
  zoneRefresh('tareas', 'dia', 'semana');
}
function editTaskText(t, span) {
  span.contentEditable = 'true';
  span.focus();
  document.getSelection().selectAllChildren(span);
  const finish = (ok) => {
    span.contentEditable = 'false';
    const v = span.textContent.trim();
    if (ok && v) { t.text = v; save(); }
    renderTasks(); renderSummary();
  };
  span.onkeydown = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); span.onblur = null; finish(true); }
    if (e.key === 'Escape') { span.onblur = null; finish(false); }
  };
  span.onblur = () => finish(true);
}
function deleteTask(t) {
  const arr = M().tasks;
  const i = arr.indexOf(t);
  arr.splice(i, 1);
  save(); renderTasks(); renderSummary();
  toast('Borraste la tarea', { label: 'Deshacer', fn: () => { arr.splice(i, 0, t); save(); renderTasks(); renderSummary(); } });
}

// ---------- Notas ----------
function noteTitle(n) {
  const first = (n.body || '').split('\n').find(l => l.trim());
  return first ? first.trim().slice(0, 60) : 'Nota sin título';
}
function noteDate(ts) {
  const d = new Date(ts);
  return ymd(d) === ymd(new Date())
    ? `Hoy, ${pad(d.getHours())}:${pad(d.getMinutes())}`
    : fmt(d, { day: 'numeric', month: 'short' });
}
function currentNote() {
  const m = M();
  let id = ui.note[S.activeMode];
  let n = m.notes.find(x => x.id === id);
  if (!n && m.notes.length) { n = [...m.notes].sort((a, b) => b.updated - a.updated)[0]; ui.note[S.activeMode] = n.id; }
  return n || null;
}
function renderNotes() {
  const m = M();
  const cur = currentNote();
  const list = $('#note-list');
  list.replaceChildren();
  const sorted = [...m.notes].sort((a, b) => b.updated - a.updated);
  for (const n of sorted) {
    const b = el('button', { class: 'note-item' + (cur && n.id === cur.id ? ' on' : '') },
      el('div', { class: 'n-title', text: noteTitle(n) }),
      el('div', { class: 'n-date', text: noteDate(n.updated) }));
    b.onclick = () => { ui.note[S.activeMode] = n.id; renderNotes(); $('#note-text').focus(); };
    list.append(el('li', {}, b));
  }
  const ta = $('#note-text');
  if (document.activeElement !== ta || !cur || ta.dataset.id !== (cur && cur.id)) {
    ta.value = cur ? cur.body : '';
    ta.dataset.id = cur ? cur.id : '';
  }
  $('#btn-del-note').style.visibility = cur ? 'visible' : 'hidden';
  $('#note-saved').textContent = cur ? `Guardada · ${noteDate(cur.updated)}` : '';
}
function newNote() {
  const n = { id: uid(), body: '', updated: Date.now() };
  M().notes.push(n);
  ui.note[S.activeMode] = n.id;
  save(); renderNotes();
  $('#note-text').focus();
}
function onNoteInput() {
  const ta = $('#note-text');
  let n = M().notes.find(x => x.id === ta.dataset.id);
  if (!n) {
    if (!ta.value.trim()) return;
    n = { id: uid(), body: '', updated: Date.now() };
    M().notes.push(n);
    ui.note[S.activeMode] = n.id;
    ta.dataset.id = n.id;
  }
  n.body = ta.value;
  n.updated = Date.now();
  save();
  // solo refrescamos la lista (no el texto) para no mover el cursor
  clearTimeout(onNoteInput.t);
  onNoteInput.t = setTimeout(renderNotes, 200);
}
function deleteNote() {
  const cur = currentNote();
  if (!cur) return;
  const arr = M().notes;
  const i = arr.indexOf(cur);
  arr.splice(i, 1);
  ui.note[S.activeMode] = null;
  save(); renderNotes();
  toast('Borraste la nota', { label: 'Deshacer', fn: () => { arr.splice(i, 0, cur); ui.note[S.activeMode] = cur.id; save(); renderNotes(); } });
}

// ---------- Agenda ----------
const DOW = ['D', 'L', 'M', 'M', 'J', 'V', 'S']; // la semana empieza el domingo
function renderCalendar() {
  const cal = $('#cal');
  cal.replaceChildren();
  const first = ui.calMonth;
  $('#cal-title').textContent = fmt(first, { month: 'long', year: 'numeric' });
  $('#cal-title').title = 'Volver a hoy';
  DOW.forEach(d => cal.append(el('div', { class: 'dow', 'aria-hidden': 'true', text: d })));
  const offset = first.getDay(); // domingo = 0
  const start = addDays(first, -offset);
  const today = ymd(new Date());
  const withEvents = new Set(allEvents().map(e => e.date));
  for (let i = 0; i < 42; i++) {
    const d = addDays(start, i);
    const key = ymd(d);
    if (i >= 35 && d.getMonth() !== first.getMonth()) break; // no mostrar una 6ª fila vacía
    const cls = ['d'];
    if (d.getMonth() !== first.getMonth()) cls.push('out');
    if (key === today) cls.push('today');
    if (key === ui.sel) cls.push('sel');
    if (withEvents.has(key)) cls.push('has');
    const b = el('button', {
      class: cls.join(' '), text: d.getDate(),
      'aria-label': fmt(d, { weekday: 'long', day: 'numeric', month: 'long' }) + (withEvents.has(key) ? ', con eventos' : ''),
      'aria-pressed': String(key === ui.sel)
    });
    b.onclick = () => {
      ui.sel = key;
      if (d.getMonth() !== first.getMonth()) ui.calMonth = new Date(d.getFullYear(), d.getMonth(), 1);
      renderAgenda();
    };
    cal.append(b);
  }
}
function googleEvents(mode = S.activeMode) {
  const c = S.cache['gcal:' + mode];
  if (!c || !acct(mode)) return [];
  const out = [];
  for (const g of c.data || []) {
    if (g.allDay) {
      // eventos de todo el día que duran varios días: aparecen en cada día (hasta 14)
      let d = parseYmd(g.start);
      const end = g.end ? parseYmd(g.end) : addDays(d, 1);
      for (let i = 0; i < 14 && d < end; i++, d = addDays(d, 1)) {
        out.push({ g: true, id: g.id, key: g.id + ':' + ymd(d), title: g.title, date: ymd(d), time: '', link: g.link, startTs: +d });
      }
    } else {
      const d = new Date(g.start);
      out.push({ g: true, id: g.id, key: g.id + ':' + g.start, title: g.title, date: ymd(d), time: `${pad(d.getHours())}:${pad(d.getMinutes())}`, link: g.link, startTs: +d });
    }
  }
  return out;
}
function allEvents(mode = S.activeMode) { return S.modes[mode].events.concat(googleEvents(mode)); }
function eventsOn(date) {
  return allEvents().filter(e => e.date === date).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
}
function eventRow(e, opts = {}) {
  const now = new Date();
  const past = e.date < ymd(now) || (e.date === ymd(now) && e.time && e.time < pad(now.getHours()) + ':' + pad(now.getMinutes()));
  const when = opts.upcoming
    ? fmt(parseYmd(e.date), { weekday: 'short', day: 'numeric' }) + (e.time ? ` ${e.time}` : '')
    : (e.time || 'Todo el día');
  const del = el('button', { class: 'row-del', 'aria-label': 'Borrar evento', title: 'Borrar' }, svg(ICON.trash));
  del.onclick = async (ev) => {
    ev.stopPropagation();
    if (e.g) {
      if (!confirm(`¿Borrar “${e.title}” de tu Google Calendar?`)) return;
      const r = await G.deleteEvent(S.activeMode, e.id);
      if (!r.ok) return toast('No se pudo borrar en Google: ' + r.error);
      const c = S.cache['gcal:' + S.activeMode];
      if (c) c.data = c.data.filter(x => x.id !== e.id);
      save(); renderAgenda(); renderSummary();
      return toast('Borraste el evento de Google Calendar');
    }
    const arr = M().events; const i = arr.indexOf(e); arr.splice(i, 1);
    save(); renderAgenda(); renderSummary();
    toast('Borraste el evento', { label: 'Deshacer', fn: () => { arr.splice(i, 0, e); save(); renderAgenda(); renderSummary(); } });
  };
  const row = el('li', { class: 'event' + (past && !opts.upcoming ? ' past' : '') + (e.g ? ' g' : ''), title: e.g ? 'De Google Calendar · clic para abrirlo' : null },
    el('span', { class: 'e-time', text: when }),
    el('span', { class: 'e-title', text: e.title }));
  if (!opts.upcoming) {
    row.append(e.notify !== '' && e.notify != null
      ? el('span', { class: 'bell', title: notifyLabel(e.notify) }, svg(ICON.bell)) : el('span'), del);
    if (e.g && e.link) row.onclick = () => api.google.open(e.link);
  } else {
    row.style.cursor = 'pointer';
    row.onclick = () => { ui.sel = e.date; const d = parseYmd(e.date); ui.calMonth = new Date(d.getFullYear(), d.getMonth(), 1); renderAgenda(); };
  }
  return row;
}
function notifyLabel(v) {
  return { '0': 'Aviso a la hora', '10': 'Aviso 10 min antes', '30': 'Aviso 30 min antes', '60': 'Aviso 1 hora antes', '1440': 'Aviso 1 día antes' }[String(v)] || '';
}
function renderDayEvents() {
  const d = parseYmd(ui.sel);
  const today = ymd(new Date());
  const label = ui.sel === today ? 'Hoy' : ui.sel === ymd(addDays(new Date(), 1)) ? 'Mañana' : fmt(d, { weekday: 'long', day: 'numeric', month: 'long' });
  $('#day-title').textContent = label;
  const list = $('#day-events');
  list.replaceChildren();
  const evs = eventsOn(ui.sel);
  if (!evs.length) list.append(el('li', { class: 'empty', style: 'padding:4px 6px 6px' }, 'Sin eventos. Agregá uno abajo.'));
  evs.forEach(e => list.append(eventRow(e)));
}
function renderUpcoming() {
  const list = $('#upcoming');
  list.replaceChildren();
  const from = ymd(addDays(new Date(), 1));
  const to = ymd(addDays(new Date(), 21));
  const evs = allEvents().filter(e => e.date >= from && e.date <= to)
    .sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || ''))).slice(0, 12);
  if (!evs.length) list.append(el('li', { class: 'empty', style: 'padding:4px 6px' }, 'Nada en las próximas tres semanas.'));
  evs.forEach(e => list.append(eventRow(e, { upcoming: true })));
}
function renderAgenda() { renderCalendar(); renderDayEvents(); renderUpcoming(); zoneRefresh('dia', 'semana'); }

// avisos de eventos
function checkReminders() {
  const now = Date.now();
  let changed = false;
  for (const [mode, data] of Object.entries(S.modes)) {
    for (const e of data.events) {
      if (e.notify === '' || e.notify == null || e.notified) continue;
      const [h, mi] = (e.time || '09:00').split(':').map(Number);
      const at = parseYmd(e.date); at.setHours(h, mi, 0, 0);
      const fire = at.getTime() - Number(e.notify) * 60000;
      if (now >= fire) {
        e.notified = true; changed = true;
        if (now - fire > 6 * 3600e3) continue; // ya pasó hace mucho: no avisamos tarde
        const mins = Number(e.notify);
        const when = mins === 0 ? 'Ahora' : mins === 1440 ? `Mañana${e.time ? ' a las ' + e.time : ''}` : mins === 60 ? 'En 1 hora' : `En ${mins} minutos`;
        notify('agenda', e.title, `${when}${mode !== S.activeMode ? ` · ${mode === 'casa' ? 'Casa' : 'Trabajo'}` : ''}`, { w: 'agenda', mode });
      }
    }
  }
  // eventos de Google Calendar
  for (const mode of ['casa', 'trabajo']) {
    const m = S.modes[mode];
    if (m.gcalNotify === '' || m.gcalNotify == null) continue;
    const lead = Number(m.gcalNotify) * 60000;
    for (const e of googleEvents(mode)) {
      const at = e.time ? e.startTs : parseYmd(e.date).setHours(9, 0, 0, 0);
      const fire = at - lead;
      if (now >= fire && now - fire < 30 * 60000 && !m.gNotified.includes(e.key)) {
        m.gNotified.push(e.key);
        if (m.gNotified.length > 100) m.gNotified.splice(0, m.gNotified.length - 100);
        changed = true;
        const mins = Math.round((at - now) / 60000);
        notify('agenda', e.title, (mins <= 1 ? 'Empieza ahora' : `Empieza en ${mins} minutos`) + (e.time ? ` (${e.time})` : '') + ` · Google${mode !== S.activeMode ? ` · ${mode === 'casa' ? 'Casa' : 'Trabajo'}` : ''}`, { w: 'agenda', mode });
      }
    }
  }
  if (changed) save();
}

// ---------- Datos de internet con caché ----------
async function cached(key, maxAgeMin, url, parse, force) {
  const c = S.cache[key];
  if (!force && c && Date.now() - c.at < maxAgeMin * 60000) return c.data;
  const r = await api.get(url);
  if (!r || !r.ok) return c ? c.data : null; // sin internet: mostramos lo último que tengamos
  try {
    const data = parse(r.text);
    if (data == null) return c ? c.data : null;
    S.cache[key] = { at: Date.now(), data };
    save();
    return data;
  } catch {
    return c ? c.data : null;
  }
}

// ---------- Clima ----------
const WX = {
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  partly: '<path d="M8 2.5V4M3 8H1.5M4.1 4.1l1 1M11.9 4.1l-1 1"/><path d="M4.8 10.6A3.6 3.6 0 0 1 11.3 6.6"/><path d="M9 20h8.5a3.5 3.5 0 0 0 .3-7 5 5 0 0 0-9.6.9A3.1 3.1 0 0 0 9 20z"/>',
  partlyNight: '<path d="M10.6 6.2A4 4 0 0 0 5 10.8"/><path d="M9 20h8.5a3.5 3.5 0 0 0 .3-7 5 5 0 0 0-9.6.9A3.1 3.1 0 0 0 9 20z"/>',
  cloud: '<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/>',
  fog: '<path d="M7 11h10a4 4 0 0 0 .3-8 6 6 0 0 0-11.1 1.9"/><path d="M4 15h16M6 19h12"/>',
  drizzle: '<path d="M7 14h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 5.5 4.3 4.3 0 0 0 7 14z"/><path d="M8 18v1M12 18v1M16 18v1M10 21v.5M14 21v.5"/>',
  rain: '<path d="M7 14h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 5.5 4.3 4.3 0 0 0 7 14z"/><path d="M8.5 17l-1.5 4M12.5 17 11 21M16.5 17 15 21"/>',
  storm: '<path d="M7 14h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 5.5 4.3 4.3 0 0 0 7 14z"/><path d="M13 15.5 10.5 19h3L11 22.5"/>',
  snow: '<path d="M7 14h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 5.5 4.3 4.3 0 0 0 7 14z"/><path d="M8 18h.01M12 18h.01M16 18h.01M10 21h.01M14 21h.01" stroke-width="2.6"/>'
};
function wmo(code, day = true) {
  const c = Number(code);
  if (c === 0) return ['Despejado', day ? 'sun' : 'moon'];
  if (c === 1) return ['Mayormente despejado', day ? 'sun' : 'moon'];
  if (c === 2) return ['Parcialmente nublado', day ? 'partly' : 'partlyNight'];
  if (c === 3) return ['Nublado', 'cloud'];
  if (c === 45 || c === 48) return ['Niebla', 'fog'];
  if (c >= 51 && c <= 57) return ['Llovizna', 'drizzle'];
  if (c === 61) return ['Lluvia débil', 'rain'];
  if (c === 63) return ['Lluvia', 'rain'];
  if (c === 65) return ['Lluvia fuerte', 'rain'];
  if (c === 66 || c === 67) return ['Lluvia helada', 'rain'];
  if (c >= 71 && c <= 77) return ['Nieve', 'snow'];
  if (c === 80 || c === 81) return ['Chaparrones', 'rain'];
  if (c === 82) return ['Chaparrones fuertes', 'rain'];
  if (c === 85 || c === 86) return ['Nevadas', 'snow'];
  if (c === 95) return ['Tormenta', 'storm'];
  if (c === 96 || c === 99) return ['Tormenta con granizo', 'storm'];
  return ['—', 'cloud'];
}
function weatherUrl(w) {
  return `https://api.open-meteo.com/v1/forecast?latitude=${w.lat}&longitude=${w.lon}` +
    '&current=temperature_2m,apparent_temperature,weather_code,is_day,relative_humidity_2m,wind_speed_10m' +
    '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=4';
}
async function loadWeather(force) {
  const w = M().weather;
  const mode = S.activeMode;
  const data = await cached(`wx:${w.lat.toFixed(3)},${w.lon.toFixed(3)}`, 15, weatherUrl(w), (t) => {
    const j = JSON.parse(t);
    return j.current && j.daily ? { current: j.current, daily: j.daily } : null;
  }, force);
  if (mode === S.activeMode) renderWeather(data);
  if (mode === S.activeMode && widgetOn('pronostico')) loadPronostico(false);
  else if (mode === S.activeMode && (zoneOn('dia') || zoneOn('semana'))) loadZoneWx(force);
}
function renderWeather(data) {
  const box = $('#weather');
  const w = M().weather;
  const city = el('button', { class: 'w-city', title: 'Cambiar ciudad', text: w.name });
  city.onclick = openCityDialog;
  if (!data) {
    WxAnim.set(null);
    box.replaceChildren(el('div', { class: 'w-msg' }, 'Clima no disponible por ahora · '), city);
    return;
  }
  const cur = data.current;
  WxAnim.set(cur.weather_code, cur.is_day !== 0);
  const [desc, ic] = wmo(cur.weather_code, cur.is_day !== 0);
  PN.wx = { t: Math.round(cur.temperature_2m), d: desc, ic: WX[ic] || '', max: Math.round(data.daily.temperature_2m_max[0]), min: Math.round(data.daily.temperature_2m_min[0]), city: w.name };
  panelPush();
  const days = el('div', { class: 'w-days' });
  const d = data.daily;
  for (let i = 0; i < Math.min(3, d.time.length); i++) {
    const [dd, di] = wmo(d.weather_code[i]);
    const label = i === 0 ? 'Hoy' : fmt(parseYmd(d.time[i]), { weekday: 'short' }).replace('.', '');
    const p = d.precipitation_probability_max ? d.precipitation_probability_max[i] : null;
    days.append(el('div', { class: 'w-day', title: dd },
      el('span', { class: 'dn', text: label }),
      svg(WX[di]),
      el('span', { class: 'tt' }, `${Math.round(d.temperature_2m_max[i])}° `, el('span', { text: `${Math.round(d.temperature_2m_min[i])}°` })),
      p != null && p >= 20 ? el('span', { class: 'pp', text: `Lluvia ${p}%` }) : null));
  }
  box.replaceChildren(
    el('div', { class: 'w-now' },
      svg(WX[ic]),
      el('div', { class: 'w-temp', text: `${Math.round(cur.temperature_2m)}°` })),
    el('div', { class: 'w-desc' },
      el('b', { text: desc }), ` · Sensación ${Math.round(cur.apparent_temperature)}°`, el('br'),
      `Humedad ${Math.round(cur.relative_humidity_2m)}% · Viento ${Math.round(cur.wind_speed_10m)} km/h · `, city),
    days);
}
function openCityDialog() {
  $('#city-q').value = '';
  $('#city-results').replaceChildren();
  $('#dlg-city').showModal();
  $('#city-q').focus();
}
async function searchCity(q) {
  const list = $('#city-results');
  list.replaceChildren(el('li', { class: 'w-msg', style: 'padding:8px 10px', text: 'Buscando…' }));
  const r = await api.get(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=es&format=json`);
  list.replaceChildren();
  let results = [];
  try { results = (r.ok && JSON.parse(r.text).results) || []; } catch {}
  if (!results.length) {
    list.append(el('li', { class: 'w-msg', style: 'padding:8px 10px', text: r.ok ? 'No encontré esa ciudad. Probá con otro nombre.' : 'Sin conexión. Probá de nuevo en un rato.' }));
    return;
  }
  for (const c of results) {
    const detail = [c.admin1, c.country].filter(Boolean).join(', ');
    const b = el('button', { type: 'button' }, c.name, el('small', { text: detail }));
    b.onclick = () => {
      M().weather = { name: c.name, detail, lat: c.latitude, lon: c.longitude };
      save();
      $('#dlg-city').close();
      loadWeather(true);
    };
    list.append(el('li', {}, b));
  }
}

// ---------- Fórmula 1 ----------
const F1_SESSIONS = [
  ['FirstPractice', 'Práctica 1', 60],
  ['SecondPractice', 'Práctica 2', 60],
  ['ThirdPractice', 'Práctica 3', 60],
  ['SprintQualifying', 'Clasificación sprint', 45],
  ['SprintShootout', 'Clasificación sprint', 45],
  ['Sprint', 'Sprint', 60],
  ['Qualifying', 'Clasificación', 60]
];
const GP_ES = {
  'Australian': 'Australia', 'Chinese': 'China', 'Japanese': 'Japón', 'Bahrain': 'Baréin', 'Saudi Arabian': 'Arabia Saudita',
  'Miami': 'Miami', 'Emilia Romagna': 'Emilia-Romaña', 'Monaco': 'Mónaco', 'Spanish': 'España', 'Canadian': 'Canadá',
  'Austrian': 'Austria', 'British': 'Gran Bretaña', 'Belgian': 'Bélgica', 'Hungarian': 'Hungría', 'Dutch': 'Países Bajos',
  'Italian': 'Italia', 'Azerbaijan': 'Azerbaiyán', 'Singapore': 'Singapur', 'United States': 'Estados Unidos',
  'Mexico City': 'México', 'Mexican': 'México', 'São Paulo': 'São Paulo', 'Brazilian': 'Brasil', 'Las Vegas': 'Las Vegas',
  'Qatar': 'Catar', 'Abu Dhabi': 'Abu Dabi', 'Barcelona-Catalunya': 'Barcelona', 'Madrid': 'Madrid', 'Argentine': 'Argentina',
  'Portuguese': 'Portugal', 'Turkish': 'Turquía', 'French': 'Francia', 'German': 'Alemania', 'South African': 'Sudáfrica'
};
function gpName(raceName) {
  const m = /^(.*) Grand Prix$/.exec(raceName || '');
  if (!m) return raceName;
  return `GP de ${GP_ES[m[1]] || m[1]}`;
}
function f1Sessions(races) {
  const out = [];
  for (const r of races || []) {
    const add = (type, name, mins, obj) => {
      if (!obj || !obj.date) return;
      const start = new Date(`${obj.date}T${obj.time || '12:00:00Z'}`);
      if (isNaN(start)) return;
      out.push({ key: `${r.season}-${r.round}-${type}`, round: `${r.season}-${r.round}`, gp: gpName(r.raceName),
        circuitUrl: r.Circuit && r.Circuit.url ? r.Circuit.url : '',
        place: r.Circuit && r.Circuit.Location ? r.Circuit.Location.locality : '', country: r.Circuit && r.Circuit.Location ? r.Circuit.Location.country : '', name, start: +start, end: +start + mins * 60000 });
    };
    for (const [k, n, mins] of F1_SESSIONS) add(k, n, mins, r[k]);
    add('Race', 'Carrera', 120, { date: r.date, time: r.time });
  }
  return out.sort((a, b) => a.start - b.start);
}
// ---------- F1: bandera del país y campeonatos ----------
const COUNTRY_ISO = {
  australia: 'au', china: 'cn', japan: 'jp', bahrain: 'bh', 'saudi arabia': 'sa', usa: 'us', 'united states': 'us',
  italy: 'it', monaco: 'mc', spain: 'es', canada: 'ca', austria: 'at', uk: 'gb', 'united kingdom': 'gb', 'great britain': 'gb',
  belgium: 'be', hungary: 'hu', netherlands: 'nl', azerbaijan: 'az', singapore: 'sg', mexico: 'mx', brazil: 'br',
  qatar: 'qa', uae: 'ae', 'united arab emirates': 'ae', portugal: 'pt', france: 'fr', germany: 'de', argentina: 'ar',
  turkey: 'tr', russia: 'ru', 'south africa': 'za', korea: 'kr', india: 'in', malaysia: 'my', vietnam: 'vn', thailand: 'th', rwanda: 'rw'
};
// dibujos propios por si no carga la foto de la bandera (sin internet)
const H3 = (a, b, c) => `<rect width="30" height="20" fill="${a}"/><rect y="6.67" width="30" height="6.67" fill="${b}"/><rect y="13.33" width="30" height="6.67" fill="${c}"/>`;
const V3 = (a, b, c) => `<rect width="30" height="20" fill="${a}"/><rect x="10" width="10" height="20" fill="${b}"/><rect x="20" width="10" height="20" fill="${c}"/>`;
const UJ = '<rect width="30" height="20" fill="#012169"/><path d="M0 0l30 20M30 0L0 20" stroke="#fff" stroke-width="4"/><path d="M0 0l30 20M30 0L0 20" stroke="#c8102e" stroke-width="1.3"/><path d="M15 0v20M0 10h30" stroke="#fff" stroke-width="6"/><path d="M15 0v20M0 10h30" stroke="#c8102e" stroke-width="3.6"/>';
const FLAG_SVG = {
  it: V3('#009246', '#fff', '#ce2b37'), be: V3('#000', '#fdda24', '#ef3340'), fr: V3('#002395', '#fff', '#ed2939'),
  hu: H3('#ce2939', '#fff', '#477050'), nl: H3('#ae1c28', '#fff', '#21468b'), de: H3('#000', '#dd0000', '#ffce00'),
  at: H3('#ed2939', '#fff', '#ed2939'), ru: H3('#fff', '#0039a6', '#d52b1e'),
  az: H3('#00b5e2', '#ef3340', '#509e2f') + '<circle cx="14.2" cy="10" r="2.6" fill="#fff"/><circle cx="14.9" cy="10" r="2.1" fill="#ef3340"/><circle cx="17" cy="10" r=".8" fill="#fff"/>',
  ar: H3('#74acdf', '#fff', '#74acdf') + '<circle cx="15" cy="10" r="1.8" fill="#f6b40e"/>',
  mc: '<rect width="30" height="20" fill="#fff"/><rect width="30" height="10" fill="#ce1126"/>',
  jp: '<rect width="30" height="20" fill="#fff"/><circle cx="15" cy="10" r="6" fill="#bc002d"/>',
  es: '<rect width="30" height="20" fill="#aa151b"/><rect y="5" width="30" height="10" fill="#f1bf00"/>',
  mx: V3('#006847', '#fff', '#ce1126') + '<circle cx="15" cy="10" r="2.2" fill="#8c5a2b"/>',
  ca: '<rect width="30" height="20" fill="#fff"/><rect width="7.5" height="20" fill="#d80621"/><rect x="22.5" width="7.5" height="20" fill="#d80621"/><path d="M15 4.5l1 2 1.6-.6-.5 3 1.8-1.6.4 1.2 1.8-.3-.8 2 .8.5-3.2 2.2.3 1.2-3-.5v2.4h-.4v-2.4l-3 .5.3-1.2-3.2-2.2.8-.5-.8-2 1.8.3.4-1.2 1.8 1.6-.5-3 1.6.6z" fill="#d80621"/>',
  gb: UJ,
  us: '<rect width="30" height="20" fill="#fff"/>' + Array.from({ length: 7 }, (_, i) => `<rect y="${i * 3.08}" width="30" height="1.54" fill="#b22234"/>`).join('') + '<rect width="12" height="10.8" fill="#3c3b6e"/>' + Array.from({ length: 20 }, (_, i) => `<circle cx="${1.3 + (i % 5) * 2.35 + (Math.floor(i / 5) % 2) * 1.1}" cy="${1.4 + Math.floor(i / 5) * 2.6}" r=".45" fill="#fff"/>`).join(''),
  au: '<rect width="30" height="20" fill="#012169"/><svg width="15" height="10" viewBox="0 0 30 20">' + UJ + '</svg><g fill="#fff"><circle cx="7.5" cy="15" r="1.6"/><circle cx="22.5" cy="16" r=".8"/><circle cx="20" cy="9" r=".8"/><circle cx="23" cy="4" r=".8"/><circle cx="26" cy="8" r=".8"/><circle cx="24" cy="11" r=".5"/></g>',
  br: '<rect width="30" height="20" fill="#009c3b"/><path d="M15 2.5L27.5 10 15 17.5 2.5 10z" fill="#ffdf00"/><circle cx="15" cy="10" r="4.2" fill="#002776"/><path d="M11 9.2q4-1 8 1" stroke="#fff" stroke-width=".6" fill="none"/>',
  sa: '<rect width="30" height="20" fill="#006c35"/><path d="M8 7h14M9 9h12" stroke="#fff" stroke-width=".7"/><path d="M8 13.5h13l1.5-.8" stroke="#fff" stroke-width=".9" fill="none"/>',
  sg: '<rect width="30" height="20" fill="#fff"/><rect width="30" height="10" fill="#ef3340"/><circle cx="6.5" cy="5" r="3" fill="#fff"/><circle cx="7.6" cy="5" r="2.6" fill="#ef3340"/><g fill="#fff"><circle cx="9.8" cy="3" r=".5"/><circle cx="12" cy="3.8" r=".5"/><circle cx="11.4" cy="6.2" r=".5"/><circle cx="8.6" cy="6.4" r=".5"/><circle cx="8.2" cy="3.9" r=".5"/></g>',
  bh: '<rect width="30" height="20" fill="#ce1126"/><path d="M0 0h8l3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1 3 1-3 1H0z" fill="#fff"/>',
  qa: '<rect width="30" height="20" fill="#8a1538"/><path d="M0 0h8l3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1 3 1.1-3 1.1H0z" fill="#fff"/>',
  cn: '<rect width="30" height="20" fill="#ee1c25"/><circle cx="5" cy="5" r="2.6" fill="#ffff00"/><g fill="#ffff00"><circle cx="10" cy="2" r=".7"/><circle cx="12" cy="4" r=".7"/><circle cx="12" cy="7" r=".7"/><circle cx="10" cy="9" r=".7"/></g>',
  ae: '<rect width="30" height="20" fill="#fff"/><rect width="30" height="6.67" fill="#00732f"/><rect y="13.33" width="30" height="6.67" fill="#000"/><rect width="8" height="20" fill="#ff0000"/>',
  pt: '<rect width="30" height="20" fill="#ff0000"/><rect width="12" height="20" fill="#006600"/><circle cx="12" cy="10" r="3.2" fill="#ffcc00"/>'
};
function flagIso(country) { return COUNTRY_ISO[String(country || '').toLowerCase().trim()] || ''; }
function flagLayer(iso) {
  const box = el('div', { class: 'flag', 'aria-hidden': 'true' });
  const drawn = () => {
    if (!FLAG_SVG[iso]) { box.remove(); return; }
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 30 20'); s.setAttribute('preserveAspectRatio', 'xMidYMid slice');
    s.innerHTML = FLAG_SVG[iso];
    box.replaceChildren(s, el('span', { class: 'wave' }));
  };
  const img = el('img', { alt: '', src: `https://flagcdn.com/w1280/${iso}.png`, draggable: 'false' });
  img.onerror = drawn;
  box.append(img, el('span', { class: 'wave' }));
  return box;
}

// campeonatos
const TEAM_COLOR = {
  mercedes: '#27f4d2', ferrari: '#e8002d', red_bull: '#3671c6', mclaren: '#ff8000', aston_martin: '#229971',
  alpine: '#ff87bc', williams: '#64c4ff', rb: '#6692ff', racing_bulls: '#6692ff', sauber: '#52e252', kick_sauber: '#52e252',
  audi: '#bb0a30', haas: '#b6babd', cadillac: '#c9a227'
};
const teamColor = (id) => TEAM_COLOR[id] || '#9aa0a6';
async function loadStandings(force) {
  const parseD = (t) => { const j = JSON.parse(t).MRData.StandingsTable; const l = j.StandingsLists[0]; return l ? { season: j.season, round: l.round, rows: l.DriverStandings } : null; };
  const parseC = (t) => { const j = JSON.parse(t).MRData.StandingsTable; const l = j.StandingsLists[0]; return l ? { season: j.season, round: l.round, rows: l.ConstructorStandings } : null; };
  await Promise.all([
    cached('f1:drivers', 60, 'https://api.jolpi.ca/ergast/f1/current/driverStandings.json?limit=40', parseD, force),
    cached('f1:teams', 60, 'https://api.jolpi.ca/ergast/f1/current/constructorStandings.json?limit=20', parseC, force)
  ]);
  renderStandings();
}
function renderStandings() {
  const box = $('#f1-standings');
  if (!box) return;
  const which = ui.f1Champ || 'drivers';
  for (const b of $$('#f1-champ button')) b.classList.toggle('on', b.dataset.c === which);
  const data = (S.cache['f1:' + which] || {}).data;
  const list = $('#f1-table');
  list.replaceChildren();
  if (!data || !data.rows || !data.rows.length) {
    list.append(el('li', { class: 'empty', text: navigator.onLine === false ? 'Sin conexión: la tabla aparece cuando vuelva internet.' : 'Cargando posiciones…' }));
    setText('f1-champ-sub', '');
    return;
  }
  const leader = Number(data.rows[0].points);
  const fav = (S.settings.topic && S.settings.topic.news || 'Colapinto').toLowerCase();
  setText('f1-champ-sub', `Temporada ${data.season} · después de la fecha ${data.round}`);
  for (const r of data.rows) {
    const pts = Number(r.points);
    const pos = Number(r.position || r.positionText) || '–';
    let name, team, tid, extra;
    if (which === 'drivers') {
      const c = (r.Constructors || [])[r.Constructors.length - 1] || {};
      tid = c.constructorId; team = c.name || '';
      name = `${r.Driver.givenName} ${r.Driver.familyName}`;
      extra = r.Driver.code || '';
    } else {
      tid = r.Constructor.constructorId; name = r.Constructor.name; team = r.Constructor.nationality || ''; extra = '';
    }
    const mine = which === 'drivers' ? fav.includes(r.Driver.familyName.toLowerCase()) : false;
    const myTeam = which === 'teams' && (data.rows.length && (S.cache['f1:drivers'] || {}).data && ((S.cache['f1:drivers'].data.rows || []).some(d => fav.includes(d.Driver.familyName.toLowerCase()) && (d.Constructors || []).some(c => c.constructorId === tid))));
    const pct = leader ? Math.max(3, (pts / leader) * 100) : 0;
    list.append(el('li', { class: 'st-row' + (pos <= 3 ? ' podium p' + pos : '') + (mine || myTeam ? ' mine' : ''), style: `--tc:${teamColor(tid)}` },
      el('span', { class: 'st-pos', text: String(pos) }),
      el('span', { class: 'st-bar' }),
      el('span', { class: 'st-n' }, el('b', {}, name, extra ? el('small', { text: ' ' + extra }) : null), el('span', { text: which === 'drivers' ? team : `${plural(Number(r.wins || 0), 'victoria', 'victorias')}` })),
      el('span', { class: 'st-pts' }, el('b', { text: String(pts) }), el('span', { text: pos === 1 ? 'pts' : `-${leader - pts}` })),
      el('span', { class: 'st-meter' }, el('span', { style: `width:${pct}%` }))));
  }
  const mineEl = list.querySelector('.mine');
  if (mineEl && ui.f1ScrollMine !== which) { ui.f1ScrollMine = which; requestAnimationFrame(() => mineEl.scrollIntoView({ block: 'nearest' })); }
}
function setF1Tab(t) {
  ui.f1Tab = t;
  const panel = $('#f1-panel');
  panel.classList.toggle('tab-camp', t === 'camp');
  for (const b of $$('#f1-tabs button')) b.classList.toggle('on', b.dataset.t === t);
  if (t === 'camp') { renderStandings(); loadStandings(false); }
}
function setupF1Extra() {
  for (const b of $$('#f1-tabs button')) b.onclick = () => setF1Tab(b.dataset.t);
  for (const b of $$('#f1-champ button')) b.onclick = () => { ui.f1Champ = b.dataset.c; renderStandings(); };
}
const parseRaces = (t) => { const j = JSON.parse(t); return j.MRData.RaceTable.Races; };
let f1List = [];
async function loadF1(force) {
  const year = new Date().getFullYear();
  let races = await cached('f1:' + year, 360, `https://api.jolpi.ca/ergast/f1/${year}.json?limit=100`, parseRaces, force) || [];
  let list = f1Sessions(races);
  // terminó la temporada: buscamos el calendario del año que viene
  if (!list.some(s => s.end > Date.now())) {
    const next = await cached('f1:' + (year + 1), 720, `https://api.jolpi.ca/ergast/f1/${year + 1}.json?limit=100`, parseRaces, force) || [];
    list = list.concat(f1Sessions(next));
  }
  f1List = list;
  renderF1();
  checkF1Alerts();
}
function nextF1() {
  const now = Date.now();
  return f1List.find(s => s.end > now) || null;
}
function f1When(ts) {
  const d = new Date(ts);
  const day = ymd(d) === ymd(new Date()) ? 'hoy' : ymd(d) === ymd(addDays(new Date(), 1)) ? 'mañana' : fmt(d, { weekday: 'long', day: 'numeric', month: 'long' });
  return `${day}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function f1Short(ts) {
  const d = new Date(ts);
  const day = ymd(d) === ymd(new Date()) ? 'hoy' : ymd(d) === ymd(addDays(new Date(), 1)) ? 'mañana'
    : fmt(d, { weekday: 'short', day: 'numeric' }).replace(/[.,]/g, '');
  return `${day} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function renderF1() {
  if (!widgetOn('f1')) return;
  applyTopicChrome();
  const tp = topic();
  $('#f1-next').classList.remove('has-flag');
  $('#f1-sessions').replaceChildren();
  $('#team-results').replaceChildren();
  if (!tp) { $('#f1-next').replaceChildren(); return; }
  if (tp.kind === 'team') return renderTeamPanel();
  if (tp.kind === 'tema') return renderTemaPanel();
  $('#f1-alert').value = S.modes.casa.f1.alert;
  const box = $('#f1-next');
  const list = $('#f1-sessions');
  const n = nextF1();
  list.replaceChildren();
  if (!n) {
    box.classList.remove('live');
    box.replaceChildren(el('div', { class: 'sess', text: f1List.length ? 'Terminó la temporada' : 'Calendario no disponible' }),
      el('div', { class: 'when', text: f1List.length ? 'Cuando salga el calendario nuevo, la cuenta regresiva aparece acá.' : 'Se actualiza solo cuando haya conexión.' }));
    return;
  }
  const iso = flagIso(n.country);
  box.classList.toggle('has-flag', !!iso);
  box.replaceChildren(
    iso ? flagLayer(iso) : null,
    el('div', { class: 'track', id: 'f1-track', 'aria-hidden': 'true' }),
    el('div', { class: 'race', text: n.gp + (n.place ? ` · ${n.place}` : '') }),
    el('div', { class: 'sess', text: n.name }),
    el('div', { class: 'count', id: 'f1-count' }),
    el('div', { class: 'when', text: f1When(n.start) }));
  renderF1Count();
  loadCircuit(n);
  renderF1Photo();
  const now = Date.now();
  const weekend = f1List.filter(x => x.round === n.round);
  const done = weekend.filter(x => x.end <= now);
  if (done.length) {
    const li = el('li', { class: 'done-sum' + (ui.f1ShowDone ? ' open' : '') });
    const b = el('button', { class: 'done-btn', 'aria-expanded': String(!!ui.f1ShowDone) },
      el('span', { text: `Ya se corrieron: ${done.map(x => x.name).join(', ')}` }),
      el('span', { class: 'st', text: ui.f1ShowDone ? 'Ocultar' : 'Ver' }));
    b.onclick = () => { ui.f1ShowDone = !ui.f1ShowDone; renderF1(); };
    li.append(b);
    list.append(li);
    if (ui.f1ShowDone) for (const s of done) list.append(el('li', { class: 'past' }, el('span', { text: s.name }), el('span', { class: 'st', text: f1Short(s.start) })));
  }
  for (const s of weekend.filter(x => x.end > now)) {
    const live = s.start <= now;
    list.append(el('li', { class: live ? 'now' : '' },
      el('span', { text: s.name }),
      el('span', { class: 'st', text: live ? 'En vivo' : f1Short(s.start) })));
  }
}
function renderF1Count() {
  const tp = topic();
  if (!tp || tp.kind === 'tema') return;
  if (tp.kind === 'team') return renderTeamCount();
  const c = $('#f1-count');
  if (!c) return;
  const n = nextF1();
  if (!n) return renderF1();
  const now = Date.now();
  const box = $('#f1-next');
  if (n.start <= now) {
    if (!box.classList.contains('live')) { box.classList.add('live'); }
    c.replaceChildren(el('div', {}, el('b', {}, el('span', { class: 'dot' }), 'En vivo'),
      el('span', { text: `Termina cerca de las ${pad(new Date(n.end).getHours())}:${pad(new Date(n.end).getMinutes())}` })));
    return;
  }
  if (box.classList.contains('live')) { box.classList.remove('live'); return renderF1(); }
  let s = Math.floor((n.start - now) / 1000);
  const dd = Math.floor(s / 86400); s %= 86400;
  const hh = Math.floor(s / 3600); s %= 3600;
  const mm = Math.floor(s / 60); const ss = s % 60;
  const unit = (v, l) => el('div', {}, el('b', { text: dd || l !== 'días' ? pad(v) : '0' }), el('span', { text: l }));
  c.replaceChildren(...(dd ? [unit(dd, dd === 1 ? 'día' : 'días')] : []), unit(hh, 'horas'), unit(mm, 'min'), unit(ss, 'seg'));
  c.setAttribute('aria-label', `Faltan ${dd} días, ${hh} horas y ${mm} minutos`);
}
function checkF1Alerts() {
  const tp = topic();
  if (!tp || tp.kind === 'tema') return;
  if (tp.kind === 'team') return checkTeamAlerts();
  const cfg = S.modes.casa.f1;
  if (cfg.alert === '' || cfg.alert == null) return;
  const lead = Number(cfg.alert) * 60000;
  const now = Date.now();
  for (const s of f1List) {
    const fire = s.start - lead;
    if (now >= fire && now < s.start + 10 * 60000 && !cfg.notified.includes(s.key)) {
      cfg.notified.push(s.key);
      if (cfg.notified.length > 60) cfg.notified.splice(0, cfg.notified.length - 60);
      const t = new Date(s.start);
      const mins = Math.round((s.start - now) / 60000);
      const when = mins <= 1 ? 'empieza ahora' : mins < 90 ? `empieza en ${mins} minutos` : `empieza a las ${pad(t.getHours())}:${pad(t.getMinutes())}`;
      notify('f1', `F1 · ${s.gp}`, `${s.name}: ${when} (${pad(t.getHours())}:${pad(t.getMinutes())})`, { w: 'f1', mode: 'casa' });
      save();
    }
  }
}

// noticias
function parseRss(t) {
  const xml = new DOMParser().parseFromString(t, 'text/xml');
  if (xml.querySelector('parsererror')) return null;
  const items = [...xml.getElementsByTagName('item')].slice(0, 20).map(it => {
    const kids = [...it.children];
    const find = (name) => kids.find(k => k.nodeName.toLowerCase() === name || k.localName.toLowerCase() === name);
    const text = (name) => { const k = find(name); return k ? k.textContent.trim() : ''; };
    const srcEl = kids.find(k => k.nodeName === 'source') || null;
    const source = text('news:source') || (srcEl ? srcEl.textContent.trim() : '');
    let link = text('link');
    // Bing manda un enlace de seguimiento: sacamos la nota original
    try { const u = new URL(link); if (/apiclick\.aspx/i.test(u.pathname) && u.searchParams.get('url')) link = u.searchParams.get('url'); } catch {}
    let title = text('title');
    if (source && title.endsWith(' - ' + source)) title = title.slice(0, -(source.length + 3));
    let image = text('news:image') || text('image');
    if (image) image = image.replace(/^http:\/\//i, 'https://');
    let domain = '';
    try { domain = new URL(srcEl && srcEl.getAttribute('url') ? srcEl.getAttribute('url') : link).hostname.replace(/^www\./, ''); } catch {}
    if (domain === 'news.google.com') domain = '';
    let desc = text('description').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
    if (!desc || normTitle(desc).startsWith(normTitle(title).slice(0, 30))) desc = ''; // Google repite el título
    if (desc.length > 600) desc = desc.slice(0, 597) + '…';
    return { title, link, date: Date.parse(text('pubdate')) || 0, source, image, domain, desc };
  }).filter(i => i.title && /^https?:\/\//.test(i.link));
  return items.length ? items : null;
}
const normTitle = (t) => t.toLowerCase().normalize('NFD').replace(/[^a-z0-9 ]/g, '').slice(0, 48);
function newsKey() { return 'news:' + newsQuery().toLowerCase(); }
function newsItems() {
  if (!newsQuery()) return [];
  const bing = (S.cache[newsKey() + ':bing'] || {}).data || [];
  const goog = (S.cache[newsKey()] || {}).data || [];
  const seen = new Set(bing.map(i => normTitle(i.title)));
  return bing.concat(goog.filter(i => !seen.has(normTitle(i.title)))).sort((a, b) => b.date - a.date);
}
async function loadNews(force) {
  if (!newsQuery()) { renderNews(); return; }
  const q = encodeURIComponent(newsQuery());
  const key = newsKey();
  await Promise.all([
    cached(key + ':bing', 30, `https://www.bing.com/news/search?q=${q}&format=rss&setlang=es&cc=AR`, parseRss, force),
    cached(key, 30, `https://news.google.com/rss/search?q=${q}&hl=es-419&gl=AR&ceid=AR:es-419`, parseRss, force)
  ]);
  renderNews();
  renderF1Photo();
  if (topic() && topic().kind === 'tema') renderTemaPanel();
}
const thumbUrl = (img, w, h) => img + (img.includes('?') ? '&' : '?') + `w=${w}&h=${h}&c=7&rs=1`;
function newsThumb(it) {
  const box = el('span', { class: 'n-thumb' });
  const logo = () => {
    box.classList.add('logo');
    if (it.domain) {
      const fav = el('img', { src: `https://www.google.com/s2/favicons?domain=${encodeURIComponent(it.domain)}&sz=64`, alt: '', loading: 'lazy' });
      fav.onerror = () => box.replaceChildren(el('span', { class: 'n-letter', text: letterFor(it.source || it.domain) }));
      box.replaceChildren(fav);
    } else box.replaceChildren(el('span', { class: 'n-letter', text: letterFor(it.source || '?') }));
  };
  if (it.image) {
    const img = el('img', { src: thumbUrl(it.image, 160, 120), alt: '', loading: 'lazy' });
    img.onerror = logo;
    box.append(img);
  } else logo();
  return box;
}
function ago(ts) {
  if (!ts) return '';
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 60) return `hace ${Math.max(1, m)} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.round(h / 24);
  return d === 1 ? 'ayer' : `hace ${d} días`;
}
function renderNews() {
  if (!widgetOn('f1')) return;
  const items = newsItems();
  const list = $('#news');
  list.replaceChildren();
  if (!topic()) return;
  if (!items.length) {
    list.append(el('li', { class: 'empty', style: 'padding:8px 6px' }, 'Noticias no disponibles por ahora. Se actualizan solas cuando haya conexión.'));
    return;
  }
  for (const it of items.slice(0, 12)) {
    const a = el('a', { href: it.link, title: 'Abrir en el navegador' },
      newsThumb(it),
      el('span', { class: 'n-body' },
        el('span', { class: 'nt', text: it.title }),
        el('span', { class: 'ns', text: [it.source, ago(it.date)].filter(Boolean).join(' · ') })));
    a.onclick = (e) => { e.preventDefault(); api.openUrl(it.link); };
    list.append(el('li', {}, a));
  }
}

// foto destacada del panel de F1: la de la noticia más reciente con imagen,
// o una ilustración propia si no hay ninguna
const F1_ART = `<svg viewBox="0 0 600 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <defs><linearGradient id="f1g" x1="0" x2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".95"/><stop offset="1" stop-color="currentColor" stop-opacity=".7"/></linearGradient></defs>
  <g fill="none" stroke="currentColor" stroke-opacity=".18" stroke-width="2"><path d="M-10 170 Q150 120 300 150 T610 120"/><path d="M-10 186 Q150 136 300 166 T610 136"/></g>
  <g fill="url(#f1g)">
    <path d="M62 128 h40 l18 -14 h70 l30 -22 h58 l12 -16 h34 l6 16 h44 l46 22 h86 l26 10 v14 l-40 6 H62 z"/>
    <path d="M38 96 h30 l8 30 h-30 z"/><path d="M30 92 h52 v8 h-52 z"/>
    <path d="M498 124 h62 v10 h-62 z"/>
  </g>
  <path d="M296 86 q34 -26 70 0" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/>
  <g><circle cx="128" cy="144" r="30" fill="currentColor"/><circle cx="128" cy="144" r="12" fill="var(--accent)"/>
     <circle cx="462" cy="146" r="27" fill="currentColor"/><circle cx="462" cy="146" r="11" fill="var(--accent)"/></g>
  <g fill="currentColor" opacity=".25"><rect x="560" y="20" width="12" height="12"/><rect x="572" y="32" width="12" height="12"/><rect x="560" y="44" width="12" height="12"/><rect x="584" y="20" width="12" height="12"/><rect x="584" y="44" width="12" height="12"/></g>
</svg>`;
function renderF1Photo() {
  const box = $('#f1-next');
  if (!box || !widgetOn('f1')) return;
  if (box.classList.contains('has-flag')) { const a = box.querySelector('.art'); if (a) a.remove(); return; }
  const it = newsItems().find(i => i.image);
  const art = box.querySelector('.art');
  if (it) {
    const url = thumbUrl(it.image, 900, 380);
    // probamos la foto antes de ponerla de fondo
    const probe = new Image();
    probe.onload = () => { box.style.setProperty('--photo', `url("${url.replace(/"/g, '%22')}")`); box.classList.add('has-photo'); if (art) art.remove(); };
    probe.onerror = () => { box.classList.remove('has-photo'); };
    probe.src = url;
    box.title = `Foto: ${it.source || 'noticias'} · ${it.title}`;
  } else {
    box.classList.remove('has-photo');
    box.style.removeProperty('--photo');
    if (!art) { const a = el('div', { class: 'art', 'aria-hidden': 'true' }); a.innerHTML = F1_ART; box.prepend(a); }
    box.title = '';
  }
}

// dibujo del circuito de la próxima carrera (imagen de Wikipedia)
async function loadCircuit(n) {
  const wrap = $('#f1-track');
  if (!wrap) return;
  if (!n || !n.circuitUrl) { wrap.replaceChildren(); return; }
  const title = decodeURIComponent((n.circuitUrl.split('/wiki/')[1] || '').replace(/#.*$/, ''));
  if (!title) return;
  const url = `https://en.wikipedia.org/w/api.php?action=query&format=json&prop=pageimages&piprop=thumbnail&pithumbsize=500&redirects=1&titles=${encodeURIComponent(title)}`;
  const src = await cached('circuit:' + title, 43200, url, (t) => {
    const pages = JSON.parse(t).query.pages;
    const pg = pages[Object.keys(pages)[0]];
    return pg && pg.thumbnail ? pg.thumbnail.source : '';
  });
  const now = $('#f1-track');
  if (!now) return;
  if (src) {
    const img = el('img', { src, alt: `Circuito de ${n.place || n.gp}` });
    img.onerror = () => now.replaceChildren();
    now.replaceChildren(img);
  } else now.replaceChildren();
}

// ---------- Google: cuentas ----------
const safeCall = async (fn) => { try { return await fn(); } catch (e) { return { ok: false, error: (e && e.message) || String(e) }; } };

function acct(mode = S.activeMode) {
  return ui.gstatus && ui.gstatus.accounts ? ui.gstatus.accounts[gmode(mode)] : null;
}
async function refreshGStatus() {
  if (!api.google) return;
  const r = await safeCall(() => api.google.status());
  ui.gstatus = r && r.ok ? r.data : { configured: false, accounts: {} };
}
function openGoogleSetup(mode) {
  ui.gsetupMode = mode || S.activeMode;
  $('#g-error').textContent = '';
  $('#dlg-google').showModal();
  $('#g-id').focus();
}
async function linkGoogle(mode = S.activeMode) {
  if (!ui.gstatus || !ui.gstatus.configured) return openGoogleSetup(mode);
  toast(`Se abrió el navegador: elegí la cuenta de Google para ${modeName(mode)}.`);
  ui.linking = mode;
  renderMail();
  const r = await safeCall(() => G.link(mode));
  ui.linking = null;
  if (!r.ok) {
    toast('No se vinculó: ' + r.error);
  } else {
    const miss = r.data.missing && r.data.missing.length ? ` (sin permiso para ${r.data.missing.join(' y ')}: volvé a vincular y tildá todas las casillas)` : '';
    toast(`Vinculaste ${r.data.email} a ${modeName(mode)}${miss}`);
    S.modes[mode].mail.seen = null;
  }
  await refreshGStatus();
  if ($('#drawer').classList.contains('on')) renderDrawer();
  loadMail(true, mode);
  loadGcal(true, mode);
}
async function unlinkGoogle(mode) {
  const a = acct(mode);
  if (!a || !confirm(`¿Desvincular ${a.email} del modo ${modeName(mode)}?`)) return;
  await G.unlink(mode);
  delete S.cache['gcal:' + mode];
  delete S.cache['gmail:' + mode];
  save();
  await refreshGStatus();
  renderDrawer(); renderMail(); renderAgenda(); renderSummary();
  toast(`Desvinculaste la cuenta de ${modeName(mode)}`);
}
function renderAccounts() {
  const box = $('#acct-rows');
  box.replaceChildren();
  for (const mode of (SINGLE ? ['casa'] : ['casa', 'trabajo'])) {
    const a = acct(mode);
    const btn = el('button', { class: 'text-btn', text: a ? 'Desvincular' : 'Vincular' });
    btn.onclick = () => a ? unlinkGoogle(mode) : linkGoogle(mode);
    box.append(el('div', { class: 'acct-row' },
      el('b', { text: modeName(mode) }),
      el('span', { class: 'who', text: a ? a.email + (a.needsRelink ? ' (volvé a vincular)' : '') : 'Sin vincular' }),
      btn));
  }
  $('#btn-gsetup').textContent = ui.gstatus && ui.gstatus.configured ? 'Cambiar la conexión con Google…' : 'Configurar la conexión con Google…';
}

// ---------- Google Calendar ----------
let gcalBusy = {};
async function loadGcal(force, mode = S.activeMode) {
  if (!api.google || !acct(mode) || gcalBusy[mode]) { if (mode === S.activeMode) renderGsync(); return; }
  const c = S.cache['gcal:' + mode];
  const from = addDays(new Date(ui.calMonth.getFullYear(), ui.calMonth.getMonth(), 1), -7);
  const toA = addDays(new Date(ui.calMonth.getFullYear(), ui.calMonth.getMonth() + 1, 1), 7);
  const toB = addDays(new Date(), 30);
  const to = toA > toB ? toA : toB;
  const covered = c && c.from <= +from && c.to >= +to;
  if (!force && covered && Date.now() - c.at < 5 * 60000) return;
  gcalBusy[mode] = true;
  const r = await safeCall(() => G.events(mode, from.toISOString(), to.toISOString()));
  gcalBusy[mode] = false;
  if (r.ok) {
    S.cache['gcal:' + mode] = { at: Date.now(), from: +from, to: +to, data: r.data, error: null };
  } else if (c) {
    c.error = r.error;
  } else {
    S.cache['gcal:' + mode] = { at: 0, from: 0, to: 0, data: [], error: r.error };
  }
  if (r.code === 'relink') await refreshGStatus();
  save();
  if (mode === S.activeMode) { renderAgenda(); renderSummary(); renderGsync(); }
}
function renderGsync() {
  const tag = $('#gsync');
  const a = acct();
  const c = S.cache['gcal:' + S.activeMode];
  $('#ev-google-wrap').hidden = !a;
  if (!a) { tag.hidden = true; return; }
  tag.hidden = false;
  tag.textContent = c && c.error ? 'Google: sin sincronizar' : 'con Google';
  tag.title = c && c.error ? c.error : `Sincronizada con ${a.email}`;
}

// ---------- Correo (Gmail) ----------
let mailBusy = {};
async function loadMail(force, mode = S.activeMode) {
  if (!api.google || !acct(mode) || mailBusy[mode]) { if (mode === S.activeMode) renderMail(); return; }
  const c = S.cache['gmail:' + mode];
  if (!force && c && Date.now() - c.at < 2 * 60000) { if (mode === S.activeMode) renderMail(); return; }
  mailBusy[mode] = true;
  const r = await safeCall(() => G.mail(mode));
  mailBusy[mode] = false;
  if (r.ok) {
    S.cache['gmail:' + mode] = { at: Date.now(), data: r.data, error: null };
    notifyNewMail(mode, r.data);
  } else {
    S.cache['gmail:' + mode] = Object.assign(c || { data: null }, { at: Date.now(), error: r.error, code: r.code });
    if (r.code === 'relink') await refreshGStatus();
  }
  save();
  if (mode === S.activeMode) renderMail();
}
function notifyNewMail(mode, data) {
  const cfg = S.modes[mode].mail;
  const ids = data.messages.map(m => m.id);
  if (cfg.seen && cfg.notify) {
    const fresh = data.messages.filter(m => !cfg.seen.includes(m.id));
    if (fresh.length === 1) notify('mail', `${fresh[0].from} · ${modeName(mode)}`, fresh[0].subject, { w: 'mail', mode, msg: fresh[0].id });
    else if (fresh.length > 1) notify('mail', `${fresh.length} mails nuevos · ${modeName(mode)}`, fresh.slice(0, 3).map(m => `${m.from}: ${m.subject}`).join('\n'), { w: 'mail', mode });
  }
  cfg.seen = Array.from(new Set([...(cfg.seen || []), ...ids])).slice(-80);
}
// color propio de cada remitente, y el logo de su empresa si no es un correo personal
const MAIL_COLORS = ['#e8590c', '#2b8a3e', '#1971c2', '#9c36b5', '#c2255c', '#0c8599', '#d9480f', '#5f3dc4', '#5c940d', '#a61e4d'];
const PERSONAL_DOMAINS = new Set(['gmail.com', 'googlemail.com', 'hotmail.com', 'hotmail.com.ar', 'outlook.com', 'outlook.com.ar', 'live.com',
  'live.com.ar', 'msn.com', 'yahoo.com', 'yahoo.com.ar', 'icloud.com', 'me.com', 'proton.me', 'protonmail.com', 'aol.com', 'fibertel.com.ar', 'speedy.com.ar']);
function senderColor(key) {
  let h = 0;
  for (const c of String(key)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return MAIL_COLORS[h % MAIL_COLORS.length];
}
function initials(name) {
  const w = String(name).replace(/["']/g, '').trim().split(/\s+/).filter(Boolean);
  return ((w[0] || '?')[0] + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase();
}
function mailAvatar(m) {
  const box = el('span', { class: 'm-av' });
  const letters = () => { box.classList.remove('logo'); box.replaceChildren(el('span', { text: initials(m.from) })); };
  const domain = (m.addr || '').split('@')[1] || '';
  const base = domain.split('.').slice(-3).join('.');
  if (domain && !PERSONAL_DOMAINS.has(domain) && !PERSONAL_DOMAINS.has(base)) {
    const site = domain.replace(/^(mail|email|e|info|news|noreply|no-reply|notificaciones|notifications|mailer|mkt|marketing)\./, '');
    const img = el('img', { src: `https://www.google.com/s2/favicons?domain=${encodeURIComponent(site)}&sz=64`, alt: '' });
    img.onerror = letters;
    img.onload = () => { if (img.naturalWidth <= 16) letters(); };
    box.classList.add('logo');
    box.append(img);
  } else letters();
  return box;
}
function renderMail() {
  if (S && stageKind() === 'redes') renderRedesMail();
  const list = $('#mail-list');
  const a = acct();
  const cfg = M().mail;
  $('#mail-bell').setAttribute('aria-pressed', String(!!cfg.notify));
  $('#mail-bell').title = cfg.notify ? 'Te aviso cuando llegan mails nuevos (tocá para apagar)' : 'Avisarme cuando lleguen mails nuevos';
  $('#mail-open').hidden = !a;
  $('#mail-refresh').hidden = !a;
  $('#mail-allread').hidden = !a || !(S.cache['gmail:' + S.activeMode] && S.cache['gmail:' + S.activeMode].data && S.cache['gmail:' + S.activeMode].data.messages.length);
  $('#mail-bell').hidden = !a;
  list.replaceChildren();
  if (!a) {
    $('#mail-count').textContent = '';
    $('#mail-acct').textContent = '';
    const b = el('button', { class: 'btn', text: ui.linking === S.activeMode ? 'Esperando a Google…' : 'Vincular cuenta de Google' });
    b.disabled = ui.linking === S.activeMode;
    b.onclick = () => linkGoogle(S.activeMode);
    list.append(el('li', { class: 'connect' },
      el('p', { text: gmode(S.activeMode) === 'trabajo'
        ? 'Vinculá tu cuenta de Google del trabajo para ver acá los mails sin leer y tu calendario en la agenda.'
        : 'Vinculá tu cuenta personal de Google para ver acá los mails sin leer y tu calendario en la agenda.' }), b));
    return;
  }
  $('#mail-acct').textContent = a.email;
  const c = S.cache['gmail:' + S.activeMode];
  const data = c && c.data;
  if (a.needsRelink || (c && c.code === 'relink')) {
    const b = el('button', { class: 'btn', text: 'Volver a vincular' });
    b.onclick = () => linkGoogle(S.activeMode);
    list.append(el('li', { class: 'connect err' }, el('p', { text: 'Google pidió volver a vincular esta cuenta (pasa si la app quedó en modo de prueba).' }), b));
    $('#mail-count').textContent = '';
    return;
  }
  $('#mail-count').textContent = data && data.unread ? (data.unread > 99 ? '99+' : data.unread) : '';
  if (c && c.error && !data) {
    list.append(el('li', { class: 'connect err' }, el('p', { text: 'No se pudo leer el correo: ' + c.error })));
    return;
  }
  if (!data) { list.append(el('li', { class: 'empty', text: 'Cargando…' })); return; }
  if (!data.messages.length) { list.append(el('li', { class: 'empty', text: 'No tenés mails sin leer en la bandeja de entrada.' })); return; }
  for (const m of data.messages) {
    const d = new Date(m.date);
    const when = ymd(d) === ymd(new Date()) ? `${pad(d.getHours())}:${pad(d.getMinutes())}` : fmt(d, { day: 'numeric', month: 'short' }).replace('.', '');
    const link = el('a', { href: '#', title: 'Abrir en Gmail' },
      mailAvatar(m),
      el('span', { class: 'm-body' },
        el('span', { class: 'mf', text: m.from }),
        el('span', { class: 'md', text: when }),
        el('span', { class: 'ms', text: m.subject }),
        m.snippet ? el('span', { class: 'mp', text: m.snippet }) : null));
    link.style.setProperty('--mc', senderColor(m.addr || m.from));
    const done = el('button', { class: 'm-done', title: 'Marcar como leído', 'aria-label': 'Marcar como leído' }, svg('<path d="M5 12l5 5L20 7"/>'));
    done.onclick = (e) => { e.preventDefault(); e.stopPropagation(); markMailRead([m.id]); };
    link.append(done);
    link.title = 'Abrir el mail';
    link.onclick = (e) => { e.preventDefault(); openMailView(m.id); };
    list.append(el('li', {}, link));
  }
}

// ---------- Centro de notificaciones ----------
const NOTIF_ICON = {
  agenda: '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/>',
  f1: '<path d="M4 21V4M4 4h14l-3 4 3 4H4"/>',
  team: '<circle cx="12" cy="12" r="9"/><path d="m12 7 4 3-1.5 4.5h-5L8 10z"/>',
  sistema: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>',
  pomo: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9.5 3h5"/>'
};
function notify(kind, title, body, action) {
  const n = { id: uid(), kind, title: String(title), body: String(body || ''), at: Date.now(), read: false, action: action || null };
  S.notifs = [n, ...(S.notifs || [])].slice(0, 80);
  save();
  renderNotifBadge();
  if (!$('#notif-panel').hidden) renderNotifs();
  if (!S.settings.dnd) showNotif(n);
}
const NOTIF_COLOR = { agenda: '#3a86d6', mail: '#e0533d', f1: '#e10600', team: '#2f9e44', pomo: '#e8590c' };
function showNotif(n) {
  const style = S.settings.notifStyle || 'float';
  if ((style === 'float' || style === 'both') && api.floatNotify) {
    const kind = n.kind === 'match' ? 'team' : n.kind;
    const st = S.settings;
    api.floatNotify({ id: n.id, kind, title: n.title, body: n.body, scheme: M().theme.scheme, color: NOTIF_COLOR[kind] || M().theme.accent,
      look: st.notifLook || 'tarjeta', pos: st.notifPos || 'br', sound: st.notifSound || 'none', life: st.notifLife || 8,
      label: n.action && n.action.mode && n.action.mode !== S.activeMode ? `${({ agenda: 'Agenda', mail: 'Correo' })[kind] || 'Base'} · ${modeName(n.action.mode)}` : '' });
  }
  if (style === 'windows' || style === 'both' || !api.floatNotify) api.notify(n.title, n.body);
}
function renderNotifBadge() {
  const unread = (S.notifs || []).filter(n => !n.read).length;
  $('#notif-count').textContent = unread ? (unread > 9 ? '9+' : unread) : '';
  $('#btn-notifs').classList.toggle('dnd', !!S.settings.dnd);
  $('#btn-notifs').title = S.settings.dnd ? 'Notificaciones (No molestar activado)' : 'Notificaciones';
}
function renderNotifs() {
  const list = $('#np-list');
  list.replaceChildren();
  const items = S.notifs || [];
  $('#np-dnd').checked = !!S.settings.dnd;
  if (!items.length) {
    list.append(el('li', { class: 'empty' }, 'No hay notificaciones. Acá van a quedar los avisos de la agenda, de tus mails nuevos y de tu sección de noticias.'));
    return;
  }
  for (const n of items) {
    const del = el('button', { class: 'row-del', 'aria-label': 'Borrar', title: 'Borrar' }, svg(ICON.x));
    del.onclick = (e) => { e.stopPropagation(); S.notifs = S.notifs.filter(x => x.id !== n.id); save(); renderNotifs(); renderNotifBadge(); };
    const b = el('li', { class: 'np-item' + (n.read ? '' : ' unread') },
      el('span', { class: 'np-ico k-' + n.kind }, svg(NOTIF_ICON[n.kind] || NOTIF_ICON.sistema)),
      el('span', { class: 'np-body' },
        el('span', { class: 'np-t', text: n.title }),
        n.body ? el('span', { class: 'np-b', text: n.body }) : null,
        el('span', { class: 'np-d', text: ago(n.at) })),
      del);
    b.onclick = () => openNotif(n);
    list.append(b);
  }
}
function openNotif(n) {
  n.read = true; save(); renderNotifBadge();
  toggleNotifPanel(false);
  const a = n.action;
  if (!a) return;
  if (a.mode && a.mode !== S.activeMode && S.modes[a.mode] && !(SINGLE && a.mode !== 'casa')) setMode(a.mode);
  setTimeout(() => {
    openWidget(a.w, true);
    if (a.msg) openMailView(a.msg);
  }, 60);
}
function toggleNotifPanel(on) {
  const p = $('#notif-panel');
  if (on === undefined) on = p.hidden;
  p.hidden = !on;
  $('#btn-notifs').setAttribute('aria-expanded', String(on));
  if (on) {
    renderNotifs();
    // al abrir, las marcamos como vistas (siguen en la lista)
    setTimeout(() => { (S.notifs || []).forEach(x => x.read = true); save(); renderNotifBadge(); }, 1500);
  }
}

// ---------- Correo: leer adentro de Base y marcar como leído ----------
const escHtml = (t) => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
function mailFrameDoc(m, showImages) {
  const csp = showImages
    ? "default-src 'none'; img-src https: http: data:; style-src 'unsafe-inline' https:; font-src https: data:"
    : "default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:";
  const body = m.html || `<pre style="white-space:pre-wrap;font:14px/1.55 'Segoe UI',system-ui,sans-serif;margin:0">${escHtml(m.text || '(Este mail no tiene texto)')}</pre>`;
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${csp}"><base target="_blank">` +
    `<style>html,body{background:#fff}body{margin:18px;font:14px/1.5 'Segoe UI',system-ui,sans-serif;color:#1d232b;overflow-wrap:anywhere}img{max-width:100%;height:auto}table{max-width:100%}</style></head><body>${body}</body></html>`;
}
async function openMailView(id) {
  const mode = S.activeMode;
  ui.mailView = { id, mode, images: false, data: null };
  $('#mail-list').hidden = true;
  $('#mail-view').hidden = false;
  widgetEl('mail').classList.add('reading');
  if (W.open === 'mail') positionPop(widgetEl('mail'));
  $('#mv-subject').textContent = 'Cargando…';
  $('#mv-meta').textContent = '';
  $('#mv-note').hidden = true;
  $('#mv-frame').srcdoc = '';
  const r = await safeCall(() => G.message(mode, id));
  if (!ui.mailView || ui.mailView.id !== id) return;
  if (!r || !r.ok) { $('#mv-subject').textContent = 'No se pudo abrir el mail'; $('#mv-meta').textContent = (r && r.error) || ''; return; }
  ui.mailView.data = r.data;
  renderMailView();
}
function renderMailView() {
  const v = ui.mailView;
  if (!v || !v.data) return;
  const m = v.data;
  $('#mv-subject').textContent = m.subject;
  const d = new Date(m.date);
  const meta = $('#mv-meta');
  meta.replaceChildren(
    el('span', { class: 'mv-from', text: m.from.replace(/<.*>/, '').replace(/"/g, '').trim() || m.from }),
    el('span', { class: 'mv-addr', text: (/<([^>]+)>/.exec(m.from) || [])[1] || '' }),
    el('span', { class: 'mv-date', text: fmt(d, { weekday: 'short', day: 'numeric', month: 'short' }) + ` ${pad(d.getHours())}:${pad(d.getMinutes())}` }));
  if (m.attachments.length) meta.append(el('span', { class: 'mv-att', text: `Adjuntos: ${m.attachments.join(', ')} (se abren en Gmail)` }));
  $('#mv-read').hidden = !m.unread;
  $('#mv-images').textContent = v.images ? 'Ocultar imágenes' : 'Mostrar imágenes';
  $('#mv-images').hidden = !m.html;
  $('#mv-frame').srcdoc = mailFrameDoc(m, v.images);
}
function closeMailView() {
  ui.mailView = null;
  $('#mail-view').hidden = true;
  $('#mail-list').hidden = false;
  $('#mv-frame').srcdoc = '';
  widgetEl('mail').classList.remove('reading');
  if (W.open === 'mail') positionPop(widgetEl('mail'));
}
async function markMailRead(ids, mode = S.activeMode) {
  ids = [].concat(ids);
  if (!ids.length) return true;
  const r = await safeCall(() => G.markRead(mode, ids));
  if (!r || !r.ok) {
    if (r && r.code === 'need_modify') {
      const note = $('#mv-note');
      const msg = 'Para marcar como leído, Google pide un permiso más (modificar el correo). Es un clic: se abre el navegador, elegís tu cuenta y aceptás.';
      if (!$('#mail-view').hidden) {
        note.replaceChildren(msg + ' ', Object.assign(el('button', { class: 'text-btn', text: 'Dar permiso' }), { onclick: () => linkGoogle(mode) }));
        note.hidden = false;
      } else {
        toast('Google pide un permiso más para marcar como leído', { label: 'Dar permiso', fn: () => linkGoogle(mode) });
      }
    } else toast('No se pudo marcar como leído: ' + ((r && r.error) || 'sin conexión'));
    return false;
  }
  const c = S.cache['gmail:' + mode];
  if (c && c.data) {
    c.data.messages = c.data.messages.filter(x => !ids.includes(x.id));
    c.data.unread = Math.max(0, (c.data.unread || 0) - ids.length);
    save();
  }
  renderMail(); renderPeeks();
  return true;
}

// ---------- Control multimedia de Windows (Spotify, YouTube en el navegador, etc.) ----------
const MEDIA = { list: [], ok: null, thumbs: {}, at: 0 };
async function loadMedia() {
  if (!api.media || !api.media.sessions) return false;
  if (MEDIA.busy) return MEDIA.ok;
  MEDIA.busy = true;
  const r = await safeCall(() => api.media.sessions());
  MEDIA.busy = false;
  if (!r || !r.ok) { MEDIA.ok = false; return false; }
  MEDIA.ok = true; MEDIA.list = r.data || []; MEDIA.at = Date.now();
  return true;
}
const mediaLen = (s) => s ? Math.max(0, (s.end || 0) - (s.start || 0)) : 0;
function mediaPos(s) {
  if (!s) return 0;
  let p = (s.pos || 0) - (s.start || 0);
  if (s.status === 'Playing' && s.upd > 0) p += Math.max(0, Date.now() - s.upd) / 1000;
  const len = mediaLen(s);
  return Math.max(0, len ? Math.min(p, len) : p);
}
const mmss = (x) => { x = Math.max(0, Math.round(x || 0)); const h = Math.floor(x / 3600), m = Math.floor(x / 60) % 60, ss = x % 60; return (h ? h + ':' + pad(m) : m) + ':' + pad(ss); };
function appLabel(app) {
  const a = String(app || '');
  if (/spotify/i.test(a)) return 'Spotify';
  if (/chrome/i.test(a)) return 'Chrome';
  if (/msedge/i.test(a)) return 'Edge';
  if (/firefox|308046B0AF4A39CB/i.test(a)) return 'Firefox';
  if (/opera/i.test(a)) return 'Opera';
  if (/brave/i.test(a)) return 'Brave';
  if (/zunemusic|music/i.test(a)) return 'Reproductor multimedia';
  if (/vlc/i.test(a)) return 'VLC';
  if (/netflix/i.test(a)) return 'Netflix';
  if (/disney/i.test(a)) return 'Disney+';
  return a.split('!')[0].replace(/\.exe$/i, '').split(/[._]/).filter(x => x && !/^\d+$/.test(x) && x.length > 2).pop() || 'Multimedia';
}
async function mediaThumb(s) {
  const key = s.app + '|' + s.title + '|' + s.artist;
  if (key in MEDIA.thumbs) return MEDIA.thumbs[key];
  MEDIA.thumbs[key] = null;
  const u = api.media.thumb ? await safeCall(() => api.media.thumb(s.app)) : null;
  MEDIA.thumbs[key] = u || '';
  return MEDIA.thumbs[key];
}
// barra de reproducción reutilizable
function bindSeek(input, getSess) {
  input.addEventListener('pointerdown', () => { input.dataset.drag = '1'; });
  input.addEventListener('input', () => { input.style.setProperty('--p', (100 * input.value / (input.max || 1)) + '%'); const c = input.parentElement.querySelector('[data-cur]'); if (c) c.textContent = mmss(input.value); });
  input.addEventListener('change', async () => {
    const s = getSess();
    delete input.dataset.drag;
    if (!s) return;
    const target = (s.start || 0) + Number(input.value);
    s.pos = target; s.upd = Date.now();
    await api.media.act(s.app, 'seek', target);
    setTimeout(() => { loadPlayer(); if (typeof loadNowPlaying === 'function') loadNowPlaying(); }, 500);
  });
}
function paintSeek(input, curEl, endEl, s) {
  const len = mediaLen(s);
  if (!input || input.dataset.drag) return;
  const p = mediaPos(s);
  input.max = len || 1; input.value = p;
  input.disabled = !s.seek;
  input.style.setProperty('--p', (len ? 100 * p / len : 0) + '%');
  if (curEl) curEl.textContent = mmss(p);
  if (endEl) endEl.textContent = len ? mmss(len) : '';
}

// ---------- Mini reproductor (Spotify) ----------
const PLAY_ICON = '<path d="M8 5v14l11-7z" fill="currentColor"/>';
const PAUSE_ICON = '<rect x="6.5" y="5" width="4" height="14" rx="1" fill="currentColor"/><rect x="13.5" y="5" width="4" height="14" rx="1" fill="currentColor"/>';
const player = { running: false, playing: false, artist: '', song: '', covers: {}, sess: null };
async function loadPlayer() {
  if (!api.media) return;
  if (await loadMedia()) {
    const s = MEDIA.list.find(x => /spotify/i.test(x.app));
    if (s && (s.title || s.status === 'Playing')) {
      player.running = true; player.sess = s;
      player.playing = s.status === 'Playing';
      player.artist = s.artist || ''; player.song = s.title || '';
      renderPlayer();
      return;
    }
  }
  player.sess = null;
  const r = await safeCall(() => api.media.state());
  if (!r || !r.ok || !r.data) return;
  const d = r.data;
  player.running = !!d.running;
  const title = d.title || '';
  const i = title.indexOf(' - ');
  if (d.running && i > 0 && !/^spotify/i.test(title)) {
    player.playing = true;
    player.artist = title.slice(0, i).trim();
    player.song = title.slice(i + 3).trim();
  } else {
    player.playing = false; // en pausa: Spotify muestra su nombre en vez de la canción
  }
  renderPlayer();
}
async function coverFor(artist, song) {
  const key = (artist + '|' + song).toLowerCase();
  if (key in player.covers) return player.covers[key];
  player.covers[key] = null;
  const r = await api.get(`https://itunes.apple.com/search?term=${encodeURIComponent(artist + ' ' + song)}&entity=song&limit=1`);
  try {
    const j = JSON.parse(r.text);
    const a = j.results && j.results[0] && j.results[0].artworkUrl100;
    player.covers[key] = a ? a.replace(/100x100bb/, '300x300bb') : '';
  } catch { player.covers[key] = ''; }
  return player.covers[key];
}
function paintPlayerSeek() {
  const row = $('#pl-seekrow');
  const s = player.sess;
  const show = !!(s && mediaLen(s) > 0);
  row.hidden = !show;
  if (show) paintSeek($('#pl-seek'), $('#pl-cur'), $('#pl-end'), s);
}
async function renderPlayer() {
  const box = $('#player');
  if (!player.running) { box.hidden = true; return; }
  box.hidden = false;
  box.classList.toggle('paused', !player.playing);
  const song = player.song || 'Spotify';
  setText('pl-song', player.playing ? song : (player.song ? song : 'Spotify está abierto'));
  setText('pl-artist', player.playing ? player.artist : (player.song ? `${player.artist} · En pausa` : 'Poné algo para escuchar'));
  $('#pl-play').innerHTML = `<svg viewBox="0 0 24 24">${player.playing ? PAUSE_ICON : PLAY_ICON}</svg>`;
  $('#pl-play').title = player.playing ? 'Pausar' : 'Reproducir';
  paintPlayerSeek();
  const coverBox = $('#pl-cover');
  if (player.song) {
    const key = (player.artist + '|' + player.song).toLowerCase();
    if (coverBox.dataset.key !== key) {
      coverBox.dataset.key = key;
      coverBox.replaceChildren(svg('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/>'));
      let url = player.sess ? await mediaThumb(player.sess) : '';
      if (!url) url = await coverFor(player.artist, player.song);
      if (url && coverBox.dataset.key === key) coverBox.replaceChildren(imgChain([url], () => {}));
    }
  } else if (coverBox.dataset.key !== '') {
    coverBox.dataset.key = '';
    coverBox.replaceChildren(svg('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/>'));
  }
}
function setupPlayer() {
  if (!api.media) return;
  $$('#player [data-media]').forEach(b => b.onclick = async () => {
    const k = b.dataset.media;
    const s = player.sess;
    if (s && api.media.act && ['play', 'next', 'prev'].includes(k)) {
      if (k === 'play') { s.status = s.status === 'Playing' ? 'Paused' : 'Playing'; player.playing = s.status === 'Playing'; renderPlayer(); }
      await api.media.act(s.app, k === 'play' ? 'toggle' : k);
    } else await api.media.key(k);
    if (['play', 'next', 'prev'].includes(k)) setTimeout(loadPlayer, 450);
  });
  bindSeek($('#pl-seek'), () => player.sess);
  $('#pl-song').onclick = () => {
    const w = (WINS.list || []).find(x => /spotify/i.test(x.app));
    if (w) winAct('focus', w);
  };
  loadPlayer();
  setInterval(() => { if (!document.hidden) loadPlayer(); }, 2000);
  setInterval(() => { if (!document.hidden && player.sess && player.playing) paintPlayerSeek(); }, 500);
  setInterval(() => { if (!document.hidden && stageKind() === 'streaming') loadNowPlaying(); }, 2000);
  setInterval(() => { if (!document.hidden && stageKind() === 'streaming') { const s2 = npSession(); if (s2 && s2.status === 'Playing') paintSeek($('#np-seek'), $('#np-cur'), $('#np-end'), s2); } }, 500);
}

// ---------- Ventanas abiertas y botones de Windows ----------
const WINS = { list: [], ok: null, sig: '' };
async function loadWindows() {
  if (!api.windows) return;
  const r = await safeCall(() => api.windows.list());
  if (!r || !r.ok) {
    if (WINS.ok !== false) { WINS.ok = false; WINS.err = r && r.error; renderSwitcher(); }
    return;
  }
  const sig = JSON.stringify(r.data.map(w => [w.h, w.title, w.min, w.max]));
  WINS.ok = true;
  if (sig === WINS.sig) return;
  WINS.sig = sig;
  WINS.list = r.data;
  renderSwitcher();
}
// La barra de ventanas va arriba si entra; si no, baja a una fila propia de todo el ancho
// Dónde va la barra de ventanas. Se decide por el ancho de la pantalla (no por cuántas ventanas hay),
// así no salta de lugar cada vez que se abre o se cierra una.
let swRowLast = null;
function switcherWanted() {
  const pref = S && S.settings.winBar || 'auto';
  if (WINS.ok === false) return false;
  if (pref === 'fila') return true;
  if (pref === 'arriba') return false;
  const bar = $('.topbar');
  let used = 0;
  for (const c of bar.children) if (c.id !== 'switcher' && !c.hidden && getComputedStyle(c).display !== 'none') used += c.getBoundingClientRect().width;
  const avail = bar.clientWidth - used - 40 - 12 * (bar.children.length - 1);
  // con margen para que no cambie de un lado al otro por pocos píxeles
  if (swRowLast === true && avail < 820) return true;
  if (swRowLast === false && avail > 700) return false;
  swRowLast = avail < 760;
  return swRowLast;
}
function placeSwitcher() {
  const box = $('#switcher');
  if (!box) return false;
  const row = switcherWanted();
  let holder = $('#winrow');
  if (row) {
    if (!holder) { holder = el('div', { class: 'winrow', id: 'winrow' }); $('.topbar').after(holder); }
    if (box.parentElement !== holder) holder.append(box);
  } else if (box.parentElement !== $('.topbar')) {
    $('#sysbtns').before(box);
  }
  if (holder) holder.hidden = !row;
  document.documentElement.classList.toggle('has-winrow', row);
  return row;
}
let swResizeT = 0;
addEventListener('resize', () => { clearTimeout(swResizeT); swResizeT = setTimeout(() => { if (S && WINS.ok != null) renderSwitcher(); }, 150); });
// Barra de ventanas: agrupa por programa, muestra programas fijados aunque estén cerrados
// y una vista previa al pasar el mouse.
const exeKey = (exe) => String(exe || '').toLowerCase();
const noGroup = (exe) => !exe || /\\(applicationframehost|explorer)\.exe$/i.test(exe);
const prettyApp = (n) => { n = String(n || ''); if (!n) return n; if (n === n.toUpperCase() || n === n.toLowerCase()) n = n.charAt(0).toUpperCase() + n.slice(1).toLowerCase(); return n.replace(/^Winword$/, 'Word').replace(/^Msedge$/, 'Edge').replace(/^Powerpnt$/, 'PowerPoint').replace(/^Chrome$/, 'Chrome'); };
function winPins() { if (!Array.isArray(S.settings.pins)) S.settings.pins = []; return S.settings.pins; }
function isPinned(exe) { const k = exeKey(exe); return !!k && winPins().some(p => exeKey(p.exe) === k); }
function togglePin(g) {
  const pins = winPins(), k = exeKey(g.exe);
  const i = pins.findIndex(p => exeKey(p.exe) === k);
  if (i >= 0) { pins.splice(i, 1); toast(`${g.name} ya no está fijado en la barra`); }
  else { pins.push({ exe: g.exe, name: g.name, icon: g.icon || null }); toast(`${g.name} quedó fijado en la barra`); }
  save(); renderSwitcher();
}
function winGroups() {
  const groups = [], byKey = new Map();
  for (const p of winPins()) { const g = { key: exeKey(p.exe), exe: p.exe, name: prettyApp(p.name || exeName(p.exe)), icon: p.icon, pinned: true, wins: [] }; groups.push(g); byKey.set(g.key, g); }
  for (const w of (WINS.list || [])) {
    const key = noGroup(w.exe) ? 'h' + w.h : exeKey(w.exe);
    let g = byKey.get(key);
    if (!g) { g = { key, exe: w.exe, name: w.app ? prettyApp(w.app) : w.title, icon: w.icon, pinned: false, wins: [] }; groups.push(g); byKey.set(key, g); }
    if (!g.icon && w.icon) g.icon = w.icon;
    g.wins.push(w);
  }
  return groups;
}
const PEEK = { key: null, timer: 0, hideT: 0, thumbs: new Map(), anchor: null };
function renderSwitcher() {
  const box = $('#switcher');
  box.hidden = false;
  const inRow = placeSwitcher();
  $('#sysbtns').hidden = false;
  box.replaceChildren();
  if (WINS.ok === false) {
    box.append(el('span', { class: 'sw-msg', text: 'Ventanas abiertas no disponibles en esta compu', title: WINS.err || '' }));
    return;
  }
  const groups = winGroups();
  if (!groups.length) { box.append(el('span', { class: 'sw-msg', text: 'No hay otras ventanas abiertas' })); return; }
  const compact = groups.length > (inRow ? 16 : 7);
  box.classList.toggle('compact', compact);
  for (const g of groups) {
    const n = g.wins.length, w0 = g.wins[0];
    const icon = g.icon ? el('img', { src: g.icon, alt: '' }) : el('span', { class: 'sw-letter', text: letterFor(g.name) });
    const label = n === 1 ? w0.title : g.name;
    const allMin = n > 0 && g.wins.every(w => w.min);
    const tip = n === 0 ? `${g.name} (fijado, cerrado)\nClic: abrir · Clic derecho: más opciones`
      : n === 1 ? w0.title + (w0.min ? ' (minimizada)' : '') + '\nClic: ir · Clic derecho: más opciones · Rueda: cerrar'
      : `${g.name}: ${n} ventanas\nClic: elegir cuál · Clic derecho: más opciones`;
    const b = el('button', { class: 'sw' + (allMin ? ' min' : '') + (n === 0 ? ' closed' : '') + (g.pinned ? ' pinned' : '') + (g.wins.some(w => w.fg) ? ' fg' : ''), 'data-key': g.key },
      icon, (compact || n === 0) ? null : el('span', { class: 'sw-t', text: label }), n > 1 ? el('span', { class: 'sw-n', text: String(n) }) : null);
    b.setAttribute('aria-label', tip.split('\n')[0]);
    b.onclick = () => {
      hidePeek(true);
      if (n === 0) { launchPin(g); return; }
      if (n === 1) { winAct('focus', w0); return; }
      showPeek(g, b, true);
    };
    b.addEventListener('contextmenu', (e) => { e.preventDefault(); hidePeek(true); openWinMenu(n === 1 ? w0 : null, b, g); });
    b.addEventListener('auxclick', (e) => { if (e.button === 1 && n === 1) { e.preventDefault(); winAct('close', w0); } });
    b.addEventListener('pointerenter', () => { clearTimeout(PEEK.hideT); clearTimeout(PEEK.timer); if (n === 0) { b.title = tip; return; } b.removeAttribute('title'); PEEK.timer = setTimeout(() => showPeek(g, b), PEEK.key ? 60 : 450); });
    b.addEventListener('pointerleave', () => { clearTimeout(PEEK.timer); PEEK.hideT = setTimeout(() => hidePeek(), 260); });
    box.append(b);
  }
  // Si la vista previa estaba abierta, la actualiza con las ventanas nuevas
  if (PEEK.key) { const g = groups.find(x => x.key === PEEK.key); const b = box.querySelector(`.sw[data-key="${CSS.escape(PEEK.key)}"]`); if (g && g.wins.length && b) showPeek(g, b, PEEK.sticky); else hidePeek(true); }
}
async function launchPin(g) {
  const r = await safeCall(() => api.open({ type: 'app', name: g.name, target: g.exe }));
  if (typeof r === 'string' && r) toast(`No se pudo abrir ${g.name}: ${r}`);
  setTimeout(loadWindows, 1500);
}
function peekBox() {
  let p = $('#win-peek');
  if (!p) {
    p = el('div', { id: 'win-peek', class: 'win-peek', hidden: true });
    p.addEventListener('pointerenter', () => clearTimeout(PEEK.hideT));
    p.addEventListener('pointerleave', () => { if (!PEEK.sticky) PEEK.hideT = setTimeout(() => hidePeek(), 260); });
    document.body.append(p);
    document.addEventListener('pointerdown', (e) => { if (PEEK.key && !e.target.closest('#win-peek, #switcher .sw')) hidePeek(true); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hidePeek(true); });
  }
  return p;
}
function hidePeek(force) { clearTimeout(PEEK.timer); if (PEEK.sticky && !force) return; const p = $('#win-peek'); if (p) p.hidden = true; PEEK.key = null; PEEK.sticky = false; }
async function peekThumb(w) {
  const c = PEEK.thumbs.get(w.h);
  if (c && Date.now() - c.t < 4000) return c.src;
  if (w.min || !api.windows.thumb) return null;
  const src = await safeCall(() => api.windows.thumb(w.h));
  PEEK.thumbs.set(w.h, { t: Date.now(), src: src || null });
  if (PEEK.thumbs.size > 60) PEEK.thumbs.delete(PEEK.thumbs.keys().next().value);
  return src || null;
}
function showPeek(g, anchor, sticky) {
  const p = peekBox();
  PEEK.key = g.key; PEEK.sticky = !!sticky || PEEK.sticky && PEEK.key === g.key;
  const cards = g.wins.slice(0, 8).map(w => {
    const ph = el('div', { class: 'wp-img' });
    const cached = PEEK.thumbs.get(w.h);
    const paint = (src) => ph.replaceChildren(src ? el('img', { src, alt: '' }) : (g.icon ? el('img', { class: 'wp-ico', src: g.icon, alt: '' }) : el('span', { class: 'sw-letter', text: letterFor(g.name) })), w.min ? el('span', { class: 'wp-min', text: 'Minimizada' }) : null);
    paint(cached && cached.src);
    peekThumb(w).then(src => { if (ph.isConnected) paint(src); });
    const x = el('span', { class: 'wp-x', role: 'button', title: 'Cerrar esta ventana' }); x.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>';
    x.onclick = (e) => { e.stopPropagation(); winAct('close', w); };
    const card = el('button', { class: 'wp-card' + (w.fg ? ' fg' : '') }, el('div', { class: 'wp-head' }, g.icon ? el('img', { src: g.icon, alt: '' }) : null, el('span', { text: w.title || g.name }), x), ph);
    card.onclick = () => { hidePeek(true); winAct('focus', w); };
    card.addEventListener('contextmenu', (e) => { e.preventDefault(); hidePeek(true); openWinMenu(w, anchor, g); });
    return card;
  });
  if (g.wins.length > 8) cards.push(el('div', { class: 'wp-more', text: `y ${g.wins.length - 8} más` }));
  p.replaceChildren(...cards);
  p.hidden = false;
  const r = anchor.getBoundingClientRect(), pw = p.offsetWidth, phh = p.offsetHeight;
  let left = r.left + r.width / 2 - pw / 2; left = Math.max(10, Math.min(left, innerWidth - pw - 10));
  let top = r.bottom + 8; if (top + phh > innerHeight - 10) top = Math.max(10, r.top - phh - 8);
  p.style.left = left + 'px'; p.style.top = top + 'px';
}
async function winAct(action, w) {
  closeWinMenu();
  const r = await safeCall(() => api.windows.act(action, w.h));
  if (!r || !r.ok) toast('Windows no permitió hacer eso con esa ventana');
  setTimeout(loadWindows, action === 'close' ? 700 : 300);
}
function openWinMenu(w, anchor, g) {
  const m = $('#win-ctx');
  const item = (label, action) => { const b = el('button', { role: 'menuitem', text: label }); b.onclick = () => winAct(action, w); return b; };
  const fn = (label, f, cls) => { const b = el('button', { role: 'menuitem', text: label }); if (cls) b.className = cls; b.onclick = () => { closeWinMenu(); f(); }; return b; };
  const parts = [el('div', { class: 'ctx-title', text: w ? w.title : (g ? g.name : '') })];
  if (w) {
    parts.push(item(w.min ? 'Restaurar' : 'Traer al frente', 'focus'));
    if (!w.min) parts.push(item('Minimizar', 'minimize'));
    parts.push(item(w.max ? 'Restaurar tamaño' : 'Maximizar', 'max'));
  } else if (g && g.wins.length) {
    parts.push(fn('Ver sus ventanas', () => showPeek(g, anchor, true)));
    parts.push(fn('Minimizar todas', () => g.wins.forEach(x => !x.min && winAct('minimize', x))));
  }
  if (g && g.exe && !noGroup(g.exe)) {
    if (g.wins.length) parts.push(fn('Abrir otra ventana', () => launchPin(g)));
    else parts.push(fn(`Abrir ${g.name}`, () => launchPin(g)));
    parts.push(fn(g.pinned || isPinned(g.exe) ? 'Quitar de la barra' : 'Fijar en la barra', () => togglePin(g)));
  }
  if (w) { parts.push(el('hr')); parts.push(Object.assign(item('Cerrar', 'close'), { className: 'danger' })); }
  else if (g && g.wins.length > 1) { parts.push(el('hr')); parts.push(fn(`Cerrar las ${g.wins.length} ventanas`, () => g.wins.forEach(x => winAct('close', x)), 'danger')); }
  m.replaceChildren(...parts);
  m.hidden = false;
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.max(8, Math.min(r.left, window.innerWidth - m.offsetWidth - 12)) + 'px';
  const top = r.bottom + 6; m.style.top = (top + m.offsetHeight > innerHeight - 8 ? Math.max(8, r.top - m.offsetHeight - 6) : top) + 'px';
  m.querySelector('button').focus();
}
function closeWinMenu() { const m = $('#win-ctx'); if (m) m.hidden = true; }
function setupWindows() {
  if (!api.windows) return; // en el navegador de prueba no hay ventanas de Windows
  $$('#sysbtns [data-sys]').forEach(b => b.onclick = async () => {
    const r = await safeCall(() => api.windows.system(b.dataset.sys));
    if (!r || !r.ok) toast('Windows no permitió esa acción en esta compu');
    if (b.dataset.sys === 'minimizeAll') setTimeout(loadWindows, 500);
  });
  document.addEventListener('pointerdown', (e) => { if (!e.target.closest('#win-ctx')) closeWinMenu(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeWinMenu(); });
  loadWindows();
  setInterval(() => { if (!document.hidden) loadWindows(); }, 2000);
  window.addEventListener('focus', loadWindows);
}

// ---------- Accesos de Windows: barra de tareas y escritorio ----------
async function loadTaskbar() {
  let data;
  if (api.systemShortcuts) data = await api.systemShortcuts();
  else if (api.taskbar) data = { taskbar: await api.taskbar(), desktop: [] };
  else return;
  data = data || {};
  const sig = JSON.stringify(['taskbar', 'desktop'].map(k => (data[k] || []).map(x => x.target)));
  if (sig === ui.sysSig) return;
  ui.sysSig = sig;
  ui.sys = { taskbar: data.taskbar || [], desktop: data.desktop || [] };
  renderLaunch();
}
function refreshOnline(force) {
  loadMail(force);
  loadGcal(force);
  loadWeather(force);
  if (widgetOn('f1') || force) loadTopicData(force);
}

// ---------- Personalizar: reloj ----------
function setClock(patch) {
  const t = M().theme;
  t.clock = Object.assign(clockCfg(), patch);
  save();
  renderClock(true);
  renderClockSettings();
}
function renderClockSettings() {
  const cfg = clockCfg();
  const grid = $('#clock-models');
  grid.replaceChildren();
  const sample = new Date(); sample.setHours(10, 8, 42);
  for (const st of CLOCK_STYLES) {
    const prev = el('span', { class: 'cm-prev' });
    const mini = el('span', {});
    buildClock(mini, sample, { ...cfg, style: st.id, size: 'm' });
    mini.classList.add('mini');
    prev.append(mini);
    const b = el('button', { class: 'cm' + (cfg.style === st.id ? ' on' : ''), 'aria-pressed': String(cfg.style === st.id), 'aria-label': 'Reloj ' + st.n },
      prev, el('span', { class: 'lbl', text: st.n }));
    b.onclick = () => setClock({ style: st.id });
    grid.append(b);
  }
  for (const b of $$('#clock-size button')) b.classList.toggle('on', b.dataset.size === cfg.size);
  $('#clk-seconds').checked = !!cfg.seconds;
  $('#clk-12').checked = !!cfg.h12;
  $('#clk-accent').checked = !!cfg.accent;
  $('#clk-12-row').hidden = cfg.style === 'analogico' || cfg.style === 'palabras';
  $('#clk-seconds-row').hidden = cfg.style === 'palabras';
}

// ---------- Personalizar ----------
function openDrawer(on) {
  $('#drawer').classList.toggle('on', on);
  $('#drawer').setAttribute('aria-hidden', String(!on));
  $('#scrim').classList.toggle('on', on);
  if (on) { renderDrawer(); $('#drawer-close').focus(); }
}
function renderDrawer() {
  const t = M().theme;
  renderModeTabs();
  const sw = $('#accent-swatches');
  sw.replaceChildren();
  for (const a of ACCENTS) {
    const b = el('button', { class: 'swatch' + (a.c.toLowerCase() === t.accent.toLowerCase() ? ' on' : ''), style: `--c:${a.c}`, title: a.n, 'aria-label': a.n });
    b.onclick = () => { t.accent = a.c; commitTheme(); };
    sw.append(b);
  }
  $('#accent-custom').value = t.accent;
  const g = $('#bg-presets');
  g.replaceChildren();
  for (const p of BACKGROUNDS) {
    const on = t.bg.kind === 'preset' && t.bg.value === p.id;
    const b = el('button', { class: 'bg-opt' + (on ? ' on' : ''), 'aria-label': `Fondo ${p.n}` },
      el('span', { class: 'prev', style: `--p:${p[t.scheme]}` }), el('span', { class: 'lbl', text: p.n }));
    b.onclick = () => { t.bg = { kind: 'preset', value: p.id }; commitTheme(); };
    g.append(b);
  }
  for (const [kind, label, prev] of [['auto', 'Según el momento', AUTO_BG[autoBgKey()][t.scheme]], ['bing', 'Foto del día', (S.cache.bing && S.cache.bing.data) ? `url("${S.cache.bing.data.url}")` : AUTO_BG.day[t.scheme]]]) {
    const b = el('button', { class: 'bg-opt' + (t.bg.kind === kind ? ' on' : ''), 'aria-label': `Fondo ${label}`, title: kind === 'auto' ? 'Cambia solo según la hora y el clima' : ((S.cache.bing && S.cache.bing.data && S.cache.bing.data.credit) || 'Una foto distinta cada día (de Bing)') },
      el('span', { class: 'prev', style: `--p:${prev}` }), el('span', { class: 'lbl', text: label }));
    b.onclick = async () => {
      t.bg = { kind, value: '' };
      if (kind === 'bing') { await loadBing(false); if (t.glass < 30) t.glass = 40; }
      commitTheme();
    };
    g.append(b);
  }
  if (t.bg.kind === 'image') {
    const b = el('button', { class: 'bg-opt on', 'aria-label': 'Tu imagen' },
      el('span', { class: 'prev', style: `--p:url("${t.bg.value}")` }), el('span', { class: 'lbl', text: 'Tu imagen' }));
    g.append(b);
  }
  $('#glass').value = t.glass;
  $('#veil').value = t.veil == null ? 'auto' : String(t.veil);
  renderCursorPicker();
  $('#user-name').value = S.settings.name || '';
  $('#set-startup').checked = !!S.settings.startWithWindows;
  $('#set-fullscreen').checked = !!S.settings.fullscreen;
  $('#set-deskmode').checked = !!S.settings.deskMode;
  $('#set-autoupd').value = S.settings.autoUpdate === 'off' ? 'off' : 'ask';
  $('#set-hidetaskbar').checked = !!S.settings.hideTaskbar;
  $('#set-wxanim').checked = S.settings.wxAnim !== false;
  $('#set-wxstyle').value = S.settings.wxStyle || 'clasica';
  $('#set-brief').checked = S.settings.brief !== false;
  $('#set-notif').value = S.settings.notifStyle || 'float';
  $('#set-floatbr').value = S.settings.floatBrowser || '';
  if (api.browsers && !ui.brChecked) { ui.brChecked = true; api.browsers().then(list => { for (const o of $$('#set-floatbr option')) if (o.value) { o.disabled = !(list || []).includes(o.value); if (o.disabled) o.textContent = o.textContent.replace(/ \(no instalado\)$/, '') + ' (no instalado)'; } }); }
  $('#set-daily').value = S.settings.daily || 'both';
  $('#set-searchkey').value = S.settings.searchHotkey ?? 'Control+Shift+Space';
  $('#set-hotkey').value = S.settings.hotkey ?? 'Control+Alt+Space';
  $('#set-startmode').value = S.settings.startMode || 'last';
  renderAccounts();
  renderClockSettings();
  renderNotifSettings();
  renderZonePick();
  $('#set-winbar').value = S.settings.winBar || 'auto';
  $('#set-baseshell').checked = S.settings.baseShell !== false;
  if (api.displays) api.displays().then(list => {
    const sel = $('#set-display');
    if (!sel || !list) return;
    sel.replaceChildren(el('option', { value: '', text: 'La pantalla principal' }), ...list.map(d => el('option', { value: d.id, text: `Pantalla ${d.n} · ${d.w}×${d.h}${d.internal ? ' (la de la notebook)' : ''}${d.primary ? ' · principal' : ''}${d.current ? ' · acá está Base' : ''}` })));
    sel.value = S.settings.display && list.some(d => d.id === S.settings.display) ? S.settings.display : '';
  });
  $('#btn-quit').style.display = window.baseApi ? '' : 'none';
}
function showDrawerSec(sec) {
  ui.dsec = sec;
  for (const b of $$('#dnav button')) b.classList.toggle('on', b.dataset.sec === sec);
  for (const x of $$('#dpanes .dsec')) x.classList.toggle('on', x.dataset.sec === sec);
  $('#dpanes').scrollTop = 0;
}
const NF_LOOKS = [
  { id: 'tarjeta', n: 'Tarjeta (la de siempre)' }, { id: 'compacta', n: 'Compacta' }, { id: 'burbuja', n: 'Burbuja' },
  { id: 'color', n: 'De color' }, { id: 'vidrio', n: 'Vidrio' }, { id: 'linea', n: 'Línea' }, { id: 'neon', n: 'Neón' }
];
function nfSample(look) {
  const dark = M().theme.scheme === 'dark';
  return el('div', { class: `nf l-${look}${dark ? ' dark' : ''}`, style: '--c:#3a86d6' },
    el('span', { class: 'ico' }, svg('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>')),
    el('span', { class: 'tx' }, el('span', { class: 'app', text: 'Agenda' }), el('span', { class: 't', text: 'Turno médico en 30 min' }), el('span', { class: 'b', text: 'Hoy 18:30 · Clínica' })),
    el('span', { class: 'x', text: '×' }), el('span', { class: 'bar' }));
}
function renderNotifSettings() {
  const st = S.settings;
  $('#set-notiflife').value = String(st.notifLife || 8);
  $('#set-notifsound').value = st.notifSound || 'none';
  $('.dsec[data-sec="avisos"]').classList.toggle('win-only', (st.notifStyle || 'float') === 'windows');
  for (const b of $$('#nf-pos button')) b.classList.toggle('on', b.dataset.pos === (st.notifPos || 'br'));
  const cur = st.notifLook || 'tarjeta';
  $('#nf-looks').replaceChildren(...NF_LOOKS.map(l => {
    const b = el('button', { type: 'button', class: 'nf-look' + (l.id === cur ? ' on' : ''), 'aria-pressed': String(l.id === cur) }, el('span', { text: l.n }), nfSample(l.id));
    b.onclick = () => { st.notifLook = l.id; save(); renderNotifSettings(); testNotif(); };
    return b;
  }));
}
function testNotif() { showNotif({ id: 'test', kind: 'agenda', title: 'Así se ven los avisos', body: 'Tocalo para ir a Base. Se van solos en unos segundos.' }); }
function renderZonePick() {
  const box = $('#zone-pick');
  if (!box) return;
  const mods = zoneMods();
  box.replaceChildren(...ZONE_MODS.map(z => {
    const on = mods.includes(z.id);
    const b = el('button', { type: 'button', class: 'zp-opt' + (on ? ' on' : ''), 'aria-pressed': String(on) }, svg(z.ico), el('span', {}, el('b', { text: z.n }), el('small', { text: z.d })), el('i', { text: on ? '✓' : '+' }));
    b.onclick = () => {
      const cur = zoneMods().slice();
      const i = cur.indexOf(z.id);
      if (i >= 0) cur.splice(i, 1);
      else if (cur.length >= ZONE_MAX) return toast(`Entran hasta ${ZONE_MAX}. Sacá uno para sumar “${z.n}”.`);
      else cur.push(z.id);
      M().zone = cur; save(); renderZonePick(); renderZone();
    };
    return b;
  }));
}
function commitTheme() { applyTheme(); save(); renderDrawer(); }
// ---------- Actualizaciones ----------
const UPDU = { ver: '', skipped: '' };
function showUpdate(d) {
  if (!d || !d.version) return;
  try { if (localStorage.getItem('base-upd-skip') === d.version) return; } catch {}
  UPDU.ver = d.version;
  $('#upd-tx').textContent = 'Hay una versión nueva de Base (' + d.version + ')';
  $('#upd-go').disabled = false; $('#upd-go').hidden = false; $('#upd-later').hidden = false;
  $('#updbar').hidden = false;
}
function setupUpdates() {
  if (!api.update) return;
  api.update.onAvailable(d => { if (S.settings.autoUpdate !== 'off') showUpdate(d); });
  api.update.onProgress(p => {
    const bar = $('#updbar'); bar.hidden = false;
    $('#upd-go').hidden = true; $('#upd-later').hidden = p.step !== 'error';
    $('#upd-tx').textContent = p.step === 'descargando' ? `Descargando la versión nueva… ${p.pct || 0}%`
      : p.step === 'preparando' ? 'Preparando la actualización…'
      : p.step === 'reiniciando' ? 'Listo. Base se reinicia en un segundo…'
      : 'No se pudo actualizar: ' + (p.error || 'error desconocido');
  });
  $('#upd-go').onclick = async () => {
    $('#upd-go').disabled = true; $('#upd-tx').textContent = 'Empezando…';
    const r = await api.update.install();
    if (r && !r.ok) { $('#upd-tx').textContent = 'No se pudo actualizar: ' + (r.error || ''); $('#upd-go').disabled = false; $('#upd-go').hidden = false; $('#upd-later').hidden = false; }
  };
  $('#upd-later').onclick = () => { $('#updbar').hidden = true; try { localStorage.setItem('base-upd-skip', UPDU.ver); } catch {} };
  $('#set-autoupd').onchange = (e) => { S.settings.autoUpdate = e.target.value; save(); };
  $('#upd-check').onclick = async () => {
    const b = $('#upd-check'); b.disabled = true; $('#upd-ver').textContent = 'Buscando…';
    const r = await api.update.check();
    b.disabled = false;
    if (!r || !r.ok) $('#upd-ver').textContent = 'No pude fijarme ahora (' + ((r && r.error) || 'sin conexión') + ').';
    else if (r.newer) { $('#upd-ver').textContent = 'Tenés la ' + r.current + ' · hay una nueva: ' + r.version; try { localStorage.removeItem('base-upd-skip'); } catch {} showUpdate({ version: r.version }); }
    else $('#upd-ver').textContent = 'Tenés la versión ' + r.current + ', que es la última.';
  };
  api.update.info().then(i => {
    if (!i) return;
    $('#upd-ver').textContent = 'Versión ' + i.current;
    if (i.updated) toast('Base se actualizó a la versión ' + i.current);
  });
}
function deskPeek() { if (api.deskPeek) api.deskPeek(); else api.minimize(); }
function applyDeskUi() {
  document.body.classList.toggle('deskmode', !!S.settings.deskMode);
  const b = $('#btn-min'); if (b) b.hidden = !!S.settings.deskMode;
}
async function commitSettings() {
  save();
  const r = await api.applySettings(S.settings);
  const msg = $('#hotkey-msg');
  if (S.settings.hotkey && r && r.hotkeyOk === false) msg.textContent = 'Ese atajo lo está usando otro programa. Probá con otro.';
  else msg.textContent = S.settings.hotkey ? 'Funciona desde cualquier programa, aunque Base esté escondido.' : '';
  if (r && S.settings.searchHotkey && r.searchHotkeyOk === false) toast('El atajo del buscador lo usa otro programa o es igual al de mostrar Base. Elegí otro.');
}

// ---------- Juegos: Steam y Xbox / Game Pass ----------
const STEAM_IMG = (id, kind) => [
  `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/${id}/${kind}.jpg`,
  `https://cdn.akamai.steamstatic.com/steam/apps/${id}/${kind}.jpg`,
  `https://cdn.cloudflare.steamstatic.com/steam/apps/${id}/${kind}.jpg`
];
// encabezado oficial de la tienda de Steam (las rutas nuevas llevan un código que solo da la tienda)
async function steamStoreHeader(id) {
  const key = 'steamhdr:' + id;
  const c = S.cache[key];
  if (c && Date.now() - c.at < 14 * 864e5) return c.data;
  const r = await safeCall(() => api.get(`https://store.steampowered.com/api/appdetails?appids=${id}&filters=basic&l=spanish`));
  let url = '';
  try { const d = JSON.parse(r.text)[id]; url = (d && d.success && d.data && d.data.header_image) || ''; } catch {}
  if (!/^https:\/\//.test(url)) url = '';
  S.cache[key] = { at: Date.now(), data: url };
  save();
  return url;
}
// bibliotecas de juegos que reconoce Base
const LIBS = {
  steam: { n: 'Steam', c: '#2a6f9e', d: 'store.steampowered.com' },
  xbox: { n: 'Xbox', c: '#107c10', d: 'xbox.com' },
  epic: { n: 'Epic Games', c: '#2b2b2b', d: 'epicgames.com' },
  ea: { n: 'EA', c: '#ff4747', d: 'ea.com' },
  rockstar: { n: 'Rockstar', c: '#fcaf17', d: 'rockstargames.com' },
  ubisoft: { n: 'Ubisoft', c: '#7b3fe4', d: 'ubisoft.com' },
  gog: { n: 'GOG', c: '#a33fc4', d: 'gog.com' },
  battlenet: { n: 'Battle.net', c: '#148eff', d: 'battle.net' }
};
const libName = (src) => (LIBS[src] || { n: src }).n;
// portada para juegos de otras tiendas: la buscamos en Steam por el nombre (muchos también están ahí)
async function steamIdByName(name) {
  const key = 'steamid:' + name.toLowerCase();
  const c = S.cache[key];
  if (c && Date.now() - c.at < 30 * 864e5) return c.data;
  const r = await safeCall(() => api.get(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(name)}&l=spanish&cc=AR`));
  let id = 0;
  try {
    const items = JSON.parse(r.text).items || [];
    const norm = (t) => t.toLowerCase().normalize('NFD').replace(/[^a-z0-9]/g, '');
    const want = norm(name);
    const hit = items.find(i => norm(i.name) === want) || items.find(i => norm(i.name).startsWith(want) || want.startsWith(norm(i.name)));
    id = hit ? hit.id : 0;
  } catch {}
  if (r && r.ok) { S.cache[key] = { at: Date.now(), data: id }; save(); }
  return id;
}
// banner de "Seguir jugando": arte ancho del juego, con el fondo de la portada difuminada
function gameBanner(x) {
  const box = el('span', { class: 'g-banner' });
  const blur = x.local || (x.src === 'steam' ? STEAM_IMG(x.id, 'library_600x900')[0] : '');
  if (blur) {
    const b = el('img', { class: 'g-blur', alt: '', draggable: 'false', src: blur });
    b.onerror = () => { if (x.src === 'steam' && !b.dataset.alt) { b.dataset.alt = 1; b.src = STEAM_IMG(x.id, 'header')[0]; } else b.remove(); };
    box.append(b);
  }
  const showArt = () => {
    box.classList.add('no-art');
    if (x.local) box.append(el('img', { class: 'g-box', alt: '', draggable: 'false', src: x.local }));
  };
  if (x.src !== 'steam' && x.src !== 'xbox') {
    steamIdByName(x.name).then(id => {
      if (!id) { if (x.icon) box.append(el('img', { class: 'g-box ico', alt: '', src: x.icon })); return; }
      const im = imgChain([...STEAM_IMG(id, 'library_hero'), ...STEAM_IMG(id, 'header')], () => {});
      im.classList.add('g-art'); box.append(im);
    });
    return box;
  }
  if (x.src !== 'steam') { showArt(); return box; }
  const first = [x.localHero, ...STEAM_IMG(x.id, 'library_hero'), x.localHeader].filter(Boolean);
  const img = imgChain(first, async () => {
    const url = await steamStoreHeader(x.id);
    const rest = [url, ...STEAM_IMG(x.id, 'header')].filter(Boolean);
    const img2 = imgChain(rest, showArt);
    img2.classList.add('g-art');
    box.append(img2);
  });
  img.classList.add('g-art');
  box.append(img);
  return box;
}
// imagen con varias fuentes de respaldo; si ninguna carga, usa el plan B
function imgChain(urls, fallback) {
  const list = urls.filter(Boolean);
  const img = el('img', { alt: '', loading: 'lazy', draggable: 'false' });
  let i = 0;
  const next = () => { if (i < list.length) img.src = list[i++]; else { img.remove(); fallback && fallback(); } };
  img.onerror = next;
  next();
  return img;
}
function gameList() {
  const g = ui.games || S.cache.games || {};
  const casa = S.modes.casa;
  const plays = casa.gamePlays || {};
  const all = [...((g.steam && g.steam.games) || []), ...((g.xbox && g.xbox.games) || []), ...((g.others && g.others.games) || [])];
  return all.map(x => ({ ...x, key: x.src + ':' + (x.id || x.name), last: Math.max(plays[x.src + ':' + (x.id || x.name)] || 0, x.lastPlayed || 0) }))
    .sort((a, b) => (b.last - a.last) || a.name.localeCompare(b.name, 'es'));
}
function playedText(min) {
  if (!min) return '';
  if (min < 60) return `${min} min jugados`;
  const h = min / 60;
  return `${h < 10 ? h.toLocaleString('es-AR', { maximumFractionDigits: 1 }) : Math.round(h).toLocaleString('es-AR')} h jugadas`;
}
function lastText(ts, min) { return ts ? `Última vez ${ago(ts)}` : min ? '' : 'Sin jugar todavía'; }
async function loadGames(force) {
  if (!api.games) return;
  if (!force && ui.gamesAt && Date.now() - ui.gamesAt < 10 * 60000) return;
  ui.gamesAt = Date.now();
  const r = await safeCall(() => api.games());
  if (r && (r.steam || r.xbox || r.others)) {
    ui.games = r;
    S.cache.games = r;
    save();
    renderGames();
  }
}
function gameCover(x, wide) {
  const box = el('span', { class: 'g-cover ' + x.src + '-c' + (wide ? ' wide' : '') });
  const letter = () => box.append(el('span', { class: 'g-letter', text: x.name }));
  if (x.src === 'steam') {
    const urls = wide
      ? [x.localHero, ...STEAM_IMG(x.id, 'library_hero'), x.localHeader, ...STEAM_IMG(x.id, 'header'), x.local]
      : [x.local, ...STEAM_IMG(x.id, 'library_600x900'), x.localHeader, ...STEAM_IMG(x.id, 'header')];
    box.append(imgChain(urls, letter));
  } else if (x.local) box.append(imgChain([x.local], letter));
  else if (LIBS[x.src] && x.src !== 'xbox') {
    // otras tiendas: ícono del juego sobre el color de la tienda, y si está en Steam, su portada
    box.style.setProperty('--lc', LIBS[x.src].c);
    box.classList.add('lib-c');
    box.append(x.icon ? el('img', { class: 'g-ico', alt: '', src: x.icon }) : null, el('span', { class: 'g-letter sm', text: x.name }));
    steamIdByName(x.name).then(id => {
      if (!id) return;
      const im = imgChain(wide ? [...STEAM_IMG(id, 'library_hero'), ...STEAM_IMG(id, 'header')] : [...STEAM_IMG(id, 'library_600x900'), ...STEAM_IMG(id, 'header')], () => {});
      im.classList.add('g-steamart');
      box.append(im);
    });
  } else letter();
  return box;
}
async function playGame(x) {
  let r;
  if (x.src === 'steam') r = await api.launchSpecial('steam', x.id);
  else if (x.src === 'epic' && x.id) r = await api.launchSpecial('epic', x.id);
  else if (x.src === 'ubisoft' && x.id && !x.exe) r = await api.launchSpecial('uplay', x.id);
  else if (x.exe) r = await api.launchSpecial('exe', x.exe);
  else if (x.src !== 'xbox') { r = await api.launchSpecial('store', x.src); }
  else if (x.id) r = await api.launchSpecial('aumid', x.id);
  else { r = await api.launchSpecial('xbox-app'); toast(`Abrí la app de Xbox: ${x.name} se inicia desde ahí`); }
  if (r) return toast(`No se pudo abrir ${x.name}. ${r}`);
  const casa = S.modes.casa;
  casa.gamePlays = casa.gamePlays || {};
  casa.gamePlays[x.key] = Date.now();
  save(); renderGames();
  toast(`Abriendo ${x.name}…`);
}
function renderGames() {
  if (S && stageKind() === 'juegos') refreshGamesStage();
  if (!widgetOn('games')) return;
  const all = gameList();
  const f = ui.gameFilter || 'all';
  const fb = $('#games-filter');
  const present = ['all', ...Object.keys(LIBS).filter(k => all.some(x => x.src === k))];
  if (fb.dataset.k !== present.join()) {
    fb.dataset.k = present.join();
    fb.replaceChildren(...present.map(k => { const b = el('button', { 'data-f': k, class: k, text: k === 'all' ? 'Todos' : libName(k) }); b.onclick = () => { ui.gameFilter = k; renderGames(); }; return b; }));
  }
  for (const b of $$('#games-filter button')) b.classList.toggle('on', b.dataset.f === f);
  const order = S.settings.gameSort || 'recent';
  for (const b of $$('#games-sort button')) b.classList.toggle('on', b.dataset.s === order);
  const list = all.filter(x => f === 'all' || x.src === f);
  if (order === 'played') list.sort((a, b) => (b.minutes || 0) - (a.minutes || 0) || b.last - a.last);
  else if (order === 'az') list.sort((a, b) => a.name.localeCompare(b.name, 'es'));
  const hero = $('#game-hero');
  const grid = $('#game-grid');
  hero.replaceChildren(); grid.replaceChildren();
  const g = ui.games || S.cache.games;
  if (!g) { grid.append(el('li', { class: 'empty', text: 'Buscando tus juegos…' })); return; }
  if (!list.length) {
    grid.append(el('li', { class: 'empty' }, f === 'xbox'
      ? 'No encontré juegos de Xbox instalados. Los de Game Pass se instalan desde la app de Xbox (carpeta XboxGames).'
      : f === 'steam' ? 'No encontré juegos de Steam instalados en esta compu.'
      : 'No encontré juegos instalados de Steam ni de Xbox en esta compu.'));
    return;
  }
  const top = all.filter(x => f === 'all' || x.src === f).sort((a, b) => b.last - a.last)[0];
  if (top && top.last) {
    const play = el('button', { class: 'btn', text: 'Jugar' });
    play.onclick = (e) => { e.stopPropagation(); playGame(top); };
    const card = el('div', { class: 'g-hero-card ' + top.src, title: `Jugar a ${top.name}` },
      gameBanner(top),
      el('div', { class: 'g-hero-info' },
        el('span', { class: 'g-hero-k', text: 'Seguir jugando' }),
        el('span', { class: 'g-hero-n', text: top.name }),
        el('span', { class: 'g-hero-s', text: [libName(top.src), playedText(top.minutes), top.last ? `última vez ${ago(top.last)}` : ''].filter(Boolean).join(' · ') })),
      play);
    card.onclick = () => playGame(top);
    hero.append(card);
  }
  for (const x of list) {
    const b = el('button', { class: 'g-tile', title: `Jugar a ${x.name}` },
      gameCover(x, false),
      el('span', { class: 'g-name', text: x.name }),
      el('span', { class: 'g-src ' + x.src, text: [libName(x.src), playedText(x.minutes)].filter(Boolean).join(' · ') }),
      el('span', { class: 'g-last' + (x.last ? '' : ' never'), text: lastText(x.last, x.minutes) }));
    b.onclick = () => playGame(x);
    grid.append(el('li', {}, b));
  }
}

// ---------- Sala de juegos (pantalla completa) ----------
const AR = { view: 'home', game: null, inst: {}, filter: 'all', q: '' };
const MINI = () => (window.BaseMini ? window.BaseMini.GAMES : []);
function miniStats(id) { S.settings.mini = S.settings.mini || {}; return S.settings.mini[id] = S.settings.mini[id] || {}; }
function openArcade(view = 'home', game = null) {
  closeWidget(true);
  if (ui.searchOpen && typeof closeSearch === 'function') closeSearch();
  $('#arcade').hidden = false;
  document.documentElement.classList.add('in-arcade');
  loadGames(false);
  arShow(view, game);
  arClock();
  clearInterval(AR.clockT); AR.clockT = setInterval(arClock, 15000);
}
function closeArcade() {
  if (AR.view === 'game' && AR.inst[AR.game] && AR.inst[AR.game].hide) AR.inst[AR.game].hide();
  $('#arcade').hidden = true;
  document.documentElement.classList.remove('in-arcade');
  clearInterval(AR.clockT);
  renderPeeks();
}
function arClock() { const d = new Date(); setText('ar-clock', `${pad(d.getHours())}:${pad(d.getMinutes())}`); }
function arShow(view, game) {
  if (AR.view === 'game' && AR.game && AR.inst[AR.game] && AR.inst[AR.game].hide && !(view === 'game' && game === AR.game)) AR.inst[AR.game].hide();
  AR.view = view; AR.game = game;
  for (const b of $$('#ar-tabs button')) b.classList.toggle('on', b.dataset.t === (view === 'game' ? 'mini' : view));
  setText('ar-back-l', view === 'game' ? 'Mini juegos' : 'Escritorio');
  const body = $('#ar-body');
  body.className = 'ar-body v-' + view;
  body.scrollTop = 0;
  if (view === 'home') arHome(body);
  else if (view === 'lib') arLib(body);
  else if (view === 'mini') arMini(body);
  else if (view === 'store') arStore(body);
  else if (view === 'game') arGame(body, game);
  arBackdrop();
}
function arBackdrop() {
  const bg = $('#ar-bg');
  const top = gameList().find(x => x.last);
  const g = AR.view === 'game' ? MINI().find(x => x.id === AR.game) : null;
  bg.style.setProperty('--gc', g ? g.c : top && LIBS[top.src] ? LIBS[top.src].c : '#2a475e');
  const img = !g && top ? (top.localHero || top.local || (top.src === 'steam' ? STEAM_IMG(top.id, 'library_hero')[0] : '')) : '';
  bg.style.setProperty('--img', img ? `url("${img.replace(/"/g, '%22')}")` : 'none');
  bg.classList.toggle('has-img', !!img);
}
function arSection(title, extra) { return el('div', { class: 'ar-sec' }, el('h2', { text: title }), extra || null); }
function miniCard(g, big) {
  const s = miniStats(g.id);
  const art = el('span', { class: 'mc-art' }); art.innerHTML = g.art;
  const b = el('button', { class: 'mini-card' + (big ? ' big' : ''), style: `--gc:${g.c}`, title: `Jugar ${g.n}` },
    art,
    el('span', { class: 'mc-txt' }, el('b', { text: g.n }), big ? el('span', { class: 'mc-d', text: g.d }) : null, el('span', { class: 'mc-s', text: g.best(s) })),
    AR.inst[g.id] ? el('span', { class: 'mc-live', text: 'En curso' }) : null);
  b.onclick = () => arShow('game', g.id);
  return b;
}
function arCover(x) {
  const b = el('button', { class: 'ar-cover', title: `Jugar a ${x.name}` },
    gameCover(x, false),
    el('span', { class: 'ac-n', text: x.name }),
    el('span', { class: 'ac-s ' + x.src, text: [libName(x.src), playedText(x.minutes)].filter(Boolean).join(' · ') }),
    el('span', { class: 'ac-l', text: lastText(x.last, x.minutes) }));
  b.onclick = () => playGame(x);
  return b;
}
function arHome(body) {
  body.replaceChildren();
  const all = gameList();
  const top = all.find(x => x.last);
  if (top) {
    const play = el('button', { class: 'ar-play', text: '▶ Jugar' });
    play.onclick = (e) => { e.stopPropagation(); playGame(top); };
    const hero = el('div', { class: 'ar-hero g-hero-card ' + top.src },
      gameBanner(top),
      el('div', { class: 'g-hero-info' },
        el('span', { class: 'g-hero-k', text: 'Seguir jugando' }),
        el('span', { class: 'g-hero-n', text: top.name }),
        el('span', { class: 'g-hero-s', text: [libName(top.src), playedText(top.minutes), top.last ? `última vez ${ago(top.last)}` : ''].filter(Boolean).join(' · ') })),
      play);
    hero.onclick = () => playGame(top);
    body.append(hero);
  } else {
    body.append(el('div', { class: 'ar-hero empty' },
      el('div', { class: 'g-hero-info' }, el('span', { class: 'g-hero-k', text: 'Sala de juegos' }), el('span', { class: 'g-hero-n', text: '¿Una partidita?' }),
        el('span', { class: 'g-hero-s', text: all.length ? 'Elegí un juego de tu biblioteca o un mini juego.' : 'No encontré juegos de Steam o Xbox instalados, pero tenés los mini juegos de Base.' }))));
  }
  const minis = el('div', { class: 'mini-row' }, MINI().map(g => miniCard(g)));
  body.append(arSection('Mini juegos'), minis);
  const recent = all.filter(x => x.last).slice(0, 8);
  const list = recent.length ? recent : all.slice(0, 8);
  if (list.length) {
    const more = el('button', { class: 'ar-link', text: `Ver todos (${all.length})` });
    more.onclick = () => arShow('lib');
    body.append(arSection(recent.length ? 'Jugados hace poco' : 'Tu biblioteca', more), el('div', { class: 'ar-row' }, list.map(arCover)));
  }
}
function arLib(body) {
  const all = gameList();
  const q = el('input', { class: 'ar-q', placeholder: 'Buscar en tu biblioteca…', value: AR.q, 'aria-label': 'Buscar juego' });
  const filt = el('div', { class: 'ar-seg' }, [['all', 'Todos'], ...Object.keys(LIBS).filter(k => all.some(x => x.src === k)).map(k => [k, libName(k)])].map(([k, n]) => {
    const b = el('button', { class: (AR.filter === k ? 'on ' : '') + k, text: `${n} (${k === 'all' ? all.length : all.filter(x => x.src === k).length})` });
    b.onclick = () => { AR.filter = k; arLib(body); };
    return b;
  }));
  const sorter = el('div', { class: 'ar-seg' }, [['recent', 'Recientes'], ['played', 'Más jugados'], ['az', 'A-Z']].map(([k, n]) => {
    const b = el('button', { class: (S.settings.gameSort || 'recent') === k ? 'on' : '', text: n });
    b.onclick = () => { S.settings.gameSort = k; save(); arLib(body); renderGames(); };
    return b;
  }));
  const refresh = el('button', { class: 'ar-link', text: 'Buscar juegos nuevos' });
  refresh.onclick = async () => { toast('Buscando juegos…'); await loadGames(true); arLib(body); };
  const grid = el('div', { class: 'ar-grid' });
  const fill = () => {
    let list = all.filter(x => (AR.filter === 'all' || x.src === AR.filter) && (!AR.q || x.name.toLowerCase().includes(AR.q.toLowerCase())));
    const order = S.settings.gameSort || 'recent';
    if (order === 'played') list.sort((a, b) => (b.minutes || 0) - (a.minutes || 0) || b.last - a.last);
    else if (order === 'az') list.sort((a, b) => a.name.localeCompare(b.name, 'es'));
    grid.replaceChildren(...(list.length ? list.map(arCover) : [el('p', { class: 'ar-empty', text: all.length ? 'Ningún juego coincide.' : 'No encontré juegos instalados de Steam ni de Xbox en esta compu.' })]));
  };
  q.oninput = () => { AR.q = q.value; fill(); };
  const actions = el('div', { class: 'ar-libbar' }, filt, sorter, q, refresh);
  const apps = el('div', { class: 'ar-apps' });
  const os = el('button', { class: 'ar-link', text: 'Abrir Steam' }); os.onclick = () => api.launchSpecial('steam-app');
  const ox = el('button', { class: 'ar-link', text: 'Abrir Xbox' }); ox.onclick = () => api.launchSpecial('xbox-app');
  apps.append(os, ox);
  body.replaceChildren(el('div', { class: 'ar-sec' }, el('h2', { text: 'Mis juegos' }), apps), actions, grid);
  fill();
}
function arMini(body) {
  body.replaceChildren(arSection('Mini juegos', el('span', { class: 'ar-sub', text: 'Para una pausa corta. Se juegan acá mismo, sin internet.' })),
    el('div', { class: 'mini-grid' }, MINI().map(g => miniCard(g, true))));
}
// ----- Estilos de cada mini juego (mazos, colores, autos…) -----
function skinPicker(g, inst) {
  const cur = () => { const k = miniStats(g.id).skin; return g.skins.some(x => x[0] === k) ? k : g.skins[0][0]; };
  const label = () => (g.skins.find(x => x[0] === cur()) || g.skins[0])[1];
  const b = el('button', { type: 'button', class: 'mg-btn mg-skin' }, el('i', { style: `--c:${(g.skins.find(x => x[0] === cur()) || g.skins[0])[2]}` }), el('span', { text: (g.skinLabel || 'Estilo') + ': ' + label() }));
  b.onclick = (e) => {
    e.stopPropagation();
    const m = $('#fx-ctx');
    m.replaceChildren(el('span', { class: 'fx-ctx-h', text: g.skinLabel || 'Estilo' }), ...g.skins.map(([id, n, c]) => {
      const it = el('button', { class: 'fx-ctx-i mg-skin-i' + (id === cur() ? ' on' : '') }, el('i', { style: `--c:${c}` }), el('span', { text: n }));
      it.onclick = () => {
        m.hidden = true;
        const st = miniStats(g.id); st.skin = id; S.settings.mini[g.id] = st; save();
        if (inst.el) inst.el.dataset.skin = id;
        if (inst.setSkin) inst.setSkin(id);
        b.querySelector('i').style.setProperty('--c', c); b.querySelector('span').textContent = (g.skinLabel || 'Estilo') + ': ' + n;
      };
      return it;
    }));
    m.hidden = false;
    const r = b.getBoundingClientRect(), mr = m.getBoundingClientRect();
    m.style.left = Math.min(r.left, innerWidth - mr.width - 8) + 'px'; m.style.top = Math.min(r.bottom + 6, innerHeight - mr.height - 8) + 'px';
    const close = (ev) => { if (!ev.target.closest('#fx-ctx')) { m.hidden = true; document.removeEventListener('pointerdown', close, true); } };
    setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
  };
  return b;
}
// ----- Tienda de mini juegos -----
const STORE = { loaded: {}, busy: {} };
function storeLoad(it) {
  if (!it || !it.url) return Promise.resolve(false);
  return new Promise((res) => {
    const old = document.querySelector(`script[data-store="${it.id}"]`); if (old) old.remove();
    const sc = document.createElement('script');
    sc.src = it.url; sc.dataset.store = it.id;
    sc.onload = () => { STORE.loaded[it.id] = true; res(true); };
    sc.onerror = () => res(false);
    document.body.append(sc);
  });
}
function setupStore() {
  if (!api.store) { const b = $('#ar-tabs button[data-t="store"]'); if (b) b.hidden = true; return; }
  api.store.installed().then(list => (list || []).forEach(storeLoad)).catch(() => {});
  window.addEventListener('basemini:changed', () => { if (AR.view === 'mini' || AR.view === 'store') arShow(AR.view); const g = $('#gx-minis'); if (g) g.replaceChildren(); });
}
async function arStore(body) {
  body.replaceChildren(arSection('Tienda de mini juegos', el('span', { class: 'ar-sub', text: 'Juegos nuevos para sumar a Base. Son gratis, se bajan en un segundo y después se juegan sin internet.' })), el('p', { class: 'ar-empty', text: 'Buscando juegos…' }));
  const r = await safeCall(() => api.store.catalog());
  if (AR.view !== 'store') return;
  if (!r || !r.ok) { body.lastChild.textContent = 'No pude abrir la tienda ahora (' + ((r && r.error) || 'sin conexión') + ').'; return; }
  const inst = r.installed || {};
  const grid = el('div', { class: 'store-grid' }, ...r.list.map(g => {
    const have = !!inst[g.id], upd = have && String(inst[g.id].v) !== String(g.v || '1');
    const art = el('span', { class: 'mc-art' }); art.innerHTML = g.art || '';
    const act = el('button', { class: 'st-btn' + (have && !upd ? ' ghost' : ''), text: STORE.busy[g.id] ? 'Bajando…' : upd ? 'Actualizar' : have ? 'Jugar' : 'Sumar' });
    act.disabled = !!STORE.busy[g.id];
    act.onclick = async () => {
      if (have && !upd) return arShow('game', g.id);
      STORE.busy[g.id] = true; act.textContent = 'Bajando…'; act.disabled = true;
      const x = await safeCall(() => api.store.install(g.id));
      STORE.busy[g.id] = false;
      if (!x || !x.ok) { toast('No se pudo sumar: ' + ((x && x.error) || 'error')); arShow('store'); return; }
      if (AR.inst[g.id]) { try { AR.inst[g.id].hide && AR.inst[g.id].hide(); } catch {} delete AR.inst[g.id]; }
      await storeLoad({ id: g.id, url: x.url });
      toast(`${g.n} ya está en tus mini juegos`);
      arShow('store');
    };
    const rm = have ? el('button', { class: 'text-btn st-rm', text: 'Quitar' }) : null;
    if (rm) rm.onclick = async () => { await api.store.remove(g.id); if (AR.inst[g.id]) { try { AR.inst[g.id].hide && AR.inst[g.id].hide(); } catch {} delete AR.inst[g.id]; } window.BaseMini.unregister(g.id); toast(`Quitaste ${g.n}`); arShow('store'); };
    return el('div', { class: 'store-card', style: `--gc:${g.c || '#555'}` }, art,
      el('div', { class: 'st-txt' }, el('b', { text: g.n }), el('span', { text: g.d || '' }), el('small', { text: [g.tipo, g.size ? Math.max(1, Math.round(g.size / 1024)) + ' KB' : ''].filter(Boolean).join(' · ') })),
      el('div', { class: 'st-acts' }, act, rm));
  }));
  body.replaceChildren(body.firstChild, r.list.length ? grid : el('p', { class: 'ar-empty', text: 'Todavía no hay juegos en la tienda.' }));
}
function arGame(body, id) {
  const g = MINI().find(x => x.id === id);
  if (!g) return arShow('mini');
  const stats = el('div', { class: 'mg-stats' });
  AR.statusEl = stats;
  const stage = el('div', { class: 'mg-stage' });
  const head = el('div', { class: 'mg-head', style: `--gc:${g.c}` },
    el('div', { class: 'mg-title' }, el('span', { class: 'mc-art sm' }), el('b', { text: g.n }), stats),
    el('div', { class: 'mg-tools' }));
  head.querySelector('.mc-art').innerHTML = g.art;
  const help = el('p', { class: 'mg-help' });
  body.replaceChildren(head, stage, help);
  let inst = AR.inst[id];
  if (!inst) {
    try {
      inst = AR.inst[id] = g.create({
        get: () => miniStats(id),
        set: (o) => { S.settings.mini[id] = o; save(); },
        status: (parts) => { AR.last = AR.last || {}; AR.last[id] = parts; if (AR.view === 'game' && AR.game === id && AR.statusEl) AR.statusEl.replaceChildren(...parts.filter(Boolean).map(p => el('span', { text: p }))); },
        toast
      });
    } catch (e) { console.error(e); stage.append(el('p', { class: 'ar-empty', text: 'No se pudo abrir el juego.' })); return; }
    if (g.skins && inst.el) { const k = miniStats(id).skin; inst.el.dataset.skin = g.skins.some(x => x[0] === k) ? k : g.skins[0][0]; }
  }
  head.querySelector('.mg-tools').append(...(inst.tools || []));
  if (g.skins && g.skins.length > 1) head.querySelector('.mg-tools').prepend(skinPicker(g, inst));
  help.textContent = inst.help || '';
  stage.append(inst.el);
  const last = (AR.last || {})[id];
  if (last) stats.replaceChildren(...last.filter(Boolean).map(p => el('span', { text: p })));
  if (inst.show) inst.show();
}
function setupArcade() {
  if (!window.BaseMini) return;
  setupStore();
  $('#open-arcade').onclick = () => openArcade('home');
  $('#ar-back').onclick = () => (AR.view === 'game' ? arShow('mini') : closeArcade());
  $('#ar-min').onclick = () => api.minimize && api.minimize();
  for (const b of $$('#ar-tabs button')) b.onclick = () => arShow(b.dataset.t);
  document.addEventListener('keydown', (e) => {
    if ($('#arcade').hidden) return;
    if (e.target.matches && e.target.matches('input, textarea, select')) { if (e.key === 'Escape') e.target.blur(); return; }
    if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); if (AR.view === 'game') arShow('mini'); else if (AR.view !== 'home') arShow('home'); else closeArcade(); return; }
    if (AR.view === 'game') {
      const inst = AR.inst[AR.game];
      if (inst && inst.key && inst.key(e)) { e.preventDefault(); e.stopImmediatePropagation(); }
    }
    e.stopPropagation();
  }, true);
}

// ---------- Streaming ----------
const STREAMING = [
  { id: 'youtube', n: 'YouTube', url: 'https://www.youtube.com', d: 'youtube.com', c: '#e62117', g: 'play', sub: 'Videos', app: /^youtube$/i },
  { id: 'netflix', n: 'Netflix', url: 'https://www.netflix.com', d: 'netflix.com', c: '#b20710', g: 'film', sub: 'Series y películas', app: /^netflix$/i },
  { id: 'disney', n: 'Disney+', url: 'https://www.disneyplus.com', d: 'disneyplus.com', c: '#0a2a7a', g: 'star', sub: 'Disney, Pixar, Marvel', app: /^disney\+?$/i },
  { id: 'spotify', n: 'Spotify', url: 'https://open.spotify.com', d: 'spotify.com', c: '#138a43', g: 'wave', sub: 'Música y podcasts', app: /^spotify/i },
  { id: 'prime', n: 'Prime Video', url: 'https://www.primevideo.com', d: 'primevideo.com', c: '#0a6fa8', g: 'tv', sub: 'Series y películas', app: /prime video/i },
  { id: 'hbomax', n: 'HBO Max', url: 'https://www.hbomax.com', d: 'hbomax.com', c: '#3d1aa6', g: 'film', sub: 'Series y películas', app: /^(hbo ?)?max$|hbo max/i },
  { id: 'twitch', n: 'Twitch', url: 'https://www.twitch.tv', d: 'twitch.tv', c: '#6c2bd9', g: 'live', sub: 'En vivo', app: /^twitch$/i },
  { id: 'ytmusic', n: 'YouTube Music', url: 'https://music.youtube.com', d: 'music.youtube.com', c: '#b3170f', g: 'note', sub: 'Música', app: /^youtube music$/i },
  { id: 'paramount', n: 'Paramount+', url: 'https://www.paramountplus.com', d: 'paramountplus.com', c: '#0b4fd6', g: 'star', sub: 'Series y películas', app: /paramount/i },
  { id: 'crunchyroll', n: 'Crunchyroll', url: 'https://www.crunchyroll.com', d: 'crunchyroll.com', c: '#d4600f', g: 'bigplay', sub: 'Anime', app: /crunchyroll/i },
  { id: 'appletv', n: 'Apple TV', url: 'https://tv.apple.com', d: 'tv.apple.com', c: '#2b2b30', g: 'tv', sub: 'Series y películas', app: /^apple tv/i },
  { id: 'flow', n: 'Flow', url: 'https://web.flow.com.ar', d: 'flow.com.ar', c: '#0f7d8c', g: 'tv', sub: 'TV y deportes', app: /^flow$/i }
];
const STREAM_DEFAULT = ['youtube', 'netflix', 'disney', 'spotify', 'prime', 'hbomax'];
async function loadStartApps(force) {
  if (!api.startApps) return;
  if (!force && ui.startAppsAt && Date.now() - ui.startAppsAt < 10 * 60000) return;
  ui.startAppsAt = Date.now();
  const r = await safeCall(() => api.startApps(force));
  if (Array.isArray(r)) { ui.startApps = r; renderStreaming(); renderSocial(); }
}
function streamApp(svc) {
  return (ui.startApps || []).find(a => svc.app.test(a.name)) || null;
}
async function openStream(svc) {
  const app = streamApp(svc);
  const r = app ? await api.launchSpecial('aumid', app.id) : await api.launchSpecial('url', svc.url);
  if (r && app) { await api.launchSpecial('url', svc.url); }
  const casa = S.modes.casa;
  casa.streamLast = { id: svc.id, at: Date.now() };
  save(); renderPeeks();
}
function renderStreaming() {
  if (S && stageKind() === 'streaming') renderStreamStage();
  if (!widgetOn('stream')) return;
  const casa = S.modes.casa;
  const chosen = casa.streaming || STREAM_DEFAULT;
  const editing = !!ui.streamEdit;
  $('#stream-edit').textContent = editing ? 'Listo' : 'Elegir servicios';
  const grid = $('#stream-grid');
  grid.replaceChildren();
  grid.classList.toggle('editing', editing);
  const list = editing ? STREAMING : chosen.map(id => STREAMING.find(x => x.id === id)).filter(Boolean);
  for (const svc of list) {
    const on = chosen.includes(svc.id);
    const app = streamApp(svc);
    const b = serviceTile(svc, { off: editing && !on, how: editing ? (on ? 'En tu lista' : 'Sumar') : app ? 'App' : 'Web',
      title: editing ? (on ? 'Tocá para sacarlo' : 'Tocá para sumarlo') : `Abrir ${svc.n}${app ? ' (app)' : ''}` });
    b.onclick = () => {
      if (!editing) return openStream(svc);
      const cur = (casa.streaming || STREAM_DEFAULT).slice();
      const i = cur.indexOf(svc.id);
      if (i >= 0) cur.splice(i, 1); else cur.push(svc.id);
      casa.streaming = cur; save(); renderStreaming(); renderPeeks();
    };
    grid.append(el('li', {}, b));
  }
  $('#stream-hint').textContent = editing
    ? 'Tocá cada servicio para sumarlo o sacarlo de tu lista.'
    : (list.length ? 'Si tenés la app instalada se abre la app; si no, la página web.' : 'Tocá “Elegir servicios” para armar tu lista.');
}

// ---------- Sección a elección: F1, un equipo de fútbol u otro tema ----------
const topic = () => S.settings.topic || null;
function newsQuery() {
  const t = topic();
  if (!t) return '';
  return t.kind === 'f1' ? (t.news || 'Fórmula 1') : t.kind === 'team' ? t.name : (t.query || '');
}
function topicLabel() {
  const t = topic();
  if (!t) return 'Elegí qué seguir';
  return t.kind === 'f1' ? 'Fórmula 1' : t.kind === 'team' ? t.name : t.query;
}
const LEAGUES = [
  ['arg.1', 'Liga Profesional (Argentina)'], ['bra.1', 'Brasileirão (Brasil)'], ['uru.1', 'Primera División (Uruguay)'],
  ['chi.1', 'Primera División (Chile)'], ['col.1', 'Liga BetPlay (Colombia)'], ['mex.1', 'Liga MX (México)'],
  ['usa.1', 'MLS (Estados Unidos)'], ['esp.1', 'LaLiga (España)'], ['eng.1', 'Premier League (Inglaterra)'],
  ['ita.1', 'Serie A (Italia)'], ['ger.1', 'Bundesliga (Alemania)'], ['fra.1', 'Ligue 1 (Francia)'], ['por.1', 'Primeira Liga (Portugal)']
];
const ESPN = 'https://site.api.espn.com/apis/site/v2/sports/soccer';
function parseEspnEvents(t) {
  const j = JSON.parse(t);
  const out = [];
  for (const e of j.events || []) {
    const c = (e.competitions || [])[0] || {};
    const side = (k) => {
      const x = (c.competitors || []).find(z => z.homeAway === k) || {};
      const sc = x.score;
      return {
        id: x.team && String(x.team.id), name: x.team && (x.team.shortDisplayName || x.team.displayName) || '',
        logo: x.team && ((x.team.logos && x.team.logos[0] && x.team.logos[0].href) || x.team.logo) || '',
        score: sc == null ? null : typeof sc === 'object' ? (sc.displayValue ?? sc.value) : sc,
        winner: !!(x.winner || (sc && sc.winner))
      };
    };
    const st = (c.status || e.status || {}).type || {};
    out.push({
      id: String(e.id), start: Date.parse(e.date), comp: (e.league && e.league.name) || (e.season && e.season.displayName) || '',
      venue: (c.venue && c.venue.fullName) || '', home: side('home'), away: side('away'),
      state: st.state || '', completed: !!st.completed
    });
  }
  return out.filter(e => isFinite(e.start));
}
let teamData = { next: [], past: [] };
async function loadTeam(force) {
  const t = topic();
  if (!t || t.kind !== 'team') return;
  const base = `${ESPN}/${t.league}/teams/${t.id}/schedule`;
  const [next, past] = await Promise.all([
    cached(`team:${t.league}:${t.id}:next`, 60, base + '?fixture=true', parseEspnEvents, force),
    cached(`team:${t.league}:${t.id}:past`, 60, base, parseEspnEvents, force)
  ]);
  teamData = { next: next || [], past: past || [] };
  renderF1();
  checkF1Alerts();
}
function nextMatch() {
  const now = Date.now();
  return teamData.next.filter(e => !e.completed && e.start + 2.2 * 3600e3 > now).sort((a, b) => a.start - b.start)[0] || null;
}
function crest(side) {
  const box = el('span', { class: 'crest' });
  if (side.logo) box.append(imgChain([side.logo], () => box.append(el('span', { text: letterFor(side.name) }))));
  else box.append(el('span', { text: letterFor(side.name) }));
  return box;
}
function renderTeamPanel() {
  const t = topic();
  const box = $('#f1-next');
  const m = nextMatch();
  box.classList.remove('live');
  if (!m) {
    box.replaceChildren(el('div', { class: 'race', text: t.leagueName || '' }), el('div', { class: 'sess', text: t.name }),
      el('div', { class: 'when', text: teamData.next.length || teamData.past.length ? 'Sin partidos programados por ahora.' : 'Cargando el fixture…' }));
  } else {
    box.replaceChildren(
      el('div', { class: 'race', text: [m.comp, m.venue].filter(Boolean).join(' · ') }),
      el('div', { class: 'match' }, crest(m.home), el('span', { class: 'vs', text: `${m.home.name}  vs  ${m.away.name}` }), crest(m.away)),
      el('div', { class: 'count', id: 'f1-count' }),
      el('div', { class: 'when', text: f1When(m.start) }));
    renderTeamCount();
  }
  renderF1Photo();
  // últimos resultados
  const res = $('#team-results');
  res.replaceChildren();
  const past = teamData.past.filter(e => e.completed).sort((a, b) => b.start - a.start).slice(0, 5);
  if (past.length) {
    res.append(el('h3', { text: 'Últimos resultados' }));
    const ul = el('ul', {});
    for (const e of past) {
      const mine = e.home.id === String(t.id) ? 'home' : 'away';
      const us = e[mine], them = e[mine === 'home' ? 'away' : 'home'];
      const a = Number(us.score), b = Number(them.score);
      const r = a > b ? ['G', 'win'] : a < b ? ['P', 'loss'] : ['E', 'draw'];
      ul.append(el('li', {},
        el('span', { class: 'res ' + r[1], text: r[0], title: r[1] === 'win' ? 'Ganó' : r[1] === 'loss' ? 'Perdió' : 'Empató' }),
        crest(them),
        el('span', { class: 'opp', text: (mine === 'home' ? 'vs ' : 'en cancha de ') + them.name }),
        el('span', { class: 'sc', text: `${us.score ?? '-'} - ${them.score ?? '-'}` }),
        el('span', { class: 'dt', text: fmt(new Date(e.start), { day: 'numeric', month: 'short' }).replace('.', '') })));
    }
    res.append(ul);
  }
}
function renderTeamCount() {
  const c = $('#f1-count');
  const m = nextMatch();
  if (!c || !m) return;
  const now = Date.now();
  const box = $('#f1-next');
  if (m.start <= now) {
    box.classList.add('live');
    c.replaceChildren(el('div', {}, el('b', {}, el('span', { class: 'dot' }), 'En juego'), el('span', { text: 'Seguilo en vivo por TV o streaming' })));
    return;
  }
  if (box.classList.contains('live')) { box.classList.remove('live'); return renderF1(); }
  let s2 = Math.floor((m.start - now) / 1000);
  const dd = Math.floor(s2 / 86400); s2 %= 86400;
  const hh = Math.floor(s2 / 3600); s2 %= 3600;
  const mm = Math.floor(s2 / 60); const ss = s2 % 60;
  const unit = (v, l) => el('div', {}, el('b', { text: pad(v) }), el('span', { text: l }));
  c.replaceChildren(...(dd ? [unit(dd, dd === 1 ? 'día' : 'días')] : []), unit(hh, 'horas'), unit(mm, 'min'), unit(ss, 'seg'));
}
function renderTemaPanel() {
  const box = $('#f1-next');
  const it = newsItems()[0];
  box.classList.remove('live');
  box.replaceChildren(
    el('div', { class: 'race', text: 'Lo último' }),
    el('div', { class: 'sess', text: topicLabel() }),
    el('div', { class: 'headline', text: it ? it.title : 'Buscando noticias…' }),
    el('div', { class: 'when', text: it ? [it.source, ago(it.date)].filter(Boolean).join(' · ') : '' }));
  if (it) { box.style.cursor = 'pointer'; box.onclick = () => api.openUrl(it.link); } else { box.onclick = null; }
  renderF1Photo();
}
// estructura del panel según lo elegido
function applyTopicChrome() {
  const t = topic();
  const panel = $('#f1-panel');
  panel.classList.remove('kind-f1', 'kind-team', 'kind-tema', 'kind-none');
  panel.classList.add('kind-' + (t ? t.kind : 'none'));
  $('#h-f1').textContent = topicLabel();
  setText('pk-f1-label', t ? topicLabel() : 'Noticias');
  const ico = $('#peek-f1 .pk-label svg');
  if (ico) ico.innerHTML = !t || t.kind === 'tema'
    ? '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h10M7 12h10M7 16h6"/>'
    : t.kind === 'team'
      ? '<circle cx="12" cy="12" r="9"/><path d="m12 7 4 3-1.5 4.5h-5L8 10z"/>'
      : '<path d="M4 21V4M4 4h14l-3 4 3 4H4"/><path d="M9 4v8M14 4v8" stroke-width="1.2"/>';
  $('#news-title').textContent = t ? `Noticias de ${newsQuery()}` : '';
  $('#f1-tabs').hidden = !t || t.kind !== 'f1';
  if (!t || t.kind !== 'f1') $('#f1-panel').classList.remove('tab-camp');
  else if (ui.f1Tab === 'camp') $('#f1-panel').classList.add('tab-camp');
  $('#f1-alert').hidden = !t || t.kind === 'tema';
  $('#f1-next').onclick = null; $('#f1-next').style.cursor = '';
  if (t && t.kind !== 'tema') $('#f1-alert').value = S.modes.casa.f1.alert;
}
function checkTeamAlerts() {
  const cfg = S.modes.casa.f1;
  const t = topic();
  if (cfg.alert === '' || cfg.alert == null || !t) return;
  const lead = Number(cfg.alert) * 60000;
  const now = Date.now();
  for (const m of teamData.next) {
    const key = 'match:' + m.id;
    if (now >= m.start - lead && now < m.start + 10 * 60000 && !cfg.notified.includes(key)) {
      cfg.notified.push(key);
      if (cfg.notified.length > 60) cfg.notified.splice(0, cfg.notified.length - 60);
      const mins = Math.round((m.start - now) / 60000);
      notify('team', `${t.name} · ${m.home.name} vs ${m.away.name}`, mins <= 1 ? 'El partido empieza ahora' : `El partido empieza en ${mins} minutos`, { w: 'f1', mode: 'casa' });
      save();
    }
  }
}
function loadTopicData(force) {
  const t = topic();
  if (t && t.kind === 'f1') loadF1(force);
  if (t && t.kind === 'team') loadTeam(force);
  if (t) loadNews(force);
}

// diálogo para elegir
function openTopicDialog() {
  const t = topic() || { kind: 'f1' };
  ui.tp = { kind: t.kind, league: t.league || 'arg.1', team: t.kind === 'team' ? { id: t.id, name: t.name, logo: t.logo } : null };
  $('#tp-f1-news').value = t.kind === 'f1' ? (t.news || 'Fórmula 1') : 'Fórmula 1';
  $('#tp-tema').value = t.kind === 'tema' ? t.query : '';
  $('#tp-team-q').value = '';
  $('#tp-error').textContent = '';
  const sel = $('#tp-league');
  sel.replaceChildren(...LEAGUES.map(([id, n]) => el('option', { value: id, text: n })));
  sel.value = ui.tp.league;
  setTopicKind(ui.tp.kind);
  $('#dlg-topic').showModal();
}
function setTopicKind(k) {
  ui.tp.kind = k;
  for (const b of $$('.topic-kinds button')) b.setAttribute('aria-checked', String(b.dataset.kind === k));
  for (const sec of $$('.tp-sec')) sec.hidden = sec.dataset.for !== k;
  if (k === 'team') loadLeagueTeams();
}
async function loadLeagueTeams() {
  const lg = ui.tp.league;
  const list = $('#tp-teams');
  list.replaceChildren(el('li', { class: 'w-msg', text: 'Cargando equipos…' }));
  const teams = await cached('league:' + lg, 1440, `${ESPN}/${lg}/teams`, (t) => {
    const j = JSON.parse(t);
    const arr = (((j.sports || [])[0] || {}).leagues || [])[0];
    return ((arr && arr.teams) || []).map(x => x.team).map(x => ({ id: String(x.id), name: x.displayName, logo: (x.logos && x.logos[0] && x.logos[0].href) || '' }))
      .sort((a, b) => a.name.localeCompare(b.name, 'es'));
  });
  if (ui.tp.league !== lg) return;
  ui.tp.teams = teams || [];
  renderLeagueTeams();
}
function renderLeagueTeams() {
  const list = $('#tp-teams');
  const q = $('#tp-team-q').value.trim().toLowerCase();
  list.replaceChildren();
  const teams = (ui.tp.teams || []).filter(x => !q || x.name.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(q.normalize('NFD').replace(/[̀-ͯ]/g, '')));
  if (!ui.tp.teams || !ui.tp.teams.length) { list.append(el('li', { class: 'w-msg', text: 'No se pudieron cargar los equipos. Revisá la conexión.' })); return; }
  for (const x of teams) {
    const on = ui.tp.team && ui.tp.team.id === x.id;
    const b = el('button', { type: 'button', class: 'tp-team' + (on ? ' on' : ''), 'aria-pressed': String(on) }, crest(x), el('span', { text: x.name }));
    b.onclick = () => { ui.tp.team = x; renderLeagueTeams(); };
    list.append(el('li', {}, b));
  }
}
function saveTopic() {
  const k = ui.tp.kind;
  let t;
  if (k === 'f1') t = { kind: 'f1', news: $('#tp-f1-news').value.trim() || 'Fórmula 1' };
  else if (k === 'team') {
    if (!ui.tp.team) { $('#tp-error').textContent = 'Elegí un equipo de la lista.'; return; }
    const lg = LEAGUES.find(x => x[0] === ui.tp.league);
    t = { kind: 'team', league: ui.tp.league, leagueName: lg ? lg[1] : '', id: ui.tp.team.id, name: ui.tp.team.name, logo: ui.tp.team.logo };
  } else {
    const q = $('#tp-tema').value.trim();
    if (!q) { $('#tp-error').textContent = 'Escribí un tema, por ejemplo NBA o Tecnología.'; return; }
    t = { kind: 'tema', query: q };
  }
  S.settings.topic = t;
  S.modes.casa.f1.notified = [];
  save();
  $('#dlg-topic').close();
  teamData = { next: [], past: [] };
  applyTopicChrome();
  renderF1(); renderNews(); renderPeeks();
  loadTopicData(true);
  toast(`Listo: ahora seguís ${topicLabel()}`);
}

// ---------- Ubicación de la compu para el clima ----------
async function useMyLocation(quiet) {
  if (!api.locate) { if (!quiet) toast('La ubicación automática solo funciona en la app instalada'); return false; }
  if (!quiet) toast('Buscando la ubicación de esta compu…');
  const r = await safeCall(() => api.locate());
  if (!r || !r.ok) { if (!quiet) toast('No pude averiguar la ubicación. Buscá tu ciudad a mano.'); return false; }
  const d = r.data;
  S.modes.casa.weather = { name: d.name, detail: d.detail, lat: d.lat, lon: d.lon };
  if (S.activeMode !== 'casa') M().weather = { name: d.name, detail: d.detail, lat: d.lat, lon: d.lon };
  S.settings.geoDone = true;
  save();
  if ($('#dlg-city').open) $('#dlg-city').close();
  loadWeather(true);
  toast(`Clima de ${d.name}${d.source === 'internet' ? ' (ubicación aproximada por internet)' : ''}`);
  return true;
}

// íconos propios (no son logos: representan el tipo de servicio)
const GLYPH = {
  card: '<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6 15h4"/>',
  chat: '<path d="M4 12a8 8 0 1 1 3.4 6.5L4 20l1.3-3.6A7.9 7.9 0 0 1 4 12z"/><path d="M9 11h.01M12 11h.01M15 11h.01" stroke-width="2.6"/>',
  send: '<path d="M21 3 3 10.5l7 2.5 2.5 7z"/><path d="M10 13l4.5-4.5"/>',
  camera: '<rect x="3" y="6" width="18" height="14" rx="4"/><circle cx="12" cy="13" r="3.6"/><path d="M8 6l1.5-2h5L16 6"/>',
  feed: '<path d="M5 5h14M5 10h14M5 15h9M5 20h6"/>',
  people: '<circle cx="9" cy="9" r="3.2"/><circle cx="17" cy="10" r="2.4"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5M15 14.5c2.6 0 4.6 1.6 5.2 4.5"/>',
  note: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  headset: '<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>',
  at: '<circle cx="12" cy="12" r="3.6"/><path d="M15.6 12v1.4a2.6 2.6 0 0 0 5.2 0V12a8.8 8.8 0 1 0-3.4 7"/>',
  thread: '<path d="M7 7h10M7 12h6"/><path d="M5 4h14a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-7l-5 4v-4H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  case: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M3 12h18"/>',
  cloud: '<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/>',
  pin: '<path d="M12 21s-6-5.6-6-11a6 6 0 0 1 12 0c0 5.4-6 11-6 11z"/><circle cx="12" cy="10" r="2.3"/>',
  play: '<rect x="3" y="5" width="18" height="14" rx="4"/><path d="M10 9v6l5-3z" fill="currentColor"/>',
  film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
  tv: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
  live: '<circle cx="12" cy="12" r="2.5"/><path d="M8 8a5.6 5.6 0 0 0 0 8M16 8a5.6 5.6 0 0 1 0 8M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/>',
  wave: '<path d="M3 12h2M7 8v8M11 5v14M15 8v8M19 10v4M21 12h0"/>',
  bigplay: '<path d="M8 5v14l11-7z" fill="currentColor"/>'
};
// tarjeta de servicio: color de la marca, ícono propio, nombre y para qué sirve
// logo oficial de cada servicio: el ícono que publica el propio sitio (si no carga, un dibujito)
const LOGO_DOMAIN = { youtube: 'youtube.com', netflix: 'netflix.com', disney: 'disneyplus.com', spotify: 'spotify.com', prime: 'primevideo.com', hbomax: 'max.com',
  twitch: 'twitch.tv', ytmusic: 'music.youtube.com', paramount: 'paramountplus.com', crunchyroll: 'crunchyroll.com', appletv: 'tv.apple.com', flow: 'flow.com.ar' };
function brandLogo(domain, glyph, cls) {
  const box = el('span', { class: cls });
  const fallback = () => { box.classList.remove('has-logo'); box.replaceChildren(svg(GLYPH[glyph] || GLYPH.feed)); };
  if (!domain) { fallback(); return box; }
  const srcs = [`https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=256`, `https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`];
  let i = 0;
  const img = el('img', { alt: '', draggable: 'false', referrerpolicy: 'no-referrer' });
  const next = () => { if (i < srcs.length) img.src = srcs[i++]; else fallback(); };
  img.onerror = next;
  img.onload = () => { if (img.naturalWidth && img.naturalWidth < 48 && i < srcs.length) next(); else if (img.naturalWidth && img.naturalWidth < 24) fallback(); else box.classList.add('has-logo'); };
  box.append(img);
  next();
  return box;
}
function serviceTile(svc, opts) {
  const dom = LOGO_DOMAIN[svc.id] || svc.d;
  const b = el('button', { class: 's-tile v2' + (opts.off ? ' off' : ''), style: `--sc:${svc.c}`, title: opts.title },
    brandLogo(dom, svc.g, 's-glyph-bg'),
    brandLogo(dom, svc.g, 's-badge'),
    el('span', { class: 's-txt' }, el('span', { class: 's-name', text: svc.n }), el('span', { class: 's-sub', text: svc.sub || '' })),
    el('span', { class: 's-how', text: opts.how }));
  return b;
}

// ---------- Redes: accesos directos (abren la app si está instalada; si no, la web) ----------
const SOCIALS = [
  { id: 'whatsapp', n: 'WhatsApp', url: 'https://web.whatsapp.com/', d: 'whatsapp.com', c: '#1a9e52', g: 'chat', sub: 'Mensajes', app: /^whatsapp/i },
  { id: 'instagram', n: 'Instagram', url: 'https://www.instagram.com/', d: 'instagram.com', c: '#c13584', g: 'camera', sub: 'Fotos y reels', app: /^instagram$/i },
  { id: 'x', n: 'X', url: 'https://x.com/home', d: 'x.com', c: '#14171a', g: 'at', sub: 'Lo que pasa ahora', app: /^(x|twitter)$/i },
  { id: 'facebook', n: 'Facebook', url: 'https://www.facebook.com/', d: 'facebook.com', c: '#1565d8', g: 'people', sub: 'Amigos y grupos', app: /^facebook$/i },
  { id: 'tiktok', n: 'TikTok', url: 'https://www.tiktok.com/', d: 'tiktok.com', c: '#18181c', g: 'note', sub: 'Videos cortos', app: /^tiktok$/i },
  { id: 'telegram', n: 'Telegram', url: 'https://web.telegram.org/', d: 'telegram.org', c: '#1c8ad6', g: 'send', sub: 'Mensajes y canales', app: /^telegram/i },
  { id: 'discord', n: 'Discord', url: 'https://discord.com/app', d: 'discord.com', c: '#5865f2', g: 'headset', sub: 'Charlas y juegos', app: /^discord$/i },
  { id: 'threads', n: 'Threads', url: 'https://www.threads.net/', d: 'threads.net', c: '#2a2a2a', g: 'thread', sub: 'Conversaciones', app: /^threads$/i },
  { id: 'reddit', n: 'Reddit', url: 'https://www.reddit.com/', d: 'reddit.com', c: '#e03d00', g: 'feed', sub: 'Comunidades', app: /^reddit$/i },
  { id: 'messenger', n: 'Messenger', url: 'https://www.messenger.com/', d: 'messenger.com', c: '#7a3cff', g: 'bolt', sub: 'Mensajes', app: /^messenger$/i },
  { id: 'linkedin', n: 'LinkedIn', url: 'https://www.linkedin.com/feed/', d: 'linkedin.com', c: '#0a66c2', g: 'case', sub: 'Trabajo y contactos', app: /^linkedin$/i },
  { id: 'bluesky', n: 'Bluesky', url: 'https://bsky.app/', d: 'bsky.app', c: '#1185fe', g: 'cloud', sub: 'Lo que pasa ahora', app: /^bluesky$/i },
  { id: 'pinterest', n: 'Pinterest', url: 'https://ar.pinterest.com/', d: 'pinterest.com', c: '#c8102e', g: 'pin', sub: 'Ideas e inspiración', app: /^pinterest$/i }
];
const SOCIAL_DEFAULT = ['whatsapp', 'instagram', 'x', 'facebook', 'tiktok', 'discord'];
const socialChosen = () => (S.settings.socials || SOCIAL_DEFAULT).map(id => SOCIALS.find(x => x.id === id)).filter(Boolean);
async function openSocial(net) {
  const app = streamApp(net);
  let r = app ? await api.launchSpecial('aumid', app.id) : await api.launchSpecial('url', net.url);
  if (r && app) r = await api.launchSpecial('url', net.url);
  if (r) return toast(`No se pudo abrir ${net.n}`);
  S.settings.socialLast = { id: net.id, at: Date.now() };
  save(); renderPeeks();
}
function renderSocial() {
  if (!widgetOn('social')) return;
  const chosen = S.settings.socials || SOCIAL_DEFAULT;
  const editing = !!ui.socEdit;
  setText('soc-edit', editing ? 'Listo' : 'Elegir redes');
  const grid = $('#soc-grid');
  grid.replaceChildren();
  grid.classList.toggle('editing', editing);
  const list = editing ? SOCIALS : socialChosen();
  for (const net of list) {
    const on = chosen.includes(net.id);
    const app = streamApp(net);
    const b = serviceTile(net, { off: editing && !on, how: editing ? (on ? 'En tu lista' : 'Sumar') : app ? 'App' : 'Web',
      title: editing ? (on ? 'Tocá para sacarla' : 'Tocá para sumarla') : `Abrir ${net.n}${app ? ' (app)' : ''}` });
    b.onclick = () => {
      if (!editing) return openSocial(net);
      const cur = (S.settings.socials || SOCIAL_DEFAULT).slice();
      const i = cur.indexOf(net.id);
      if (i >= 0) cur.splice(i, 1); else cur.push(net.id);
      S.settings.socials = cur; save(); renderSocial(); renderPeeks();
    };
    grid.append(el('li', {}, b));
  }
  setText('soc-hint', editing ? 'Tocá cada red para sumarla o sacarla de tu lista.'
    : list.length ? 'Si tenés la app instalada se abre la app; si no, la página web.' : 'Tocá “Elegir redes” para armar tu lista.');
}
function setupSocial() {
  $('#soc-edit').onclick = () => { ui.socEdit = !ui.socEdit; renderSocial(); };
}

// ---------- Buscador rápido ----------
const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
function score(name, q) {
  const n = norm(name);
  if (!q) return 0;
  if (n === q) return 100;
  if (n.startsWith(q)) return 80;
  if (n.split(/[\s\-_.()]+/).some(w => w.startsWith(q))) return 60;
  const i = n.indexOf(q);
  if (i >= 0) return 40 - Math.min(20, i);
  // iniciales: "gc" → Google Chrome
  const ini = n.split(/[\s\-_.]+/).map(w => w[0]).join('');
  if (q.length >= 2 && ini.startsWith(q)) return 35;
  return 0;
}
// calculadora segura (sin eval): + - * / % ^ y paréntesis, admite coma decimal
function calc(expr) {
  const src = expr.replace(/\s+/g, '').replace(/,/g, '.').replace(/[x×]/gi, '*').replace(/÷/g, '/');
  if (!/^[\d.+\-*/%^()]+$/.test(src) || !/[+\-*/%^]/.test(src.replace(/^-/, ''))) return null;
  let i = 0;
  const peek = () => src[i];
  function num() {
    if (peek() === '(') { i++; const v = add(); if (src[i++] !== ')') throw 0; return v; }
    if (peek() === '-') { i++; return -num(); }
    const m = /^\d*\.?\d+/.exec(src.slice(i));
    if (!m) throw 0;
    i += m[0].length;
    return parseFloat(m[0]);
  }
  function pow() { let v = num(); while (peek() === '^') { i++; v = Math.pow(v, num()); } return v; }
  function mul() {
    let v = pow();
    while ('*/%'.includes(peek()) && peek()) {
      const o = src[i++];
      const r = pow();
      v = o === '*' ? v * r : o === '/' ? v / r : v % r;
    }
    return v;
  }
  function add() {
    let v = mul();
    while ((peek() === '+' || peek() === '-')) { const o = src[i++]; const r = mul(); v = o === '+' ? v + r : v - r; }
    return v;
  }
  try { const v = add(); return i === src.length && isFinite(v) ? v : null; } catch { return null; }
}
const fmtNum = (v) => Number(v).toLocaleString('es-AR', { maximumFractionDigits: 6 });
const SEARCH_ACTIONS = [
  { n: 'Modo oscuro / claro', k: 'oscuro claro tema noche', ico: 'moon', run: () => $('#btn-scheme').click() },
  { n: 'Historial del portapapeles', k: 'portapapeles copiar pegar copiado historial', ico: 'note', run: () => setTimeout(() => clipOpen(true), 120) },
  { n: 'Recortar una captura de pantalla', k: 'captura recorte recortar pantalla screenshot imprimir', ico: 'desk', run: () => cropNow() },
  { n: 'Modo descanso (reloj grande y fotos)', k: 'descanso protector pantalla tele reloj grande fotos', ico: 'moon', run: () => setTimeout(enterRest, 200) },
  { n: 'Ver el escritorio de Windows', k: 'escritorio windows ver mostrar ocultar base', ico: 'desk', run: () => deskPeek() },
  { n: 'Ajustes de Base', k: 'ajustes personalizar colores fondo reloj configuracion opciones', ico: 'palette', run: () => openDrawer(true) },
  { n: 'Editar escritorio', k: 'editar tarjetas escritorio ordenar', ico: 'edit', run: () => setDeskEdit(true) },
  { n: 'Resumen del día', k: 'resumen dia briefing hoy', ico: 'sun', run: () => openBrief() },
  { n: 'Sala de juegos', k: 'juegos sala jugar steam xbox mini', ico: 'game', run: () => openArcade('home') },
  { n: 'Solitario', k: 'solitario cartas klondike juego', ico: 'game', run: () => openArcade('game', 'solitario') },
  { n: 'Sudoku', k: 'sudoku juego numeros', ico: 'game', run: () => openArcade('game', 'sudoku') },
  { n: 'Mahjong', k: 'mahjong fichas juego', ico: 'game', run: () => openArcade('game', 'mahjong') },
  { n: 'Buscaminas', k: 'buscaminas minas juego', ico: 'game', run: () => openArcade('game', 'buscaminas') },
  { n: '2048', k: '2048 juego numeros', ico: 'game', run: () => openArcade('game', '2048') },
  { n: 'Memotest', k: 'memotest memoria pares juego', ico: 'game', run: () => openArcade('game', 'memotest') },
  { n: 'Viborita', k: 'viborita snake serpiente juego', ico: 'game', run: () => openArcade('game', 'viborita') },
  { n: 'Ta-te-ti', k: 'tateti ta te ti tres en linea juego', ico: 'game', run: () => openArcade('game', 'tateti') },
  { n: 'Adiviná la palabra', k: 'palabra wordle adivina juego letras', ico: 'game', run: () => openArcade('game', 'palabra') },
  { n: 'Bloques', k: 'bloques tetris piezas juego', ico: 'game', run: () => openArcade('game', 'bloques') },
  { n: 'Carreras', k: 'carreras autos auto manejar ruta juego', ico: 'game', run: () => openArcade('game', 'carreras') },
  { n: 'Vuelo', k: 'vuelo avion avioneta volar juego', ico: 'game', run: () => openArcade('game', 'vuelo') },
  { n: 'Nueva tarea', k: 'tarea pendiente agregar', ico: 'check', run: () => { openWidget('tasks', true); setTimeout(() => $('#task-text').focus(), 120); } },
  { n: 'Nueva nota', k: 'nota escribir agregar', ico: 'note', run: () => { openWidget('notes', true); setTimeout(newNote, 120); } },
  { n: 'Nuevo evento en la agenda', k: 'evento agenda calendario turno', ico: 'cal', run: () => { openWidget('agenda', true); setTimeout(() => $('#ev-title').focus(), 120); } },
  { n: 'Cambiar a modo Casa', k: 'casa modo', ico: 'home', run: () => setMode('casa'), multi: true },
  { n: 'Cambiar a modo Trabajo', k: 'trabajo modo oficina', ico: 'work', run: () => setMode('trabajo'), multi: true },
  { n: 'Ciudad del clima', k: 'clima ciudad tiempo ubicacion', ico: 'sun', run: () => openCityDialog() },
  { n: 'Minimizar todas las ventanas', k: 'minimizar escritorio ventanas', ico: 'win', run: () => api.windows && api.windows.system('minimizeAll') },
  { n: 'Bloquear la compu', k: 'bloquear lock', ico: 'lock', run: () => api.windows && api.windows.system('lock') },
  { n: 'Configuración de Windows', k: 'configuracion windows ajustes', ico: 'win', run: () => api.windows && api.windows.system('settings') },
  { n: 'Administrador de tareas', k: 'administrador tareas procesos', ico: 'win', run: () => api.windows && api.windows.system('taskmgr') }
];
const SICON = {
  desk: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
  app: '<rect x="4" y="4" width="16" height="16" rx="4"/>', file: '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>', web: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/>',
  calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h2M12 11h2M16 11h0M8 15h2M12 15h2M8 18h2M12 18h2"/>',
  money: '<circle cx="12" cy="12" r="9"/><path d="M15 9.5c-.5-1-1.6-1.5-3-1.5-1.7 0-3 .8-3 2s1.3 1.7 3 2 3 .8 3 2-1.3 2-3 2c-1.4 0-2.5-.5-3-1.5M12 6v2M12 16v2"/>',
  game: '<rect x="2.5" y="7" width="19" height="11" rx="5.5"/><path d="M7 10.5v4M5 12.5h4"/>', check: '<path d="M9 11l2 2 4-4"/><rect x="4" y="4" width="16" height="16" rx="3"/>',
  note: '<path d="M6 3h9l4 4v14H6z"/><path d="M9 13h7M9 17h5"/>', cal: '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>', sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.6-.7 1.6-1.5 0-.9-.6-1.3-.6-2.2 0-1 .8-1.8 1.8-1.8H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', home: '<path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>',
  work: '<path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M4 8h16v11H4z"/>', win: '<rect x="4" y="4" width="7" height="7"/><rect x="13" y="4" width="7" height="7"/><rect x="4" y="13" width="7" height="7"/><rect x="13" y="13" width="7" height="7"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'
};
const SR = { items: [], sel: 0, recent: null, recentAt: 0 };
function allShortcutsFlat() {
  const out = [];
  for (const mode of (SINGLE ? ['casa'] : ['casa', 'trabajo'])) {
    for (const x of S.modes[mode].shortcuts) {
      if (isFolder(x)) x.items.forEach(i => out.push(i)); else out.push(x);
    }
  }
  for (const src of ['desktop', 'taskbar']) for (const t of ((ui.sys && ui.sys[src]) || [])) out.push({ type: 'app', name: t.name, target: t.target, icon: t.icon });
  return out;
}
function searchResults(raw) {
  const q = norm(raw.trim());
  const res = [];
  const add = (group, n, sub, ico, run, sc, img) => res.push({ group, n, sub, ico, run, sc, img });
  if (!q) {
    add('Sugerencias', 'Resumen del día', 'Clima, agenda, mails y más', 'sun', () => openBrief(), 1);
    add('Sugerencias', 'Nueva tarea', '', 'check', SEARCH_ACTIONS.find(a => a.n === 'Nueva tarea').run, 1);
    add('Sugerencias', 'Nueva nota', '', 'note', SEARCH_ACTIONS.find(a => a.n === 'Nueva nota').run, 1);
    for (const f of (SR.recent || []).slice(0, 5)) add('Archivos recientes', f.name, f.target, f.folder ? 'folder' : 'file', () => api.open({ type: 'app', target: f.target }), 1, f.icon);
    return res;
  }
  // cuentas
  const c = calc(raw);
  if (c != null) add('Resultado', fmtNum(c), `${raw.trim()} =`, 'calc', () => { navigator.clipboard && navigator.clipboard.writeText(String(c)); toast('Resultado copiado'); }, 1000);
  // dólar
  const d = dolarData();
  const mUsd = /^\s*(?:u\$s|us\$|usd)?\s*([\d.,]+)\s*(?:usd|u\$s|us\$|dolares?|dólares?|verdes?)\s*(blue|oficial|mep|tarjeta|cripto|ccl)?\s*$/i.exec(raw) || /^\s*(?:usd|u\$s)\s*([\d.,]+)\s*(blue|oficial|mep|tarjeta|cripto|ccl)?\s*$/i.exec(raw);
  const mArs = /^\s*\$?\s*([\d.,]+)\s*(?:pesos|ars)\s*(?:a|en)?\s*(?:usd|dolares?|dólares?)?\s*(blue|oficial|mep|tarjeta|cripto|ccl)?\s*$/i.exec(raw);
  const casaOf = (t) => ({ mep: 'bolsa', ccl: 'contadoconliqui' })[String(t || 'blue').toLowerCase()] || String(t || 'blue').toLowerCase();
  const toNum = (t) => parseFloat(t.replace(/\./g, '').replace(',', '.'));
  if (d.length && mUsd) {
    const n = toNum(mUsd[1]);
    for (const casa of mUsd[2] ? [casaOf(mUsd[2])] : ['blue', 'oficial', 'bolsa', 'tarjeta']) {
      const x = d.find(y => y.casa === casa);
      if (x) add('Dólar', money(n * x.venta, 2), `${fmtNum(n)} USD al ${DOLAR_NAME[casa] || casa} (${money(x.venta)})`, 'money', () => openWidget('dolar', true), 900);
    }
  }
  if (d.length && mArs) {
    const n = toNum(mArs[1]);
    const x = d.find(y => y.casa === casaOf(mArs[2]));
    if (x) add('Dólar', `US$ ${fmtNum(Math.round(n / x.venta * 100) / 100)}`, `${money(n)} al ${DOLAR_NAME[x.casa]} (${money(x.venta)})`, 'money', () => openWidget('dolar', true), 900);
  }
  // programas del menú Inicio
  for (const a of ui.startApps || []) {
    const sc = score(a.name, q);
    if (sc) add('Programas', a.name, 'Programa', 'app', () => api.launchSpecial('aumid', a.id), sc + 6, a.icon);
  }
  // accesos de Base y de Windows
  const seenNames = new Set(res.map(r => norm(r.n)));
  for (const x of allShortcutsFlat()) {
    const sc = score(x.name, q);
    if (!sc || seenNames.has(norm(x.name))) continue;
    seenNames.add(norm(x.name));
    add('Accesos', x.name, x.type === 'web' ? x.target.replace(/^https?:\/\/(www\.)?/, '') : 'Acceso', x.type === 'web' ? 'web' : x.type === 'folder' ? 'folder' : 'app', () => launch(x), sc + 4, x.icon);
  }
  // juegos, streaming y redes
  for (const g of gameList()) { const sc = score(g.name, q); if (sc) add('Juegos', g.name, libName(g.src), 'game', () => playGame(g), sc + 3); }
  for (const x of STREAMING) { const sc = score(x.n, q); if (sc) add('Streaming y redes', x.n, 'Streaming', 'web', () => openStream(x), sc + 2); }
  for (const x of SOCIALS) { const sc = score(x.n, q); if (sc) add('Streaming y redes', x.n, 'Red social', 'web', () => openSocial(x), sc + 2); }
  // archivos recientes
  for (const f of SR.recent || []) { const sc = score(f.name, q); if (sc) add('Archivos recientes', f.name, f.target, f.folder ? 'folder' : 'file', () => api.open({ type: 'app', target: f.target }), sc, f.icon); }
  // archivos de toda la compu (índice de Windows)
  if (SR.files && SR.files.q === raw.trim() && Array.isArray(SR.files.list)) {
    const seenP = new Set((SR.recent || []).map(f => String(f.target).toLowerCase()));
    let k = 0;
    for (const f of SR.files.list) {
      if (k >= 6 || seenP.has(f.path.toLowerCase())) continue;
      k++;
      const sc = Math.max(score(f.name, q), 15);
      add('En tu compu', f.name, shortPath(f.folder), f.dir ? 'folder' : 'file', () => api.open({ type: 'app', target: f.path }), 4 + sc / 3 - k * 0.1, f.icon);
    }
  }
  if (api.fileSearchAll && q.length >= 2) add('En tu compu', `Buscar “${raw.trim()}” en todos tus archivos`, 'Abre el buscador del Explorador', 'search', () => api.fileSearchAll(raw.trim()), -0.5);
  // acciones de Base
  for (const a of SEARCH_ACTIONS) {
    if (a.multi && SINGLE) continue;
    const sc = Math.max(score(a.n, q), norm(a.k).split(' ').some(w => w.startsWith(q)) ? 45 : 0);
    if (sc) add('Base', a.n, '', a.ico, a.run, sc + 1);
  }
  // tareas y notas
  for (const t of M().tasks.filter(t => !t.done)) { const sc = score(t.text, q); if (sc) add('Tareas', t.text, t.due ? `Para el ${t.due.split('-').reverse().slice(0, 2).join('/')}` : 'Pendiente', 'check', () => openWidget('tasks', true), sc - 5); }
  for (const n of M().notes) { if (norm(n.body).includes(q)) add('Notas', noteTitle(n), noteDate(n.updated), 'note', () => { ui.note[S.activeMode] = n.id; openWidget('notes', true); renderNotes(); }, 20); }
  // web
  const isUrl = /^[\w-]+(\.[\w-]+)+(\/\S*)?$/i.test(raw.trim()) || /^https?:\/\//i.test(raw.trim());
  if (isUrl) add('Web', raw.trim(), 'Abrir el sitio', 'web', () => api.openUrl(/^https?:/i.test(raw.trim()) ? raw.trim() : 'https://' + raw.trim()), 500);
  add('Web', `Buscar “${raw.trim()}” en Google`, '', 'search', () => api.openUrl('https://www.google.com/search?q=' + encodeURIComponent(raw.trim())), -1);
  // orden: por puntaje, agrupando
  res.sort((a, b) => b.sc - a.sc);
  const seen = new Map();
  return res.filter(r => { const k = r.group + '|' + norm(r.n); if (seen.has(k)) return false; seen.set(k, 1); return true; }).slice(0, 14);
}
function renderSearch() {
  const list = $('#search-results');
  list.replaceChildren();
  let lastGroup = '';
  SR.items.forEach((r, i) => {
    if (r.group !== lastGroup) { list.append(el('li', { class: 'sr-group', text: r.group })); lastGroup = r.group; }
    const ico = el('span', { class: 'sr-ico' });
    if (r.img) ico.append(el('img', { src: r.img, alt: '' })); else ico.append(svg(SICON[r.ico] || SICON.app));
    const li = el('li', { class: 'sr' + (i === SR.sel ? ' on' : ''), role: 'option', 'aria-selected': String(i === SR.sel) },
      ico, el('span', { class: 'sr-n', text: r.n }), r.sub ? el('span', { class: 'sr-s', text: r.sub }) : null);
    li.onmousemove = () => { if (SR.sel !== i) { SR.sel = i; renderSearch(); } };
    li.onclick = () => runSearch(i);
    list.append(li);
  });
  const on = list.querySelector('.sr.on');
  if (on) on.scrollIntoView({ block: 'nearest' });
}
const shortPath = (p) => { p = String(p || ''); const m = /^[a-z]:\\users\\[^\\]+/i.exec(p); if (m) p = 'Tu carpeta' + p.slice(m[0].length); p = p.replace(/\\OneDrive(\s-\s[^\\]+)?\\/i, '\\OneDrive\\'); return p.length > 60 ? '…' + p.slice(-58) : p; };
function updateSearch() {
  const raw = $('#search-q').value;
  SR.items = searchResults(raw);
  SR.sel = Math.min(SR.sel, Math.max(0, SR.items.length - 1));
  if (!SR.keepSel) SR.sel = 0;
  SR.keepSel = false;
  renderSearch();
  // archivos de la compu: se buscan aparte, un ratito después de dejar de escribir
  const q = raw.trim();
  if (!api.fileSearch || q.length < 3 || /^[\d\s.,+\-*/%^()x×÷]+$/.test(q)) return;
  if (SR.files && SR.files.q === q) return;
  clearTimeout(SR.fileT);
  SR.fileT = setTimeout(async () => {
    const list = await safeCall(() => api.fileSearch(q));
    if ($('#search').hidden || $('#search-q').value.trim() !== q) return;
    SR.files = { q, list: list || [] };
    SR.keepSel = true;
    updateSearch();
  }, 320);
}
function runSearch(i) {
  const r = SR.items[i];
  if (!r) return;
  closeSearch();
  Promise.resolve(r.run()).catch(() => {});
}
async function openSearch(prefill) {
  closeWidget(true);
  $('#search').hidden = false;
  const q = $('#search-q');
  q.value = prefill || '';
  q.focus();
  updateSearch();
  if (!SR.recent || Date.now() - SR.recentAt > 60000) {
    if (api.recentFiles) { SR.recent = await safeCall(() => api.recentFiles()) || []; SR.recentAt = Date.now(); updateSearch(); }
  }
  loadStartApps(false);
  if (!dolarData().length) loadDolar(true, true).then(() => { if (!$('#search').hidden) updateSearch(); });
}
function closeSearch() { $('#search').hidden = true; }
function setupSearch() {
  const q = $('#search-q');
  q.addEventListener('input', updateSearch);
  q.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); SR.sel = Math.min(SR.items.length - 1, SR.sel + 1); renderSearch(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); SR.sel = Math.max(0, SR.sel - 1); renderSearch(); }
    else if (e.key === 'Enter') { e.preventDefault(); runSearch(SR.sel); }
    else if (e.key === 'Escape') { e.preventDefault(); closeSearch(); }
  });
  $('#search').addEventListener('pointerdown', (e) => { if (e.target.id === 'search') closeSearch(); });
  $('#btn-search').onclick = () => openSearch();
  if (api.onSearch) api.onSearch(() => openSearch());
  document.addEventListener('keydown', (e) => {
    if (!$('#search').hidden) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openSearch(); return; }
    // empezar a escribir en cualquier lado abre el buscador
    const a = document.activeElement;
    const typing = a && (a.matches('input, textarea, select, [contenteditable="true"]') || a.isContentEditable);
    if (!typing && !document.querySelector('dialog[open]') && !e.ctrlKey && !e.altKey && !e.metaKey && e.key.length === 1 && /\S/.test(e.key) && $('#brief').hidden) {
      e.preventDefault(); openSearch(e.key);
    }
  });
}

// ---------- Frase o efeméride del día ----------
const FRASES = [
  ['Lo que no se empieza, no se termina.', 'Dicho popular'],
  ['Paso a paso se llega lejos.', 'Dicho popular'],
  ['El que madruga, Dios lo ayuda.', 'Refrán'],
  ['La perseverancia es la madre de la buena suerte.', 'Miguel de Cervantes'],
  ['Caminante, no hay camino: se hace camino al andar.', 'Antonio Machado'],
  ['El genio es un uno por ciento de inspiración y un noventa y nueve de transpiración.', 'Thomas Edison'],
  ['La simplicidad es la máxima sofisticación.', 'Leonardo da Vinci'],
  ['No cuentes los días: hacé que los días cuenten.', 'Muhammad Ali'],
  ['Primero lo primero.', 'Dicho popular'],
  ['Hecho es mejor que perfecto.', 'Dicho popular'],
  ['Quien tiene un porqué para vivir puede soportar casi cualquier cómo.', 'Friedrich Nietzsche'],
  ['La mejor forma de predecir el futuro es crearlo.', 'Peter Drucker'],
  ['El éxito es la suma de pequeños esfuerzos repetidos día tras día.', 'Robert Collier'],
  ['Si querés ir rápido, andá solo; si querés llegar lejos, andá acompañado.', 'Proverbio africano'],
  ['Nunca es tarde para ser lo que podrías haber sido.', 'George Eliot'],
  ['El que no arriesga, no gana.', 'Refrán'],
  ['La imaginación es más importante que el conocimiento.', 'Albert Einstein'],
  ['Hoy es el primer día del resto de tu vida.', 'Dicho popular'],
  ['Elegí un trabajo que te guste y no vas a tener que trabajar ni un día.', 'Atribuida a Confucio'],
  ['Saber es poder.', 'Francis Bacon'],
  ['No hay viento favorable para el que no sabe adónde va.', 'Séneca'],
  ['La paciencia es amarga, pero su fruto es dulce.', 'Jean-Jacques Rousseau'],
  ['Más vale tarde que nunca.', 'Refrán'],
  ['El hombre es dueño de lo que calla y esclavo de lo que habla.', 'Atribuida a Sigmund Freud'],
  ['Lo importante no es caer, sino levantarse.', 'Dicho popular'],
  ['Una vez que aceptás tus límites, vas más allá de ellos.', 'Atribuida a Albert Einstein'],
  ['El tiempo es oro.', 'Refrán'],
  ['La disciplina es el puente entre las metas y los logros.', 'Jim Rohn'],
  ['En la vida hay que ser como el agua: suave pero constante.', 'Dicho popular'],
  ['Si podés soñarlo, podés hacerlo.', 'Atribuida a Walt Disney'],
  ['A mal tiempo, buena cara.', 'Refrán'],
  ['Divide y vencerás: las tareas grandes se hacen de a pedacitos.', 'Dicho popular']
];
function dayIndex() { const n = new Date(); return Math.floor((n - new Date(n.getFullYear(), 0, 0)) / 864e5); }
function fraseDelDia(shift = 0) { return FRASES[(dayIndex() + shift) % FRASES.length]; }
async function loadEfemeride() {
  const n = new Date();
  const mm = pad(n.getMonth() + 1), dd = pad(n.getDate());
  const data = await cached(`efem:${mm}${dd}`, 1440, `https://es.wikipedia.org/api/rest_v1/feed/onthisday/events/${mm}/${dd}`, (t) => {
    const j = JSON.parse(t);
    const ev = (j.events || []).filter(e => e.text && e.year && e.text.length < 220);
    return ev.length ? ev.map(e => ({ text: e.text, year: e.year, ar: /argentin|buenos aires|rosario|córdoba|mendoza|malvinas/i.test(e.text) })) : null;
  });
  ui.efem = data || [];
  renderDaily();
}
function dailyItem() {
  const mode = S.settings.daily || 'both';
  if (mode === 'none') return null;
  const shift = ui.dailyShift || 0;
  const ef = (ui.efem || []);
  if (mode === 'both' && ef.length) {
    const sorted = [...ef.filter(e => e.ar), ...ef.filter(e => !e.ar)];
    const e = sorted[(dayIndex() + shift) % sorted.length];
    return { kind: 'efem', text: e.text.replace(/\.$/, ''), meta: `Un día como hoy, en ${e.year}` };
  }
  const f = fraseDelDia(shift);
  return { kind: 'frase', text: f[0], meta: f[1] };
}
function renderDaily() {
  const box = $('#daily');
  const it = dailyItem();
  if (!it) { box.hidden = true; return; }
  box.hidden = false;
  box.replaceChildren(el('span', { class: 'd-meta', text: it.meta + ':' }), ' ', el('span', { class: 'd-text', text: it.kind === 'frase' ? `“${it.text}”` : it.text }));
  box.title = 'Tocá para ver otra';
}

// ---------- Fondo que cambia solo ----------
const AUTO_BG = {
  dawn: { light: 'radial-gradient(1100px 700px at 10% 100%, #ffd1a6 0%, transparent 60%), radial-gradient(1000px 700px at 90% 0%, #c9d7f2 0%, transparent 62%), #f3e3dc', dark: 'radial-gradient(1100px 700px at 10% 100%, #5b3a2e 0%, transparent 60%), radial-gradient(1000px 700px at 90% 0%, #253556 0%, transparent 62%), #1b1a24' },
  day: { light: 'radial-gradient(1200px 800px at 85% -10%, #fff6c9 0%, transparent 55%), linear-gradient(180deg, #bfe0fb 0%, #e6f1fb 60%, #f2f6f9 100%)', dark: 'radial-gradient(1200px 800px at 85% -10%, #3c3a24 0%, transparent 55%), linear-gradient(180deg, #16263a 0%, #18202b 100%)' },
  sunset: { light: 'radial-gradient(1100px 650px at 50% 110%, #ff9e6b 0%, transparent 60%), radial-gradient(900px 600px at 0% 0%, #b48ce0 0%, transparent 60%), linear-gradient(180deg, #f6c6c9, #fbd9b9)', dark: 'radial-gradient(1100px 650px at 50% 110%, #6b2e2a 0%, transparent 60%), radial-gradient(900px 600px at 0% 0%, #3d2a63 0%, transparent 60%), #1c1524' },
  night: { light: 'radial-gradient(1000px 700px at 80% 0%, #9aa6dc 0%, transparent 60%), linear-gradient(180deg, #c9cfe8, #dcdff0)', dark: 'radial-gradient(1000px 700px at 80% 0%, #1f2b5a 0%, transparent 60%), linear-gradient(180deg, #0d1120, #141827)' },
  rain: { light: 'linear-gradient(180deg, #b9c3cf 0%, #d4dae2 60%, #e2e6eb 100%)', dark: 'linear-gradient(180deg, #151b23 0%, #1b222b 100%)' },
  cloud: { light: 'linear-gradient(180deg, #d3dae3 0%, #e7ebf0 100%)', dark: 'linear-gradient(180deg, #1a1f27, #20262e)' }
};
function autoBgKey() {
  const h = new Date().getHours();
  const wc = S.cache[`wx:${M().weather.lat.toFixed(3)},${M().weather.lon.toFixed(3)}`];
  const code = wc && wc.data ? Number(wc.data.current.weather_code) : 0;
  if (code >= 51) return 'rain';
  if (code === 3 || code === 45 || code === 48) return h >= 20 || h < 6 ? 'night' : 'cloud';
  return h >= 6 && h < 9 ? 'dawn' : h >= 9 && h < 18 ? 'day' : h >= 18 && h < 21 ? 'sunset' : 'night';
}
async function loadBing(force) {
  return cached('bing', 360, 'https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=es-AR', (t) => {
    const im = JSON.parse(t).images[0];
    return im ? { url: 'https://www.bing.com' + im.urlbase + '_1920x1080.jpg', credit: im.copyright || '' } : null;
  }, force);
}

// ---------- Resumen del día ----------
const BRIEF_COLOR = { cal: '#3a86d6', check: '#2f9e44', note: '#e0533d', game: '#e10600', money: '#1f9d6b' };
function briefCard(icon, title, lines, w, color) {
  const card = el('div', { class: 'b-card' + (w ? ' link' : ''), style: `--bc:${color || BRIEF_COLOR[icon] || 'var(--accent)'}` },
    el('div', { class: 'b-h' }, el('span', { class: 'b-ico' }, svg(SICON[icon] || SICON.app)), el('span', { text: title }), w ? el('span', { class: 'b-go', text: '→' }) : null),
    ...lines.map(l => el('div', { class: 'b-l' + (l.strong ? ' strong' : '') + (l.muted ? ' muted' : '') }, l.text)));
  if (w) card.onclick = () => { closeBrief(); openWidget(w, true); };
  return card;
}
function openBrief() {
  const now = new Date();
  const h = now.getHours();
  const name = (S.settings.name || '').trim();
  $('#brief-date').textContent = fmt(now, { weekday: 'long', day: 'numeric', month: 'long' }).replace(/^\w/, c => c.toUpperCase());
  $('#brief-hello').textContent = (h >= 6 && h < 12 ? 'Buen día' : h >= 12 && h < 20 ? 'Buenas tardes' : 'Buenas noches') + (name ? `, ${name}` : '');
  // clima
  const wc = S.cache[`wx:${M().weather.lat.toFixed(3)},${M().weather.lon.toFixed(3)}`];
  const cur0 = wc && wc.data ? wc.data.current : null;
  const sky = briefSky(cur0 ? cur0.weather_code : null, cur0 ? cur0.is_day !== 0 : (h >= 7 && h < 20), h);
  const hero = $('#brief-hero');
  hero.dataset.sky = sky;
  $('#brief-art').innerHTML = BRIEF_ART[sky] || BRIEF_ART.sun;
  // cuánto del día pasó y cuánto falta para el finde
  const dayPct = Math.round(100 * (h * 60 + now.getMinutes()) / 1440);
  $('#brief-day').firstElementChild.style.width = dayPct + '%';
  const wd = now.getDay();
  $('#brief-line').textContent = wd === 0 || wd === 6 ? '¡Es fin de semana! Disfrutalo.'
    : wd === 5 ? 'Último día de la semana, ya casi.'
    : `Faltan ${5 - wd + 1 > 1 ? plural(6 - wd, 'día', 'días') : '1 día'} para el finde.`;
  const wx = $('#brief-wx');
  wx.replaceChildren();
  if (wc && wc.data) {
    const cur = wc.data.current, dd = wc.data.daily;
    const [desc, ic] = wmo(cur.weather_code, cur.is_day !== 0);
    const rain = dd.precipitation_probability_max ? dd.precipitation_probability_max[0] : null;
    wx.append(svg(WX[ic]), el('div', {}, el('b', { text: `${Math.round(cur.temperature_2m)}°` }),
      el('span', { text: `${desc} · máx ${Math.round(dd.temperature_2m_max[0])}° mín ${Math.round(dd.temperature_2m_min[0])}°${rain >= 30 ? ` · lluvia ${rain}%` : ''}` }),
      rain >= 50 ? el('span', { class: 'tip', text: 'Llevá paraguas ☂' }) : null));
  }
  const grid = $('#brief-grid');
  grid.replaceChildren();
  const today = ymd(now);
  // agenda
  const evs = allEvents().filter(e => e.date === today).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  grid.append(briefCard('cal', 'Agenda de hoy', evs.length
    ? evs.slice(0, 4).map(e => ({ text: `${e.time || 'Todo el día'} · ${e.title}` })).concat(evs.length > 4 ? [{ text: `y ${evs.length - 4} más`, muted: true }] : [])
    : [{ text: 'Nada agendado. Día libre.', muted: true }], 'agenda'));
  // tareas
  const pend = M().tasks.filter(t => !t.done);
  const hoy = pend.filter(t => t.due === today), late = pend.filter(t => t.due && t.due < today), prio = pend.filter(t => t.prio);
  const tl = [];
  if (late.length) tl.push({ text: `${plural(late.length, 'tarea vencida', 'tareas vencidas')}`, strong: true });
  hoy.slice(0, 3).forEach(t => tl.push({ text: `Hoy: ${t.text}` }));
  prio.filter(t => !hoy.includes(t)).slice(0, 2).forEach(t => tl.push({ text: `Importante: ${t.text}` }));
  if (!tl.length) tl.push({ text: pend.length ? `${plural(pend.length, 'pendiente', 'pendientes')}, nada urgente` : 'Sin pendientes 🎉', muted: !pend.length });
  grid.append(briefCard('check', 'Tareas', tl, 'tasks'));
  // correo
  const ml = [];
  for (const mode of (SINGLE ? ['casa'] : ['casa', 'trabajo'])) {
    const a = acct(mode);
    const c = S.cache['gmail:' + mode];
    if (a && c && c.data) ml.push({ text: `${modeName(mode)}: ${c.data.unread ? plural(c.data.unread, 'mail sin leer', 'mails sin leer') : 'al día'}`, strong: mode === S.activeMode && c.data.unread > 0 });
  }
  if (ml.length) grid.append(briefCard('note', 'Correo', ml, 'mail'));
  // sección elegida
  const tp = topic();
  if (tp && tp.kind === 'f1') {
    const n = nextF1();
    if (n) grid.append(briefCard('game', 'Fórmula 1', [{ text: `${n.name} · ${n.gp.replace(/^GP de /, '')}`, strong: true }, { text: n.start <= Date.now() ? 'En vivo ahora' : `${f1When(n.start)} (${countdown(n.start - Date.now())})` }], 'f1'));
  } else if (tp && tp.kind === 'team') {
    const m = nextMatch();
    if (m) grid.append(briefCard('game', tp.name, [{ text: `${m.home.name} vs ${m.away.name}`, strong: true }, { text: `${f1When(m.start)} (${countdown(m.start - Date.now())})` }], 'f1'));
  }
  // dólar
  const blue = dolarData().find(x => x.casa === 'blue'), of = dolarData().find(x => x.casa === 'oficial');
  if (blue) grid.append(briefCard('money', 'Dólar', [{ text: `Blue ${money(blue.venta)}`, strong: true }, of ? { text: `Oficial ${money(of.venta)}` } : { text: '' }], widgetOn('dolar') ? 'dolar' : null));
  // frase / efeméride
  // números del día, con cuenta animada
  const unread = (S.cache['gmail:' + S.activeMode] || {}).data;
  const stats = [
    ['cal', evs.length, evs.length === 1 ? 'evento hoy' : 'eventos hoy'],
    ['check', pend.length, pend.length === 1 ? 'pendiente' : 'pendientes'],
    late.length ? ['check', late.length, late.length === 1 ? 'vencida' : 'vencidas', '#e0533d'] : null,
    unread && acct() ? ['note', unread.unread || 0, (unread.unread || 0) === 1 ? 'mail sin leer' : 'mails sin leer'] : null,
    M().habits && M().habits.length ? ['check', `${M().habits.filter(x => x.days && x.days[today]).length}/${M().habits.length}`, 'hábitos'] : null
  ].filter(Boolean);
  const st = $('#brief-stats');
  st.replaceChildren(...stats.map(([ic, n, label, c], i) => {
    const b = el('b', { 'data-n': String(n), text: typeof n === 'number' ? '0' : String(n) });
    return el('div', { class: 'b-stat', style: `--bc:${c || BRIEF_COLOR[ic]};--i:${i}` }, el('span', { class: 'b-ico' }, svg(SICON[ic])), b, el('span', { text: label }));
  }));
  countUp(st);
  [...grid.children].forEach((c, i) => c.style.setProperty('--i', i + stats.length));
  const it = dailyItem();
  const bd = $('#brief-daily');
  bd.replaceChildren();
  if (it) bd.append(el('span', { class: 'd-meta', text: it.meta + ': ' }), it.kind === 'frase' ? `“${it.text}”` : it.text);
  $('#brief-auto').checked = S.settings.brief !== false;
  $('#brief').hidden = false;
  $('#brief-go').focus();
}
function closeBrief() { $('#brief').hidden = true; }
function countUp(root) {
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  for (const b of root.querySelectorAll('b[data-n]')) {
    const target = Number(b.dataset.n);
    if (!isFinite(target)) continue;
    if (reduce || target === 0) { b.textContent = String(target); continue; }
    const t0 = performance.now(), dur = 700 + Math.min(target, 30) * 20;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur);
      b.textContent = String(Math.round(target * (1 - Math.pow(1 - k, 3))));
      if (k < 1) requestAnimationFrame(step);
    };
    setTimeout(() => requestAnimationFrame(step), 250);
  }
}
function briefSky(code, isDay, h) {
  const c = Number(code);
  if (code != null) {
    if (c >= 95) return 'storm';
    if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return 'rain';
    if ((c >= 71 && c <= 77) || c === 85 || c === 86) return 'snow';
    if (c === 3 || c === 45 || c === 48) return isDay ? 'cloud' : 'night';
  }
  if (!isDay) return 'night';
  return h < 11 ? 'dawn' : 'sun';
}
const BRIEF_ART = {
  sun: '<div class="ba-sun"><i></i></div><div class="ba-cloud c1"></div><div class="ba-cloud c2"></div>',
  dawn: '<div class="ba-sun low"><i></i></div><div class="ba-cloud c1"></div><div class="ba-bird b1"></div><div class="ba-bird b2"></div>',
  cloud: '<div class="ba-cloud big c1"></div><div class="ba-cloud c2"></div><div class="ba-cloud c3"></div>',
  rain: '<div class="ba-cloud big dark c1"></div><div class="ba-cloud dark c3"></div><div class="ba-rain">' + '<i></i>'.repeat(26) + '</div>',
  storm: '<div class="ba-cloud big dark c1"></div><div class="ba-cloud dark c3"></div><div class="ba-bolt"></div><div class="ba-rain">' + '<i></i>'.repeat(26) + '</div>',
  snow: '<div class="ba-cloud big c1"></div><div class="ba-snow">' + '<i></i>'.repeat(22) + '</div>',
  night: '<div class="ba-moon"></div><div class="ba-stars">' + '<i></i>'.repeat(18) + '</div><div class="ba-cloud dim c2"></div>'
};
function maybeAutoBrief() {
  if (S.settings.brief === false) return;
  const today = ymd(new Date());
  if (S.settings.briefDay === today) return;
  S.settings.briefDay = today;
  save();
  openBrief();
}
function setupBrief() {
  $('#brief-go').onclick = closeBrief;
  $('#brief').addEventListener('pointerdown', (e) => { if (e.target.id === 'brief') closeBrief(); });
  $('#brief-auto').onchange = (e) => { S.settings.brief = e.target.checked; save(); };
  $('#greeting').onclick = openBrief;
  $('#daily').onclick = () => { ui.dailyShift = (ui.dailyShift || 0) + 1; renderDaily(); };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#brief').hidden) closeBrief(); });
}

// ---------- Dibujitos de cada tarjeta ----------
// .a = relleno del color principal, .s = trazo, .p = papel (claro), .k = detalle oscuro
const CARD_ART = {
  tasks: '<rect class="p s" x="14" y="10" width="36" height="46" rx="5"/><rect class="a" x="24" y="6" width="16" height="9" rx="3"/><path class="s" d="M21 25l3 3 6-6M21 37l3 3 6-6"/><path class="s" d="M34 26h9M34 38h9M21 49h22"/>',
  agenda: '<rect class="p s" x="9" y="13" width="46" height="42" rx="6"/><path class="a" d="M9 19a6 6 0 0 1 6-6h34a6 6 0 0 1 6 6v6H9z"/><path class="s" d="M20 8v10M44 8v10"/><g class="k"><circle cx="20" cy="34" r="2.4"/><circle cx="32" cy="34" r="2.4"/><circle cx="20" cy="45" r="2.4"/><circle cx="44" cy="45" r="2.4"/></g><circle class="a" cx="44" cy="34" r="4.5"/>',
  mail: '<rect class="p s" x="7" y="15" width="50" height="36" rx="5"/><path class="s" d="M8 18l24 18 24-18M8 49l17-15M56 49L39 34"/><circle class="a" cx="52" cy="15" r="7"/>',
  notes: '<path class="p s" d="M12 9h40v32L38 55H12z"/><path class="a" d="M38 55V41h14z"/><path class="s" d="M19 21h26M19 30h26M19 39h13"/><path class="a s" d="M44 6l9 9-14 14-11 2 2-11z"/>',
  f1: '<path class="s" d="M14 58V8"/><path class="p s" d="M14 10h38v28H14z"/><g class="k"><rect x="14" y="10" width="9.5" height="9.3"/><rect x="33" y="10" width="9.5" height="9.3"/><rect x="23.5" y="19.3" width="9.5" height="9.3"/><rect x="42.5" y="19.3" width="9.5" height="9.3"/><rect x="14" y="28.6" width="9.5" height="9.4"/><rect x="33" y="28.6" width="9.5" height="9.4"/></g><circle class="a" cx="14" cy="8" r="4"/>',
  'f1-team': '<circle class="p s" cx="32" cy="32" r="24"/><path class="k" d="M32 22l9 6.5-3.4 10.6H26.4L23 28.5z"/><path class="s" d="M32 22v-14M41 28.5l12-5M37.6 39.1l7.6 11M26.4 39.1l-7.6 11M23 28.5l-12-5"/><circle class="a" cx="50" cy="12" r="5"/>',
  'f1-tema': '<rect class="p s" x="8" y="12" width="42" height="42" rx="4"/><path class="p s" d="M50 22h7v26a6 6 0 0 1-6 6h-1"/><rect class="a" x="15" y="20" width="16" height="13" rx="2"/><path class="s" d="M36 21h8M36 28h8M15 40h29M15 47h22"/>',
  news: '<rect class="p s" x="8" y="12" width="42" height="42" rx="4"/><path class="p s" d="M50 22h7v26a6 6 0 0 1-6 6h-1"/><rect class="a" x="15" y="20" width="16" height="13" rx="2"/><path class="s" d="M36 21h8M36 28h8M15 40h29M15 47h22"/>',
  games: '<path class="p s" d="M20 20h24c8 0 12 6 13 14l1 9c1 6-6 9-10 4l-5-6H21l-5 6c-4 5-11 2-10-4l1-9c1-8 5-14 13-14z"/><path class="s" d="M20 27v10M15 32h10"/><circle class="a" cx="42" cy="29" r="3.2"/><circle class="k" cx="48" cy="35" r="3.2"/><path class="s" d="M32 20v-6c0-4 6-4 6-8"/>',
  stream: '<rect class="p s" x="6" y="14" width="52" height="34" rx="5"/><rect class="a" x="11" y="19" width="42" height="24" rx="2"/><path class="k" d="M28 25l10 6-10 6z"/><path class="s" d="M22 56h20M32 48v8M24 6l8 8 8-8"/>',
  social: '<path class="p s" d="M8 14a6 6 0 0 1 6-6h22a6 6 0 0 1 6 6v12a6 6 0 0 1-6 6H20l-8 7v-7.5A6 6 0 0 1 8 26z"/><path class="a s" d="M56 32a6 6 0 0 0-6-6H30a6 6 0 0 0-6 6v11a6 6 0 0 0 6 6h14l8 7v-7.4a6 6 0 0 0 4-5.6z"/><g class="k"><circle cx="17" cy="20" r="2"/><circle cx="25" cy="20" r="2"/><circle cx="33" cy="20" r="2"/></g><path class="p" d="M40 44.5l-5-4.6a3.1 3.1 0 1 1 5-3.6 3.1 3.1 0 1 1 5 3.6z"/>',
  dolar: '<rect class="p s" x="4" y="16" width="56" height="32" rx="4" transform="rotate(-8 32 32)"/><g transform="rotate(-8 32 32)"><rect class="a" x="9" y="21" width="46" height="22" rx="2"/><circle class="p" cx="32" cy="32" r="8.5"/><path class="s" d="M35 28.5c-1-1.3-6-1.6-6 1.2 0 3 6 1.6 6 4.6 0 2.6-5 2.5-6.4 1M32 25.5v13"/><circle class="k" cx="15" cy="32" r="2"/><circle class="k" cx="49" cy="32" r="2"/></g>',
  pomodoro: '<path class="a s" d="M32 18c13 0 23 9 23 20s-10 19-23 19S9 49 9 38s10-20 23-20z"/><path class="k" d="M32 19c-3-6-9-7-13-5 4 1 6 3 7 6-5-1-9 1-10 4 5-1 10 0 13 1 3-1 9-2 14-1-1-3-5-5-10-4 1-3 3-5 7-6-4-2-10-1-8 5z"/><path class="p s" d="M32 31v8l6 4"/>',
  sistema: '<rect class="p s" x="16" y="16" width="32" height="32" rx="4"/><rect class="a" x="23" y="23" width="18" height="18" rx="2"/><path class="s" d="M24 16V8M32 16V8M40 16V8M24 56v-8M32 56v-8M40 56v-8M16 24H8M16 32H8M16 40H8M56 24h-8M56 32h-8M56 40h-8"/><path class="k" d="M27 36l4-6 3 4 3-5"/>',
  relojes: '<circle class="p s" cx="32" cy="32" r="24"/><path class="a" d="M20 16c4 3 9 1 11 5s-3 7 0 11 8 2 9 7-4 9-8 11c-7-4-5-10-9-13s-10-4-11-9 4-10 8-12zM44 14c3 3 8 7 9 13-4 1-7-2-9-5s-3-5 0-8z"/><path class="s" d="M8 32h48M32 8c-8 8-8 40 0 48M32 8c8 8 8 40 0 48"/>',
  feriados: '<path class="s" d="M32 26v32"/><path class="a s" d="M6 28C8 14 19 7 32 7s24 7 26 21c-4-3-9-3-13 0-4-3-9-3-13 0-4-3-9-3-13 0-4-3-9-3-13 0z"/><path class="s" d="M19 28c1-10 6-18 13-21M45 28c-1-10-6-18-13-21"/><path class="p s" d="M10 58c5-5 11-6 22-6s17 1 22 6z"/>',
  pronostico: '<circle class="a" cx="22" cy="22" r="10"/><path class="s" d="M22 5v4M22 35v4M5 22h4M35 22h4M10 10l3 3M31 31l3 3M10 34l3-3M31 13l3-3"/><path class="p s" d="M24 52h24a9 9 0 0 0 1-18 13 13 0 0 0-25 3 7.5 7.5 0 0 0 0 15z"/>',
  cuenta: '<path class="s" d="M16 6h32M16 58h32"/><path class="p s" d="M19 6v6c0 9 10 13 10 20s-10 11-10 20v6h26v-6c0-9-10-13-10-20s10-11 10-20V6z"/><path class="a" d="M24 51c0-5 8-8 8-12 0 4 8 7 8 12v3H24zM24 15h16c-1 4-5 7-8 9-3-2-7-5-8-9z"/>',
  habitos: '<path class="a s" d="M32 6c3 9 14 14 14 28a14 14 0 0 1-28 0c0-7 4-11 6-13 1 5 3 7 5 7-1-8 0-15 3-22z"/><path class="p" d="M32 54a7 7 0 0 1-7-7c0-5 4-7 6-11 1 3 8 6 8 11a7 7 0 0 1-7 7z"/><g class="s"><circle cx="9" cy="57" r="3"/><circle cx="55" cy="57" r="3"/></g>',
  super: '<path class="s" d="M6 14h40l-5 22H12z"/><path class="a s" d="M10 18h32l-4 15H14z"/><circle class="p s" cx="18" cy="46" r="4"/><circle class="p s" cx="38" cy="46" r="4"/><path class="s" d="M2 8h6l4 6"/><path class="k" d="M22 8c0-4 4-6 8-4 2 1 3 3 2 6"/>',
  luces: '<path class="a s" d="M32 6a17 17 0 0 0-10 30.7c2 1.6 3 3.6 3 6.3h14c0-2.7 1-4.7 3-6.3A17 17 0 0 0 32 6z"/><path class="s" d="M25 49h14M27 55h10"/><path class="k" d="M27 26l5 6 5-6"/><g class="p s"><path d="M8 14l5 3M56 14l-5 3M4 30h6M60 30h-6"/></g>',
  calc: '<rect class="p s" x="12" y="4" width="40" height="56" rx="6"/><rect class="a s" x="18" y="10" width="28" height="12" rx="2"/><g class="s"><rect x="18" y="28" width="7" height="6" rx="1.5"/><rect x="28.5" y="28" width="7" height="6" rx="1.5"/><rect class="k" x="39" y="28" width="7" height="6" rx="1.5"/><rect x="18" y="38" width="7" height="6" rx="1.5"/><rect x="28.5" y="38" width="7" height="6" rx="1.5"/><rect class="k" x="39" y="38" width="7" height="16" rx="1.5"/><rect x="18" y="48" width="17.5" height="6" rx="1.5"/></g>',
  gastos: '<rect class="k" x="14" y="20" width="44" height="30" rx="5"/><rect class="a s" x="6" y="12" width="44" height="30" rx="5"/><path class="s" d="M6 21h44"/><path class="p s" d="M12 32h10M12 36h6"/><circle class="p" cx="42" cy="33" r="4"/>',
  cripto: '<circle class="k" cx="38" cy="38" r="20"/><circle class="a s" cx="28" cy="28" r="21"/><circle class="s" cx="28" cy="28" r="15"/><path class="p s" d="M24 19h7c6 0 6 8 0 8h-7zM24 27h8c6 0 6 9 0 9h-8zM24 19v17M27 15v4M27 36v4"/>'
};
function cardArt(id) {
  const k = id === 'f1' ? (topic() && topic().kind !== 'f1' ? (topic().kind === 'team' ? 'f1-team' : 'f1-tema') : 'f1') : id;
  return CARD_ART[k] || '';
}
function artEl(id, cls = 'pk-art') {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 64 64');
  s.setAttribute('aria-hidden', 'true');
  s.setAttribute('class', cls);
  s.innerHTML = cardArt(id);
  return s;
}
function renderCardArt() {
  for (const w of $$('.widgets .w')) {
    const peek = w.querySelector('.peek');
    if (!peek) continue;
    let a = peek.querySelector('.pk-art');
    const html = cardArt(w.dataset.w);
    if (!a) { a = artEl(w.dataset.w); peek.prepend(a); }
    else if (a.dataset.k !== html.length + '') a.innerHTML = html;
    a.dataset.k = html.length + '';
  }
}

// ---------- Editar escritorio: qué tarjetas se ven y en qué orden ----------
const MAX_WIDGETS = 8;
const WIDGETS = [
  { id: 'tasks', n: 'Tareas', d: 'Tus pendientes con prioridad y fecha.' },
  { id: 'agenda', n: 'Agenda', d: 'Calendario, eventos y avisos (con Google Calendar).' },
  { id: 'mail', n: 'Correo', d: 'Mails sin leer de Gmail; leerlos y marcarlos.' },
  { id: 'notes', n: 'Notas', d: 'Notas rápidas que se guardan solas.' },
  { id: 'f1', n: 'Noticias y deportes', d: 'F1, tu equipo de fútbol o el tema que quieras.' },
  { id: 'games', n: 'Juegos', d: 'Tus juegos de Steam y Xbox / Game Pass.' },
  { id: 'stream', n: 'Streaming', d: 'YouTube, Netflix, Disney+, Spotify y más.' },
  { id: 'social', n: 'Redes', d: 'WhatsApp, Instagram, X, Discord y más, a un clic.' },
  { id: 'dolar', n: 'Dólar', d: 'Oficial, blue, MEP, tarjeta y conversor.' },
  { id: 'pomodoro', n: 'Pomodoro', d: 'Temporizador para concentrarte y hacer pausas.' },
  { id: 'sistema', n: 'Rendimiento', d: 'Procesador, memoria, disco y batería.' },
  { id: 'relojes', n: 'Relojes del mundo', d: 'La hora en otras ciudades.' },
  { id: 'news', nueva: true, n: 'Noticias', d: 'Tus temas en una barra deslizante; tocá una nota para leerla acá.' },
  { id: 'pronostico', nueva: true, n: 'Pronóstico', d: 'Hora por hora y los próximos 7 días.' },
  { id: 'feriados', nueva: true, n: 'Feriados', d: 'Próximos feriados y fines de semana largos.' },
  { id: 'cuenta', nueva: true, n: 'Cuenta regresiva', d: 'Cuántos días faltan para lo que esperás.' },
  { id: 'habitos', nueva: true, n: 'Hábitos', d: 'Marcá tus hábitos diarios y mantené la racha.' },
  { id: 'cripto', nueva: true, n: 'Cripto', d: 'Bitcoin, Ethereum y más, en dólares o pesos.' },
  { id: 'super', nueva: true, n: 'Supermercado', d: 'La lista de lo que falta en casa, ordenada por sección del súper.' },
  { id: 'luces', nueva: true, n: 'Luces', d: 'Prendé, apagá y cambiá el color de tus lamparitas Smart Life.' },
  { id: 'calc', nueva: true, n: 'Calculadora', d: 'Cuentas rápidas con el teclado o el mouse, con historial.' },
  { id: 'gastos', nueva: true, n: 'Gastos con tarjeta', d: 'Cuánto llevás gastado con Visa y Amex, leído de los avisos de consumo de tu mail.' }
];
const DEFAULT_LAYOUT = {
  casa: ['tasks', 'agenda', 'mail', 'notes', 'f1', 'games', 'stream', 'social'],
  trabajo: ['tasks', 'agenda', 'mail', 'notes', 'dolar', 'relojes']
};
function layout(mode = S.activeMode) {
  const m = S.modes[mode];
  if (!Array.isArray(m.widgets)) m.widgets = DEFAULT_LAYOUT[mode].slice();
  return m.widgets;
}
const widgetOn = (id) => !!S && layout().includes(id);
function applyWidgetLayout() {
  const list = layout();
  for (const w of $$('.widgets .w')) {
    const i = list.indexOf(w.dataset.w);
    w.hidden = i < 0;
    w.style.order = i < 0 ? 99 : i; // con "order" no se mueve el elemento (así Redes no se recarga)
  }
  const editing = document.documentElement.classList.contains('desk-edit');
  $('#w-add-slot').hidden = !editing || list.length >= MAX_WIDGETS;
  setText('wbar-count', `${list.length} de ${MAX_WIDGETS}`);
  $('#wbar-add').disabled = list.length >= MAX_WIDGETS;
  $('#wbar-add').title = list.length >= MAX_WIDGETS ? 'Ya tenés 8: quitá una para sumar otra' : '';
}
function setDeskEdit(on) {
  closeWidget(true);
  document.documentElement.classList.toggle('desk-edit', on);
  for (const w of $$('.widgets .w')) w.draggable = on;
  applyWidgetLayout();
  if (on) toast('Arrastrá las tarjetas para ordenarlas. ✕ para quitarlas.');
}
function removeWidget(id) {
  const list = layout();
  const i = list.indexOf(id);
  if (i < 0) return;
  list.splice(i, 1);
  save(); applyWidgetLayout(); renderPeeks();
  const w = WIDGETS.find(x => x.id === id);
  toast(`Quitaste ${w ? w.n : 'la tarjeta'}`, { label: 'Deshacer', fn: () => { list.splice(i, 0, id); save(); applyWidgetLayout(); renderAll(); } });
}
function addWidget(id) {
  const list = layout();
  if (list.includes(id)) return;
  if (list.length >= MAX_WIDGETS) return toast('Ya tenés 8 tarjetas: quitá una para sumar otra');
  list.push(id);
  save(); applyWidgetLayout(); renderAll();
  if (id === 'dolar') loadDolar(true);
  if (id === 'sistema') loadSistema();
  if (id === 'games' || id === 'stream' || id === 'social') { loadGames(true); loadStartApps(true); }
  if (id === 'f1') loadTopicData(false);
  if (id === 'news') loadNewsW(false);
  if (id === 'feriados') loadFeriados(false);
  if (id === 'pronostico') loadPronostico(false);
  if (id === 'cripto') loadCripto(false);
  if (id === 'gastos') loadCC(true);
  $('#dlg-gallery').close();
  const w = WIDGETS.find(x => x.id === id);
  toast(`Agregaste ${w.n}`);
}
function openGallery() {
  const list = layout();
  const g = $('#gallery');
  g.replaceChildren();
  const full = list.length >= MAX_WIDGETS;
  $('#gal-hint').textContent = full
    ? 'Ya tenés 8 tarjetas, que es el máximo. Quitá una con la ✕ para sumar otra.'
    : `Tenés ${list.length} de ${MAX_WIDGETS}. Tocá una para sumarla al final de la fila.`;
  for (const w of WIDGETS) {
    const on = list.includes(w.id);
    const src = $(`#peek-${w.id} .pk-label svg`);
    const ico = el('span', { class: 'gal-ico' });
    if (src) ico.append(src.cloneNode(true));
    const b = el('button', { type: 'button', class: 'gal-item' + (on ? ' on' : ''), disabled: on || full ? true : null },
      artEl(w.id, 'gal-art'), ico, el('span', { class: 'gal-n' }, w.n, w.nueva && !on ? el('span', { class: 'gal-new', text: 'Nueva' }) : null), el('span', { class: 'gal-d', text: w.d }),
      el('span', { class: 'gal-s', text: on ? 'Ya está en tu escritorio' : full ? 'Llegaste a 8' : 'Agregar' }));
    b.onclick = () => addWidget(w.id);
    g.append(b);
  }
  $('#dlg-gallery').showModal();
}
function setupDeskEdit() {
  const nav = $('.widgets');
  // ✕ para quitar y "+" para agregar
  for (const w of $$('.widgets .w')) {
    const x = el('button', { class: 'w-x', title: 'Quitar del escritorio', 'aria-label': 'Quitar tarjeta' }, svg(ICON.x));
    x.onclick = (e) => { e.stopPropagation(); removeWidget(w.dataset.w); };
    w.append(x);
    w.addEventListener('dragstart', (e) => {
      if (!document.documentElement.classList.contains('desk-edit')) return e.preventDefault();
      ui.wDrag = w.dataset.w;
      e.dataTransfer.setData('text/x-base-widget', w.dataset.w);
      e.dataTransfer.effectAllowed = 'move';
      requestAnimationFrame(() => w.classList.add('dragging'));
    });
    w.addEventListener('dragend', () => { w.classList.remove('dragging'); $$('.w.drop-l, .w.drop-r').forEach(n => n.classList.remove('drop-l', 'drop-r')); ui.wDrag = null; });
    w.addEventListener('dragover', (e) => {
      if (!ui.wDrag || ui.wDrag === w.dataset.w) return;
      e.preventDefault();
      const r = w.getBoundingClientRect();
      const left = e.clientX < r.left + r.width / 2;
      w.classList.toggle('drop-l', left); w.classList.toggle('drop-r', !left);
    });
    w.addEventListener('dragleave', () => w.classList.remove('drop-l', 'drop-r'));
    w.addEventListener('drop', (e) => {
      const id = e.dataTransfer.getData('text/x-base-widget');
      if (!id || id === w.dataset.w) return;
      e.preventDefault();
      const left = w.classList.contains('drop-l');
      w.classList.remove('drop-l', 'drop-r');
      const list = layout();
      list.splice(list.indexOf(id), 1);
      list.splice(list.indexOf(w.dataset.w) + (left ? 0 : 1), 0, id);
      save(); applyWidgetLayout();
    });
  }
  const slot = el('button', { class: 'w-add', id: 'w-add-slot', title: 'Agregar tarjeta', hidden: true }, svg(ICON.plus), el('span', { text: 'Agregar' }));
  slot.style.order = 98;
  slot.onclick = openGallery;
  nav.append(slot);
  $('#wbar-edit').onclick = () => setDeskEdit(true);
  $('#wbar-done').onclick = () => setDeskEdit(false);
  $('#wbar-add').onclick = openGallery;
  $('#btn-edit-desk').onclick = () => { openDrawer(false); setDeskEdit(true); };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && document.documentElement.classList.contains('desk-edit') && !document.querySelector('dialog[open]')) setDeskEdit(false); });
}

// ---------- Dólar ----------
const DOLAR_ORDER = ['blue', 'oficial', 'bolsa', 'contadoconliqui', 'tarjeta', 'cripto', 'mayorista'];
const DOLAR_NAME = { blue: 'Blue', oficial: 'Oficial', bolsa: 'MEP', contadoconliqui: 'CCL', tarjeta: 'Tarjeta', cripto: 'Cripto', mayorista: 'Mayorista' };
const money = (n, dec = 0) => n == null || isNaN(n) ? '—' : '$' + Number(n).toLocaleString('es-AR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
const dolarData = () => (S.cache.dolar && S.cache.dolar.data) || [];
async function loadDolar(force, always) {
  if (!widgetOn('dolar') && !always) return;
  await cached('dolar', 15, 'https://dolarapi.com/v1/dolares', (t) => { const j = JSON.parse(t); return Array.isArray(j) && j.length ? j : null; }, force);
  renderDolar(); renderPeeks();
}
function renderDolar() {
  if (!widgetOn('dolar')) return;
  const data = dolarData().slice().sort((a, b) => DOLAR_ORDER.indexOf(a.casa) - DOLAR_ORDER.indexOf(b.casa));
  const list = $('#dolar-list');
  list.replaceChildren();
  if (!data.length) { list.append(el('li', { class: 'empty', text: 'Cargando cotizaciones…' })); return; }
  list.append(el('li', { class: 'dl-head' }, el('span'), el('span', { text: 'Compra' }), el('span', { text: 'Venta' })));
  for (const d of data) {
    list.append(el('li', { class: 'dl-row' + (d.casa === 'blue' ? ' main' : '') },
      el('span', { class: 'dl-n', text: DOLAR_NAME[d.casa] || d.nombre }),
      el('span', { class: 'dl-v', text: d.compra != null ? money(d.compra) : '—' }),
      el('span', { class: 'dl-v sell', text: money(d.venta) })));
  }
  const sel = $('#conv-type');
  if (sel.options.length !== data.length) {
    sel.replaceChildren(...data.map(d => el('option', { value: d.casa, text: DOLAR_NAME[d.casa] || d.nombre })));
    sel.value = S.settings.convType || 'blue';
  }
  convert();
  const upd = data.map(d => Date.parse(d.fechaActualizacion)).filter(Boolean).sort((a, b) => b - a)[0];
  setText('dolar-upd', upd ? `Actualizado ${ago(upd)} · Fuente: DolarApi` : '');
}
function convert() {
  const usd = parseFloat(String($('#conv-usd').value || '0').replace(/\./g, '').replace(',', '.'));
  const d = dolarData().find(x => x.casa === $('#conv-type').value);
  setText('conv-ars', d && usd ? money(usd * d.venta, 2) : '—');
}

// ---------- Pomodoro ----------
const POMO_LABEL = { focus: 'Concentración', short: 'Pausa', long: 'Pausa larga' };
function pomoCfg() {
  const p = S.settings.pomo = Object.assign({ f: 25, s: 5, l: 15, mode: 'focus', endAt: 0, left: 0, done: 0, day: '' }, S.settings.pomo || {});
  if (p.day !== ymd(new Date())) { p.day = ymd(new Date()); p.done = 0; }
  return p;
}
const pomoLen = (p, m = p.mode) => (m === 'focus' ? p.f : m === 'short' ? p.s : p.l) * 60000;
function pomoLeft(p) { return p.endAt ? Math.max(0, p.endAt - Date.now()) : (p.left || pomoLen(p)); }
function pomoSet(mode) {
  const p = pomoCfg();
  p.mode = mode; p.endAt = 0; p.left = 0;
  save(); renderPomo(); renderPeeks();
}
function pomoToggle() {
  const p = pomoCfg();
  if (p.endAt) { p.left = pomoLeft(p); p.endAt = 0; }
  else { p.endAt = Date.now() + pomoLeft(p); p.left = 0; }
  save(); renderPomo(); renderPeeks();
}
function pomoTick() {
  const p = S && S.settings.pomo;
  if (!p || !p.endAt || Date.now() < p.endAt) return;
  // terminó
  const was = p.mode;
  p.endAt = 0; p.left = 0;
  if (was === 'focus') {
    p.done++;
    p.mode = p.done % 4 === 0 ? 'long' : 'short';
    notify('pomo', '¡Bien! Terminaste un bloque de concentración', `Ahora: ${POMO_LABEL[p.mode].toLowerCase()} de ${p.mode === 'long' ? p.l : p.s} minutos. Tocá Empezar cuando quieras.`, { w: 'pomodoro' });
  } else {
    p.mode = 'focus';
    notify('pomo', 'Terminó la pausa', `¿Arrancamos otro bloque de ${p.f} minutos?`, { w: 'pomodoro' });
  }
  save(); renderPomo(); renderPeeks();
}
function renderPomo() {
  if (!widgetOn('pomodoro')) return;
  const p = pomoCfg();
  const left = pomoLeft(p);
  const total = pomoLen(p);
  const m = Math.floor(left / 60000), sec = Math.floor(left / 1000) % 60;
  setText('pomo-time', `${pad(m)}:${pad(sec)}`);
  setText('pomo-lbl', POMO_LABEL[p.mode] + (p.endAt ? '' : left < total ? ' · en pausa' : ''));
  const C = 2 * Math.PI * 88;
  const bar = $('#pomo-bar');
  bar.style.strokeDasharray = C;
  bar.style.strokeDashoffset = C * (1 - left / total);
  $('#pomo-ring').dataset.mode = p.mode;
  setText('pomo-start', p.endAt ? 'Pausar' : left < total ? 'Seguir' : 'Empezar');
  for (const b of $$('#pomo-modes button')) b.classList.toggle('on', b.dataset.m === p.mode);
  for (const [id, k] of [['pomo-f', 'f'], ['pomo-s', 's'], ['pomo-l', 'l']]) if (document.activeElement.id !== id) $('#' + id).value = p[k];
  setText('pomo-count', p.done ? `Hoy completaste ${plural(p.done, 'bloque', 'bloques')} de concentración.` : 'Cada 4 bloques de concentración te toca una pausa larga.');
}

// ---------- Rendimiento de la compu ----------
let sysStats = null, battery = null;
async function loadSistema() {
  if ((!widgetOn('sistema') && !zoneOn('pc')) || document.hidden) return;
  if (api.stats) {
    const r = await safeCall(() => api.stats(W.open === 'sistema'));
    if (r && r.mem) {
      // aviso cuando se conecta un pendrive o disco externo
      const prev = sysStats && sysStats.drives ? new Set(sysStats.drives.map(d => d.name)) : null;
      if (prev && Array.isArray(r.drives)) for (const d of r.drives) if (!prev.has(d.name) && d.type !== 'Fixed') toast(`Se conectó ${d.label || (d.type === 'Removable' ? 'un pendrive' : 'una unidad')} (${d.name})`, { label: 'Abrir', fn: () => api.openDrive && api.openDrive(d.name) });
      sysStats = r;
      const h = ui.sysHist = ui.sysHist || { cpu: [], mem: [], down: [], up: [] };
      const push = (k, v) => { h[k].push(v == null ? null : v); if (h[k].length > 40) h[k].shift(); };
      push('cpu', r.cpu); push('mem', Math.round(100 * (r.mem.total - r.mem.free) / r.mem.total));
      push('down', r.net ? r.net.down : null); push('up', r.net ? r.net.up : null);
    }
  }
  if (!battery && navigator.getBattery) { try { battery = await navigator.getBattery(); } catch {} }
  renderSistema(); renderPeeks(); zoneRefresh('pc');
}
const GB = (b) => b >= 1099511627776 ? (b / 1099511627776).toLocaleString('es-AR', { maximumFractionDigits: 1 }) + ' TB'
  : (b / 1073741824).toLocaleString('es-AR', { maximumFractionDigits: b > 100 * 1073741824 ? 0 : 1 }) + ' GB';
const RATE = (bps) => bps == null ? '—' : bps < 1024 ? `${Math.round(bps)} B/s` : bps < 1048576 ? `${Math.round(bps / 1024)} KB/s` : `${(bps / 1048576).toLocaleString('es-AR', { maximumFractionDigits: 1 })} MB/s`;
function meter(label, pct, detail) {
  const lvl = pct == null ? '' : pct >= 90 ? ' hi' : pct >= 70 ? ' mid' : '';
  return el('div', { class: 'meter' + lvl },
    el('div', { class: 'm-top' }, el('span', { text: label }), el('b', { text: pct == null ? '…' : pct + '%' })),
    el('div', { class: 'm-bar' }, el('span', { style: `width:${pct || 0}%` })),
    el('div', { class: 'm-d', text: detail || '' }));
}
// gráfico chiquito de los últimos 2 minutos
function spark(values, max, cls = '') {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 120 36'); s.setAttribute('preserveAspectRatio', 'none'); s.setAttribute('class', 'spark ' + cls);
  const v = values.map(x => x == null ? 0 : x);
  const m = max || Math.max(1, ...v);
  const n = Math.max(2, v.length);
  const pts = v.map((x, i) => `${(i / (n - 1)) * 120},${34 - (Math.min(x, m) / m) * 32}`);
  if (pts.length > 1) s.innerHTML = `<path class="area" d="M0,36 L${pts.join(' L')} L${((v.length - 1) / (n - 1)) * 120},36Z"/><path class="line" d="M${pts.join(' L')}"/>`;
  return s;
}
function ring(pct, label, sub, values, cls) {
  const lvl = pct == null ? '' : pct >= 90 ? ' hi' : pct >= 70 ? ' mid' : '';
  const C = 2 * Math.PI * 26;
  const r = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  r.setAttribute('viewBox', '0 0 64 64'); r.setAttribute('class', 'ring');
  r.innerHTML = `<circle cx="32" cy="32" r="26" class="tr"/><circle cx="32" cy="32" r="26" class="br" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - (pct || 0) / 100)}"/>`;
  return el('div', { class: 'sx-tile ' + (cls || '') + lvl },
    el('div', { class: 'sx-ring' }, r, el('b', { text: pct == null ? '…' : pct + '%' })),
    el('div', { class: 'sx-info' }, el('span', { class: 'sx-l', text: label }), el('span', { class: 'sx-s', text: sub })),
    spark(values || [], 100));
}
const DRIVE_ICON = {
  Fixed: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="17" cy="12" r="1.2" fill="currentColor"/><path d="M6 12h6"/>',
  Removable: '<path d="M9 2h6v6H9z"/><rect x="6" y="8" width="12" height="14" rx="2"/><path d="M11 4h.01M13 4h.01"/>',
  Network: '<rect x="3" y="4" width="18" height="8" rx="2"/><path d="M12 12v4M5 20h14M12 16v4"/>',
  CDRom: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/>'
};
const DRIVE_TYPE = { Fixed: 'Disco', Removable: 'Extraíble', Network: 'De red', CDRom: 'Lectora', Ram: 'RAM' };
function renderSistema() {
  if (!widgetOn('sistema')) return;
  const box = $('#meters');
  box.replaceChildren();
  const s2 = sysStats;
  if (!s2) { box.append(el('p', { class: 'empty', text: api.stats ? 'Midiendo…' : 'Disponible en la app instalada.' })); return; }
  const h = ui.sysHist || { cpu: [], mem: [], down: [], up: [] };
  const memUsed = s2.mem.total - s2.mem.free;
  const memPct = Math.round(100 * memUsed / s2.mem.total);
  const nCores = s2.coreCount || (Array.isArray(s2.cores) ? s2.cores.length : s2.cores) || 0;
  const top = el('div', { class: 'sx-top' },
    ring(s2.cpu, 'Procesador', `${nCores} núcleos${s2.mhz ? ` · ${(s2.mhz / 1000).toLocaleString('es-AR', { maximumFractionDigits: 1 })} GHz` : ''}`, h.cpu, 'cpu'),
    ring(memPct, 'Memoria', `${GB(memUsed)} de ${GB(s2.mem.total)}`, h.mem, 'mem'));
  const nt = s2.net;
  top.append(el('div', { class: 'sx-tile net' },
    el('div', { class: 'sx-net' },
      el('span', { class: 'dn' }, svg('<path d="M12 4v14M6 12l6 6 6-6"/>'), el('b', { text: RATE(nt && nt.down) })),
      el('span', { class: 'upl' }, svg('<path d="M12 20V6M6 12l6-6 6 6"/>'), el('b', { text: RATE(nt && nt.up) }))),
    el('div', { class: 'sx-info' }, el('span', { class: 'sx-l', text: 'Red' }),
      el('span', { class: 'sx-s', text: nt ? [nt.kind === 'Wireless80211' ? 'Wi-Fi' : nt.kind === 'Ethernet' ? 'Cable' : nt.name, nt.link ? `${Math.round(nt.link / 1e6)} Mbps` : ''].filter(Boolean).join(' · ') : 'Sin datos' })),
    spark(h.down || [], null, 'down')));
  box.append(top);
  if (Array.isArray(s2.cores) && s2.cores.length) {
    box.append(el('div', { class: 'sx-sec', text: 'Núcleos' }),
      el('div', { class: 'sx-cores' }, s2.cores.map((v, i) => el('span', { class: 'core' + (v >= 90 ? ' hi' : v >= 70 ? ' mid' : ''), title: `Núcleo ${i + 1}: ${v}%` }, el('i', { style: `height:${Math.max(3, v)}%` })))));
  }
  const drives = Array.isArray(s2.drives) && s2.drives.length ? s2.drives : s2.disk ? [{ ...s2.disk, type: 'Fixed', label: '' }] : [];
  if (drives.length) {
    box.append(el('div', { class: 'sx-sec', text: `Unidades (${drives.length})` }));
    const ul = el('div', { class: 'sx-drives' });
    for (const d of drives) {
      const pct = Math.round(100 * (1 - d.free / d.total));
      const lvl = pct >= 90 ? ' hi' : pct >= 75 ? ' mid' : '';
      const b = el('button', { class: 'drive' + lvl + (d.type === 'Removable' ? ' rem' : ''), title: `Abrir ${d.name}` },
        el('span', { class: 'dr-ico' }, svg(DRIVE_ICON[d.type] || DRIVE_ICON.Fixed)),
        el('span', { class: 'dr-n' }, el('b', {}, `${d.name} `, el('span', { text: d.label || (d.name.toUpperCase() === 'C:' ? 'Windows' : DRIVE_TYPE[d.type] || '') })),
          el('span', { class: 'dr-bar' }, el('i', { style: `width:${pct}%` })),
          el('small', { text: `${GB(d.free)} libres de ${GB(d.total)}${d.fs ? ' · ' + d.fs : ''}` })),
        el('span', { class: 'dr-p' }, el('b', { text: pct + '%' }), d.type && d.type !== 'Fixed' ? el('span', { class: 'dr-t', text: DRIVE_TYPE[d.type] || d.type }) : null));
      b.onclick = () => api.openDrive && api.openDrive(d.name);
      ul.append(b);
    }
    box.append(ul);
  }
  if (s2.procs && s2.procs.top && s2.procs.top.length) {
    box.append(el('div', { class: 'sx-sec', text: `Lo que más memoria usa · ${s2.procs.total} procesos` }));
    const maxM = s2.procs.top[0].m;
    box.append(el('div', { class: 'sx-procs' }, s2.procs.top.map(p => el('div', { class: 'proc' },
      el('span', { class: 'pn', text: p.n + (p.c > 1 ? ` (${p.c})` : '') }),
      el('span', { class: 'pb' }, el('i', { style: `width:${Math.max(4, 100 * p.m / maxM)}%` })),
      el('span', { class: 'pm', text: p.m >= 1073741824 ? GB(p.m) : Math.round(p.m / 1048576) + ' MB' })))));
  }
  const noBattery = battery && battery.level === 1 && battery.charging && battery.dischargingTime === Infinity && battery.chargingTime === 0;
  if (battery && !noBattery) {
    const mins = battery.charging ? battery.chargingTime : battery.dischargingTime;
    box.append(meter('Batería', Math.round(battery.level * 100), (battery.charging ? 'Cargando' : 'Con batería') + (isFinite(mins) && mins > 0 ? ` · ${battery.charging ? 'llena en' : 'quedan'} ${Math.floor(mins / 3600)} h ${Math.round(mins / 60) % 60} min` : '')));
  }
  const up = Math.floor(s2.uptime / 3600);
  const info = $('#sys-info');
  info.replaceChildren(...[
    ['Equipo', s2.cpuName.replace(/\(R\)|\(TM\)|CPU|@.*$/gi, '').replace(/\s+/g, ' ').trim()],
    ['Sistema', s2.osName ? `${s2.osName.replace(/^Windows 10/, Number((s2.osRelease || '').split('.')[2]) >= 22000 ? 'Windows 11' : 'Windows 10')}` : ''],
    ['Encendida hace', up >= 24 ? `${plural(Math.floor(up / 24), 'día', 'días')} ${up % 24} h` : plural(up, 'hora', 'horas')],
    ['IP local', s2.ip || '']
  ].filter(x => x[1]).map(([k, v]) => el('span', {}, el('small', { text: k }), el('b', { text: v }))));
}
// ---------- Relojes del mundo ----------
const CITIES = [
  ['America/Argentina/Buenos_Aires', 'Buenos Aires'], ['America/Sao_Paulo', 'San Pablo'], ['America/Santiago', 'Santiago'], ['America/Montevideo', 'Montevideo'],
  ['America/Bogota', 'Bogotá'], ['America/Lima', 'Lima'], ['America/Mexico_City', 'Ciudad de México'], ['America/New_York', 'Nueva York'],
  ['America/Chicago', 'Chicago'], ['America/Los_Angeles', 'Los Ángeles'], ['Europe/London', 'Londres'], ['Europe/Madrid', 'Madrid'],
  ['Europe/Paris', 'París'], ['Europe/Rome', 'Roma'], ['Europe/Berlin', 'Berlín'], ['Europe/Moscow', 'Moscú'], ['Asia/Dubai', 'Dubái'],
  ['Asia/Kolkata', 'Nueva Delhi'], ['Asia/Shanghai', 'Pekín'], ['Asia/Singapore', 'Singapur'], ['Asia/Tokyo', 'Tokio'], ['Australia/Sydney', 'Sídney']
];
const tzList = () => S.settings.tz || ['America/New_York', 'Europe/Madrid', 'Asia/Tokyo'];
function tzInfo(zone, now = new Date()) {
  const f = new Intl.DateTimeFormat('es-AR', { timeZone: zone, hour: '2-digit', minute: '2-digit', hour12: false, weekday: 'short' });
  const parts = Object.fromEntries(f.formatToParts(now).map(x => [x.type, x.value]));
  const local = new Date(now.toLocaleString('en-US', { timeZone: zone }));
  const here = new Date(now.toLocaleString('en-US'));
  const diff = Math.round((local - here) / 3600000);
  const h = Number(parts.hour) % 24;
  return { time: `${pad(h)}:${parts.minute}`, wd: parts.weekday, diff, night: h < 7 || h >= 20 };
}
function renderRelojes() {
  if (!widgetOn('relojes')) return;
  const list = $('#tz-list');
  const editing = !!ui.tzEdit;
  setText('tz-edit', editing ? 'Listo' : 'Elegir ciudades');
  list.replaceChildren();
  list.classList.toggle('editing', editing);
  const chosen = tzList();
  const zones = editing ? CITIES : chosen.map(z => CITIES.find(c => c[0] === z) || [z, z.split('/').pop().replace(/_/g, ' ')]);
  for (const [zone, name] of zones) {
    const i = tzInfo(zone);
    const on = chosen.includes(zone);
    const li = el('li', { class: 'tz' + (i.night ? ' night' : '') + (editing && !on ? ' off' : '') },
      el('span', { class: 'tz-ico' }, svg(i.night ? WX.moon : WX.sun)),
      el('span', { class: 'tz-n' }, el('b', { text: name }), el('span', { text: `${i.wd.replace('.', '')} · ${i.diff === 0 ? 'misma hora' : (i.diff > 0 ? '+' : '') + i.diff + ' h'}` })),
      el('span', { class: 'tz-t', text: i.time }));
    if (editing) {
      li.tabIndex = 0;
      li.onclick = () => {
        const cur = tzList().slice();
        const k = cur.indexOf(zone);
        if (k >= 0) cur.splice(k, 1); else cur.push(zone);
        S.settings.tz = cur; save(); renderRelojes(); renderPeeks();
      };
    }
    list.append(li);
  }
  if (!editing && !chosen.length) list.append(el('li', { class: 'empty', text: 'Tocá “Elegir ciudades”.' }));
}

// ---------- Noticias de tus temas (carrusel + vista previa) ----------
const NEWS_DEFAULT = { casa: ['Argentina', 'Tecnología', 'Deportes'], trabajo: ['Economía', 'Argentina', 'Negocios'] };
function nwTopics() {
  const m = M();
  if (!Array.isArray(m.newsTopics)) m.newsTopics = (NEWS_DEFAULT[S.activeMode] || NEWS_DEFAULT.casa).slice();
  return m.newsTopics;
}
const nwKey = (t) => 'nw:' + t.toLowerCase();
async function loadNewsW(force) {
  if (!widgetOn('news')) return;
  const ts = nwTopics();
  await Promise.all(ts.flatMap(t => {
    const q = encodeURIComponent(t);
    return [
      cached(nwKey(t) + ':b', 30, `https://www.bing.com/news/search?q=${q}&format=rss&setlang=es&cc=AR`, parseRss, force),
      cached(nwKey(t) + ':g', 30, `https://news.google.com/rss/search?q=${q}&hl=es-419&gl=AR&ceid=AR:es-419`, parseRss, force)
    ];
  }));
  renderNewsW(); renderPeeks();
}
function nwItemsOf(t) {
  const b = (S.cache[nwKey(t) + ':b'] || {}).data || [];
  const g = (S.cache[nwKey(t) + ':g'] || {}).data || [];
  const seen = new Set(b.map(i => normTitle(i.title)));
  return b.concat(g.filter(i => !seen.has(normTitle(i.title)))).map(i => ({ ...i, topic: t }));
}
function nwItems(sel = ui.nwSel || '*') {
  const ts = nwTopics();
  let list;
  if (sel !== '*' && ts.includes(sel)) list = nwItemsOf(sel);
  else {
    // "Todo": mezclamos los temas para que no gane siempre el mismo
    const per = ts.map(t => nwItemsOf(t).sort((a, b) => b.date - a.date));
    list = []; const seen = new Set();
    for (let i = 0; i < 25; i++) for (const arr of per) {
      const it = arr[i];
      if (it && !seen.has(normTitle(it.title))) { seen.add(normTitle(it.title)); list.push(it); }
    }
  }
  const dayAgo = Date.now() - 4 * 864e5;
  return list.filter(i => !i.date || i.date > dayAgo).sort((a, b) => b.date - a.date).slice(0, 48);
}
function nwPic(it, w, h) {
  const box = el('span', { class: 'nw-pic' });
  const ph = () => { box.classList.add('ph'); box.replaceChildren(el('span', { class: 'nw-ph', text: letterFor(it.source || it.topic) })); };
  if (it.image) {
    const img = el('img', { src: thumbUrl(it.image, w, h), alt: '', loading: 'lazy', draggable: 'false' });
    img.onerror = ph;
    box.append(img);
  } else {
    ph();
    // la nota no trajo foto (Google News casi nunca la manda): la buscamos en la página de la nota
    nwFetchImg(it).then(u => { if (u && box.isConnected) { const img = el('img', { src: u, alt: '', loading: 'lazy', draggable: 'false' }); img.onerror = ph; box.classList.remove('ph'); box.replaceChildren(img); } });
  }
  return box;
}
const NW_IMG = { cache: {}, queue: [], busy: 0 };
function nwFetchImg(it) {
  if (!api.article || !it.link) return Promise.resolve('');
  const k = it.link;
  if (k in NW_IMG.cache) return Promise.resolve(NW_IMG.cache[k]);
  const saved = S.cache.nwImg && S.cache.nwImg[k];
  if (saved !== undefined) { NW_IMG.cache[k] = saved; return Promise.resolve(saved); }
  return new Promise(res => {
    NW_IMG.queue.push({ k, res });
    nwImgPump();
  });
}
function nwImgPump() {
  while (NW_IMG.busy < 3 && NW_IMG.queue.length) {
    const { k, res } = NW_IMG.queue.shift();
    if (k in NW_IMG.cache) { res(NW_IMG.cache[k]); continue; }
    NW_IMG.busy++;
    safeCall(() => api.article(k)).then(r => {
      const d = r && (r.data || r);
      let u = d && d.image ? String(d.image) : '';
      if (/gstatic\.com\/(images\/branding|gnews)|news\.google\.com\/.*logo|lh3\.googleusercontent\.com\/[^?]*=s0-w300/i.test(u) || !/^https:\/\//.test(u)) u = '';
      NW_IMG.cache[k] = u;
      const all = S.cache.nwImg = S.cache.nwImg || {};
      all[k] = u;
      const keys = Object.keys(all); if (keys.length > 400) for (const x of keys.slice(0, keys.length - 300)) delete all[x];
      res(u);
    }).catch(() => res('')).finally(() => { NW_IMG.busy--; nwImgPump(); });
  }
}
function renderNewsW() {
  if (!widgetOn('news')) return;
  const ts = nwTopics();
  if (ui.nwSel && ui.nwSel !== '*' && !ts.includes(ui.nwSel)) ui.nwSel = '*';
  const sel = ui.nwSel || '*';
  const editing = !!ui.nwEdit;
  setText('nw-edit', editing ? 'Listo' : 'Mis temas');
  $('#nw-add').hidden = !editing;
  const chips = $('#nw-chips');
  chips.replaceChildren();
  chips.classList.toggle('editing', editing);
  if (!editing) {
    const all = el('button', { class: 'nw-chip' + (sel === '*' ? ' on' : ''), text: 'Todo', role: 'tab' });
    all.onclick = () => { ui.nwSel = '*'; renderNewsW(); };
    chips.append(all);
  }
  for (const t of ts) {
    const c = el('button', { class: 'nw-chip' + (!editing && sel === t ? ' on' : ''), role: 'tab', title: editing ? `Quitar ${t}` : t },
      el('span', { text: t }), editing ? svg(ICON.x) : null);
    c.onclick = () => {
      if (!editing) { ui.nwSel = t; renderNewsW(); return; }
      const list = nwTopics(); list.splice(list.indexOf(t), 1); save(); renderNewsW(); renderPeeks();
    };
    chips.append(c);
  }
  if (editing && !ts.length) chips.append(el('span', { class: 'hint', text: 'Sin temas: agregá alguno abajo.' }));

  const items = nwItems(sel);
  ui.nwList = items;
  const withPic = items.filter(i => i.image);
  const railItems = (withPic.length >= 4 ? withPic : items).slice(0, 12);
  const rest = items.filter(i => !railItems.includes(i)).slice(0, 20);
  const rail = $('#nw-rail');
  rail.replaceChildren();
  const more = $('#nw-more');
  more.replaceChildren();
  if (!ts.length) { rail.append(el('li', { class: 'empty', text: 'Tocá “Mis temas” y sumá lo que te interesa.' })); updateNwDots(); return; }
  if (!items.length) { rail.append(el('li', { class: 'empty', text: navigator.onLine === false ? 'Sin conexión. Las noticias vuelven solas.' : 'Buscando noticias…' })); updateNwDots(); return; }
  railItems.forEach((it) => {
    const b = el('button', { class: 'nw-card', title: it.title },
      nwPic(it, 560, 320),
      el('span', { class: 'nw-shade' }),
      el('span', { class: 'nw-txt' },
        sel === '*' ? el('span', { class: 'nw-tag', text: it.topic }) : null,
        el('span', { class: 'nw-t', text: it.title }),
        el('span', { class: 'nw-s', text: [it.source, ago(it.date)].filter(Boolean).join(' · ') })));
    b.onclick = () => openNewsReader(items.indexOf(it));
    rail.append(el('li', {}, b));
  });
  for (const it of rest) {
    const b = el('button', { class: 'nw-row' },
      newsThumb(it),
      el('span', { class: 'n-body' },
        el('span', { class: 'nt', text: it.title }),
        el('span', { class: 'ns', text: [it.source, ago(it.date), sel === '*' ? it.topic : ''].filter(Boolean).join(' · ') })));
    b.onclick = () => openNewsReader(items.indexOf(it));
    more.append(el('li', {}, b));
  }
  requestAnimationFrame(updateNwDots);
}
function updateNwDots() {
  const rail = $('#nw-rail');
  const dots = $('#nw-dots');
  if (!rail || !dots) return;
  const pages = rail.clientWidth ? Math.max(1, Math.round(rail.scrollWidth / rail.clientWidth)) : 1;
  const cur = rail.clientWidth ? Math.round(rail.scrollLeft / rail.clientWidth) : 0;
  if (dots.childElementCount !== pages) {
    dots.replaceChildren(...Array.from({ length: pages > 1 ? pages : 0 }, (_, i) => {
      const d = el('button', { 'aria-label': `Página ${i + 1}` });
      d.onclick = () => rail.scrollTo({ left: i * rail.clientWidth, behavior: 'smooth' });
      return d;
    }));
  }
  [...dots.children].forEach((d, i) => d.classList.toggle('on', i === cur));
  $('#nw-prev').disabled = rail.scrollLeft < 8;
  $('#nw-next').disabled = rail.scrollLeft + rail.clientWidth >= rail.scrollWidth - 8;
}
function openNewsReader(i) {
  const list = ui.nwList || [];
  if (!list[i]) return;
  ui.nwRead = i;
  const it = list[i];
  const sec = $('.newsw');
  sec.classList.add('reading');
  $('#nw-reader').hidden = false;
  widgetEl('news').classList.add('reading');
  $('#nr-scroll').scrollTop = 0;
  setText('nr-pos', `${i + 1} de ${list.length}`);
  $('#nr-prev').disabled = i === 0;
  $('#nr-next').disabled = i >= list.length - 1;
  const img = $('#nr-img');
  img.replaceChildren();
  img.hidden = !it.image;
  if (it.image) {
    const pic = el('img', { src: thumbUrl(it.image, 960, 520), alt: '' });
    pic.onerror = () => { img.hidden = true; };
    img.append(pic);
  }
  $('#nr-meta').replaceChildren(
    el('span', { class: 'nr-src' }, el('span', { class: 'nr-letter', text: letterFor(it.source || it.domain) }), it.source || it.domain || 'Noticia'),
    el('span', { text: ago(it.date) }),
    el('span', { class: 'nr-topic', text: it.topic }));
  setText('nr-title', it.title);
  const lead = $('#nr-lead');
  lead.textContent = it.desc || '';
  lead.hidden = !it.desc;
  const body = $('#nr-body');
  body.replaceChildren(el('div', { class: 'nr-loading' }, el('span'), el('span'), el('span')));
  setText('nr-foot', '');
  loadArticle(it, i);
}
async function loadArticle(it, i) {
  ui.nwArt = ui.nwArt || new Map();
  let r = ui.nwArt.get(it.link);
  let host = '';
  try { host = new URL(it.link).hostname; } catch {}
  if (!r) {
    if (host === 'news.google.com' || !api.article) r = { ok: false, error: 'google' };
    else r = await safeCall(() => api.article(it.link)) || { ok: false };
    if (r.ok) ui.nwArt.set(it.link, r);
  }
  if (ui.nwRead !== i || (ui.nwList || [])[i] !== it) return;
  const body = $('#nr-body');
  body.replaceChildren();
  const src = it.source || host.replace(/^www\./, '') || 'el sitio';
  if (r.ok && r.data) {
    const d = r.data;
    if (!it.image && d.image) {
      const img = $('#nr-img');
      const pic = el('img', { src: d.image, alt: '' });
      pic.onerror = () => { img.hidden = true; };
      img.replaceChildren(pic); img.hidden = false;
    }
    if (!it.desc && d.desc) { $('#nr-lead').textContent = d.desc; $('#nr-lead').hidden = false; }
    const paras = d.paras.slice(0, 14);
    for (const p of paras) body.append(el('p', { text: p }));
    setText('nr-foot', paras.length
      ? (d.paras.length > paras.length ? `Sigue en ${src}. Tocá “Leer completa”.` : `Fuente: ${src}.`)
      : `${src} no deja ver el texto desde afuera. Tocá “Leer completa” para verla en el navegador.`);
  } else {
    setText('nr-foot', r.error === 'google'
      ? `Esta nota viene de Google Noticias: tocá “Leer completa” para verla en ${src}.`
      : `No se pudo traer el texto (${src} no lo permite o tardó mucho). Tocá “Leer completa”.`);
  }
}
function closeNewsReader() {
  ui.nwRead = null;
  $('#nw-reader').hidden = true;
  const sec = $('.newsw');
  if (sec) sec.classList.remove('reading');
  const w = widgetEl('news');
  if (w) w.classList.remove('reading');
  requestAnimationFrame(updateNwDots);
}
function setupNewsW() {
  $('#nw-edit').onclick = () => { ui.nwEdit = !ui.nwEdit; renderNewsW(); if (ui.nwEdit) $('#nw-add-in').focus(); };
  $('#nw-refresh').onclick = () => { toast('Actualizando noticias…'); loadNewsW(true); };
  $('#nw-add').onsubmit = (e) => {
    e.preventDefault();
    const v = $('#nw-add-in').value.trim().replace(/\s+/g, ' ');
    if (!v) return;
    const list = nwTopics();
    if (list.some(t => t.toLowerCase() === v.toLowerCase())) return toast('Ya lo tenés');
    if (list.length >= 10) return toast('Hasta 10 temas: sacá alguno para sumar otro');
    list.push(v); save();
    $('#nw-add-in').value = '';
    renderNewsW(); loadNewsW(false);
  };
  const rail = $('#nw-rail');
  rail.addEventListener('scroll', () => { cancelAnimationFrame(ui.nwRaf); ui.nwRaf = requestAnimationFrame(updateNwDots); }, { passive: true });
  rail.addEventListener('wheel', (e) => {
    if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
    e.preventDefault();
    rail.scrollBy({ left: e.deltaY * 1.4, behavior: 'auto' });
  }, { passive: false });
  $('#nw-prev').onclick = () => rail.scrollBy({ left: -rail.clientWidth, behavior: 'smooth' });
  $('#nw-next').onclick = () => rail.scrollBy({ left: rail.clientWidth, behavior: 'smooth' });
  $('#nr-back').onclick = closeNewsReader;
  $('#nr-prev').onclick = () => openNewsReader(ui.nwRead - 1);
  $('#nr-next').onclick = () => openNewsReader(ui.nwRead + 1);
  $('#nr-open').onclick = () => { const it = (ui.nwList || [])[ui.nwRead]; if (it) api.openUrl(it.link); };
  document.addEventListener('keydown', (e) => {
    if (ui.nwRead == null || W.open !== 'news' || e.target.matches('input, textarea')) return;
    if (e.key === 'ArrowLeft' && ui.nwRead > 0) { e.preventDefault(); openNewsReader(ui.nwRead - 1); }
    if (e.key === 'ArrowRight' && ui.nwRead < ui.nwList.length - 1) { e.preventDefault(); openNewsReader(ui.nwRead + 1); }
    if (e.key === 'Backspace') { e.preventDefault(); closeNewsReader(); }
  });
}

// ---------- Feriados (Argentina) ----------
const FER_TIPO = { inamovible: 'Inamovible', trasladable: 'Trasladable', puente: 'Día no laborable / puente', 'no_laborable': 'No laborable' };
async function loadFeriados(force) {
  if (!widgetOn('feriados') && !force) return;
  const y = new Date().getFullYear();
  const parse = (t) => { const j = JSON.parse(t); return Array.isArray(j) && j.length ? j.filter(x => /^\d{4}-\d\d-\d\d$/.test(x.fecha)).map(x => ({ d: x.fecha, n: String(x.nombre || 'Feriado'), t: String(x.tipo || '') })) : null; };
  const years = [y]; if (new Date().getMonth() >= 9) years.push(y + 1);
  await Promise.all(years.map(yy => cached('fer:' + yy, 24 * 60, `https://api.argentinadatos.com/v1/feriados/${yy}`, parse, force)));
  renderFeriados(); renderPeeks();
}
function feriadosAll() {
  const y = new Date().getFullYear();
  return [y - 1, y, y + 1].flatMap(yy => (S.cache['fer:' + yy] || {}).data || []).sort((a, b) => a.d.localeCompare(b.d));
}
function daysUntil(dateStr) { return Math.round((parseYmd(dateStr) - parseYmd(ymd(new Date()))) / 864e5); }
function untilText(n) { return n === 0 ? '¡Es hoy!' : n === 1 ? 'Mañana' : n > 0 ? `Faltan ${n} días` : n === -1 ? 'Fue ayer' : `Fue hace ${-n} días`; }
function longWeekend(f, all) {
  const set = new Set(all.map(x => x.d));
  const off = (d) => d.getDay() === 0 || d.getDay() === 6 || set.has(ymd(d));
  let a = parseYmd(f.d), b = parseYmd(f.d);
  while (off(addDays(a, -1))) a = addDays(a, -1);
  while (off(addDays(b, 1))) b = addDays(b, 1);
  const n = Math.round((b - a) / 864e5) + 1;
  return n >= 3 ? { n, a, b } : null;
}
function renderFeriados() {
  if (!widgetOn('feriados')) return;
  const all = feriadosAll();
  const today = ymd(new Date());
  const next = all.filter(f => f.d >= today);
  const box = $('#fer-next');
  const list = $('#fer-list');
  list.replaceChildren();
  if (!next.length) { box.replaceChildren(el('p', { class: 'hint', text: all.length ? 'No hay más feriados cargados este año.' : 'Buscando feriados…' })); return; }
  const f = next[0];
  const lw = longWeekend(f, all);
  const d = parseYmd(f.d);
  box.replaceChildren(
    el('div', { class: 'fer-cal' }, el('span', { class: 'fm', text: fmt(d, { month: 'short' }).replace('.', '') }), el('span', { class: 'fd', text: String(d.getDate()) })),
    el('div', { class: 'fer-info' },
      el('span', { class: 'fer-k', text: untilText(daysUntil(f.d)) }),
      el('span', { class: 'fer-n', text: f.n }),
      el('span', { class: 'fer-s', text: [fmt(d, { weekday: 'long' }), FER_TIPO[f.t] || ''].filter(Boolean).join(' · ') }),
      lw ? el('span', { class: 'fer-lw', text: `Finde largo de ${lw.n} días: ${fmt(lw.a, { weekday: 'short', day: 'numeric' })} al ${fmt(lw.b, { weekday: 'short', day: 'numeric', month: 'short' })}` }) : null));
  for (const x of next.slice(1, 12)) {
    const dd = parseYmd(x.d);
    const lwx = longWeekend(x, all);
    list.append(el('li', { class: 'fer-row' },
      el('span', { class: 'fer-mini' }, el('b', { text: String(dd.getDate()) }), el('span', { text: fmt(dd, { month: 'short' }).replace('.', '') })),
      el('span', { class: 'fer-rn' }, el('b', { text: x.n }), el('span', { text: [fmt(dd, { weekday: 'long' }), lwx ? `finde largo (${lwx.n} días)` : ''].filter(Boolean).join(' · ') })),
      el('span', { class: 'fer-left', text: `${daysUntil(x.d)} d` })));
  }
}

// ---------- Pronóstico extendido ----------
async function loadPronostico(force) {
  if (!widgetOn('pronostico')) return;
  const w = M().weather;
  await cached(`pr:${w.lat.toFixed(3)},${w.lon.toFixed(3)}`, 30, prUrl(w), (t) => { const j = JSON.parse(t); return j.hourly && j.daily ? { hourly: j.hourly, daily: j.daily } : null; }, force);
  renderPronostico(); renderPeeks(); zoneRefresh('dia', 'semana');
}
function prUrl(w) {
  return `https://api.open-meteo.com/v1/forecast?latitude=${w.lat}&longitude=${w.lon}` +
    '&hourly=temperature_2m,weather_code,precipitation_probability,is_day' +
    '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset' +
    '&timezone=auto&forecast_days=7';
}
function prData() { const w = M().weather; return (S.cache[`pr:${w.lat.toFixed(3)},${w.lon.toFixed(3)}`] || {}).data; }
function renderPronostico() {
  if (!widgetOn('pronostico')) return;
  setText('pr-city', M().weather.name);
  const d = prData();
  const hours = $('#pr-hours');
  const days = $('#pr-days');
  hours.replaceChildren(); days.replaceChildren();
  if (!d) { days.append(el('li', { class: 'empty', text: 'Cargando pronóstico…' })); return; }
  const h = d.hourly;
  const nowKey = new Date(); nowKey.setMinutes(0, 0, 0);
  let start = h.time.findIndex(t => new Date(t) >= nowKey);
  if (start < 0) start = 0;
  for (let i = start; i < Math.min(h.time.length, start + 24); i += 2) {
    const t = new Date(h.time[i]);
    const [desc, ic] = wmo(h.weather_code[i], h.is_day[i] !== 0);
    const p = h.precipitation_probability ? h.precipitation_probability[i] : null;
    hours.append(el('div', { class: 'pr-h', title: desc },
      el('span', { class: 'ph-t', text: i === start ? 'Ahora' : `${pad(t.getHours())} h` }),
      svg(WX[ic]),
      el('b', { text: `${Math.round(h.temperature_2m[i])}°` }),
      el('span', { class: 'ph-p' + (p >= 40 ? ' wet' : ''), text: p != null && p >= 10 ? `${p}%` : '' })));
  }
  const dy = d.daily;
  const lo = Math.min(...dy.temperature_2m_min), hi = Math.max(...dy.temperature_2m_max);
  for (let i = 0; i < dy.time.length; i++) {
    const [desc, ic] = wmo(dy.weather_code[i]);
    const mn = dy.temperature_2m_min[i], mx = dy.temperature_2m_max[i];
    const p = dy.precipitation_probability_max ? dy.precipitation_probability_max[i] : null;
    const left = ((mn - lo) / (hi - lo || 1)) * 100, width = ((mx - mn) / (hi - lo || 1)) * 100;
    days.append(el('li', { class: 'pr-d', title: `${desc}${dy.wind_speed_10m_max ? ` · viento hasta ${Math.round(dy.wind_speed_10m_max[i])} km/h` : ''}` },
      el('span', { class: 'pd-n', text: i === 0 ? 'Hoy' : i === 1 ? 'Mañana' : fmt(parseYmd(dy.time[i]), { weekday: 'long' }) }),
      svg(WX[ic]),
      el('span', { class: 'pd-p' + (p >= 40 ? ' wet' : ''), text: p != null && p >= 10 ? `${p}%` : '' }),
      el('span', { class: 'pd-lo', text: `${Math.round(mn)}°` }),
      el('span', { class: 'pd-bar' }, el('span', { style: `left:${left}%;width:${Math.max(width, 4)}%` })),
      el('span', { class: 'pd-hi', text: `${Math.round(mx)}°` })));
  }
}

// ---------- Cuenta regresiva ----------
function countdowns() { const m = M(); if (!Array.isArray(m.countdowns)) m.countdowns = []; return m.countdowns; }
function renderCuenta() {
  if (!widgetOn('cuenta')) return;
  const list = $('#cd-list');
  list.replaceChildren();
  const items = countdowns().slice().sort((a, b) => {
    const da = daysUntil(a.d), db = daysUntil(b.d);
    return (da < 0) - (db < 0) || (da < 0 ? db - da : da - db);
  });
  if (!items.length) list.append(el('li', { class: 'empty', text: 'Sumá algo que estés esperando: vacaciones, un cumple, un partido…' }));
  for (const c of items) {
    const n = daysUntil(c.d);
    const total = Math.max(1, Math.round((parseYmd(c.d) - new Date(c.at || Date.now())) / 864e5));
    const pct = n <= 0 ? 100 : Math.min(100, Math.max(2, 100 - (n / total) * 100));
    const x = el('button', { class: 'icon-btn sm cd-x', title: 'Quitar', 'aria-label': `Quitar ${c.n}` }, svg(ICON.x));
    x.onclick = () => {
      const all = countdowns(); const i = all.indexOf(c);
      all.splice(i, 1); save(); renderCuenta(); renderPeeks();
      toast(`Quitaste ${c.n}`, { label: 'Deshacer', fn: () => { all.splice(i, 0, c); save(); renderCuenta(); renderPeeks(); } });
    };
    list.append(el('li', { class: 'cd' + (n < 0 ? ' past' : n === 0 ? ' today' : '') },
      el('div', { class: 'cd-num' }, el('b', { text: n === 0 ? '¡Hoy!' : String(Math.abs(n)) }), n === 0 ? null : el('span', { text: Math.abs(n) === 1 ? 'día' : 'días' })),
      el('div', { class: 'cd-info' },
        el('b', { text: c.n }),
        el('span', { text: `${fmt(parseYmd(c.d), { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' })}${n < 0 ? ' · ya pasó' : ''}` }),
        el('span', { class: 'cd-bar' }, el('span', { style: `width:${pct}%` }))),
      x));
  }
}
function setupCuenta() {
  $('#cd-date').min = ymd(new Date());
  $('#cd-add').onsubmit = (e) => {
    e.preventDefault();
    const n = $('#cd-name').value.trim();
    const d = $('#cd-date').value;
    if (!n || !/^\d{4}-\d\d-\d\d$/.test(d)) return;
    countdowns().push({ id: 'cd' + Date.now().toString(36), n, d, at: Date.now() });
    save();
    $('#cd-name').value = ''; $('#cd-date').value = '';
    renderCuenta(); renderPeeks();
  };
}

// ---------- Hábitos ----------
function habits() { const m = M(); if (!Array.isArray(m.habits)) m.habits = []; return m.habits; }
function streak(h) {
  let d = new Date(); let n = 0;
  if (!h.days[ymd(d)]) d = addDays(d, -1);
  while (h.days[ymd(d)]) { n++; d = addDays(d, -1); }
  return n;
}
function toggleHabit(h, day) {
  if (h.days[day]) delete h.days[day]; else h.days[day] = 1;
  // guardamos solo los últimos 120 días
  const cut = ymd(addDays(new Date(), -120));
  for (const k of Object.keys(h.days)) if (k < cut) delete h.days[k];
  save(); renderHabitos(); renderPeeks();
}
function renderHabitos() {
  if (!widgetOn('habitos')) return;
  const list = $('#hb-list');
  list.replaceChildren();
  const hs = habits();
  const today = ymd(new Date());
  setText('hb-today', hs.length ? `${hs.filter(h => h.days[today]).length} de ${hs.length} hoy` : '');
  if (!hs.length) list.append(el('li', { class: 'empty', text: 'Sumá un hábito que quieras sostener.' }));
  for (const h of hs) {
    h.days = h.days || {};
    const done = !!h.days[today];
    const chk = el('button', { class: 'hb-chk' + (done ? ' on' : ''), title: done ? 'Desmarcar hoy' : 'Marcar hecho hoy', 'aria-pressed': done ? 'true' : 'false' }, svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>'));
    chk.onclick = () => toggleHabit(h, today);
    const week = el('span', { class: 'hb-week' });
    for (let i = 6; i >= 0; i--) {
      const d = addDays(new Date(), -i);
      const k = ymd(d);
      const b = el('button', { class: 'hb-day' + (h.days[k] ? ' on' : '') + (i === 0 ? ' today' : ''), title: `${fmt(d, { weekday: 'long', day: 'numeric' })}: ${h.days[k] ? 'hecho' : 'sin hacer'}` },
        fmt(d, { weekday: 'narrow' }).toUpperCase());
      b.onclick = () => toggleHabit(h, k);
      week.append(b);
    }
    const st = streak(h);
    const x = el('button', { class: 'icon-btn sm hb-x', title: 'Quitar hábito', 'aria-label': `Quitar ${h.n}` }, svg(ICON.x));
    x.onclick = () => {
      const all = habits(); const i = all.indexOf(h);
      all.splice(i, 1); save(); renderHabitos(); renderPeeks();
      toast(`Quitaste ${h.n}`, { label: 'Deshacer', fn: () => { all.splice(i, 0, h); save(); renderHabitos(); renderPeeks(); } });
    };
    list.append(el('li', { class: 'hb' + (done ? ' done' : '') },
      chk,
      el('span', { class: 'hb-n' }, el('b', { text: h.n }), week),
      el('span', { class: 'hb-st' + (st ? ' on' : ''), title: `${plural(st, 'día seguido', 'días seguidos')}` }, svg('<path d="M12 3c1 3 5 5 5 10a5 5 0 0 1-10 0c0-2.5 1.4-4 2.2-4.7.3 1.8 1 2.6 1.8 2.7-.3-3 .1-5.6 1-8z"/>'), String(st)),
      x));
  }
}
function setupHabitos() {
  $('#hb-add').onsubmit = (e) => {
    e.preventDefault();
    const n = $('#hb-name').value.trim();
    if (!n) return;
    if (habits().length >= 12) return toast('Hasta 12 hábitos');
    habits().push({ id: 'hb' + Date.now().toString(36), n, days: {} });
    save(); $('#hb-name').value = '';
    renderHabitos(); renderPeeks();
  };
}

// ---------- Cripto ----------
const COINS = [
  { id: 'bitcoin', s: 'BTC', n: 'Bitcoin', c: '#f7931a' },
  { id: 'ethereum', s: 'ETH', n: 'Ethereum', c: '#627eea' },
  { id: 'solana', s: 'SOL', n: 'Solana', c: '#9945ff' },
  { id: 'tether', s: 'USDT', n: 'Tether (dólar cripto)', c: '#26a17b' }
];
async function loadCripto(force) {
  if (!widgetOn('cripto')) return;
  await cached('cripto', 5, `https://api.coingecko.com/api/v3/simple/price?ids=${COINS.map(c => c.id).join(',')}&vs_currencies=usd,ars&include_24hr_change=true`,
    (t) => { const j = JSON.parse(t); return j && j.bitcoin && j.bitcoin.usd ? j : null; }, force);
  renderCripto(); renderPeeks();
}
function cryptoMoney(v, cur) {
  if (v == null || isNaN(v)) return '—';
  const dec = v >= 1000 ? 0 : v >= 1 ? 2 : 4;
  return (cur === 'usd' ? 'US$ ' : '$ ') + Number(v).toLocaleString('es-AR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
}
function renderCripto() {
  if (!widgetOn('cripto')) return;
  const cur = S.settings.criptoCur || 'usd';
  for (const b of $$('#cr-cur button')) b.classList.toggle('on', b.dataset.c === cur);
  const c = S.cache.cripto;
  const list = $('#cr-list');
  list.replaceChildren();
  if (!c) { list.append(el('li', { class: 'empty', text: 'Cargando precios…' })); return; }
  for (const k of COINS) {
    const d = c.data[k.id];
    if (!d) continue;
    const ch = d[cur + '_24h_change'];
    list.append(el('li', { class: 'cr' },
      el('span', { class: 'cr-ico', style: `--c:${k.c}`, text: k.s[0] }),
      el('span', { class: 'cr-n' }, el('b', { text: k.s }), el('span', { text: k.n })),
      el('span', { class: 'cr-v' }, el('b', { text: cryptoMoney(d[cur], cur) }),
        ch != null ? el('span', { class: 'cr-ch ' + (ch >= 0 ? 'up' : 'down'), text: `${ch >= 0 ? '▲' : '▼'} ${Math.abs(ch).toLocaleString('es-AR', { maximumFractionDigits: 2 })}% en 24 h` }) : null)));
  }
  setText('cr-upd', `Actualizado ${ago(c.at)} · Fuente: CoinGecko. Solo informativo.`);
}
function setupCripto() {
  for (const b of $$('#cr-cur button')) b.onclick = () => { S.settings.criptoCur = b.dataset.c; save(); renderCripto(); renderPeeks(); };
  $('#cr-refresh').onclick = () => loadCripto(true);
}

function setupNewCards() {
  setupNewsW(); setupCuenta(); setupHabitos(); setupCripto(); setupCC();
  $('#fer-refresh').onclick = () => loadFeriados(true);
  $('#pr-refresh').onclick = () => loadPronostico(true);
}
function renderNewCards() { renderNewsW(); renderFeriados(); renderPronostico(); renderCuenta(); renderHabitos(); renderCripto(); renderCC(); renderSuper(); renderCalc(); renderLuces(); }
function loadNewCards(force) { loadNewsW(force); loadFeriados(force && widgetOn('feriados')); loadPronostico(force); loadCripto(force); if (widgetOn('gastos')) loadCC(force); }
function peeksNewCards() {
  peekCC(); peekSuper(); peekCalc(); peekLuces();
  const today = ymd(new Date());
  if (widgetOn('news')) {
    const it = nwItems('*')[0];
    setText('pk-news-main', it ? it.title : nwTopics().length ? 'Buscando noticias…' : 'Elegí tus temas');
    setText('pk-news-sub', it ? [it.source, ago(it.date), it.topic].filter(Boolean).join(' · ') : nwTopics().join(', '));
    setText('pk-news-badge', '');
  }
  if (widgetOn('feriados')) {
    const f = feriadosAll().find(x => x.d >= today);
    setText('pk-feriados-main', f ? f.n : 'Buscando feriados…');
    setText('pk-feriados-sub', f ? `${fmt(parseYmd(f.d), { weekday: 'short', day: 'numeric', month: 'short' })} · ${untilText(daysUntil(f.d)).toLowerCase()}` : '');
    setText('pk-feriados-badge', f && daysUntil(f.d) <= 7 ? String(daysUntil(f.d)) + ' d' : '');
  }
  if (widgetOn('pronostico')) {
    const d = prData();
    if (d) {
      const dy = d.daily;
      const rain = dy.time.findIndex((t, i) => i > 0 && (dy.precipitation_probability_max[i] || 0) >= 50);
      setText('pk-pronostico-main', `Mañana ${Math.round(dy.temperature_2m_max[1])}° / ${Math.round(dy.temperature_2m_min[1])}° · ${wmo(dy.weather_code[1])[0]}`);
      setText('pk-pronostico-sub', rain > 0 ? `Lluvia probable el ${fmt(parseYmd(dy.time[rain]), { weekday: 'long' })}` : 'Sin lluvias fuertes en la semana');
    } else { setText('pk-pronostico-main', 'Cargando…'); setText('pk-pronostico-sub', ''); }
    setText('pk-pronostico-badge', '');
  }
  if (widgetOn('cuenta')) {
    const up = countdowns().filter(c => daysUntil(c.d) >= 0).sort((a, b) => a.d.localeCompare(b.d))[0];
    setText('pk-cuenta-main', up ? up.n : 'Agregá una fecha');
    setText('pk-cuenta-sub', up ? untilText(daysUntil(up.d)) : 'Vacaciones, cumples, partidos…');
    setText('pk-cuenta-badge', up ? (daysUntil(up.d) === 0 ? '¡Hoy!' : String(daysUntil(up.d))) : '');
  }
  if (widgetOn('habitos')) {
    const hs = habits();
    const done = hs.filter(h => h.days && h.days[today]).length;
    const best = hs.map(h => [h, streak(h)]).sort((a, b) => b[1] - a[1])[0];
    setText('pk-habitos-main', hs.length ? `${done} de ${hs.length} hechos hoy` : 'Sumá un hábito');
    setText('pk-habitos-sub', best && best[1] ? `Racha: ${best[0].n}, ${plural(best[1], 'día', 'días')}` : hs.length ? 'Marcalos al hacerlos' : 'Agua, leer, caminar…');
    setText('pk-habitos-badge', hs.length && done < hs.length ? String(hs.length - done) : '');
  }
  if (widgetOn('cripto')) {
    const c = S.cache.cripto;
    const cur = S.settings.criptoCur || 'usd';
    const b = c && c.data.bitcoin, e = c && c.data.ethereum;
    setText('pk-cripto-main', b ? `BTC ${cryptoMoney(b[cur], cur)}` : 'Cargando…');
    const ch = b && b[cur + '_24h_change'];
    setText('pk-cripto-sub', b ? [ch != null ? `${ch >= 0 ? '▲' : '▼'} ${Math.abs(ch).toLocaleString('es-AR', { maximumFractionDigits: 1 })}%` : '', e ? `ETH ${cryptoMoney(e[cur], cur)}` : ''].filter(Boolean).join(' · ') : '');
    setText('pk-cripto-badge', '');
  }
}

// ---------- Gastos con tarjeta (leídos de los avisos de consumo que llegan al mail) ----------
const CC_CARDS = {
  visa: { n: 'Visa', c: '#1a1f71', d: 'visa.com' },
  amex: { n: 'Amex', c: '#2e77bb', d: 'americanexpress.com' },
  master: { n: 'Mastercard', c: '#eb001b', d: 'mastercard.com' }
};
function ccCfg() {
  const c = S.settings.cc = Object.assign({ cierre: {}, tope: {}, cuotas: 'total', q: '', days: 70 }, S.settings.cc || {});
  c.cierre = c.cierre || {}; c.tope = c.tope || {};
  return c;
}
function ccStore(mode = S.activeMode) {
  const k = 'cc:' + gmode(mode);
  // siempre el mismo objeto (si se crea uno nuevo, lo que se guarda en una lectura larga se pierde)
  if (!S.cache[k] || typeof S.cache[k] !== 'object') S.cache[k] = {};
  const st = S.cache[k];
  for (const [kk, v] of Object.entries({ items: {}, at: 0, notified: 0, failed: {} })) if (st[kk] == null) st[kk] = v;
  // cuando cambian las reglas de lectura, se vuelven a leer todos los mails
  if (st.ver !== 4) { st.ver = 4; st.items = {}; st.at = 0; st.tried = 0; st.failed = {}; st.pauseUntil = 0; st.error = ''; }
  return st;
}
// número argentino ("12.345,67", "1.234", "15,99", "9.99") a número
function ccNum(s) {
  s = String(s).replace(/\s/g, '');
  if (/,\d{1,2}$/.test(s)) return Number(s.replace(/\./g, '').replace(',', '.'));
  if (/\.\d{1,2}$/.test(s) && !/\.\d{3}\./.test(s)) return Number(s.replace(/,/g, ''));
  return Number(s.replace(/[.,]/g, ''));
}
function ccParse(m) {
  const subj = m.subject || '';
  const all = subj + '\n' + (m.text || '');
  const low = all.toLowerCase();
  const count = (re) => (all.match(re) || []).length;
  const sc = { amex: count(/american express|\bamex\b/gi), visa: count(/\bvisa\b/gi), master: count(/master\s?card|\bmaster\b/gi) };
  let card = Object.keys(sc).sort((a, b) => sc[b] - sc[a])[0];
  const mp = /mercado ?pago|mercado ?libre/i.test(m.from || '');
  if (mp && /(resumen|pagaste tu tarjeta|pago de (la |tu )?tarjeta|tus cr[eé]ditos|recibimos tu pago|cuotas sin tarjeta|pagaste tu (cuota|pr[eé]stamo))/i.test(subj + ' ' + (m.text || '').slice(0, 600))) return { bad: true, why: 'pago de resumen o crédito' };
  if (mp) {
    // Mercado Pago / Mercado Libre avisan todas las compras: contamos solo las pagadas con la Mastercard
    // (las de Visa o Amex ya las avisa el banco, así no se cuentan dos veces)
    if (!sc.master && !/tarjeta de cr[eé]dito mercado pago|cr[eé]dito mercado pago/i.test(all)) return { bad: true, why: sc.visa || sc.amex ? 'ya lo avisa el banco' : 'pago con Mercado Pago sin tarjeta' };
    card = 'master'; sc.master = sc.master || 1;
  }
  if (!sc[card]) return { bad: true, why: 'sin tarjeta' };
  const subjCard = /american express|amex/i.test(subj) ? 'amex' : /\bvisa\b/i.test(subj) ? 'visa' : /master/i.test(subj) ? 'master' : '';
  if (subjCard) card = subjCard;
  if (/^publicidad|\bpublicidad\b|newsletter|fe de erratas|beneficio|promoci[oó]n|ofertas?\b|sac[aá] tus tarjetas|listas para vos/i.test(subj + ' ' + (m.text || '').slice(0, 300))) return { bad: true, why: 'publicidad' };
  if (!/(consumo|compra|transacci|cargo|autoriz|pagaste|realizaste|gasto|d[eé]bito autom|devoluci|anulaci|reintegro)/i.test(all)) return { bad: true, why: 'no parece un consumo' };
  if (/(resumen de cuenta|tu resumen|vencimiento de tu|pago recibido|recibimos tu pago|acreditamos tu pago)/i.test(subj)) return { bad: true, why: 'resumen o pago' };
  // montos con moneda
  const re = /(u\$s|us\$|usd|u\$d|ars|\$)\s?([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{1,2})?|[0-9]+(?:[.,][0-9]{1,2})?)/gi;
  let best = null, mm;
  while ((mm = re.exec(all))) {
    const before = low.slice(Math.max(0, mm.index - 40), mm.index);
    let score = 0;
    if (/(monto|importe|por|total|consumo|compra|cargo|valor|pagaste|pago de|de)\s*:?\s*$/.test(before)) score += 3;
    if (/(env[ií]o|precio unitario|ahorraste|antes)\s*:?\s*$/.test(before)) score -= 2;
    if (/(l[ií]mite|disponible|saldo|m[ií]nimo|cuota de|cuotas de|ahorr|descuento|reintegro de hasta|tope)/.test(before)) score -= 6;
    const v = ccNum(mm[2]);
    if (!v || v > 1e9) continue;
    if (!best || score > best.score) best = { score, v, usd: /u|d/i.test(mm[1]) && !/^ars$/i.test(mm[1]) && mm[1] !== '$', at: mm.index, len: mm[0].length };
  }
  if (!best) return { bad: true, why: 'sin monto' };
  const q = /\b(\d{1,2})[ \t]*cuotas?\b/i.exec(all) || /cuotas?[ \t]*:?[ \t]*(\d{1,2})\b/i.exec(all);
  let cuotas = q && q[1] ? Math.max(1, Number(q[1])) : 1;
  if (cuotas > 48) cuotas = 1;
  let shop = '';
  const ms = /(?:comercio|establecimiento|lugar|en el comercio|destino)\s*:?\s*([^\n]{2,48})/i.exec(all) || /^\s*(?:en|a)\s+([A-Z0-9][^\n]{1,48})/.exec(all.slice(best.at + best.len));
  if (ms) shop = ms[1].replace(/^(?:en\s+)?\d+\s*(?:pagos?|cuotas?)\s+(?:en\s+)?/i, '').split(/\s+(?:el d[ií]a|el \d|con tu|con la|fecha|por un|en \d+ cuotas?|en 1 pago)\b|[.;|]\s/i)[0].replace(/[.,:;]+$/, '').trim();
  const last4 = (/(?:terminada|finalizada|termina)\s+en\s+(\d{4})/i.exec(all) || /[*xX•]{2,}\s?(\d{4})/.exec(all) || [])[1] || '';
  const refund = /(devoluci[oó]n|anulaci[oó]n|reintegro acreditado|reversa|contracargo)/i.test(subj);
  if (/^[,.;:]/.test(shop) || /est[eé]s donde est[eé]s/i.test(shop)) shop = '';
  if (!shop && mp) shop = ((/compraste\s+(.{2,40})/i.exec(subj) || /pagaste .{0,20}? a\s+(.{2,40})/i.exec(subj) || [])[1] || 'Mercado Libre').trim();
  const from = ((/<([^>]+)>/.exec(m.from || '') || [])[1] || m.from || '').toLowerCase().split('@').pop().slice(0, 40);
  return { card, v: refund ? -best.v : best.v, usd: !!best.usd, cuotas, shop: shop.slice(0, 40), last4, mp, from, subj: subj.slice(0, 80), date: m.date };
}
let ccBusy = false, ccMore = 0;
async function loadCC(force) {
  if (ccBusy || !S || !acct() || !api.google.cardMails) return;
  const st = ccStore();
  if (st.pauseUntil && Date.now() < st.pauseUntil) return;
  if (!force && Date.now() - (st.tried || 0) < 10 * 60000) return;
  ccBusy = true;
  st.tried = Date.now();
  try {
    const cfg = ccCfg();
    st.failed = st.failed || {};
    for (const [id, t] of Object.entries(st.failed)) if (Date.now() - t > 30 * 60000) delete st.failed[id];
    const r = await safeCall(() => api.google.cardMails(gmode(S.activeMode), cfg.q, [...Object.keys(st.items), ...Object.keys(st.failed)], cfg.days));
    if (!r || !r.ok) {
      const quota = /quota|rate limit|cuota/i.test((r && r.error) || '') || (r && r.code === 'quota');
      st.error = quota ? 'Google pidió ir más despacio. Sigo leyendo en unos minutos, solo.' : ((r && r.error) || 'No se pudo leer el correo');
      st.pauseUntil = Date.now() + (quota ? 3 : 1) * 60000; st.errorAt = Date.now();
      return;
    }
    st.error = ''; st.errorAt = 0;
    for (const id of r.data.failed || []) st.failed[id] = Date.now();
    const fresh = [];
    for (const m of r.data.items) {
      const p = ccParse(m);
      st.items[m.id] = p.bad ? { bad: true, why: p.why, subject: (m.subject || '').slice(0, 90), from: (m.from || '').replace(/<.*>/, '').trim().slice(0, 40), date: m.date, text: (m.text || '').slice(0, 300) } : p;
      if (!p.bad) fresh.push(p);
    }
    // olvidamos solo los mails viejos (más que el período que se busca)
    const limit = Date.now() - ((cfg.days || 70) + 5) * 864e5;
    for (const [id, p] of Object.entries(st.items)) if ((p.date || 0) && p.date < limit) delete st.items[id];
    // aviso de gastos nuevos (solo los de las últimas horas, y no la primera vez)
    if (st.at) for (const p of fresh) if (p.date > Date.now() - 6 * 3600000 && p.date > (st.notified || 0)) {
      notify('mail', `${CC_CARDS[p.card].n}: ${ccMoney(p.v, p.usd)}${p.cuotas > 1 ? ` en ${p.cuotas} cuotas` : ''}`, p.shop ? `Compra en ${p.shop}` : 'Nuevo consumo con tarjeta');
    }
    st.notified = Math.max(st.notified || 0, ...fresh.map(p => p.date), Date.now() - 6 * 3600000);
    st.at = Date.now();
    save();
    // si quedan mails por leer, seguimos de a poco (uno cada 20 segundos, hasta 12 tandas)
    if (r.data.more && ccMore < 20) { ccMore++; setTimeout(() => loadCC(true), 8000); } else ccMore = 0;
  } finally { ccBusy = false; renderCC(); renderPeeks(); }
}
const ccMoney = (v, usd) => (v < 0 ? '−' : '') + (usd ? 'US$ ' : '$ ') + Math.abs(v).toLocaleString('es-AR', { minimumFractionDigits: usd ? 2 : 0, maximumFractionDigits: usd ? 2 : 0 });
// desde cuándo cuenta el período de cada tarjeta (día de cierre; 0 = mes calendario)
function ccStart(card) {
  const c = Number(ccCfg().cierre[card]) || 0;
  const now = new Date();
  if (!c) return new Date(now.getFullYear(), now.getMonth(), 1);
  const d = now.getDate() > c ? new Date(now.getFullYear(), now.getMonth(), c + 1) : new Date(now.getFullYear(), now.getMonth() - 1, c + 1);
  return d;
}
// sin los últimos 4 números de la tarjeta, puede ser una publicidad: no lo contamos salvo que digas que sí
const ccDoubt = (p) => !p.bad && !p.ok && !p.last4 && !p.mp;
function ccSummary() {
  const st = ccStore(), cfg = ccCfg();
  const res = {};
  for (const [id, p] of Object.entries(st.items)) {
    if (p.bad || p.hidden || !CC_CARDS[p.card] || ccDoubt(p)) continue;
    const start = +ccStart(p.card);
    if (p.date < start) continue;
    const r = res[p.card] = res[p.card] || { ars: 0, usd: 0, n: 0, cuotas: 0, list: [] };
    const val = cfg.cuotas === 'cuota' && p.cuotas > 1 ? p.v / p.cuotas : p.v;
    if (p.usd) r.usd += val; else r.ars += val;
    r.n++; if (p.cuotas > 1) r.cuotas++;
    r.list.push({ id, ...p });
  }
  return res;
}
function renderCC() {
  if (!widgetOn('gastos')) return;
  const box = $('#cc-body');
  if (!box) return;
  if (!acct()) {
    const b = el('button', { class: 'btn', text: 'Vincular Gmail' }); b.onclick = () => linkGoogle(S.activeMode);
    box.replaceChildren(el('div', { class: 'cc-empty' }, el('b', { text: 'Sumá lo que gastás con tarjeta' }), el('span', { text: 'Base lee los avisos de consumo que te manda el banco por mail (Visa, Amex) y va sumando. No necesita tus datos bancarios.' }), b));
    return;
  }
  if (ui.ccCfg) return renderCCConfig(box);
  const st = ccStore(), cfg = ccCfg(), sum = ccSummary();
  const kids = [];
  if (st.error && (st.errorAt || 0) > (st.at || 0) && Date.now() - (st.errorAt || 0) < 15 * 60000) kids.push(el('p', { class: 'cc-err', text: st.error }));
  const cards = Object.keys(CC_CARDS).filter(k => sum[k] || cfg.tope[k]);
  if (!cards.length) kids.push(el('div', { class: 'cc-empty' }, el('b', { text: st.at && !ccMore ? 'Sin consumos en este período' : `Leyendo tus mails… (${Object.keys(st.items).length} leídos)` }),
    el('span', { text: st.at ? 'Cuando llegue un aviso de compra con tu Visa o Amex, aparece acá.' : 'Busco los avisos de consumo de los últimos dos meses.' })));
  const grid = el('div', { class: 'cc-cards' });
  for (const k of cards) {
    const r = sum[k] || { ars: 0, usd: 0, n: 0, cuotas: 0, list: [] };
    const tope = Number(cfg.tope[k]) || 0;
    const pct = tope ? Math.min(100, Math.round(100 * r.ars / tope)) : null;
    const start = ccStart(k);
    grid.append(el('div', { class: 'cc-card cc-' + k, style: `--cc:${CC_CARDS[k].c}` },
      el('div', { class: 'cc-top' }, brandLogo(CC_CARDS[k].d, 'card', 'cc-logo'), el('b', { text: CC_CARDS[k].n }), el('small', { text: `desde el ${start.getDate()}/${start.getMonth() + 1}` })),
      el('b', { class: 'cc-total', text: ccMoney(r.ars, false) }),
      r.usd ? el('span', { class: 'cc-usd', text: `+ ${ccMoney(r.usd, true)}` }) : null,
      el('span', { class: 'cc-meta', text: `${plural(r.n, 'compra', 'compras')}${r.cuotas ? ` · ${r.cuotas} en cuotas` : ''}` }),
      tope ? el('span', { class: 'cc-bar' + (pct >= 90 ? ' hi' : pct >= 70 ? ' mid' : ''), title: `${pct}% de ${ccMoney(tope)}` }, el('i', { style: `width:${pct}%` })) : null));
  }
  if (cards.length) kids.push(grid);
  const items = Object.values(sum).flatMap(r => r.list).sort((a, b) => b.date - a.date);
  if (items.length) {
    kids.push(el('ul', { class: 'cc-list' }, items.slice(0, 40).map(p => {
      const d = new Date(p.date);
      const x = el('button', { class: 'row-del', title: 'No contar este', 'aria-label': 'No contar este' }, svg(ICON.x));
      x.onclick = () => { const it = ccStore().items[p.id]; if (it) it.hidden = true; save(); renderCC(); renderPeeks(); toast('Listo, ese no cuenta', { label: 'Deshacer', fn: () => { it.hidden = false; save(); renderCC(); renderPeeks(); } }); };
      return el('li', { class: 'cc-row' },
        el('span', { class: 'cc-dot', style: `--cc:${CC_CARDS[p.card].c}`, title: CC_CARDS[p.card].n + (p.last4 ? ' ·' + p.last4 : '') }),
        el('span', { class: 'cc-shop' }, el('b', { text: p.shop || 'Compra' }), el('small', { text: `${d.getDate()}/${d.getMonth() + 1} · ${CC_CARDS[p.card].n}${p.cuotas > 1 ? ` · ${p.cuotas} cuotas` : ''}` })),
        el('span', { class: 'cc-v' + (p.v < 0 ? ' neg' : ''), text: ccMoney(p.v, p.usd) }), x);
    })));
  }
  const bad = Object.values(st.items).filter(p => p.bad && !/sin tarjeta|no parece|publicidad|sin tarjeta/.test(p.why || '') && !/Mercado Pago sin/.test(p.why || ''));
  if (bad.length) {
    const t = el('button', { class: 'text-btn cc-bad', text: `${plural(bad.length, 'mail', 'mails')} que no pude leer` });
    t.onclick = () => { ui.ccBad = !ui.ccBad; renderCC(); };
    kids.push(t);
    if (ui.ccBad) kids.push(el('ul', { class: 'cc-badlist' }, bad.slice(0, 12).map(p => el('li', {}, el('b', { text: p.subject || '(sin asunto)' }), el('small', { text: `${p.from} · ${p.why}` })))));
  }
  const doubts = Object.entries(st.items).filter(([, p]) => ccDoubt(p) && !p.hidden && p.date >= +ccStart(p.card)).sort((a, b) => b[1].date - a[1].date);
  if (doubts.length) {
    const t = el('button', { class: 'text-btn cc-bad', text: `${plural(doubts.length, 'consumo dudoso', 'consumos dudosos')} (sin número de tarjeta, no cuentan)` });
    t.onclick = () => { ui.ccDoubt = !ui.ccDoubt; renderCC(); };
    kids.push(t);
    if (ui.ccDoubt) kids.push(el('ul', { class: 'cc-list' }, doubts.slice(0, 20).map(([id, p]) => {
      const d = new Date(p.date);
      const ok = el('button', { class: 'text-btn', text: 'Contar' }); ok.onclick = () => { ccStore().items[id].ok = true; save(); renderCC(); renderPeeks(); };
      const no = el('button', { class: 'row-del', title: 'Descartar', 'aria-label': 'Descartar' }, svg(ICON.x)); no.onclick = () => { ccStore().items[id].hidden = true; save(); renderCC(); };
      return el('li', { class: 'cc-row doubt' }, el('span', { class: 'cc-dot', style: `--cc:${CC_CARDS[p.card].c}` }),
        el('span', { class: 'cc-shop' }, el('b', { text: p.shop || 'Sin comercio' }), el('small', { text: `${d.getDate()}/${d.getMonth() + 1} · ${CC_CARDS[p.card].n}${p.from ? ' · ' + p.from : ''}` })),
        el('span', { class: 'cc-v', text: ccMoney(p.v, p.usd) }), el('span', { class: 'cc-acts' }, ok, no));
    })));
  }
  kids.push(el('p', { class: 'hint cc-upd', text: ccMore ? 'Sigo leyendo tus mails de a poco… los totales se van completando.' : st.at ? `Actualizado ${ago(st.at)} · leído de tus mails, puede no coincidir exacto con el resumen` : '' }));
  box.replaceChildren(...kids);
}
function renderCCConfig(box) {
  const cfg = ccCfg();
  const rows = Object.entries(CC_CARDS).map(([k, c]) => {
    const ci = el('input', { type: 'number', min: '0', max: '31', value: String(cfg.cierre[k] || ''), placeholder: 'Mes', 'aria-label': `Día de cierre ${c.n}` });
    ci.onchange = () => { cfg.cierre[k] = Math.max(0, Math.min(31, Number(ci.value) || 0)); save(); };
    const tp = el('input', { type: 'number', min: '0', step: '1000', value: String(cfg.tope[k] || ''), placeholder: 'Sin tope', 'aria-label': `Tope ${c.n}` });
    tp.onchange = () => { cfg.tope[k] = Math.max(0, Number(tp.value) || 0); save(); };
    return el('div', { class: 'cc-cfg-row' }, el('b', { text: c.n }), ci, tp);
  });
  const sel = el('select', { 'aria-label': 'Compras en cuotas' }, el('option', { value: 'total', text: 'Sumar el total de la compra' }), el('option', { value: 'cuota', text: 'Sumar solo una cuota' }));
  sel.value = cfg.cuotas; sel.onchange = () => { cfg.cuotas = sel.value; save(); };
  const q = el('input', { value: cfg.q, placeholder: 'Vacío = los avisos de consumo de Visa, Amex y Mastercard', 'aria-label': 'Qué mails buscar' });
  q.onchange = () => { cfg.q = q.value.trim(); const st = ccStore(); st.items = {}; st.at = 0; st.tried = 0; save(); };
  const done = el('button', { class: 'btn', text: 'Listo' });
  done.onclick = () => { ui.ccCfg = false; renderCC(); renderPeeks(); loadCC(false); };
  const reset = el('button', { class: 'text-btn', text: 'Volver a leer todos los mails' });
  reset.onclick = () => { const st = ccStore(); st.items = {}; st.at = 0; st.failed = {}; st.pauseUntil = 0; save(); ui.ccCfg = false; renderCC(); loadCC(true); };
  box.replaceChildren(el('div', { class: 'cc-cfg' },
    el('div', { class: 'cc-cfg-row head' }, el('span'), el('small', { text: 'Día de cierre' }), el('small', { text: 'Tope del mes ($)' })), ...rows,
    el('p', { class: 'hint', text: 'Con el día de cierre, el total cuenta desde el cierre anterior (como tu resumen). Vacío = mes calendario.' }),
    el('label', { class: 'field-label', text: 'Compras en cuotas' }), sel,
    el('label', { class: 'field-label', text: 'Qué mails buscar (búsqueda de Gmail, opcional)' }), q,
    el('div', { class: 'row' }, done, el('span', { class: 'spacer' }), reset)));
}
function peekCC() {
  if (!widgetOn('gastos')) return;
  if (!acct()) { setText('pk-gastos-main', 'Vinculá Gmail'); setText('pk-gastos-sub', 'Suma tus avisos de consumo'); setText('pk-gastos-badge', ''); return; }
  const sum = ccSummary();
  const ks = Object.keys(sum);
  const ars = ks.reduce((a, k) => a + sum[k].ars, 0), usd = ks.reduce((a, k) => a + sum[k].usd, 0);
  setText('pk-gastos-main', ks.length ? `${ccMoney(ars)}${usd ? ` + ${ccMoney(usd, true)}` : ''}` : ccStore().at ? 'Sin consumos este mes' : 'Leyendo tus mails…');
  setText('pk-gastos-sub', ks.map(k => `${CC_CARDS[k].n} ${ccMoney(sum[k].ars)}`).join(' · '));
  setText('pk-gastos-badge', '');
}
function setupCC() {
  $('#cc-refresh').onclick = () => { const st = ccStore(); if (st.pauseUntil && Date.now() < st.pauseUntil) return toast('Google pidió esperar un poco; en unos minutos sigue solo'); loadCC(true); };
  $('#cc-cfg').onclick = () => { ui.ccCfg = !ui.ccCfg; renderCC(); };
  setInterval(() => { if (!document.hidden && S && widgetOn('gastos')) loadCC(false); }, 5 * 60000);
}

// ---------- Lista del Supermercado (una sola para toda la casa, en todos los tableros) ----------
const SUPER_CATS = [
  { id: 'verdu', n: 'Verdulería', c: '#2f9e44', ico: '<path d="M12 21c-4 0-7-3-7-7 0-5 4-8 7-8s7 3 7 8c0 4-3 7-7 7z"/><path d="M12 6c0-2 1-3 3-3"/>',
    rx: /tomate|papa\b|papas\b|cebolla|lechuga|zanahoria|banana|manzana|naranja|mandarina|lim[oó]n|palta|ajo\b|morr[oó]n|zapallo|calabaza|fruta|verdura|frutilla|pera\b|uva|choclo|batata|acelga|espinaca|perejil|albahaca|pepino|berenjena|zucchini|br[oó]coli|repollo|r[uú]cula|kiwi|anan[aá]|durazno|ciruela|mel[oó]n|sand[ií]a|champi|hongo/i },
  { id: 'carne', n: 'Carnicería y fiambres', c: '#e0533d', ico: '<path d="M15 4c3 1 5 4 4 8s-6 8-10 7-5-5-4-8 7-8 10-7z"/><circle cx="14" cy="9" r="1.5"/>',
    rx: /carne|pollo|cerdo|milanesa|asado|chorizo|morcilla|jam[oó]n|salame|mortadela|fiambre|pescado|merluza|salchicha|picada|bife|vac[ií]o|matambre|hamburguesa|nalga|cuadril|peceto|bondiola|pechuga|suprema|panceta|at[uú]n fresco/i },
  { id: 'lacteos', n: 'Lácteos y huevos', c: '#1c9bd6', ico: '<path d="M8 3h8v3l2 3v12H6V9l2-3z"/><path d="M6 13h12"/>',
    rx: /leche|yogur|queso|manteca|crema de leche|\bcrema\b(?! (dental|de enjuague|para))|dulce de leche|huevo|ricota|postre|flan|casancrem|mozzarella|muzzarella/i },
  { id: 'pan', n: 'Panadería', c: '#e8a10c', ico: '<path d="M4 11a8 5 0 0 1 16 0v7H4z"/><path d="M8 11v7M12 11v7M16 11v7"/>',
    rx: /\bpan\b|pan lactal|pan de|facturas|medialunas|prepizza|tapas de|bizcochos|tostadas|budín|torta/i },
  { id: 'almacen', n: 'Almacén', c: '#a0522d', ico: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M5 9h14M9 13h6"/>',
    rx: /arroz|fideos|tallarines|yerba|az[uú]car|harina|aceite|sal\b|caf[eé]|\bt[eé]\b|mate cocido|galletitas|galletas|at[uú]n|arvejas|lentejas|garbanzos|pur[eé]|salsa|mayonesa|ketchup|mostaza|vinagre|polenta|cacao|nesquik|mermelada|cereal|avena|or[eé]gano|piment[oó]n|condimento|especias|caldo|sopa|edulcorante|choclo en lata|enlatado|lata de|snacks|papas fritas|man[ií]|chocolate|alfajor|golosina|turr[oó]n|pochoclo|levadura|pan rallado|rebozador/i },
  { id: 'bebidas', n: 'Bebidas', c: '#7b4fc9', ico: '<path d="M9 3h6v4l2 3v11H7V10l2-3z"/><path d="M7 14h10"/>',
    rx: /agua|gaseosa|coca|sprite|fanta|pepsi|jugo|cerveza|vino|fernet|soda|energizante|aperitivo|whisky|vodka|gin\b|sidra|champagne|speed|gatorade|powerade|t[oó]nica/i },
  { id: 'limpieza', n: 'Limpieza', c: '#0ca678', ico: '<path d="M9 3h6v4l3 4v10H6V11l3-4z"/><path d="M6 15h12"/>',
    rx: /lavandina|detergente|jab[oó]n (en polvo|l[ií]quido|para (la )?ropa)|suavizante|rollo de cocina|servilletas|esponja|trapo|bolsas? de residuo|bolsas? de basura|limpiador|desodorante de ambiente|aromatizante|insecticida|raid|lustramuebles|cif\b|mr\.? m[uú]sculo|virulana|limpia ?vidrios|desengrasante|blem|poett|lysoform|quitamanchas|vivere|skip|ala\b|magistral|escoba|secador|balde|guantes/i },
  { id: 'higiene', n: 'Perfumería e higiene', c: '#d6336c', ico: '<path d="M10 3h4v3h-4zM8 6h8l1 3v12H7V9z"/>',
    rx: /shampoo|champ[uú]|acondicionador|jab[oó]n|pasta dental|dent[ií]frico|cepillo de dientes|hilo dental|enjuague|desodorante|papel higi[eé]nico|toallitas|toallas femeninas|tampones|algod[oó]n|hisopos|afeitadora|m[aá]quina de afeitar|espuma de afeitar|protector solar|repelente|pa[ñn]ales|crema (para|de manos|corporal)|perfume|gel|alcohol en gel|curitas|ibuprofeno|paracetamol|remedio/i },
  { id: 'congelados', n: 'Congelados', c: '#4dabf7', ico: '<path d="M12 3v18M4.5 7.5l15 9M19.5 7.5l-15 9"/>',
    rx: /helado|congelad|hielo|patitas|nuggets|bastones|papas (congeladas|pre ?fritas)|vegetales congelados/i },
  { id: 'mascotas', n: 'Mascotas', c: '#868e96', ico: '<circle cx="8" cy="8" r="2"/><circle cx="16" cy="8" r="2"/><circle cx="5" cy="13" r="2"/><circle cx="19" cy="13" r="2"/><path d="M12 13c3 0 5 3 5 5s-2 2-5 2-5 0-5-2 2-5 5-5z"/>',
    rx: /alimento (para |de )?(perro|gato)|perro|gato|piedras|arena para|dog chow|cat chow|pedigree|whiskas|royal canin/i }
];
const SUPER_OTHER = { id: 'otros', n: 'Otros', c: '#adb5bd', ico: '<rect x="4" y="6" width="16" height="13" rx="2"/><path d="M8 6V4h8v2"/>' };
const superCats = () => [...SUPER_CATS, SUPER_OTHER];
function superData() {
  const d = S.settings.super = Object.assign({ items: [], freq: {}, cats: {} }, S.settings.super || {});
  if (!Array.isArray(d.items)) d.items = [];
  d.freq = d.freq || {}; d.cats = d.cats || {};
  return d;
}
const superKey = (t) => t.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
function superCatOf(name) {
  const forced = superData().cats[superKey(name)];
  if (forced) return forced;
  for (const c of SUPER_CATS) if (c.rx.test(name)) return c.id;
  return 'otros';
}
function superParse(raw) {
  let t = String(raw || '').trim().replace(/\s+/g, ' ');
  if (!t) return null;
  let q = '';
  const m = /^(\d+(?:[.,]\d+)?)\s*(kg|kilos?|g|gr|grs|gramos|l|lt|lts|litros?|ml|cc|u|un|unidades?|paq(?:uetes?)?|cajas?|latas?|botellas?|bolsas?|docenas?|maples?|x)?\s+(.+)$/i.exec(t)
    || /^(.+?)\s+x\s*(\d+(?:[.,]\d+)?)\s*(kg|g|gr|l|lt|ml|u)?$/i.exec(t);
  if (m && /^\d/.test(m[1])) { q = [m[1], m[2] && m[2].toLowerCase() !== 'x' ? m[2] : ''].filter(Boolean).join(' '); t = m[3]; }
  else if (m) { q = [m[2], m[3]].filter(Boolean).join(' '); t = m[1]; }
  t = t.charAt(0).toUpperCase() + t.slice(1);
  return { t, q };
}
function superAdd(raw) {
  const p = superParse(raw);
  if (!p) return;
  const d = superData();
  const k = superKey(p.t);
  const ex = d.items.find(i => superKey(i.t) === k && !i.done);
  if (ex) { if (p.q) ex.q = p.q; toast(`${ex.t} ya estaba en la lista`); }
  else d.items.push({ id: uid(), t: p.t, q: p.q, done: false, at: Date.now() });
  d.freq[k] = { t: p.t, n: ((d.freq[k] && d.freq[k].n) || 0) + 1 };
  save(); renderSuperAll();
}
function superText() {
  const d = superData();
  const pend = d.items.filter(i => !i.done);
  const lines = [];
  for (const c of superCats()) {
    const list = pend.filter(i => superCatOf(i.t) === c.id);
    if (!list.length) continue;
    lines.push(`*${c.n}*`);
    for (const i of list) lines.push(`• ${i.t}${i.q ? ` (${i.q})` : ''}`);
  }
  return lines.length ? '🛒 Lista del súper\n' + lines.join('\n') : '';
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch {}
  try { const ta = el('textarea', { style: 'position:fixed;opacity:0' }); ta.value = text; document.body.append(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; } catch { return false; }
}
function buildSuper(box, compact) {
  const d = superData();
  const pend = d.items.filter(i => !i.done), done = d.items.filter(i => i.done);
  const input = el('input', { class: 'sp-in', placeholder: 'Qué falta? (ej: 2 leche, yerba, pan) + Enter', maxlength: '80', 'aria-label': 'Agregar a la lista' });
  input.onkeydown = (e) => { if (e.key === 'Enter' && input.value.trim()) { const v = input.value; input.value = ''; superAdd(v); const again = box.querySelector('.sp-in'); if (again) again.focus(); } };
  const row = (i) => {
    const c = el('input', { type: 'checkbox', class: 'check', 'aria-label': `Marcar ${i.t}` });
    c.checked = !!i.done;
    c.onchange = () => { i.done = c.checked; i.doneAt = i.done ? Date.now() : 0; save(); setTimeout(renderSuperAll, i.done ? 220 : 0); };
    const x = el('button', { class: 'row-del', title: 'Sacar de la lista', 'aria-label': `Sacar ${i.t}` }, svg(ICON.x));
    x.onclick = () => { const all = superData().items; all.splice(all.indexOf(i), 1); save(); renderSuperAll(); };
    const name = el('span', { class: 'sp-t', text: i.t, title: 'Clic derecho: cambiar de sección' });
    name.oncontextmenu = (e) => superCatMenu(e, i);
    return el('li', { class: 'sp-row' + (i.done ? ' done' : '') }, c, name, i.q ? el('span', { class: 'sp-q', text: i.q }) : null, x);
  };
  const groups = superCats().map(c => ({ c, list: pend.filter(i => superCatOf(i.t) === c.id) })).filter(g => g.list.length);
  const kids = [input];
  if (!pend.length) kids.push(el('p', { class: 'sp-empty', text: done.length ? '¡Listo! Tenés todo en el carrito.' : 'La lista está vacía. Anotá lo que falta en casa.' }));
  kids.push(el('div', { class: 'sp-groups' + (compact ? ' compact' : '') }, groups.map(g => el('div', { class: 'sp-grp', style: `--sc:${g.c.c}` },
    el('div', { class: 'sp-gh' }, svg(g.c.ico), el('b', { text: g.c.n }), el('small', { text: String(g.list.length) })),
    el('ul', { class: 'sp-list' }, g.list.map(row))))));
  if (done.length) {
    const clear = el('button', { class: 'text-btn', text: 'Ya compré todo' });
    clear.onclick = () => { const dd = superData(); dd.items = dd.items.filter(i => !i.done); save(); renderSuperAll(); toast('Lista limpia'); };
    kids.push(el('div', { class: 'sp-cart' }, el('div', { class: 'sp-gh' }, svg('<circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/><path d="M3 4h2l2.5 11h11l2-8H7"/>'), el('b', { text: 'En el carrito' }), el('small', { text: String(done.length) }), el('span', { class: 'spacer' }), clear),
      compact ? null : el('ul', { class: 'sp-list' }, done.sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0)).map(row))));
  }
  // lo de siempre: lo que más anotás y no está en la lista
  const inList = new Set(pend.map(i => superKey(i.t)));
  const usual = Object.entries(d.freq).filter(([k, v]) => !inList.has(k) && v.n >= 1).sort((a, b) => b[1].n - a[1].n).slice(0, compact ? 6 : 12);
  if (usual.length) kids.push(el('div', { class: 'sp-usual' }, el('span', { class: 'sp-ul', text: 'Lo de siempre' }),
    ...usual.map(([k, v]) => { const b = el('button', { class: 'sp-chip', title: `Sumar ${v.t}` }, el('span', { text: '+ ' + v.t })); b.onclick = () => superAdd(v.t); b.oncontextmenu = (e) => { e.preventDefault(); delete superData().freq[k]; save(); renderSuperAll(); }; return b; })));
  if (pend.length) {
    const cp = el('button', { class: 'btn ghost sp-copy' }, svg('<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>'), el('span', { text: 'Copiar la lista' }));
    cp.onclick = async () => toast(await copyText(superText()) ? 'Lista copiada: pegala en WhatsApp' : 'No se pudo copiar');
    kids.push(el('div', { class: 'sp-foot' }, cp, el('span', { class: 'hint', text: compact ? '' : 'Clic derecho en una cosa para cambiarla de sección.' })));
  }
  box.replaceChildren(...kids);
}
function superCatMenu(e, i) {
  e.preventDefault();
  const m = $('#fx-ctx');
  const cur = superCatOf(i.t);
  m.replaceChildren(el('span', { class: 'fx-ctx-h', text: `“${i.t}” va en…` }), ...superCats().map(c => {
    const b = el('button', { role: 'menuitem', class: c.id === cur ? 'on' : '', style: `--cc:${c.c}` }, svg(c.ico), el('span', { text: c.n }));
    b.onclick = () => { m.hidden = true; superData().cats[superKey(i.t)] = c.id; save(); renderSuperAll(); };
    return b;
  }));
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(e.clientX, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(e.clientY, innerHeight - r.height - 8) + 'px';
  const close = (ev) => { if (!ev.target.closest('#fx-ctx')) { m.hidden = true; document.removeEventListener('pointerdown', close, true); } };
  setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
}
function renderSuper() {
  if (!widgetOn('super')) return;
  const box = $('#sp-body');
  if (box) { const focused = document.activeElement && box.contains(document.activeElement) && document.activeElement.classList.contains('sp-in'); buildSuper(box, false); if (focused) box.querySelector('.sp-in').focus(); }
}
function renderSuperAll() {
  const a = document.activeElement;
  const inZone = a && a.classList && a.classList.contains('sp-in') && a.closest('#zone');
  renderSuper(); zoneRefresh('super'); renderPeeks();
  if (inZone) { const n = $('#zone .sp-in'); if (n) n.focus(); }
}
function peekSuper() {
  if (!widgetOn('super')) return;
  const pend = superData().items.filter(i => !i.done);
  setText('pk-super-main', pend.length ? `${plural(pend.length, 'cosa', 'cosas')} para comprar` : 'Nada para comprar');
  setText('pk-super-sub', pend.length ? pend.slice(0, 4).map(i => i.t).join(', ') : 'Anotá lo que falta en casa');
  setText('pk-super-badge', pend.length ? String(pend.length) : '');
}
// ---------- Luces (lamparitas Smart Life) ----------
const LU = { st: {}, err: {}, busy: {}, scenes: null, thr: null };
const LU_COLORS = [['#ffffff', 'Blanco', { temp: 50 }], ['#ffd29a', 'Cálida', { temp: 0 }], ['#ff4d4d', 'Rojo'], ['#ff9a2e', 'Naranja'], ['#4fd36b', 'Verde'], ['#3d9bff', 'Azul'], ['#a77bff', 'Violeta'], ['#ff5fc1', 'Rosa']];
function luData() { return S.settings.luces = Object.assign({ lamps: [], sel: '' }, S.settings.luces || {}); }
function luSel() { const d = luData(); return d.lamps.find(l => l.id === d.sel) || d.lamps[0] || null; }
function luColorName(st) {
  if (!st) return '';
  if (st.mode !== 'colour') return st.temp < 25 ? 'Blanco cálido' : st.temp > 70 ? 'Blanco frío' : 'Blanco';
  const hex = st.color; const n = parseInt(hex.slice(1), 16), r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
  let best = null, bd = 1e9;
  for (const [c, name] of LU_COLORS.slice(2)) { const m = parseInt(c.slice(1), 16); const d = (r - (m >> 16 & 255)) ** 2 + (g - (m >> 8 & 255)) ** 2 + (b - (m & 255)) ** 2; if (d < bd) { bd = d; best = name; } }
  return best || 'Color';
}
function luOrbColor(st) {
  if (!st || !st.on) return '#9aa3ad';
  if (st.mode === 'colour') return st.color;
  const t = st.temp / 100; // 0 cálido -> 1 frío
  const mix = (a, b) => Math.round(a + (b - a) * t);
  return `rgb(${mix(255, 220)},${mix(196, 236)},${mix(120, 255)})`;
}
async function luRefresh(l, quiet) {
  if (!api.luces || !l) return;
  const r = await api.luces.status(l);
  if (r && r.ok) { LU.st[l.id] = r.st; delete LU.err[l.id]; if (r.st.schema && l.schema !== r.st.schema) { l.schema = r.st.schema; save(); } }
  else if (!quiet || !LU.st[l.id]) LU.err[l.id] = (r && r.error) || 'No responde';
  renderLuces(); renderPeeks(); panelPush();
}
async function luDo(l, a) {
  if (!api.luces || !l) return;
  // se ve al instante; si falla, se corrige con lo que diga la lamparita
  const cur = LU.st[l.id];
  if (cur) { if (a.on !== undefined) cur.on = a.on; if (a.toggle) cur.on = !cur.on; if (a.bright != null) cur.bright = a.bright; if (a.temp != null) { cur.temp = a.temp; cur.mode = 'white'; } if (a.color) { cur.color = a.color; cur.mode = 'colour'; cur.on = true; } }
  renderLuces();
  LU.busy[l.id] = (LU.busy[l.id] || 0) + 1;
  const r = await api.luces.act(l, a);
  LU.busy[l.id]--;
  if (r && r.ok) { if (!LU.busy[l.id]) LU.st[l.id] = r.st; delete LU.err[l.id]; }
  else { LU.err[l.id] = (r && r.error) || 'No responde'; }
  renderLuces(); renderPeeks();
}
function luThrottle(l, a) {
  clearTimeout(LU.thr);
  const now = Date.now();
  if (!LU.last || now - LU.last > 250) { LU.last = now; luDo(l, a); }
  else LU.thr = setTimeout(() => { LU.last = Date.now(); luDo(l, a); }, 250);
}
function luSlider(label, cls, val, min, onSet) {
  const r = el('input', { type: 'range', min: String(min), max: '100', value: String(val), class: 'lu-range ' + cls, 'aria-label': label });
  r.oninput = () => onSet(Number(r.value), false);
  r.onchange = () => onSet(Number(r.value), true);
  return el('label', { class: 'lu-sl' }, el('span', { class: 'lu-lab', text: label }), r);
}
function buildLuces(box, compact) {
  const d = luData();
  box.replaceChildren();
  if (!d.lamps.length) {
    const b = el('button', { class: 'btn primary', text: 'Sumar mi primera luz' }); b.onclick = () => openLuzWizard();
    box.append(el('div', { class: 'lu-empty' },
      el('div', { class: 'lu-orb off' }),
      el('b', { text: 'Prendé y apagá tus lamparitas desde acá' }),
      el('p', { class: 'hint', text: 'Funciona con las de Smart Life (Tuya) que ya usás con el celular. Se configuran una sola vez.' }), b));
    return;
  }
  const l = luSel(); const st = LU.st[l.id]; const err = LU.err[l.id];
  const sw = el('label', { class: 'switch lu-sw', title: st && st.on ? 'Apagar' : 'Prender' }, el('input', { type: 'checkbox' }), el('span'));
  sw.firstChild.checked = !!(st && st.on); sw.firstChild.disabled = !st;
  sw.firstChild.onchange = (e) => luDo(l, { on: e.target.checked });
  const chips = el('div', { class: 'lu-chips' }, ...d.lamps.map(x => {
    const c = el('button', { class: 'lu-chip' + (x.id === l.id ? ' on' : ''), text: x.name || 'Luz' });
    c.onclick = () => { d.sel = x.id; save(); renderLuces(); if (!LU.st[x.id]) luRefresh(x); };
    c.oncontextmenu = (e) => luLampMenu(e, x);
    return c;
  }), (() => { const a = el('button', { class: 'lu-chip add', text: '+ Sumar luz' }); a.onclick = () => openLuzWizard(); return a; })());
  box.append(el('div', { class: 'lu-head' }, el('h2', { text: 'Luces' }), sw), chips);
  if (!st) {
    const rt = el('button', { class: 'btn sm', text: 'Reintentar' }); rt.onclick = () => { delete LU.err[l.id]; renderLuces(); luRefresh(l); };
    box.append(el('div', { class: 'lu-wait' }, el('div', { class: 'lu-orb off' }), el('div', {}, el('b', { text: err ? 'No pude hablar con “' + (l.name || 'la luz') + '”' : 'Conectando…' }), el('p', { class: 'hint', text: err ? err : 'Un segundo' }), err ? rt : '')));
    if (!err && !LU.busy['q' + l.id]) { LU.busy['q' + l.id] = 1; luRefresh(l).finally(() => { LU.busy['q' + l.id] = 0; }); }
    return;
  }
  const orb = el('button', { class: 'lu-orb' + (st.on ? '' : ' off'), title: st.on ? 'Apagar' : 'Prender', style: `--c:${luOrbColor(st)}` });
  orb.onclick = () => luDo(l, { on: !st.on });
  box.append(el('div', { class: 'lu-now' }, orb, el('div', {}, el('b', { text: st.on ? luColorName(st) : 'Apagada' }), el('span', { class: 'hint', text: (st.on ? `Brillo ${st.bright}% · Prendida` : 'Tocá la lamparita para prenderla') + (err ? ' · ' + err : '') }))));
  const br = luSlider('Brillo', 'br', st.bright, 1, (v, fin) => fin ? luDo(l, { bright: v }) : luThrottle(l, { bright: v }));
  br.querySelector('input').style.setProperty('--c', st.mode === 'colour' ? st.color : '#ffd9a0');
  box.append(br);
  if (st.hasTemp !== false) box.append(luSlider('Blanco cálido ↔ frío', 'tp', st.temp, 0, (v, fin) => fin ? luDo(l, { temp: v }) : luThrottle(l, { temp: v })));
  if (st.hasColor !== false) {
    const pick = el('input', { type: 'color', value: st.color || '#ffffff', 'aria-label': 'Otro color' });
    pick.oninput = () => luThrottle(l, { color: pick.value });
    box.append(el('span', { class: 'lu-lab', text: 'Color' }), el('div', { class: 'lu-cols' },
      ...LU_COLORS.map(([c, n, extra]) => {
        const sel = st.on && (extra ? st.mode === 'white' && Math.abs(st.temp - extra.temp) < 12 : st.mode === 'colour' && luColorName(st) === n);
        const b = el('button', { class: 'lu-col' + (sel ? ' on' : ''), title: n, style: `--c:${c}` });
        b.onclick = () => luDo(l, extra ? { temp: extra.temp } : { color: c });
        return b;
      }),
      el('label', { class: 'lu-col rainbow', title: 'Elegir otro color' }, pick)));
  }
  if (LU.scenes) box.append(el('span', { class: 'lu-lab', text: 'Escenas' }), el('div', { class: 'lu-scenes' }, ...LU.scenes.map(sc => {
    const b = el('button', { class: 'lu-scene', style: `--c:${sc.color}` }, el('i'), el('span', { text: sc.n })); b.onclick = () => luDo(l, { scene: sc.id }); return b;
  })));
}
function luLampMenu(e, x) {
  e.preventDefault();
  const m = $('#fx-ctx');
  const mk = (t, fn, cls) => { const b = el('button', { class: 'fx-ctx-i' + (cls ? ' ' + cls : ''), text: t }); b.onclick = () => { m.hidden = true; fn(); }; return b; };
  m.replaceChildren(el('span', { class: 'fx-ctx-h', text: x.name || 'Luz' }),
    mk('Cambiar el nombre', () => { const n = prompt('Nombre de la luz', x.name || ''); if (n && n.trim()) { x.name = n.trim().slice(0, 30); save(); renderLuces(); } }),
    mk('Volver a buscarla en la red', () => { delete LU.st[x.id]; delete LU.err[x.id]; renderLuces(); }),
    mk('Quitar', () => { const d = luData(); d.lamps = d.lamps.filter(y => y !== x); save(); renderLuces(); renderPeeks(); toast('Luz quitada'); }, 'danger'));
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(e.clientX, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(e.clientY, innerHeight - r.height - 8) + 'px';
  const close = (ev) => { if (!ev.target.closest('#fx-ctx')) { m.hidden = true; document.removeEventListener('pointerdown', close, true); } };
  setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
}
function renderLuces() {
  if (!widgetOn('luces')) return;
  const box = $('#lu-body');
  if (!box) return;
  const a = document.activeElement;
  if (a && a.classList && a.classList.contains('lu-range') && box.contains(a) && LU.dragging) return; // no cortar el arrastre
  if (!LU.scenes && api.luces && !LU.scLoading) { LU.scLoading = true; api.luces.scenes().then(sc => { LU.scenes = sc; renderLuces(); }); }
  buildLuces(box, false);
}
function peekLuces() {
  if (!widgetOn('luces')) return;
  const d = luData();
  if (!d.lamps.length) { setText('pk-luces-main', 'Sumá tus lamparitas'); setText('pk-luces-sub', 'Smart Life, sin el celular'); setText('pk-luces-badge', ''); return; }
  const on = d.lamps.filter(l => LU.st[l.id] && LU.st[l.id].on);
  const l = luSel(), st = LU.st[l.id];
  setText('pk-luces-main', st ? `${l.name || 'Luz'}: ${st.on ? luColorName(st).toLowerCase() + ' ' + st.bright + '%' : 'apagada'}` : (LU.err[l.id] ? `${l.name || 'Luz'}: no responde` : `${l.name || 'Luz'}`));
  setText('pk-luces-sub', on.length ? plural(on.length, 'prendida', 'prendidas') : 'Todas apagadas');
  setText('pk-luces-badge', on.length ? String(on.length) : '');
}
document.addEventListener('pointerdown', (e) => { if (e.target.classList && e.target.classList.contains('lu-range')) LU.dragging = true; }, true);
document.addEventListener('pointerup', () => { if (LU.dragging) { LU.dragging = false; setTimeout(renderLuces, 300); } }, true);

// ----- Asistente para sumar luces -----
const LW = { step: 'start', cid: '', secret: '', region: 'auto', found: [], scan: [], error: '', busy: false };
function openLuzWizard() {
  Object.assign(LW, { step: 'start', error: '', busy: false, found: [] });
  renderLuzWizard();
  $('#dlg-luz').showModal();
}
function luzField(label, input) { return el('label', { class: 'lw-f' }, el('span', { class: 'field-label', text: label }), input); }
function renderLuzWizard() {
  const box = $('#luz-wiz');
  const close = el('button', { type: 'button', class: 'btn ghost', text: 'Cerrar' }); close.onclick = () => $('#dlg-luz').close();
  const err = el('p', { class: 'error', text: LW.error || '' });
  if (LW.step === 'start') {
    const a = el('button', { class: 'lw-opt' }, el('b', { text: 'Con mi cuenta de Smart Life' }), el('span', { text: 'Recomendado. Base trae solas todas tus luces con sus claves. Lleva unos 10 minutos, una sola vez.' }));
    a.onclick = () => { LW.step = 'cloud'; renderLuzWizard(); };
    const b = el('button', { class: 'lw-opt' }, el('b', { text: 'Ya tengo los datos de la luz' }), el('span', { text: 'ID del dispositivo, clave local (local key) y dirección IP.' }));
    b.onclick = () => { LW.step = 'manual'; renderLuzWizard(); };
    box.replaceChildren(el('h2', { id: 'dlg-luz-title', text: 'Sumar una luz' }),
      el('p', { class: 'hint', text: 'Base maneja las lamparitas directo por el WiFi de tu casa: responde al instante y no depende de internet. Para eso necesita una clave de cada lamparita, que se consigue una sola vez.' }),
      el('div', { class: 'lw-opts' }, a, b), el('div', { class: 'dlg-actions' }, el('span', { class: 'spacer' }), close));
    return;
  }
  if (LW.step === 'cloud') {
    const steps = [
      ['Creá una cuenta gratis en la plataforma de Tuya', 'Entrá a iot.tuya.com y registrate (podés usar el mismo mail de Smart Life).', 'https://iot.tuya.com'],
      ['Creá un proyecto', 'Cloud → Development → Create Cloud Project. Nombre: Base. Industry: Smart Home. Development Method: Smart Home. Data Center: “Western America”. En la pantalla siguiente aceptá los servicios que te propone.'],
      ['Vinculá tu app Smart Life', 'Dentro del proyecto: Devices → Link App Account → Add App Account. Sale un código QR: escanealo con Smart Life (pestaña Yo → ícono de escanear arriba a la derecha) y confirmá.'],
      ['Copiá las dos claves', 'En la pestaña Overview del proyecto están el Access ID / Client ID y el Access Secret / Client Secret. Pegalos acá abajo.']
    ];
    const cid = el('input', { value: LW.cid, placeholder: 'Access ID / Client ID', autocomplete: 'off', spellcheck: 'false' });
    const sec = el('input', { value: LW.secret, placeholder: 'Access Secret / Client Secret', type: 'password', autocomplete: 'off' });
    const reg = el('select', {}, el('option', { value: 'auto', text: 'Averiguarlo solo' }));
    for (const r of [['us', 'América (oeste) — el de Argentina'], ['ue', 'América (este)'], ['eu', 'Europa central'], ['we', 'Europa (oeste)'], ['in', 'India'], ['cn', 'China']]) reg.append(el('option', { value: r[0], text: r[1] }));
    reg.value = LW.region;
    const go = el('button', { class: 'btn primary', text: LW.busy ? 'Buscando tus luces…' : 'Buscar mis luces' }); go.disabled = LW.busy;
    go.onclick = async () => {
      LW.cid = cid.value.trim(); LW.secret = sec.value.trim(); LW.region = reg.value;
      if (!LW.cid || !LW.secret) { LW.error = 'Pegá las dos claves'; return renderLuzWizard(); }
      LW.busy = true; LW.error = ''; renderLuzWizard();
      const [c, sc] = await Promise.all([api.luces.cloud(LW.cid, LW.secret, LW.region), api.luces.scan()]);
      LW.busy = false;
      if (!c || !c.ok) { LW.error = (c && c.error) || 'No pude entrar a Tuya'; return renderLuzWizard(); }
      LW.scan = (sc && sc.list) || [];
      const have = new Set(luData().lamps.map(l => l.id));
      LW.found = c.devices.map(dv => { const s2 = LW.scan.find(x => x.id === dv.id); return Object.assign({}, dv, { ip: s2 ? s2.ip : '', ver: s2 ? s2.ver : 'auto', pick: dv.light && !have.has(dv.id), have: have.has(dv.id) }); })
        .sort((x, y) => (y.light - x.light) || String(x.name).localeCompare(y.name));
      LW.step = 'pick'; renderLuzWizard();
    };
    const back = el('button', { type: 'button', class: 'btn ghost', text: 'Atrás' }); back.onclick = () => { LW.step = 'start'; LW.error = ''; renderLuzWizard(); };
    box.replaceChildren(el('h2', { id: 'dlg-luz-title', text: 'Traer tus luces de Smart Life' }),
      el('ol', { class: 'lw-steps' }, ...steps.map(([t, d2, url]) => el('li', {}, el('b', { text: t }), el('span', { text: d2 }), url ? (() => { const a = el('button', { class: 'text-btn', text: 'Abrir iot.tuya.com' }); a.onclick = () => api.openUrl ? api.openUrl(url) : window.open(url); return a; })() : ''))),
      el('div', { class: 'lw-grid' }, luzField('Access ID', cid), luzField('Access Secret', sec), luzField('Región', reg)),
      el('p', { class: 'hint', text: 'Las claves se usan solo ahora para traer la lista y no se guardan.' }),
      err, el('div', { class: 'dlg-actions' }, back, el('span', { class: 'spacer' }), close, go));
    return;
  }
  if (LW.step === 'pick') {
    const rows = LW.found.map(dv => {
      const cb = el('input', { type: 'checkbox' }); cb.checked = dv.pick; cb.disabled = dv.have; cb.onchange = () => { dv.pick = cb.checked; };
      const ip = el('input', { value: dv.ip, placeholder: 'IP (ej. 192.168.0.23)', class: 'lw-ip' }); ip.oninput = () => { dv.ip = ip.value.trim(); };
      return el('div', { class: 'lw-row' + (dv.light ? '' : ' other') }, el('label', { class: 'lw-cb' }, cb, el('span', {}, el('b', { text: dv.name }), el('small', { text: (dv.have ? 'Ya está en Base · ' : '') + (dv.product || dv.cat) + (dv.online ? '' : ' · desconectada') }))), dv.ip ? el('span', { class: 'lw-ipok', text: dv.ip }) : ip);
    });
    const add = el('button', { class: 'btn primary', text: LW.busy ? 'Probando…' : 'Sumar las elegidas' }); add.disabled = LW.busy;
    add.onclick = async () => {
      const sel = LW.found.filter(dv => dv.pick);
      if (!sel.length) { LW.error = 'Elegí al menos una'; return renderLuzWizard(); }
      const noIp = sel.filter(dv => !/^\d+\.\d+\.\d+\.\d+$/.test(dv.ip || ''));
      if (noIp.length) { LW.error = 'Falta la IP de: ' + noIp.map(x => x.name).join(', ') + '. La ves en Smart Life → la luz → lápiz arriba → Información del dispositivo.'; return renderLuzWizard(); }
      LW.busy = true; LW.error = ''; renderLuzWizard();
      const bad = [];
      for (const dv of sel) {
        const r = await api.luces.detect({ id: dv.id, key: dv.key, ip: dv.ip, ver: dv.ver || 'auto' });
        if (r && r.ok) { luData().lamps.push({ id: dv.id, name: dv.name, key: dv.key, ip: dv.ip, ver: r.ver, schema: r.schema }); LU.st[dv.id] = r.st; }
        else bad.push(dv.name + ' (' + ((r && r.error) || 'no responde') + ')');
      }
      LW.busy = false; save();
      if (!luData().sel && luData().lamps[0]) luData().sel = luData().lamps[0].id;
      renderLuces(); renderPeeks();
      if (bad.length) { LW.error = 'No pude conectarme con: ' + bad.join(' · '); LW.found.forEach(dv => { if (luData().lamps.some(l => l.id === dv.id)) { dv.have = true; dv.pick = false; } }); return renderLuzWizard(); }
      $('#dlg-luz').close(); toast(sel.length > 1 ? 'Luces sumadas' : 'Luz sumada');
    };
    box.replaceChildren(el('h2', { id: 'dlg-luz-title', text: 'Elegí qué luces sumar' }),
      el('p', { class: 'hint', text: LW.scan.length ? `Encontré ${plural(LW.found.length, 'dispositivo', 'dispositivos')} en tu cuenta y ${plural(LW.scan.length, 'equipo', 'equipos')} en tu red.` : 'No pude ver las luces en la red (puede que el firewall de Windows lo haya frenado). Escribí la IP de cada una.' }),
      el('div', { class: 'lw-list' }, ...rows), err, el('div', { class: 'dlg-actions' }, el('span', { class: 'spacer' }), close, add));
    return;
  }
  if (LW.step === 'manual') {
    const f = { name: el('input', { placeholder: 'Ej. Living' }), id: el('input', { placeholder: 'ID del dispositivo', spellcheck: 'false' }), key: el('input', { placeholder: '16 caracteres', spellcheck: 'false' }), ip: el('input', { placeholder: '192.168.0.23' }) };
    const ver = el('select', {}, ...[['auto', 'Averiguarla sola'], ['3.3', '3.3'], ['3.4', '3.4'], ['3.5', '3.5'], ['3.1', '3.1']].map(([v, t]) => el('option', { value: v, text: t })));
    const go = el('button', { class: 'btn primary', text: LW.busy ? 'Probando…' : 'Probar y sumar' }); go.disabled = LW.busy;
    go.onclick = async () => {
      const o = { id: f.id.value.trim(), key: f.key.value.trim(), ip: f.ip.value.trim(), ver: ver.value };
      if (!o.id || o.key.length !== 16 || !/^\d+\.\d+\.\d+\.\d+$/.test(o.ip)) { LW.error = 'Revisá los datos: la clave local tiene 16 caracteres y la IP es del estilo 192.168.0.23'; return renderLuzWizard(); }
      LW.busy = true; LW.error = ''; renderLuzWizard();
      const r = await api.luces.detect(o);
      LW.busy = false;
      if (!r || !r.ok) { LW.error = (r && r.error) || 'No responde'; return renderLuzWizard(); }
      const d = luData(); d.lamps = d.lamps.filter(l => l.id !== o.id);
      d.lamps.push({ id: o.id, name: f.name.value.trim() || 'Luz', key: o.key, ip: o.ip, ver: r.ver, schema: r.schema }); d.sel = o.id; LU.st[o.id] = r.st;
      save(); renderLuces(); renderPeeks(); $('#dlg-luz').close(); toast('Luz sumada');
    };
    const back = el('button', { type: 'button', class: 'btn ghost', text: 'Atrás' }); back.onclick = () => { LW.step = 'start'; LW.error = ''; renderLuzWizard(); };
    box.replaceChildren(el('h2', { id: 'dlg-luz-title', text: 'Datos de la luz' }),
      el('div', { class: 'lw-grid' }, luzField('Nombre', f.name), luzField('ID del dispositivo', f.id), luzField('Clave local (local key)', f.key), luzField('Dirección IP', f.ip), luzField('Versión', ver)),
      err, el('div', { class: 'dlg-actions' }, back, el('span', { class: 'spacer' }), close, go));
  }
}
setInterval(() => { if (!document.hidden && S && widgetOn('luces') && api.luces) for (const l of luData().lamps) if (!LU.busy[l.id]) luRefresh(l, true); }, 60000);

// ---------- Panel para la tablet ----------
const PN = { timer: null, wx: null, info: null, infoT: null };
function panelOn() { return !!(S && S.settings.panelOn); }
function pnItem(sc) { return { id: sc.id, n: sc.name, ic: sc.letter ? null : (sc.icon || (sc.type === 'web' ? webIcon(sc.target) : null)), l: letterFor(sc.name) }; }
function panelSnap() {
  if (!LU.scenes && api.luces && !LU.scLoading) { LU.scLoading = true; api.luces.scenes().then(sc => { LU.scenes = sc; panelPush(); }).catch(() => {}); }
  const m = S.activeMode;
  const items = [];
  for (const sc of M().shortcuts) {
    if (isFolder(sc)) items.push({ id: sc.id, n: sc.name, g: (sc.items || []).map(pnItem) });
    else items.push(pnItem(sc));
  }
  for (const src of ['taskbar', 'desktop']) { const its = sysItems(src); if (its.length) items.push({ id: SYS[src].id, n: SYS[src].name, g: its.map(pnItem) }); }
  const lamps = luData().lamps.map(l => ({ id: l.id, n: l.name || 'Luz', st: LU.st[l.id] || null }));
  const sp = superData().items.filter(i => !i.done).map(i => ({ id: i.id || i.t, t: i.t, q: i.q || '' }));
  return {
    v: 1, name: S.settings.name || '', board: m, boards: allModes().map(id => ({ id, n: modeName(id) })),
    accent: M().theme.accent, dark: M().theme.scheme === 'dark', dnd: !!S.settings.dnd,
    items, lamps, scenes: LU.scenes || [], super: sp, wx: PN.wx, panel: S.settings.panel || null,
    cfg: { deskMode: !!S.settings.deskMode, hideTaskbar: !!S.settings.hideTaskbar, fullscreen: !!S.settings.fullscreen, startWithWindows: !!S.settings.startWithWindows }
  };
}
function panelPush() {
  if (!panelOn() || !api.panel) return;
  clearTimeout(PN.timer);
  PN.timer = setTimeout(() => { try { api.panel.push(panelSnap()); } catch (e) { console.error(e); } }, 300);
}
function pnFindItem(id) {
  const loc = locate(id); if (loc) return loc.item;
  for (const src of ['taskbar', 'desktop']) { const it = sysItems(src).find(x => x.id === id); if (it) return it; }
  return null;
}
// ----- Ajustes de Base manejados desde la tablet: se arma una copia del panel de Ajustes de la compu -----
function drawerOn(b) { return b.classList.contains('on') || b.classList.contains('sel') || b.classList.contains('active') || b.getAttribute('aria-pressed') === 'true' || b.getAttribute('aria-checked') === 'true'; }
function drawerLabel(el) {
  if (el.id) { const l = document.querySelector(`label.field-label[for="${el.id}"]`); if (l) return l.textContent.trim(); }
  const sw = el.closest('label.switch, label.custom-color'); if (sw) return sw.textContent.trim();
  let n = el.previousElementSibling;
  while (n) { if (n.classList && n.classList.contains('field-label')) return n.textContent.trim(); n = n.previousElementSibling; }
  return el.getAttribute('aria-label') || el.title || '';
}
function drawerVisible(el) { return !el.closest('[hidden]') && !el.closest('.multi-only.hide'); }
// "foto" de un elemento del panel (para mostrarlo en la tablet): copia sus estilos y lo dibuja en un PNG
const RAST_PROPS = ['display', 'position', 'top', 'left', 'right', 'bottom', 'inset', 'width', 'height', 'min-width', 'min-height', 'max-width', 'max-height', 'margin', 'padding', 'box-sizing',
  'flex', 'flex-direction', 'flex-wrap', 'align-items', 'align-self', 'justify-content', 'justify-items', 'place-items', 'gap', 'grid-template-columns', 'grid-template-rows', 'grid-column', 'grid-row', 'grid-area',
  'color', 'background', 'background-color', 'background-image', 'background-size', 'background-position', 'background-repeat', 'opacity', 'border', 'border-radius', 'box-shadow', 'outline',
  'font-family', 'font-size', 'font-weight', 'font-style', 'font-variant-numeric', 'line-height', 'letter-spacing', 'text-align', 'text-transform', 'white-space', 'text-overflow', 'overflow', 'text-shadow',
  'transform', 'transform-origin', 'z-index', 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray', 'vertical-align', 'filter', 'backdrop-filter', '-webkit-line-clamp', '-webkit-box-orient', 'mix-blend-mode', 'clip-path', 'aspect-ratio'];
function rastClone(src) {
  const c = src.cloneNode(false);
  if (src.nodeType === 1) {
    const cs = getComputedStyle(src);
    let txt = '';
    for (const p of RAST_PROPS) { const v = cs.getPropertyValue(p); if (v && !/url\(/.test(v)) txt += `${p}:${v};`; }
    c.setAttribute('style', txt);
    c.removeAttribute('class'); c.removeAttribute('id'); c.removeAttribute('data-rid');
    for (const ch of src.childNodes) c.appendChild(rastClone(ch));
  }
  return c;
}
const RAST = new Map();
function rasterize(node, w, h, key) {
  if (key && RAST.has(key)) return Promise.resolve(RAST.get(key));
  return new Promise((resolve) => {
    try {
      const clone = rastClone(node);
      clone.style.width = w + 'px'; clone.style.height = h + 'px'; clone.style.margin = '0'; clone.style.boxSizing = 'border-box';
      const xml = new XMLSerializer().serializeToString(clone);
      const svgTxt = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><foreignObject x="0" y="0" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${w}px;height:${h}px;font-family:${getComputedStyle(document.body).fontFamily.replace(/"/g, "'")}">${xml}</div></foreignObject></svg>`;
      const img = new Image();
      img.onload = () => {
        try {
          const cv = document.createElement('canvas'); cv.width = w * 2; cv.height = h * 2;
          const g = cv.getContext('2d'); g.scale(2, 2); g.drawImage(img, 0, 0);
          const out = cv.toDataURL('image/png');
          if (key) RAST.set(key, out);
          resolve(out);
        } catch { resolve(''); }
      };
      img.onerror = () => resolve('');
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgTxt);
    } catch { resolve(''); }
  });
}
// qué parte de cada opción se "fotografía" para la tablet
const RAST_SPEC = {
  'bg-presets': { sel: '.prev', w: 132, h: 66 },
  'clock-models': { sel: '.cm-prev', w: 150, h: 70 },
  'nf-looks': { sel: '.nf', w: 250, h: 72 },
  'cursor-pick': { sel: '.cur-prev', w: 44, h: 44 }
};
async function drawerSchemaFull() {
  const sc = drawerSchema();
  const jobs = [];
  for (const sec of sc.secs) for (const it of sec.items) {
    if (it.t !== 'choice' || !it.cid || !RAST_SPEC[it.cid]) continue;
    const spec = RAST_SPEC[it.cid];
    const box = document.getElementById(it.cid);
    it.opts.forEach((o, i) => {
      const btn = box && box.children[i]; if (!btn) return;
      const img = btn.querySelector('img');
      const target = btn.querySelector(spec.sel);
      if (it.cid === 'cursor-pick' && img && /^data:/.test(img.src)) { o.img = img.src; return; }
      if (it.cid === 'bg-presets' && target) { const bg = getComputedStyle(target).backgroundImage; const m = /url\("?(https:[^")]+)"?\)/.exec(bg); if (m) { o.img = m[1]; return; } }
      if (!target) return;
      const key = it.cid + '|' + o.n + '|' + (M().theme.scheme) + '|' + M().theme.accent + '|' + (it.cid === 'cursor-pick' ? (S.settings.cursorColor || '') : '') + '|' + (it.cid === 'clock-models' ? JSON.stringify(clockCfg()) : '');
      jobs.push(rasterize(target, spec.w, spec.h, key).then(u => { if (u) o.img = u; }));
    });
  }
  await Promise.all(jobs);
  return sc;
}
function drawerSchema() {
  try { renderDrawer(); } catch {}
  let rid = 0;
  const mark = (el) => { el.dataset.rid = 'r' + (++rid); return el.dataset.rid; };
  const secs = [];
  for (const sec of $$('#dpanes .dsec')) {
    const key = sec.dataset.sec;
    if (key === 'tablet' || key === 'copia') continue;
    const items = [];
    const seen = new Set();
    for (const el of sec.querySelectorAll('input, select, button, div, p.hint')) {
      if (seen.has(el) || !drawerVisible(el)) continue;
      if (el.tagName === 'DIV') {
        const kids = [...el.children];
        if (kids.length >= 2 && kids.every(k => k.tagName === 'BUTTON')) {
          kids.forEach(k => seen.add(k));
          items.push({ t: 'choice', id: mark(el), cid: el.id || '', label: drawerLabel(el), opts: kids.map((k, i) => {
            const cs = getComputedStyle(k);
            let bg = cs.backgroundImage && cs.backgroundImage !== 'none' && !/url\(/.test(cs.backgroundImage) ? cs.backgroundImage : '';
            const swatch = k.style.getPropertyValue('--c') || k.style.background || k.style.backgroundColor || (!bg && cs.backgroundColor !== 'rgba(0, 0, 0, 0)' && k.closest('.swatches') ? cs.backgroundColor : '');
            const nm = k.title || k.getAttribute('aria-label') || ((k.querySelector('.lbl, b, strong') || [...k.querySelectorAll('span')].find(x => x.textContent.trim() && !x.querySelector('span')) || k).textContent || '');
            return { i, n: nm.trim().replace(/\s+/g, ' ').slice(0, 40), on: drawerOn(k), bg: bg || swatch || '' };
          }) });
        }
        continue;
      }
      if (el.tagName === 'P') { if (el.textContent.trim().length < 160 && items.length) items.push({ t: 'hint', text: el.textContent.trim() }); continue; }
      if (el.tagName === 'INPUT') {
        if (el.type === 'checkbox') items.push({ t: 'toggle', id: mark(el), label: drawerLabel(el), v: el.checked });
        else if (el.type === 'range') items.push({ t: 'range', id: mark(el), label: drawerLabel(el), v: Number(el.value), min: Number(el.min || 0), max: Number(el.max || 100), step: Number(el.step || 1) });
        else if (el.type === 'color') items.push({ t: 'color', id: mark(el), label: drawerLabel(el) || 'Otro color', v: el.value });
        else if (el.type === 'text' || !el.type || el.type === 'search') items.push({ t: 'text', id: mark(el), label: drawerLabel(el), v: el.value, ph: el.placeholder || '' });
        continue;
      }
      if (el.tagName === 'SELECT') { items.push({ t: 'select', id: mark(el), label: drawerLabel(el), v: el.value, opts: [...el.options].filter(o => !o.disabled).map(o => [o.value, o.textContent.trim()]) }); continue; }
      if (el.tagName === 'BUTTON') {
        if (key === 'cuentas' || el.classList.contains('danger') || el.closest('.dnav')) continue;
        items.push({ t: 'button', id: mark(el), label: el.textContent.trim() || el.title });
      }
    }
    secs.push({ key, title: (sec.querySelector('h3') || {}).textContent ? sec.querySelector('h3').textContent.trim() : key, items });
  }
  return { board: modeName(S.activeMode), secs };
}
function drawerSet(msg) {
  const el = document.querySelector(`#dpanes [data-rid="${String(msg.id).replace(/[^a-z0-9]/gi, '')}"]`);
  if (!el) return false;
  if (msg.opt != null) { const b = el.children[Number(msg.opt)]; if (b) b.click(); return true; }
  if (el.tagName === 'BUTTON') { el.click(); return true; }
  if (el.type === 'checkbox') el.checked = !!msg.v; else el.value = String(msg.v);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}
async function panelDo(msg) {
  let r = { ok: true };
  try {
    switch (msg.a) {
      case 'open': { const sc = pnFindItem(msg.id); if (!sc) { r = { ok: false, error: 'Ese acceso ya no está' }; break; } const err = await api.open(sc); r = err ? { ok: false, error: err } : { ok: true }; break; }
      case 'board': if (S.modes[msg.id]) setMode(msg.id); break;
      case 'dnd': S.settings.dnd = msg.on != null ? !!msg.on : !S.settings.dnd; save(); renderNotifBadge(); if ($('#np-dnd')) $('#np-dnd').checked = S.settings.dnd; r = { ok: true, on: S.settings.dnd }; break;
      case 'theme': $('#btn-scheme').click(); break;
      case 'super': {
        const d = superData();
        if (msg.add) superAdd(String(msg.add).slice(0, 80));
        else if (msg.done) { const it = d.items.find(i => (i.id || i.t) === msg.done); if (it) { it.done = true; save(); renderSuperAll(); } }
        break;
      }
      case 'drawer': r = { ok: true, schema: await drawerSchemaFull() }; break;
      case 'drawerset': { const ok = drawerSet(msg); await new Promise(res => setTimeout(res, 120)); r = { ok, schema: await drawerSchemaFull() }; break; }
      case 'setting': {
        const k = String(msg.k || ''), v = msg.v;
        if (k === 'dark') { const t = M().theme; t.scheme = v ? 'dark' : 'light'; commitTheme(); WxAnim.refresh(); }
        else if (k === 'accent' && /^#[0-9a-f]{6}$/i.test(String(v))) { M().theme.accent = String(v); commitTheme(); }
        else if (['deskMode', 'hideTaskbar', 'fullscreen', 'startWithWindows'].includes(k)) { S.settings[k] = !!v; if (k === 'deskMode') applyDeskUi(); await commitSettings(); }
        else r = { ok: false };
        if ($('#drawer').classList.contains('on')) renderDrawer();
        break;
      }
      case 'layout': S.settings.panel = msg.panel && typeof msg.panel === 'object' ? JSON.parse(JSON.stringify(msg.panel)) : null; save(); break;
      case 'lampState': LU.st[msg.id] = msg.st; delete LU.err[msg.id]; renderLuces(); renderPeeks(); break;
      default: r = { ok: false };
    }
  } catch (e) { r = { ok: false, error: e.message }; }
  if (msg._id) api.panel.reply(msg._id, r);
  panelPush();
}
async function renderPanelSettings() {
  if (!api.panel) return;
  $('#set-panel').checked = panelOn();
  $('#panel-box').hidden = !panelOn();
  if (!panelOn()) return;
  const i = await api.panel.info();
  PN.info = i;
  const box = $('#pn-qr');
  if (i && i.qr) {
    const n = i.qr.length, q = 2;
    let d = '';
    i.qr.forEach((row, y) => { for (let x = 0; x < n; x++) if (row[x] === '1') d += `M${x + q} ${y + q}h1v1h-1z`; });
    box.innerHTML = `<svg viewBox="0 0 ${n + q * 2} ${n + q * 2}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#111"/></svg>`;
  } else box.replaceChildren(el('span', { class: 'hint', text: 'Prendiendo…' }));
  $('#pn-url').textContent = i && i.url ? i.url.replace(/\?k=.*/, '') : '';
  $('#pn-err').textContent = i && i.error ? i.error : (i && !i.ips.length ? 'No encuentro la red de casa en esta compu (¿está conectada al WiFi o con cable?).' : '');
  const c = i && i.clients && i.clients[0];
  $('#pn-clients').textContent = c ? (Date.now() - c.at < 15000 ? 'Hay una tablet conectada ahora.' : 'La última tablet se conectó ' + ago(c.at) + '.') : 'Todavía no se conectó ninguna tablet.';
}
function setupPanel() {
  if (!api.panel) { const b = $('#dnav button[data-sec="tablet"]'); if (b) b.hidden = true; return; }
  api.panel.onDo(panelDo);
  $('#set-panel').onchange = async (e) => { S.settings.panelOn = e.target.checked; await commitSettings(); panelPush(); setTimeout(renderPanelSettings, 400); };
  $('#pn-reset').onclick = async () => { if (!confirm('Las tablets vinculadas van a dejar de funcionar hasta que escanees el código nuevo. ¿Seguimos?')) return; await api.panel.reset(); renderPanelSettings(); toast('Listo: escaneá el código nuevo con la tablet'); };
  $('#dnav button[data-sec="tablet"]').addEventListener('click', () => { renderPanelSettings(); clearInterval(PN.infoT); PN.infoT = setInterval(() => { if (ui.dsec === 'tablet' && $('#drawer').classList.contains('on')) renderPanelSettings(); else clearInterval(PN.infoT); }, 5000); });
  if (panelOn()) { api.applySettings(S.settings); panelPush(); }
  setInterval(panelPush, 20000);
}

// ---------- Calculadora ----------
const CALC = { toks: [], cur: '0', fresh: true, err: false, lbl: '', views: new Set() };
function calcData() { return S.settings.calc = Object.assign({ hist: [] }, S.settings.calc || {}); }
const CALC_SYM = { '+': '+', '-': '−', '*': '×', '/': '÷' };
function calcFmt(n) {
  if (!isFinite(n)) return 'Error';
  const r = Math.round(n * 1e10) / 1e10;
  if (r !== 0 && (Math.abs(r) >= 1e15 || Math.abs(r) < 1e-9)) return r.toExponential(6).replace('.', ',');
  return r.toLocaleString('es-AR', { maximumFractionDigits: 10 });
}
function calcFmtEntry(s) {
  const neg = s.startsWith('-'); const t = neg ? s.slice(1) : s;
  const [i, d] = t.split('.');
  const int = (Number(i) || 0).toLocaleString('es-AR', { maximumFractionDigits: 0 });
  return (neg ? '−' : '') + int + (d !== undefined ? ',' + d : '');
}
function calcEval(toks) {
  // primero × y ÷, después + y −
  const a = [toks[0]];
  for (let i = 1; i < toks.length; i += 2) {
    const op = toks[i], n = toks[i + 1];
    if (op === '*') a[a.length - 1] *= n;
    else if (op === '/') { if (n === 0) return NaN; a[a.length - 1] /= n; }
    else a.push(op, n);
  }
  let r = a[0];
  for (let i = 1; i < a.length; i += 2) r = a[i] === '+' ? r + a[i + 1] : r - a[i + 1];
  return r;
}
function calcExprText(toks) { return toks.map((t, i) => i % 2 ? ' ' + CALC_SYM[t] + ' ' : calcFmt(t)).join(''); }
function calcPress(k) {
  const C = CALC;
  if (C.err && k !== 'C') { C.toks = []; C.cur = '0'; C.fresh = true; C.err = false; }
  const lbl = C.lbl; C.lbl = '';
  if (/^[0-9]$/.test(k)) {
    if (C.fresh) { C.cur = k; C.fresh = false; }
    else if (C.cur.replace(/[-.]/g, '').length < 15) C.cur = C.cur === '0' ? k : C.cur === '-0' ? '-' + k : C.cur + k;
  } else if (k === '.') {
    if (C.fresh) { C.cur = '0.'; C.fresh = false; }
    else if (!C.cur.includes('.')) C.cur += '.';
  } else if (k === 'back') {
    if (C.fresh) return calcRender();
    C.cur = C.cur.length > 1 && C.cur !== '-0' ? C.cur.slice(0, -1) : '0';
    if (C.cur === '-' ) C.cur = '0';
  } else if (k === 'C') {
    C.toks = []; C.cur = '0'; C.fresh = true; C.err = false;
  } else if (k === 'neg') {
    C.cur = C.cur.startsWith('-') ? C.cur.slice(1) : (C.cur === '0' ? '0' : '-' + C.cur);
  } else if (k === '%') {
    const v = Number(C.cur) || 0;
    const n = C.toks.length;
    // 200 + 10% = 220 (el porcentaje es sobre lo anterior); 50 × 10% = 5
    const r = n >= 2 && (C.toks[n - 1] === '+' || C.toks[n - 1] === '-') ? calcEval(C.toks.slice(0, -1)) * v / 100 : v / 100;
    C.cur = String(Math.round(r * 1e10) / 1e10); C.fresh = false;
    C.lbl = calcFmtEntry(String(v)) + '%';
  } else if (CALC_SYM[k]) {
    if (C.fresh && C.toks.length && C.toks.length % 2 === 0) C.toks[C.toks.length - 1] = k;
    else { C.toks.push(Number(C.cur) || 0, k); }
    C.fresh = true;
  } else if (k === '=') {
    if (!C.toks.length) return calcRender();
    const toks = [...C.toks, Number(C.cur) || 0];
    const r = calcEval(toks);
    if (!isFinite(r)) { C.err = true; C.toks = []; C.cur = '0'; C.fresh = true; return calcRender('No se puede dividir por cero'); }
    const h = calcData().hist;
    h.unshift({ e: calcExprText(toks).replace(/[^ ]+$/, m => lbl || m), r: Math.round(r * 1e10) / 1e10 });
    h.length = Math.min(h.length, 8);
    save();
    C.toks = []; C.cur = String(Math.round(r * 1e10) / 1e10); C.fresh = true;
    renderPeeks();
  }
  calcRender();
}
function calcRender(msg) {
  for (const v of [...CALC.views]) { if (!v.root.isConnected) CALC.views.delete(v); else v.paint(msg); }
}
function buildCalc(box, compact) {
  box.replaceChildren();
  const root = el('div', { class: 'calc' + (compact ? ' compact' : ''), tabindex: '0', 'aria-label': 'Calculadora (podés usar el teclado)' });
  const expr = el('div', { class: 'calc-ex' });
  const big = el('button', { class: 'calc-big', title: 'Copiar el resultado' });
  big.onclick = async () => toast(await copyText(CALC.fresh && CALC.err ? '' : calcFmtEntry(CALC.cur).replace('−', '-')) ? 'Resultado copiado' : 'No se pudo copiar');
  const keys = [['C', 'C', 'fn'], ['back', '⌫', 'fn'], ['%', '%', 'fn'], ['/', '÷', 'op'], ['7'], ['8'], ['9'], ['*', '×', 'op'], ['4'], ['5'], ['6'], ['-', '−', 'op'], ['1'], ['2'], ['3'], ['+', '+', 'op'], ['neg', '±', 'fn'], ['0'], ['.', ','], ['=', '=', 'eq']];
  const pad = el('div', { class: 'calc-pad' }, ...keys.map(([k, t, c]) => {
    const b = el('button', { class: 'calc-k' + (c ? ' ' + c : ''), text: t || k, 'data-k': k, tabindex: '-1' });
    b.onclick = () => { calcPress(k); root.focus({ preventScroll: true }); };
    return b;
  }));
  const hist = el('div', { class: 'calc-hist' });
  root.append(el('div', { class: 'calc-scr' }, expr, big), pad);
  if (!compact) root.append(hist);
  root.onkeydown = (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey) { if (e.ctrlKey && e.key.toLowerCase() === 'c') { big.click(); e.preventDefault(); } return; }
    const map = { Enter: '=', '=': '=', Backspace: 'back', Escape: 'C', Delete: 'C', ',': '.', '.': '.', x: '*', X: '*', '*': '*', '/': '/', '+': '+', '-': '-', '%': '%' };
    const k = /^[0-9]$/.test(e.key) ? e.key : map[e.key];
    if (!k) return;
    e.preventDefault(); e.stopPropagation();
    if (k === 'C' && e.key === 'Escape' && CALC.toks.length === 0 && CALC.cur === '0') return; // Escape con todo vacío: deja cerrar la tarjeta
    calcPress(k);
    const b = pad.querySelector(`[data-k="${CSS.escape(k)}"]`); if (b) { b.classList.add('hit'); setTimeout(() => b.classList.remove('hit'), 120); }
  };
  const view = { root, paint(msg) {
    const C = CALC;
    expr.textContent = msg || (C.toks.length ? calcExprText(C.toks) : (C.fresh && calcData().hist[0] && C.cur === String(calcData().hist[0].r) ? calcData().hist[0].e + ' =' : '\u00a0'));
    const txt = C.err ? 'Error' : calcFmtEntry(C.cur);
    big.textContent = txt;
    big.style.fontSize = txt.length > 14 ? '.62em' : txt.length > 10 ? '.78em' : '';
    for (const b of pad.querySelectorAll('.op')) b.classList.toggle('on', C.fresh && C.toks.length > 0 && C.toks[C.toks.length - 1] === b.dataset.k);
    if (!compact) {
      const h = calcData().hist;
      hist.replaceChildren(...(h.length ? [el('div', { class: 'calc-hh' }, el('span', { text: 'Últimas cuentas' }), (() => { const x = el('button', { class: 'text-btn', text: 'Borrar' }); x.onclick = () => { calcData().hist = []; save(); calcRender(); renderPeeks(); }; return x; })())] : []),
        ...h.map(it => { const b = el('button', { class: 'calc-hi', title: 'Usar este resultado' }, el('span', { text: it.e + ' =' }), el('b', { text: calcFmt(it.r) })); b.onclick = () => { CALC.cur = String(it.r); CALC.fresh = true; calcRender(); root.focus(); }; return b; }));
    }
  } };
  CALC.views.add(view);
  view.paint();
  box.append(root);
  return root;
}
function renderCalc() {
  if (!widgetOn('calc')) return;
  const box = $('#calc-body');
  if (box && !box.querySelector('.calc')) buildCalc(box, false); else calcRender();
}
function peekCalc() {
  if (!widgetOn('calc')) return;
  const h = S.settings.calc && S.settings.calc.hist && S.settings.calc.hist[0];
  setText('pk-calc-main', h ? calcFmt(h.r) : 'Cuentas rápidas');
  setText('pk-calc-sub', h ? h.e : 'Sumá, restá, multiplicá y dividí');
}
function znCalc() {
  const box = el('div', { class: 'zs-calc' });
  buildCalc(box, true);
  return znCard('calc', null, box);
}
function znSuper() {
  const box = el('div', { class: 'zs-super' });
  buildSuper(box, true);
  return znCard('super', null, box);
}

// ---------- Tarjetas que se despliegan ----------
const W = { open: null, pinned: false, openT: null, closeT: null };
function widgetEl(key) { return document.querySelector(`.w[data-w="${key}"]`); }
function positionPop(w) {
  const pop = w.querySelector('.pop');
  pop.style.left = '0px';
  const card = w.getBoundingClientRect();
  const pw = pop.offsetWidth;
  let left = 0;
  const maxRight = window.innerWidth - 16;
  if (card.left + pw > maxRight) left = maxRight - pw - card.left;
  if (card.left + left < 16) left = 16 - card.left;
  pop.style.left = left + 'px';
  pop.style.transformOrigin = left < 0 ? 'bottom right' : 'bottom left';
}
function openWidget(key, pin) {
  if (document.documentElement.classList.contains('desk-edit')) return;
  clearTimeout(W.openT); clearTimeout(W.closeT);
  if (W.open && W.open !== key) closeWidget(true);
  const w = widgetEl(key);
  if (!w || w.offsetParent === null) return;
  W.open = key;
  if (pin) W.pinned = true;
  positionPop(w);
  w.classList.add('open');
  w.querySelector('.peek').setAttribute('aria-expanded', 'true');
  if (key === 'mail' && acct()) loadMail(false);
  if (key === 'social') { renderSocial(); loadStartApps(false); }
  if (key === 'sistema') loadSistema();
  if (key === 'dolar') loadDolar(false);
  if (key === 'news') { loadNewsW(false); requestAnimationFrame(updateNwDots); }
  if (key === 'feriados') loadFeriados(false);
  if (key === 'pronostico') loadPronostico(false);
  if (key === 'cripto') loadCripto(false);
  if (key === 'gastos') loadCC(false);
  if (key === 'luces') { const l = luSel(); if (l) luRefresh(l, true); else renderLuces(); }
  if (key === 'calc') setTimeout(() => { renderCalc(); const c = $('#calc-body .calc'); if (c) c.focus({ preventScroll: true }); }, 60);
}
function closeWidget(force) {
  clearTimeout(W.openT); clearTimeout(W.closeT);
  if (!W.open) return;
  const w = widgetEl(W.open);
  if (!force) {
    // no cerramos mientras escribís, ni con un diálogo abierto
    const a = document.activeElement;
    if (w && a && w.contains(a) && a.matches('input:not([type="checkbox"]), textarea, select, [contenteditable="true"]')) return;
    if (document.querySelector('dialog[open]')) return;
  }
  if (w) {
    w.classList.remove('open');
    w.querySelector('.peek').setAttribute('aria-expanded', 'false');
  }
  W.open = null; W.pinned = false;
}
function setupWidgets() {
  for (const w of document.querySelectorAll('.w')) {
    const key = w.dataset.w;
    const clickOnly = !!w.dataset.clickOnly;
    w.addEventListener('mouseenter', () => {
      clearTimeout(W.closeT);
      if (clickOnly) return;
      if (W.open === key) return;
      clearTimeout(W.openT);
      W.openT = setTimeout(() => { if (!W.pinned || !W.open) openWidget(key); }, W.open ? 60 : 180);
    });
    w.addEventListener('mouseleave', () => {
      clearTimeout(W.openT);
      if (clickOnly && W.open === key) return;
      if (W.open === key && !W.pinned) W.closeT = setTimeout(() => closeWidget(false), 380);
    });
    w.querySelector('.peek').addEventListener('click', () => {
      if (document.documentElement.classList.contains('desk-edit')) return;
      if (key === 'games' && window.BaseMini) return openArcade('home');
      if (W.open === key && W.pinned) closeWidget(true);
      else openWidget(key, true);
    });
  }
  // clic afuera cierra
  document.addEventListener('pointerdown', (e) => {
    if (!W.open) return;
    if (e.target.closest('.w, dialog, .drawer, .toast, .scrim')) return;
    closeWidget(true);
  });
  window.addEventListener('resize', () => { if (W.open) positionPop(widgetEl(W.open)); });
}

// resúmenes de cada tarjeta
function setText(id, v) {
  const e = document.getElementById(id);
  if (e && e.textContent !== String(v)) e.textContent = v;
}
function whenLabel(date, time) {
  const today = ymd(new Date());
  const tom = ymd(addDays(new Date(), 1));
  const d = date === today ? 'Hoy' : date === tom ? 'Mañana' : fmt(parseYmd(date), { weekday: 'short', day: 'numeric' }).replace(/[.,]/g, '');
  return d.charAt(0).toUpperCase() + d.slice(1) + (time ? ` ${time}` : '');
}
function countdown(ms) {
  let m = Math.max(0, Math.floor(ms / 60000));
  const d = Math.floor(m / 1440); m %= 1440;
  const h = Math.floor(m / 60); m %= 60;
  if (d) return `en ${d} d ${h} h`;
  if (h) return `en ${h} h ${pad(m)} min`;
  return `en ${m} min`;
}
function renderPeeks() {
  if (!S) return;
  try { renderCardArt(); peeksNewCards(); } catch (e) { console.error(e); }
  const m = M();
  const today = ymd(new Date());
  const nowHM = pad(new Date().getHours()) + ':' + pad(new Date().getMinutes());

  // Tareas
  const pending = sortTasks(m.tasks.filter(t => !t.done));
  const late = pending.filter(t => t.due && t.due < today).length;
  setText('pk-tasks-badge', pending.length || '');
  setText('pk-tasks-main', pending.length ? pending[0].text : 'Sin pendientes');
  setText('pk-tasks-sub', pending.length
    ? `${plural(pending.length, 'pendiente', 'pendientes')}${late ? ` · ${plural(late, 'vencida', 'vencidas')}` : ''}${pending[0].due === today ? ' · la primera es para hoy' : ''}`
    : 'Agregá una cuando quieras');

  // Agenda
  const upcoming = allEvents()
    .filter(e => e.date > today || (e.date === today && (!e.time || e.time >= nowHM)))
    .sort((a, b) => (a.date + (a.time || '00:00')).localeCompare(b.date + (b.time || '00:00')));
  const todayCount = allEvents().filter(e => e.date === today).length;
  setText('pk-agenda-badge', todayCount || '');
  if (upcoming.length) {
    setText('pk-agenda-main', upcoming[0].title);
    setText('pk-agenda-sub', whenLabel(upcoming[0].date, upcoming[0].time) + (todayCount ? ` · ${plural(todayCount, 'evento', 'eventos')} hoy` : ''));
  } else {
    setText('pk-agenda-main', 'Nada agendado');
    setText('pk-agenda-sub', 'Tocá para ver el calendario');
  }

  // Correo
  const a = acct();
  const c = S.cache['gmail:' + S.activeMode];
  const data = c && c.data;
  if (!a) {
    setText('pk-mail-badge', '');
    setText('pk-mail-main', 'Vincular cuenta');
    setText('pk-mail-sub', `Gmail ${gmode(S.activeMode) === 'trabajo' ? 'del trabajo' : 'personal'}`);
  } else if (a.needsRelink || (c && c.code === 'relink')) {
    setText('pk-mail-badge', '!');
    setText('pk-mail-main', 'Volvé a vincular');
    setText('pk-mail-sub', a.email);
  } else if (data && data.messages.length) {
    const last = data.messages[0];
    setText('pk-mail-badge', data.unread > 99 ? '99+' : (data.unread || ''));
    setText('pk-mail-main', last.subject);
    setText('pk-mail-sub', last.from);
  } else {
    setText('pk-mail-badge', '');
    setText('pk-mail-main', data ? 'Bandeja al día' : 'Cargando…');
    setText('pk-mail-sub', a.email);
  }

  // Notas
  const notes = [...m.notes].sort((x, y) => y.updated - x.updated);
  setText('pk-notes-badge', '');
  setText('pk-notes-main', notes.length ? noteTitle(notes[0]) : 'Sin notas');
  setText('pk-notes-sub', notes.length ? `${plural(notes.length, 'nota', 'notas')} · ${noteDate(notes[0].updated)}` : 'Escribí la primera');

  // Juegos y Streaming
  if (widgetOn('games') || widgetOn('stream')) {
    const games = gameList();
    const g = ui.games || S.cache.games;
    if (!g) { setText('pk-games-main', 'Buscando juegos…'); setText('pk-games-sub', 'Steam y Xbox'); setText('pk-games-badge', ''); }
    else if (!games.length) { setText('pk-games-main', 'Sin juegos detectados'); setText('pk-games-sub', 'Steam y Xbox'); setText('pk-games-badge', ''); }
    else {
      const top = games[0];
      setText('pk-games-main', top.last ? top.name : `${games.length} juegos instalados`);
      const counts = {}; for (const x of games) counts[x.src] = (counts[x.src] || 0) + 1;
      setText('pk-games-sub', top.last ? [playedText(top.minutes), `última vez ${ago(top.last)}`].filter(Boolean).join(' · ') : Object.entries(counts).slice(0, 3).map(([k, n]) => `${libName(k)} ${n}`).join(' · '));
      setText('pk-games-badge', '');
    }
    const casa = S.modes.casa;
    const chosen = (casa.streaming || STREAM_DEFAULT).map(id => STREAMING.find(x => x.id === id)).filter(Boolean);
    const last = casa.streamLast && STREAMING.find(x => x.id === casa.streamLast.id);
    setText('pk-stream-main', last ? last.n : chosen.length ? chosen.slice(0, 3).map(x => x.n).join(', ') : 'Elegí tus servicios');
    setText('pk-stream-sub', last ? `Último que abriste · ${ago(casa.streamLast.at)}` : `${plural(chosen.length, 'servicio', 'servicios')}`);
    setText('pk-stream-badge', '');
  }

  // Dólar, Pomodoro, Rendimiento y Relojes
  if (widgetOn('dolar')) {
    const d = dolarData();
    const g = (c) => d.find(x => x.casa === c);
    const blue = g('blue'), of = g('oficial'), mep = g('bolsa');
    setText('pk-dolar-main', blue ? `Blue ${money(blue.venta)}` : 'Cargando…');
    setText('pk-dolar-sub', [of && `Oficial ${money(of.venta)}`, mep && `MEP ${money(mep.venta)}`].filter(Boolean).join(' · '));
    setText('pk-dolar-badge', '');
  }
  if (widgetOn('pomodoro')) {
    const p = pomoCfg();
    const left = pomoLeft(p);
    setText('pk-pomodoro-main', p.endAt || left < pomoLen(p) ? `${pad(Math.floor(left / 60000))}:${pad(Math.floor(left / 1000) % 60)} · ${POMO_LABEL[p.mode]}` : 'Listo para empezar');
    setText('pk-pomodoro-sub', p.endAt ? 'Corriendo' : left < pomoLen(p) ? 'En pausa' : p.done ? `${plural(p.done, 'bloque', 'bloques')} hoy` : `${p.f} min de concentración`);
    setText('pk-pomodoro-badge', p.endAt ? '●' : '');
  }
  if (widgetOn('sistema')) {
    const s2 = sysStats;
    setText('pk-sistema-main', s2 ? `CPU ${s2.cpu ?? '…'}% · RAM ${Math.round(100 * (s2.mem.total - s2.mem.free) / s2.mem.total)}%` : 'Midiendo…');
    const ext = s2 && s2.drives ? s2.drives.filter(d => d.type === 'Removable').length : 0;
    setText('pk-sistema-sub', s2 && s2.disk ? `Disco ${s2.disk.name} ${GB(s2.disk.free)} libres${ext ? ` · ${plural(ext, 'extraíble', 'extraíbles')}` : s2.net && s2.net.down != null ? ` · ↓ ${RATE(s2.net.down)}` : ''}` : '');
    setText('pk-sistema-badge', '');
  }
  if (widgetOn('relojes')) {
    const zs = tzList();
    const nm = (z) => (CITIES.find(c => c[0] === z) || [z, z.split('/').pop().replace(/_/g, ' ')])[1];
    setText('pk-relojes-main', zs.length ? `${nm(zs[0])} ${tzInfo(zs[0]).time}` : 'Elegí ciudades');
    setText('pk-relojes-sub', zs.slice(1, 3).map(z => `${nm(z)} ${tzInfo(z).time}`).join(' · '));
    setText('pk-relojes-badge', '');
  }

  // Redes
  if (widgetOn('social')) {
    const list = socialChosen();
    const last = S.settings.socialLast && SOCIALS.find(x => x.id === S.settings.socialLast.id);
    setText('pk-social-main', last ? last.n : list.length ? list.slice(0, 3).map(x => x.n).join(', ') : 'Elegí tus redes');
    setText('pk-social-sub', last ? `Última que abriste · ${ago(S.settings.socialLast.at)}` : plural(list.length, 'red', 'redes'));
    setText('pk-social-badge', '');
  }

  // Sección a elección
  const tp = widgetOn('f1') ? topic() : null;
  if (widgetOn('f1') && !tp) {
    setText('pk-f1-label', 'Noticias');
    setText('pk-f1-main', 'Elegí qué seguir');
    setText('pk-f1-sub', 'F1, tu equipo o cualquier tema');
    setText('pk-f1-badge', '');
  } else if (tp && tp.kind === 'team') {
    const m = nextMatch();
    const now = Date.now();
    setText('pk-f1-label', tp.name);
    if (m) {
      setText('pk-f1-main', `${m.home.name} vs ${m.away.name}`);
      setText('pk-f1-sub', m.start <= now ? 'En juego' : `${countdown(m.start - now)} · ${f1Short(m.start)}`);
      setText('pk-f1-badge', m.start <= now ? 'En juego' : '');
    } else { setText('pk-f1-main', 'Sin partidos próximos'); setText('pk-f1-sub', tp.leagueName || ''); setText('pk-f1-badge', ''); }
  } else if (tp && tp.kind === 'tema') {
    const it = newsItems()[0];
    setText('pk-f1-label', tp.query);
    setText('pk-f1-main', it ? it.title : 'Buscando noticias…');
    setText('pk-f1-sub', it ? [it.source, ago(it.date)].filter(Boolean).join(' · ') : '');
    setText('pk-f1-badge', '');
  } else if (widgetOn('f1')) {
    setText('pk-f1-label', 'Fórmula 1');
    const n = nextF1();
    const now = Date.now();
    if (!n) {
      setText('pk-f1-main', f1List.length ? 'Temporada terminada' : 'Calendario no disponible');
      setText('pk-f1-sub', `Noticias de ${newsQuery()}`);
      setText('pk-f1-badge', '');
    } else {
      setText('pk-f1-main', `${n.name} · ${n.gp.replace(/^GP de /, '')}`);
      setText('pk-f1-sub', n.start <= now ? 'En vivo ahora' : `${countdown(n.start - now)} · ${f1Short(n.start)}`);
      setText('pk-f1-badge', n.start <= now ? 'En vivo' : '');
    }
  }
}

// ---------- Render general ----------
function renderAll() {
  applyTheme();
  if ($('#daily')) renderDaily();
  if ($('#notif-count')) renderNotifBadge();
  renderClock(true);
  renderModeTabs();
  renderGreeting();
  renderLaunch();
  renderTasks();
  renderNotes();
  renderAgenda();
  try { renderNewCards(); } catch (e) { console.error(e); }
  try { renderStage(); } catch (e) { console.error(e); }
  try { renderZone(); } catch (e) { console.error(e); }
  // datos de internet: primero lo guardado, después se actualiza
  renderMail();
  renderGsync();
  const wc = S.cache[`wx:${M().weather.lat.toFixed(3)},${M().weather.lon.toFixed(3)}`];
  renderWeather(wc ? wc.data : null);
  applyWidgetLayout();
  renderF1(); renderNews(); renderF1Photo(); renderGames(); renderStreaming(); renderSocial(); renderDolar(); renderPomo(); renderSistema(); renderRelojes();
  if ($('#drawer').classList.contains('on')) renderDrawer();
  renderPeeks();
}

// ---------- Eventos de la interfaz ----------
function bind() {
  setupWidgets();
  setupArcade();
  setupBoards();
  setupCursor();
  setupNewCards();
  setupBackup();
  setupF1Extra();
  WxAnim.init();
  setupWindows();
  setupPlayer();
  setupMpop();
  setupFxSm();
  setupSocial();
  setupDeskEdit();
  setupSearch();
  setupBrief();
  $('#dolar-refresh').onclick = () => loadDolar(true);
  $('#conv-usd').addEventListener('input', convert);
  $('#conv-type').onchange = (e) => { S.settings.convType = e.target.value; save(); convert(); };
  $$('#pomo-modes button').forEach(b => b.onclick = () => pomoSet(b.dataset.m));
  $('#pomo-start').onclick = pomoToggle;
  $('#pomo-reset').onclick = () => pomoSet(pomoCfg().mode);
  for (const [id, k, mx] of [['pomo-f', 'f', 120], ['pomo-s', 's', 60], ['pomo-l', 'l', 90]]) {
    $('#' + id).addEventListener('change', (e) => {
      const p = pomoCfg();
      p[k] = Math.max(1, Math.min(mx, Math.round(Number(e.target.value) || p[k])));
      if (!p.endAt) p.left = 0;
      save(); renderPomo(); renderPeeks();
    });
  }
  $('#tz-edit').onclick = () => { ui.tzEdit = !ui.tzEdit; renderRelojes(); };

  // barra superior

  $('#btn-scheme').onclick = () => { const t = M().theme; t.scheme = t.scheme === 'dark' ? 'light' : 'dark'; commitTheme(); WxAnim.refresh(); };
  $('#btn-custom').onclick = () => openDrawer(!$('#drawer').classList.contains('on'));
  $('#btn-min').onclick = () => api.minimize();
  applyDeskUi();
  setupUpdates();
  if (api.alive) setInterval(() => api.alive(), 5000);
  setupPanel();
  $('#btn-close').onclick = () => api.hide();
  api.onModeSet(setMode);

  // accesos
  $('#btn-edit-launch').onclick = () => { ui.editingLaunch = !ui.editingLaunch; renderLaunch(); };
  $$('#sc-form .seg button').forEach(b => b.onclick = () => {
    if (b.dataset.kind !== ui.scKind) { $('#sc-target').value = ''; }
    setScKind(b.dataset.kind);
  });
  $('#sc-browse').onclick = async () => {
    const p = await api.pickTarget(ui.scKind);
    if (!p) return;
    $('#sc-target').value = p;
    if (!$('#sc-name').value.trim()) $('#sc-name').value = baseName(p);
    $('#sc-name').focus();
  };
  $('#sc-form').addEventListener('submit', (e) => { e.preventDefault(); saveShortcutDialog(); });
  $('#sc-cancel').onclick = () => $('#dlg-shortcut').close();
  $('#sc-delete').onclick = () => { const sc = ui.scEditing; $('#dlg-shortcut').close(); if (sc) removeShortcut(sc.id); };
  setupLaunchDrop();
  setupFolderPop();
  $('#sc-folder').onchange = (e) => { const n = $('#sc-newfolder'); n.hidden = e.target.value !== '__new'; if (!n.hidden) n.focus(); };

  // tareas
  $('#task-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = $('#task-text');
    const text = input.value.trim();
    if (!text) return;
    M().tasks.push({ id: uid(), text, done: false, prio: ui.taskPrio, due: $('#task-due').value || null, created: Date.now() });
    input.value = ''; $('#task-due').value = '';
    ui.taskPrio = false; $('#task-prio').setAttribute('aria-pressed', 'false');
    ui.taskFilter = 'pending';
    save(); renderTasks(); renderSummary();
  });
  $('#task-due').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#task-form').requestSubmit(); } });
  $('#task-prio').onclick = () => { ui.taskPrio = !ui.taskPrio; $('#task-prio').setAttribute('aria-pressed', String(ui.taskPrio)); $('#task-text').focus(); };
  $$('.tasks .seg button').forEach(b => b.onclick = () => { ui.taskFilter = b.dataset.filter; renderTasks(); });

  // notas
  $('#btn-new-note').onclick = newNote;
  $('#btn-del-note').onclick = deleteNote;
  $('#note-text').addEventListener('input', onNoteInput);

  // agenda
  $('#cal-prev').onclick = () => { const m = ui.calMonth; ui.calMonth = new Date(m.getFullYear(), m.getMonth() - 1, 1); renderCalendar(); loadGcal(false); };
  $('#cal-next').onclick = () => { const m = ui.calMonth; ui.calMonth = new Date(m.getFullYear(), m.getMonth() + 1, 1); renderCalendar(); loadGcal(false); };
  $('#cal-title').onclick = () => { const n = new Date(); ui.calMonth = new Date(n.getFullYear(), n.getMonth(), 1); ui.sel = ymd(n); renderAgenda(); };
  $('#event-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const title = $('#ev-title').value.trim();
    if (!title) return;
    const notify = $('#ev-notify').value;
    const ev = { id: uid(), title, date: ui.sel, time: $('#ev-time').value || '', notify, notified: false };
    $('#ev-title').value = ''; $('#ev-time').value = ''; $('#ev-notify').value = '';
    const mode = S.activeMode;
    if (acct(mode) && $('#ev-google').checked) {
      toast('Guardando en Google Calendar…');
      G.createEvent(mode, ev).then(r => {
        if (r.ok) { toast('Guardado en tu Google Calendar'); loadGcal(true, mode); return; }
        S.modes[mode].events.push(ev); save(); renderAgenda(); renderSummary();
        toast('No se pudo guardar en Google (' + r.error + '). Lo guardé solo en Base.');
      });
      return;
    }
    M().events.push(ev);
    save(); renderAgenda(); renderSummary();
    if (notify !== '') toast(`Te aviso: ${notifyLabel(notify).toLowerCase().replace('aviso ', '')}.`);
  });

  // juegos y streaming

  $$('#games-sort button').forEach(b => b.onclick = () => { S.settings.gameSort = b.dataset.s; save(); renderGames(); });
  $('#open-steam').onclick = () => api.launchSpecial && api.launchSpecial('steam-app');
  $('#open-xbox').onclick = () => api.launchSpecial && api.launchSpecial('xbox-app');
  $('#games-refresh').onclick = () => { loadGames(true); loadStartApps(true); toast('Buscando tus juegos…'); };
  $('#stream-edit').onclick = () => { ui.streamEdit = !ui.streamEdit; renderStreaming(); };

  // notificaciones
  $('#btn-notifs').onclick = () => toggleNotifPanel();
  $('#np-dnd').onchange = (e) => { S.settings.dnd = e.target.checked; save(); renderNotifBadge(); toast(e.target.checked ? 'No molestar: los avisos quedan acá sin aparecer en pantalla' : 'Avisos activados'); };
  $('#np-clear').onclick = () => { S.notifs = []; save(); renderNotifs(); renderNotifBadge(); };
  $('#np-windows').onclick = () => { toggleNotifPanel(false); if (api.windows) api.windows.system('notifications'); };
  document.addEventListener('pointerdown', (e) => { if (!$('#notif-panel').hidden && !e.target.closest('#notif-panel, #btn-notifs')) toggleNotifPanel(false); });
  // lector de mails
  $('#mv-back').onclick = closeMailView;
  $('#mv-gmail').onclick = () => { const v = ui.mailView; const a = acct(); if (v && a) api.google.openMail(a.email, v.data ? v.data.thread : ''); };
  $('#mv-images').onclick = () => { if (!ui.mailView) return; ui.mailView.images = !ui.mailView.images; renderMailView(); };
  $('#mv-read').onclick = async () => { const v = ui.mailView; if (v && await markMailRead([v.id], v.mode)) { toast('Marcado como leído'); closeMailView(); } };
  $('#mail-allread').onclick = async () => {
    const c = S.cache['gmail:' + S.activeMode];
    const ids = c && c.data ? c.data.messages.map(x => x.id) : [];
    if (!ids.length) return;
    if (await markMailRead(ids)) toast(`Marcaste ${plural(ids.length, 'mail', 'mails')} como leídos`);
  };

  // Google y correo
  $('#mail-bell').onclick = () => {
    const cfg = M().mail; cfg.notify = !cfg.notify; save(); renderMail();
    toast(cfg.notify ? 'Te aviso cuando lleguen mails nuevos' : 'Sin avisos de mails nuevos');
  };
  $('#mail-refresh').onclick = () => { loadMail(true); loadGcal(true); };
  $('#mail-open').onclick = () => { const a = acct(); if (a) api.google.openMail(a.email); };
  $('#btn-gsetup').onclick = () => openGoogleSetup(S.activeMode);
  $$('#dlg-google [data-url]').forEach(b => b.onclick = () => api.google.open(b.dataset.url));
  $('#g-cancel').onclick = () => $('#dlg-google').close();
  $('#g-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const r = await api.google.setConfig($('#g-id').value, $('#g-secret').value);
    if (!r.ok) { $('#g-error').textContent = r.error; return; }
    $('#g-id').value = ''; $('#g-secret').value = '';
    $('#dlg-google').close();
    await refreshGStatus();
    linkGoogle(ui.gsetupMode || S.activeMode);
  });
  window.addEventListener('focus', () => { loadTaskbar(); if (acct()) loadMail(false); });

  // clima, F1 y noticias
  $('#city-form').addEventListener('submit', (e) => { e.preventDefault(); const q = $('#city-q').value.trim(); if (q) searchCity(q); });
  $('#city-cancel').onclick = () => $('#dlg-city').close();
  $('#f1-alert').onchange = (e) => {
    S.modes.casa.f1.alert = e.target.value;
    save();
    toast(e.target.value === '' ? 'Sin avisos de F1' : `Te aviso de cada sesión: ${e.target.selectedOptions[0].text.replace('Aviso ', '')}`);
  };
  $('#news-refresh').onclick = () => loadNews(true);
  $('#topic-change').onclick = openTopicDialog;
  $('#topic-start').onclick = openTopicDialog;
  $$('.topic-kinds button').forEach(b => b.onclick = () => setTopicKind(b.dataset.kind));
  $('#tp-league').onchange = (e) => { ui.tp.league = e.target.value; ui.tp.team = null; loadLeagueTeams(); };
  $('#tp-team-q').addEventListener('input', renderLeagueTeams);
  $('#tp-cancel').onclick = () => $('#dlg-topic').close();
  $('#topic-form').addEventListener('submit', (e) => { e.preventDefault(); saveTopic(); });
  $('#city-geo').onclick = () => useMyLocation(false);
  $('#g-skip').onclick = () => { $('#g-id').scrollIntoView({ block: 'center' }); $('#g-id').focus(); };

  // reloj
  $$('#clock-size button').forEach(b => b.onclick = () => setClock({ size: b.dataset.size }));
  $('#clk-seconds').onchange = (e) => setClock({ seconds: e.target.checked });
  $('#clk-12').onchange = (e) => setClock({ h12: e.target.checked });
  $('#clk-accent').onchange = (e) => setClock({ accent: e.target.checked });

  // personalizar
  $('#drawer-close').onclick = () => openDrawer(false);
  $('#scrim').onclick = () => openDrawer(false);
  $('#accent-custom').addEventListener('input', (e) => { M().theme.accent = e.target.value; applyTheme(); save(); });
  $('#accent-custom').addEventListener('change', () => renderDrawer());
  $('#glass').addEventListener('input', (e) => { M().theme.glass = Number(e.target.value); applyTheme(); save(); });
  $('#veil').onchange = (e) => { M().theme.veil = e.target.value === 'auto' ? null : Number(e.target.value); applyTheme(); save(); };
  $('#bg-image').onclick = async () => {
    const url = await api.pickBackground();
    if (!url) return;
    M().theme.bg = { kind: 'image', value: url };
    if (M().theme.glass < 30) M().theme.glass = 40;
    commitTheme();
  };
  $('#user-name').addEventListener('input', (e) => { S.settings.name = e.target.value; save(); renderGreeting(); });
  $('#set-startup').onchange = (e) => { S.settings.startWithWindows = e.target.checked; commitSettings(); };
  $('#set-deskmode').onchange = (e) => {
    S.settings.deskMode = e.target.checked;
    if (S.settings.deskMode && !S.settings.startWithWindows) { S.settings.startWithWindows = true; $('#set-startup').checked = true; }
    applyDeskUi(); commitSettings();
  };
  $('#set-hidetaskbar').onchange = (e) => { S.settings.hideTaskbar = e.target.checked; commitSettings(); };
  $('#set-fullscreen').onchange = (e) => { S.settings.fullscreen = e.target.checked; commitSettings(); };
  $('#set-brief').onchange = (e) => { S.settings.brief = e.target.checked; save(); };
  $('#set-notif').onchange = (e) => { S.settings.notifStyle = e.target.value; save(); renderNotifSettings(); };
  $('#set-floatbr').onchange = (e) => { S.settings.floatBrowser = e.target.value; save(); };
  $('#notif-test').onclick = testNotif;
  $$('#dnav button').forEach(b => b.onclick = () => showDrawerSec(b.dataset.sec));
  $$('#nf-pos button').forEach(b => b.onclick = () => { S.settings.notifPos = b.dataset.pos; save(); renderNotifSettings(); testNotif(); });
  $('#set-notiflife').onchange = (e) => { S.settings.notifLife = Number(e.target.value) || 8; save(); };
  $('#set-notifsound').onchange = (e) => { S.settings.notifSound = e.target.value; save(); testNotif(); };
  $('#set-display').onchange = (e) => { S.settings.display = e.target.value; save(true); if (api.setDisplay) api.setDisplay(e.target.value).then(() => setTimeout(renderDrawer, 600)); };
  $('#set-baseshell').onchange = (e) => { S.settings.baseShell = e.target.checked; save(); };
  $('#set-winbar').onchange = (e) => { S.settings.winBar = e.target.value; save(); renderSwitcher(); };
  if (api.onFloatOpen) api.onFloatOpen((id) => { const n = (S.notifs || []).find(x => x.id === id); if (n) openNotif(n); });
  $('#set-daily').onchange = (e) => { S.settings.daily = e.target.value; save(); renderDaily(); };
  $('#set-searchkey').onchange = (e) => { S.settings.searchHotkey = e.target.value; commitSettings(); };
  const wxNow = () => { const wc = S.cache[`wx:${M().weather.lat.toFixed(3)},${M().weather.lon.toFixed(3)}`]; WxAnim.set(wc && S.settings.wxAnim !== false ? wc.data.current.weather_code : null, wc ? wc.data.current.is_day !== 0 : true); };
  $('#set-wxstyle').onchange = (e) => { S.settings.wxStyle = e.target.value; save(); WxAnim.refresh(); };
  for (const b of $$('#wx-try button')) b.onclick = () => {
    clearTimeout(ui.wxTryT);
    window.__wxForce = b.dataset.k; WxAnim.set(null);
    toast(`Mostrando: ${b.textContent}. Vuelve al clima real en 8 segundos.`);
    ui.wxTryT = setTimeout(() => { window.__wxForce = null; WxAnim.refresh && (WxAnim.set(-1), wxNow()); }, 8000);
  };
  $('#set-wxanim').onchange = (e) => {
    S.settings.wxAnim = e.target.checked; save();
    const wc = S.cache[`wx:${M().weather.lat.toFixed(3)},${M().weather.lon.toFixed(3)}`];
    WxAnim.set(wc && e.target.checked ? wc.data.current.weather_code : null, wc ? wc.data.current.is_day !== 0 : true);
  };
  $('#set-hotkey').onchange = (e) => { S.settings.hotkey = e.target.value; commitSettings(); };
  $('#set-startmode').onchange = (e) => { S.settings.startMode = e.target.value; save(); };
  $('#btn-quit').onclick = () => { save(true); api.quit(); };

  // teclado
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('#drawer').classList.contains('on')) openDrawer(false);
    else if (e.key === 'Escape' && W.open && !document.querySelector('dialog[open]')) { const k = W.open; closeWidget(true); const pk = $('#peek-' + k); if (pk) pk.focus(); }
    if (e.key === 'Escape' && ui.editingLaunch && !$('#dlg-shortcut').open) { ui.editingLaunch = false; renderLaunch(); }
  });
  window.addEventListener('beforeunload', () => save(true));
}

// ---------- Inicio ----------
function migrate(d) {
  if (d && d.cache) for (const k of Object.keys(d.cache)) if (/^(gmail|gcal):/.test(k) && d.cache[k] && /call stack/i.test(String(d.cache[k].error || ''))) delete d.cache[k];
  const base = defaultData();
  if (!d || typeof d !== 'object' || !d.modes) d = base;
  d.settings = Object.assign(base.settings, d.settings || {});
  for (const m of ['casa', 'trabajo']) {
    const def = base.modes[m];
    const cur = d.modes[m] || def;
    cur.theme = Object.assign(def.theme, cur.theme || {});
    for (const k of ['shortcuts', 'tasks', 'notes', 'events']) if (!Array.isArray(cur[k])) cur[k] = [];
    if (!cur.weather || typeof cur.weather.lat !== 'number') cur.weather = { ...DEFAULT_CITY };
    if (!cur.mail || typeof cur.mail !== 'object') cur.mail = { notify: m === 'trabajo', seen: null };
    if (!Array.isArray(cur.widgets)) cur.widgets = (m === 'casa' ? DEFAULT_LAYOUT.casa : ['tasks', 'agenda', 'mail', 'notes']).slice();
    if (cur.gcalNotify === undefined) cur.gcalNotify = '10';
    if (!Array.isArray(cur.gNotified)) cur.gNotified = [];
    d.modes[m] = cur;
  }
  const casa = d.modes.casa;
  if (!casa.f1) casa.f1 = { alert: '15', notified: [] };
  if (!Array.isArray(casa.f1.notified)) casa.f1.notified = [];
  if (!Array.isArray(casa.hiddenTaskbar)) casa.hiddenTaskbar = [];
  if (d.settings.topic === undefined) d.settings.topic = SINGLE ? null : { kind: 'f1', news: 'Colapinto' };
  if (SINGLE) d.activeMode = 'casa';
  if (!d.settings.hiddenSys || typeof d.settings.hiddenSys !== 'object') d.settings.hiddenSys = { taskbar: casa.hiddenTaskbar.slice(), desktop: [] };
  for (const k of ['taskbar', 'desktop']) if (!Array.isArray(d.settings.hiddenSys[k])) d.settings.hiddenSys[k] = [];
  if (!d.cache || typeof d.cache !== 'object') d.cache = {};
  // versión 2: accesos de trabajo de la edición completa
  if ((d.version || 1) < 2) {
    const sc = d.modes.trabajo.shortcuts;
    WORK_LINKS.slice().reverse().forEach(l => {
      if (!sc.some(x => x.target === l.target)) sc.unshift({ id: uid(), ...l });
    });
  }
  if ((d.version || 1) < 3) {
    for (const m of ['casa', 'trabajo']) {
      const sc = d.modes[m].shortcuts;
      if (sc.length >= 2 && !sc.some(x => x.type === 'group')) {
        d.modes[m].shortcuts = [{ id: uid(), type: 'group', name: m === 'casa' ? 'Mis accesos' : 'Trabajo', items: sc }];
      }
    }
  }
  // tableros extra
  if (!Array.isArray(d.boards)) d.boards = [];
  d.boards = d.boards.filter(b => b && typeof b.id === 'string' && d.modes[b.id] && typeof d.modes[b.id] === 'object');
  for (const b of d.boards) {
    const cur = d.modes[b.id];
    cur.theme = Object.assign(defaultMode('casa').theme, cur.theme || {});
    for (const k of ['shortcuts', 'tasks', 'notes', 'events']) if (!Array.isArray(cur[k])) cur[k] = [];
    if (!cur.weather || typeof cur.weather.lat !== 'number') cur.weather = { ...d.modes.casa.weather };
    if (!cur.mail || typeof cur.mail !== 'object') cur.mail = { notify: false, seen: null };
    if (!Array.isArray(cur.widgets)) cur.widgets = ['tasks', 'notes', 'agenda'];
    if (cur.gcalNotify === undefined) cur.gcalNotify = '10';
    if (!Array.isArray(cur.gNotified)) cur.gNotified = [];
    if (cur.gFrom !== 'trabajo') cur.gFrom = 'casa';
    b.name = String(b.name || 'Tablero').slice(0, 24);
    if (!BOARD_ICONS[b.icon]) b.icon = 'star';
  }
  for (const m of ['casa', 'trabajo', ...d.boards.map(b => b.id)]) for (const x of d.modes[m].shortcuts) if (x.type === 'group' && !Array.isArray(x.items)) x.items = [];
  for (const k of Object.keys(d.modes)) if (k !== 'casa' && k !== 'trabajo' && !d.boards.some(b => b.id === k)) delete d.modes[k];
  d.version = 3;
  if (!d.modes[d.activeMode] || (SINGLE && d.activeMode === 'trabajo')) d.activeMode = 'casa';
  return d;
}

(async function start() {
  // 1) Arrancamos enseguida con la pantalla funcionando (sin guardar todavía)
  S = migrate(null);
  canSave = false;
  try { bind(); } catch (e) { showFatal('Botones: ' + (e.stack || e)); }
  try { renderAll(); } catch (e) { showFatal('Pantalla: ' + (e.stack || e)); }
  tick();
  setInterval(() => { try { tick(); } catch (e) { console.error(e); } }, 1000);

  // 2) Leemos tus datos guardados
  let loaded = null;
  let loadOk = true;
  try {
    loaded = await Promise.race([
      api.load(),
      new Promise((_, rej) => setTimeout(() => rej(new Error('El programa no respondió al leer tus datos')), 5000))
    ]);
  } catch (e) {
    loadOk = false;
    showFatal('Cargar datos: ' + (e.stack || e.message || e));
  }
  const first = loadOk && !loaded;
  S = migrate(loaded);
  canSave = loadOk; // si no pudimos leer, no pisamos lo que haya guardado
  if (S.settings.startMode && S.settings.startMode !== 'last') S.activeMode = S.settings.startMode;
  if (SINGLE) S.activeMode = 'casa';
  lastMinute = '';
  try { await refreshGStatus(); } catch (e) { console.error(e); }
  if (!Array.isArray(S.notifs)) S.notifs = [];
  renderAll();
  loadTaskbar();
  setInterval(loadTaskbar, 2 * 60000);
  setTimeout(() => { loadGames(false); loadStartApps(false); }, 2500);
  loadDolar(false); loadSistema();
  setInterval(() => loadDolar(false), 15 * 60000);
  loadEfemeride();
  if (['bing'].includes(M().theme.bg.kind) || ['bing'].includes(((S.modes.trabajo || {}).theme || { bg: {} }).bg.kind)) loadBing(false).then(applyTheme);
  loadDolar(false, true);
  if (loadOk) setTimeout(async () => { await checkPendingImport(); if ($('#dlg-import').open) return; maybeAutoBrief(); }, 2600);
  setInterval(loadSistema, 3000);
  loadNewCards(false);
  setInterval(() => { loadNewsW(false); loadPronostico(false); loadFeriados(false); }, 30 * 60000);
  setInterval(() => loadCripto(false), 5 * 60000);
  setInterval(() => { if (stageKind() === 'juegos') loadDeals(false); }, 60 * 60000);
  setInterval(() => { if (widgetOn('cuenta')) renderCuenta(); if (widgetOn('habitos')) renderHabitos(); }, 30 * 60000);
  if (SINGLE && !S.settings.geoDone && loadOk) setTimeout(() => useMyLocation(true), 1200);
  setInterval(() => { if (widgetOn('games') || widgetOn('stream') || widgetOn('social')) { loadGames(false); loadStartApps(false); } }, 10 * 60000);
  // correo en segundo plano para los modos con aviso de mails nuevos
  setInterval(() => { for (const m of allModes()) if (m === S.activeMode || (S.modes[m].mail && S.modes[m].mail.notify)) loadMail(false, m); }, 2 * 60000);
  setInterval(() => { for (const m of allModes()) if (acct(m) && (!isBoard(m) || m === S.activeMode)) loadGcal(false, m); }, 5 * 60000);
  tick();
  checkReminders();
  setInterval(() => { checkReminders(); checkF1Alerts(); }, 15000);
  refreshOnline(false);
  loadTopicData(false); // los avisos funcionan en cualquier modo
  setInterval(() => { refreshOnline(false); if (S.activeMode !== 'casa') loadTopicData(false); }, 5 * 60000);
  window.addEventListener('online', () => refreshOnline(true));
  commitSettings();
  if (api.ready) api.ready();
  if (first) {
    save(true);
    setTimeout(() => toast('Bienvenido a Base. Arrastrá programas o carpetas a “Accesos” para tenerlos a mano.'), 900);
  }
})();

})();
