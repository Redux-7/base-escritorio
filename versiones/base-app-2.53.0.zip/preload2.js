// Ventana de Base en los otros monitores: sólo recibe lo que hay que mostrar y abre accesos
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('s2', {
  onSnap: (cb) => ipcRenderer.on('s2:snap', (_e, d) => cb(d)),
  open: (item) => ipcRenderer.invoke('s2:open', item),
  base: () => ipcRenderer.send('s2:base'),
  swap: () => ipcRenderer.send('s2:swap')
});
