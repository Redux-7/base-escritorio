const { contextBridge, ipcRenderer, webUtils } = require('electron');
let edition = { edicion: 'completa' };
try { edition = Object.assign(edition, JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'edicion.json'), 'utf8'))); } catch {}

contextBridge.exposeInMainWorld('baseApi', {
  health: {
    get: () => ipcRenderer.invoke('health:get'),
    folders: () => ipcRenderer.invoke('health:folders'),
    clean: () => ipcRenderer.invoke('health:clean'),
    recycle: () => ipcRenderer.invoke('health:recycle'),
    storage: () => ipcRenderer.invoke('health:storage')
  },
  fbk: {
    pick: () => ipcRenderer.invoke('fbk:pick'),
    drive: () => ipcRenderer.invoke('fbk:drive'),
    run: (cfg) => ipcRenderer.invoke('fbk:run', cfg),
    gdrive: (cfg) => ipcRenderer.invoke('gdrive:run', cfg),
    gdriveInfo: () => ipcRenderer.invoke('gdrive:info'),
    open: (p) => ipcRenderer.invoke('fbk:open', p),
    onProgress: (cb) => ipcRenderer.on('fbk:progress', (_e, d) => cb(d))
  },
  ext: {
    keys: (list) => ipcRenderer.invoke('ext:keys', list),
    corners: (map) => ipcRenderer.invoke('ext:corners', map),
    onKey: (cb) => ipcRenderer.on('ext:key', (_e, i) => cb(i)),
    onCorner: (cb) => ipcRenderer.on('ext:corner', (_e, a) => cb(a)),
    shutdownIn: (secs) => ipcRenderer.invoke('sys:shutdownIn', secs),
    shutdownAbort: () => ipcRenderer.invoke('sys:shutdownAbort')
  },
  load: () => ipcRenderer.invoke('data:load'),
  save: (data) => ipcRenderer.send('data:save', data),

  minimize: () => ipcRenderer.send('win:minimize'),
  hide: () => ipcRenderer.send('win:hide'),
  quit: () => ipcRenderer.send('app:quit'),

  pickTarget: (kind) => ipcRenderer.invoke('shortcut:pick', kind),
  iconFor: (target) => ipcRenderer.invoke('shortcut:icon', target),
  open: (item) => ipcRenderer.invoke('shortcut:open', item),
  fileSearch: (q) => ipcRenderer.invoke('files:search', q),
  idle: () => ipcRenderer.invoke('sys:idle'),
  clip: {
    list: () => ipcRenderer.invoke('clip:list'), use: (id) => ipcRenderer.invoke('clip:use', id), pin: (id) => ipcRenderer.invoke('clip:pin', id),
    del: (id) => ipcRenderer.invoke('clip:del', id), clear: () => ipcRenderer.invoke('clip:clear'), set: (on) => ipcRenderer.invoke('clip:set', on),
    onChange: (cb) => ipcRenderer.on('clip:changed', () => cb())
  },
  map: {
    search: (q) => ipcRenderer.invoke('map:search', q), download: (a) => ipcRenderer.invoke('map:download', a), list: () => ipcRenderer.invoke('map:list'),
    get: (id) => ipcRenderer.invoke('map:get', id), remove: (id) => ipcRenderer.invoke('map:remove', id), onProgress: (cb) => ipcRenderer.on('map:progress', (_e, t) => cb(t))
  },
  shotCrop: () => ipcRenderer.invoke('shot:crop'),
  onShotDone: (cb) => ipcRenderer.on('shot:done', (_e, r) => cb(r)),
  fileSearchAll: (q) => ipcRenderer.invoke('files:searchAll', q),
  pathForFile: (file) => {
    try { return webUtils.getPathForFile(file); } catch { return ''; }
  },

  pickBackground: () => ipcRenderer.invoke('bg:pick'),
  applySettings: (s) => ipcRenderer.invoke('settings:apply', s),
  deskPeek: () => ipcRenderer.send('desk:peek'),
  deskSwap: () => ipcRenderer.send('desk:swap'),
  onCovered: (cb) => ipcRenderer.on('desk:covered', (_e, on) => cb(!!on)),
  vdesk: { list: () => ipcRenderer.invoke('vdesk:list'), act: (what, n) => ipcRenderer.invoke('vdesk:do', what, n) },
  screen2: (snap) => ipcRenderer.send('s2:snap', snap),
  winSettings: (uri) => ipcRenderer.invoke('sys:settings', uri),
  quick: {
    get: () => ipcRenderer.invoke('quick:get'),
    radio: (kind, on) => ipcRenderer.invoke('quick:radio', kind, on),
    bright: (i, v) => ipcRenderer.invoke('quick:bright', i, v),
    wifiList: (scan) => ipcRenderer.invoke('quick:wifiList', !!scan),
    wifiConnect: (n, pass, auth) => ipcRenderer.invoke('quick:wifiConnect', n, pass, auth),
    wifiOff: () => ipcRenderer.invoke('quick:wifiOff'), wifiForget: (n) => ipcRenderer.invoke('quick:wifiForget', n),
    btList: () => ipcRenderer.invoke('quick:btList')
  },
  deskFiles: () => ipcRenderer.invoke('desk:files'),
  deskImport: (list) => ipcRenderer.invoke('desk:import', list),
  alive: () => ipcRenderer.send('hb'),
  mdesk: (on) => ipcRenderer.send('desk:mdesk', !!on),
  store: {
    catalog: () => ipcRenderer.invoke('store:catalog'),
    installed: () => ipcRenderer.invoke('store:installed'),
    install: (id) => ipcRenderer.invoke('store:install', id),
    remove: (id) => ipcRenderer.invoke('store:remove', id)
  },
  panel: {
    info: () => ipcRenderer.invoke('panel:info'),
    reset: () => ipcRenderer.invoke('panel:reset'),
    push: (snap) => ipcRenderer.send('panel:snap', snap),
    reply: (id, r) => ipcRenderer.send('panel:reply', id, r),
    onDo: (cb) => ipcRenderer.on('panel:do', (_e, m) => cb(m))
  },
  luces: {
    scan: () => ipcRenderer.invoke('luces:scan'),
    cloud: (cid, secret, region) => ipcRenderer.invoke('luces:cloud', cid, secret, region),
    detect: (l) => ipcRenderer.invoke('luces:detect', l),
    status: (l) => ipcRenderer.invoke('luces:status', l),
    act: (l, a) => ipcRenderer.invoke('luces:do', l, a),
    scenes: () => ipcRenderer.invoke('luces:scenes')
  },
  update: {
    check: () => ipcRenderer.invoke('update:check'),
    install: () => ipcRenderer.invoke('update:install'),
    info: () => ipcRenderer.invoke('update:info'),
    onAvailable: (cb) => ipcRenderer.on('update:available', (_e, d) => cb(d)),
    onProgress: (cb) => ipcRenderer.on('update:progress', (_e, d) => cb(d))
  },
  displays: () => ipcRenderer.invoke('displays:list'),
  setDisplay: (id) => ipcRenderer.invoke('displays:set', id),
  notify: (title, body) => ipcRenderer.send('notify', { title, body }),
  floatNotify: (n) => ipcRenderer.send('fnotif:show', n),
  floatPlayer: (site, pref) => ipcRenderer.invoke('player:float', site, pref),
  browsers: () => ipcRenderer.invoke('browsers:list'),
  waBounds: (r) => ipcRenderer.invoke('wa:bounds', r),
  waReload: () => ipcRenderer.invoke('wa:reload'),
  dealsEpic: () => ipcRenderer.invoke('deals:epic'),
  onFloatOpen: (cb) => ipcRenderer.on('fnotif:open', (_e, id) => cb(id)),
  get: (url) => ipcRenderer.invoke('net:get', url),
  openUrl: (url) => ipcRenderer.invoke('shortcut:open', { type: 'web', target: url }),

  onModeSet: (cb) => ipcRenderer.on('mode:set', (_e, m) => cb(m)),
  onSearch: (cb) => ipcRenderer.on('search:open', () => cb()),
  recentFiles: () => ipcRenderer.invoke('files:recent'),
  article: (url) => ipcRenderer.invoke('news:article', url),
  smallIcon: (p) => ipcRenderer.invoke('icon:for', p),
  google: {
    status: () => ipcRenderer.invoke('google:status'),
    setConfig: (id, secret) => ipcRenderer.invoke('google:setConfig', id, secret),
    link: (mode) => ipcRenderer.invoke('google:link', mode),
    unlink: (mode) => ipcRenderer.invoke('google:unlink', mode),
    events: (mode, from, to) => ipcRenderer.invoke('google:events', mode, from, to),
    createEvent: (mode, ev) => ipcRenderer.invoke('google:createEvent', mode, ev),
    deleteEvent: (mode, id) => ipcRenderer.invoke('google:deleteEvent', mode, id),
    mail: (mode) => ipcRenderer.invoke('google:mail', mode),
    message: (mode, id) => ipcRenderer.invoke('google:message', mode, id),
    markRead: (mode, ids) => ipcRenderer.invoke('google:markRead', mode, ids),
    cardMails: (mode, q, skip, days) => ipcRenderer.invoke('google:cardMails', mode, q, skip, days),
    openMail: (email, thread) => ipcRenderer.invoke('open:mail', email, thread),
    open: (url) => ipcRenderer.invoke('open:google', url)
  },
  taskbar: () => ipcRenderer.invoke('taskbar:list'),
  systemShortcuts: () => ipcRenderer.invoke('system:shortcuts'),
  games: () => ipcRenderer.invoke('games:list'),
  startApps: (force) => ipcRenderer.invoke('apps:start', force),
  launchSpecial: (kind, id) => ipcRenderer.invoke('launch:special', kind, id),
  media: {
    state: () => ipcRenderer.invoke('media:state'),
    key: (k) => ipcRenderer.invoke('media:key', k),
    vol: () => ipcRenderer.invoke('vol:get'),
    volSet: (v) => ipcRenderer.invoke('vol:set', v),
    volMute: (on) => ipcRenderer.invoke('vol:mute', on),
    sessions: () => ipcRenderer.invoke('media:sessions'),
    thumb: (app) => ipcRenderer.invoke('media:thumb', app),
    act: (app, act, val) => ipcRenderer.invoke('media:do', app, act, val)
  },
  windows: {
    list: () => ipcRenderer.invoke('win:list'),
    act: (action, h) => ipcRenderer.invoke('win:do', action, h),
    thumb: (h) => ipcRenderer.invoke('win:thumb', h),
    system: (name) => ipcRenderer.invoke('sys:action', name)
  },
  edition,
  stats: (detail) => ipcRenderer.invoke('sys:stats', !!detail),
  openDrive: (name) => ipcRenderer.invoke('sys:openDrive', name),
  luma: (src) => ipcRenderer.invoke('img:luma', src),
  dock: { find: (n) => ipcRenderer.invoke('dock:find', n), pick: () => ipcRenderer.invoke('dock:pick'), bounds: (b) => ipcRenderer.invoke('dock:bounds', b), release: () => ipcRenderer.invoke('dock:release'), state: () => ipcRenderer.invoke('dock:state'), windows: () => ipcRenderer.invoke('dock:windows'), adopt: (h) => ipcRenderer.invoke('dock:adopt', h) },
  fx: {
    places: () => ipcRenderer.invoke('fx:places'), list: (d, h) => ipcRenderer.invoke('fx:list', d, h), peek: (p) => ipcRenderer.invoke('fx:peek', p), thumb: (p) => ipcRenderer.invoke('fx:thumb', p),
    icon: (p) => ipcRenderer.invoke('fx:icon', p), open: (p) => ipcRenderer.invoke('fx:open', p), reveal: (p) => ipcRenderer.invoke('fx:reveal', p),
    winExplorer: (p) => ipcRenderer.invoke('fx:winexplorer', p), trash: (l) => ipcRenderer.invoke('fx:trash', l), rename: (p, n) => ipcRenderer.invoke('fx:rename', p, n),
    mkdir: (d, n) => ipcRenderer.invoke('fx:mkdir', d, n), paste: (l, d, mv) => ipcRenderer.invoke('fx:paste', l, d, mv), copyPath: (p) => ipcRenderer.invoke('fx:copypath', p),
    newFile: (d, n) => ipcRenderer.invoke('fx:newfile', d, n), stat: (p) => ipcRenderer.invoke('fx:stat', p), du: (p) => ipcRenderer.invoke('fx:du', p), free: (p) => ipcRenderer.invoke('fx:free', p),
    openWith: (p) => ipcRenderer.invoke('fx:openwith', p), zip: (l, d) => ipcRenderer.invoke('fx:zip', l, d), unzip: (p) => ipcRenderer.invoke('fx:unzip', p), search: (d, q, h) => ipcRenderer.invoke('fx:search', d, q, h),
    del: (l) => ipcRenderer.invoke('fx:delete', l), shellMenu: (l, x, y) => ipcRenderer.invoke('fx:shellmenu', l, x, y),
    clipSet: (l, mv) => ipcRenderer.invoke('fx:clipset', l, mv), clipGet: () => ipcRenderer.invoke('fx:clipget'), dragOut: (l) => ipcRenderer.invoke('fx:dragout', l),
    terminal: (d) => ipcRenderer.invoke('fx:terminal', d), recycle: () => ipcRenderer.invoke('fx:recycle'), shortcut: (p) => ipcRenderer.invoke('fx:shortcut', p)
  },
  sm: { apps: (f) => ipcRenderer.invoke('sm:apps', f), icon: (p) => ipcRenderer.invoke('sm:icon', p), open: (it) => ipcRenderer.invoke('sm:open', it), recent: () => ipcRenderer.invoke('sm:recent') },
  photos: { pick: () => ipcRenderer.invoke('photos:pick'), list: (dir) => ipcRenderer.invoke('photos:list', dir), show: (url) => ipcRenderer.invoke('photos:show', url) },
  backup: {
    export: (data, opts) => ipcRenderer.invoke('backup:export', data, opts),
    autoInfo: () => ipcRenderer.invoke('backup:autoInfo'), autoNow: () => ipcRenderer.invoke('backup:autoNow'), autoOpen: () => ipcRenderer.invoke('backup:autoOpen'),
    pick: () => ipcRenderer.invoke('backup:pick'),
    pending: () => ipcRenderer.invoke('backup:pending'),
    dismiss: () => ipcRenderer.invoke('backup:dismiss'),
    apply: (which, current) => ipcRenderer.invoke('backup:apply', which, current)
  },
  clearSocial: () => ipcRenderer.invoke('redes:clear'),
  locate: () => ipcRenderer.invoke('geo:locate'),
  ready: () => ipcRenderer.send('app:ready'),
  reportError: (msg) => ipcRenderer.send('app:error', String(msg)),
  platform: process.platform
});
