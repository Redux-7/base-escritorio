// Más mini juegos de Base: Memotest, Viborita, Ta-te-ti, Adiviná la palabra y Bloques.
(() => {
  'use strict';
  if (!window.BaseMini || !window.BaseMini.util) return;
  const { h, rnd, shuffle, timer, seg, btn, overlay, confetti, fmtTime } = window.BaseMini.util;
  const SFX = window.BaseMini.util.sfx || (() => {});
  const closeOver = (root) => { const o = root.querySelector('.mg-over'); if (o) o.remove(); };

  // =====================================================================
  // MEMOTEST
  // =====================================================================
  const MEMO_SETS = {
    frutas: ['🍎', '🍌', '🍇', '🍓', '🍒', '🍍', '🥝', '🍉', '🍑', '🍋', '🥥', '🍐', '🫐', '🍈', '🥭', '🍊', '🍅', '🥑'],
    animales: ['🐶', '🐱', '🦊', '🐼', '🐸', '🦁', '🐵', '🐧', '🦄', '🐙', '🐢', '🦋', '🐰', '🐨', '🐯', '🐮', '🐷', '🦉'],
    deportes: ['⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏉', '🎱', '🏓', '🏸', '🥊', '⛳', '🏒', '🥏', '🎳', '🏆', '🥇', '⛸️'],
    comida: ['🍕', '🍔', '🌭', '🍟', '🌮', '🍣', '🍩', '🍪', '🧁', '🍦', '🥐', '🧀', '🍫', '🍿', '🥨', '🍝', '🥞', '🍰'],
    viajes: ['✈️', '🚀', '🚗', '🚲', '⛵', '🚂', '🏝️', '🗽', '🗼', '🏰', '🌋', '🗻', '🎡', '🚁', '🛵', '🏕️', '🌉', '🚌']
  };
  const MEMO_FACES = MEMO_SETS.frutas;
  const MEMO_LV = { facil: { c: 4, r: 4, n: 'Fácil' }, medio: { c: 6, r: 4, n: 'Medio' }, dificil: { c: 6, r: 6, n: 'Difícil' } };
  function memotest(H) {
    let lv = H.get().lv || 'facil';
    let cards, open, moves, found, lock, done;
    const root = h('div', { class: 'mg-memo' });
    const board = h('div', { class: 'mm-board' });
    root.append(board);
    const t = timer(() => status());
    const status = () => H.status([`Pares ${found || 0}/${cards ? cards.length / 2 : 0}`, `Intentos ${moves || 0}`, fmtTime(t.secs), H.get()['best_' + lv] ? `Récord ${fmtTime(H.get()['best_' + lv])}` : '']);
    function newGame() {
      closeOver(root);
      const L = MEMO_LV[lv], pairs = L.c * L.r / 2;
      const faces = shuffle((MEMO_SETS[H.get().skin] || MEMO_FACES).slice()).slice(0, pairs);
      cards = shuffle([...faces, ...faces]).map((f, i) => ({ i, f, up: false, ok: false }));
      open = []; moves = 0; found = 0; lock = false; done = false;
      t.reset();
      board.style.setProperty('--cols', L.c); board.style.setProperty('--rows', L.r);
      board.replaceChildren(...cards.map(c => {
        const e = h('button', { type: 'button', class: 'mm-c', 'aria-label': 'Carta' }, h('span', { class: 'mm-in' }, h('span', { class: 'mm-back' }), h('span', { class: 'mm-front', text: c.f })));
        e.onclick = () => flip(c);
        c.el = e; return e;
      }));
      status();
    }
    function flip(c) {
      if (lock || done || c.up || c.ok) return;
      t.start();
      c.up = true; c.el.classList.add('up'); open.push(c); SFX('flip');
      if (open.length < 2) return;
      moves++;
      const [a, b] = open;
      if (a.f === b.f) {
        a.ok = b.ok = true; found++; setTimeout(() => SFX('good'), 200);
        setTimeout(() => { a.el.classList.add('ok'); b.el.classList.add('ok'); }, 250);
        open = [];
        if (found === cards.length / 2) win();
      } else {
        lock = true; setTimeout(() => SFX('erase'), 500);
        setTimeout(() => { a.up = b.up = false; a.el.classList.remove('up'); b.el.classList.remove('up'); open = []; lock = false; }, 850);
      }
      status();
    }
    function win() {
      done = true; t.stop();
      const s = H.get(), secs = Math.round(t.secs);
      s.wins = (s.wins || 0) + 1;
      const rec = !s['best_' + lv] || secs < s['best_' + lv];
      if (rec) s['best_' + lv] = secs;
      H.set(s); status();
      setTimeout(() => { confetti(root); overlay(root, '¡Encontraste todos!', `${moves} intentos · ${fmtTime(secs)}${rec ? ' · ¡récord!' : ''}`, [btn('Otra vez', newGame, 'primary')]); }, 500);
    }
    const tools = [seg(Object.entries(MEMO_LV).map(([k, v]) => [k, v.n]), lv, (v) => { lv = v; const s = H.get(); s.lv = v; H.set(s); newGame(); }), btn('Nueva', newGame)];
    requestAnimationFrame(newGame);
    return { el: root, tools, setSkin: () => newGame(), help: 'Dá vuelta dos cartas por vez y encontrá los pares.', hide: () => t.running && t.stop(), show: () => { if (moves && !done) t.start(); } };
  }

  // =====================================================================
  // VIBORITA
  // =====================================================================
  const SNAKE_SP = { lenta: { ms: 150, n: 'Lenta' }, normal: { ms: 105, n: 'Normal' }, rapida: { ms: 72, n: 'Rápida' } };
  function viborita(H) {
    const COLS = 26, ROWS = 17;
    let sp = H.get().sp || 'normal';
    let snake, dir, nextDir, food, score, loop, over, paused, started;
    const root = h('div', { class: 'mg-snake' });
    const cv = h('canvas', { class: 'sn-cv' });
    const msg = h('div', { class: 'sn-msg', text: 'Tocá una flecha para empezar' });
    root.append(cv, msg);
    const ctx = cv.getContext('2d');
    const status = () => H.status([`Puntos ${score || 0}`, `Mejor ${Math.max(H.get()['best_' + sp] || 0, score || 0)}`]);
    let cell = 24;
    function fit() {
      const W = root.clientWidth - 30 || 700, Hh = root.clientHeight - 30 || 460;
      cell = Math.max(12, Math.floor(Math.min(W / COLS, Hh / ROWS)));
      const dpr = window.devicePixelRatio || 1;
      cv.width = COLS * cell * dpr; cv.height = ROWS * cell * dpr;
      cv.style.width = COLS * cell + 'px'; cv.style.height = ROWS * cell + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw();
    }
    function placeFood() {
      const busy = new Set(snake.map(p => p.x + ',' + p.y));
      let p; do { p = { x: rnd(COLS), y: rnd(ROWS) }; } while (busy.has(p.x + ',' + p.y));
      food = p;
    }
    function newGame() {
      closeOver(root);
      clearInterval(loop);
      const y = Math.floor(ROWS / 2);
      snake = [{ x: 6, y }, { x: 5, y }, { x: 4, y }];
      dir = { x: 1, y: 0 }; nextDir = dir; score = 0; over = false; paused = false; started = false;
      placeFood(); msg.hidden = false; msg.textContent = 'Tocá una flecha para empezar';
      draw(); status();
    }
    function start() { if (started || over) return; started = true; msg.hidden = true; clearInterval(loop); loop = setInterval(step, SNAKE_SP[sp].ms); }
    function step() {
      if (paused || over) return;
      dir = nextDir;
      const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
      if (head.x < 0 || head.y < 0 || head.x >= COLS || head.y >= ROWS || snake.some((p, i) => i < snake.length - 1 && p.x === head.x && p.y === head.y)) return die();
      snake.unshift(head);
      if (head.x === food.x && head.y === food.y) { score += 10; SFX('eat'); placeFood(); status(); }
      else snake.pop();
      draw();
    }
    function die() {
      over = true; clearInterval(loop); SFX('crash');
      const s = H.get(); const rec = score > (s['best_' + sp] || 0);
      if (rec) s['best_' + sp] = score; s.games = (s.games || 0) + 1; H.set(s); status();
      if (rec && score) confetti(root);
      overlay(root, rec && score ? '¡Nuevo récord!' : 'Chocaste', `${score} puntos`, [btn('Otra vez', newGame, 'primary')]);
    }
    function rr(x, y, w, hh, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function draw() {
      if (!snake) return;
      ctx.clearRect(0, 0, COLS * cell, ROWS * cell);
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) { ctx.fillStyle = (x + y) % 2 ? '#1c2a1f' : '#203024'; ctx.fillRect(x * cell, y * cell, cell, cell); }
      // comida
      ctx.fillStyle = '#ff4d5e'; ctx.beginPath(); ctx.arc(food.x * cell + cell / 2, food.y * cell + cell / 2 + 1, cell * 0.36, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#3ecf6a'; ctx.fillRect(food.x * cell + cell / 2 - 1, food.y * cell + cell * 0.12, 3, cell * 0.22);
      snake.forEach((p, i) => {
        const k = 1 - i / (snake.length + 6);
        const sk = H.get().skin || 'verde';
        ctx.fillStyle = sk === 'arcoiris' ? `hsl(${(i * 24) % 360}, 75%, 55%)` : sk === 'azul' ? `hsl(${210 - i * 1.2}, 75%, ${40 + k * 18}%)` : sk === 'fuego' ? `hsl(${40 - Math.min(40, i * 2)}, 90%, ${45 + k * 12}%)` : sk === 'cebra' ? (i % 2 ? '#f2f2f2' : '#222') : `hsl(${140 - i * 1.2}, 70%, ${38 + k * 18}%)`;
        rr(p.x * cell + 1.5, p.y * cell + 1.5, cell - 3, cell - 3, cell * 0.3); ctx.fill();
      });
      const hd = snake[0];
      ctx.fillStyle = '#fff';
      const ex = dir.y !== 0 ? [0.3, 0.7] : [dir.x > 0 ? 0.68 : 0.32, dir.x > 0 ? 0.68 : 0.32];
      const ey = dir.x !== 0 ? [0.3, 0.7] : [dir.y > 0 ? 0.68 : 0.32, dir.y > 0 ? 0.68 : 0.32];
      for (let j = 0; j < 2; j++) { ctx.beginPath(); ctx.arc(hd.x * cell + ex[j] * cell, hd.y * cell + ey[j] * cell, cell * 0.11, 0, Math.PI * 2); ctx.fill(); }
    }
    const DIRS = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0], w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0], W: [0, -1], S: [0, 1], A: [-1, 0], D: [1, 0] };
    const key = (e) => {
      if (e.key === ' ' || e.key === 'p' || e.key === 'P') { if (started && !over) { paused = !paused; msg.hidden = !paused; msg.textContent = 'En pausa · espacio para seguir'; } return true; }
      const d = DIRS[e.key]; if (!d || over) return false;
      if (d[0] === -dir.x && d[1] === -dir.y && snake.length > 1) return true;
      nextDir = { x: d[0], y: d[1] }; start(); return true;
    };
    // en pantallas táctiles: deslizar
    let sx = 0, sy = 0;
    cv.addEventListener('pointerdown', (e) => { sx = e.clientX; sy = e.clientY; });
    cv.addEventListener('pointerup', (e) => { const dx = e.clientX - sx, dy = e.clientY - sy; if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return; key({ key: Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'ArrowRight' : 'ArrowLeft') : (dy > 0 ? 'ArrowDown' : 'ArrowUp') }); });
    let lastSz = '', rf = 0;
    const ro = new ResizeObserver(() => { const k = root.clientWidth + 'x' + root.clientHeight; if (k === lastSz) return; lastSz = k; cancelAnimationFrame(rf); rf = requestAnimationFrame(fit); }); ro.observe(root);
    const tools = [seg(Object.entries(SNAKE_SP).map(([k, v]) => [k, v.n]), sp, (v) => { sp = v; const s = H.get(); s.sp = v; H.set(s); newGame(); }), btn('Nueva', newGame)];
    requestAnimationFrame(() => { newGame(); fit(); });
    return { el: root, tools, key, setSkin: () => draw(), help: 'Flechas (o W A S D) para moverte. Espacio pausa. Comé las manzanas y no choques.', hide: () => { if (started && !over) { paused = true; msg.hidden = false; msg.textContent = 'En pausa · espacio para seguir'; } } };
  }

  // =====================================================================
  // TA-TE-TI
  // =====================================================================
  const TTT_LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
  function tttWinner(b) { for (const l of TTT_LINES) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[0]] === b[l[2]]) return { p: b[l[0]], l }; return b.every(Boolean) ? { p: 'empate' } : null; }
  function minimax(b, me, turn, depth) {
    const w = tttWinner(b);
    if (w) return w.p === 'empate' ? 0 : (w.p === me ? 10 - depth : depth - 10);
    const other = turn === 'X' ? 'O' : 'X';
    let best = turn === me ? -99 : 99;
    for (let i = 0; i < 9; i++) if (!b[i]) {
      b[i] = turn; const v = minimax(b, me, other, depth + 1); b[i] = null;
      best = turn === me ? Math.max(best, v) : Math.min(best, v);
    }
    return best;
  }
  function tateti(H) {
    let mode = H.get().mode || 'medio';
    let b, turn, over, starter = 'X';
    const root = h('div', { class: 'mg-ttt' });
    const grid = h('div', { class: 'tt-grid' });
    const info = h('div', { class: 'tt-info' });
    root.append(info, grid);
    const sc = () => { const s = H.get(); s.sc = s.sc || {}; s.sc[mode] = s.sc[mode] || { yo: 0, otro: 0, emp: 0 }; return s; };
    const status = () => { const s = sc().sc[mode]; H.status([mode === 'dos' ? `X ${s.yo}` : `Vos ${s.yo}`, mode === 'dos' ? `O ${s.otro}` : `Compu ${s.otro}`, `Empates ${s.emp}`]); };
    const cells = [];
    for (let i = 0; i < 9; i++) { const c = h('button', { type: 'button', class: 'tt-c' }); c.onclick = () => play(i, true); cells.push(c); grid.append(c); }
    function newGame() {
      closeOver(root);
      b = new Array(9).fill(null); over = false;
      turn = starter; starter = starter === 'X' ? 'O' : 'X';
      render();
      if (mode !== 'dos' && turn === 'O') setTimeout(cpu, 450);
    }
    function render() {
      const SYM = { clasico: { X: 'X', O: 'O' }, frutas: { X: '🍓', O: '🍋' }, animales: { X: '🐶', O: '🐱' }, corazones: { X: '❤️', O: '💙' }, futbol: { X: '⚽', O: '🏀' } }[H.get().skin || 'clasico'] || { X: 'X', O: 'O' };
      cells.forEach((c, i) => { c.textContent = b[i] ? SYM[b[i]] : ''; c.className = 'tt-c' + (b[i] ? ' ' + b[i].toLowerCase() : ''); });
      info.textContent = over ? '' : mode === 'dos' ? `Juega ${turn}` : turn === 'X' ? 'Te toca (sos X)' : 'Piensa la compu…';
      status();
    }
    function play(i, human) {
      if (over || b[i]) return;
      if (human && mode !== 'dos' && turn !== 'X') return;
      SFX(turn === 'X' ? 'place' : 'click'); b[i] = turn; turn = turn === 'X' ? 'O' : 'X';
      const w = tttWinner(b);
      render();
      if (w) return end(w);
      if (mode !== 'dos' && turn === 'O') setTimeout(cpu, 380);
    }
    function cpu() {
      if (over) return;
      const free = b.map((v, i) => v ? null : i).filter(v => v != null);
      let pick;
      const smart = mode === 'imposible' || (mode === 'medio' && Math.random() < 0.65);
      if (!smart) pick = free[rnd(free.length)];
      else {
        let best = -99;
        for (const i of shuffle(free.slice())) { b[i] = 'O'; const v = minimax(b, 'O', 'X', 0); b[i] = null; if (v > best) { best = v; pick = i; } }
      }
      play(pick, false);
    }
    function end(w) {
      over = true;
      const s = sc(); const r = s.sc[mode];
      if (w.p === 'empate') r.emp++; else if (w.p === 'X') r.yo++; else r.otro++;
      H.set(s); render();
      if (w.l) for (const i of w.l) cells[i].classList.add('win');
      const title = w.p === 'empate' ? 'Empate' : mode === 'dos' ? `Ganó ${w.p}` : w.p === 'X' ? '¡Ganaste!' : 'Ganó la compu';
      if (w.p === 'X' && mode !== 'dos') confetti(root);
      setTimeout(() => overlay(root, title, '', [btn('Otra', newGame, 'primary')]), 500);
    }
    const tools = [seg([['facil', 'Fácil'], ['medio', 'Medio'], ['imposible', 'Imposible'], ['dos', '2 jugadores']], mode, (v) => { mode = v; const s = H.get(); s.mode = v; H.set(s); starter = 'X'; newGame(); }), btn('Nueva', newGame)];
    const key = (e) => { const n = +e.key; if (n >= 1 && n <= 9) { play([6, 7, 8, 3, 4, 5, 0, 1, 2][n - 1], true); return true; } return false; };
    requestAnimationFrame(newGame);
    return { el: root, tools, key, setSkin: () => render(), help: 'Tres en línea gana. También podés usar el teclado numérico (1 a 9).' };
  }

  // =====================================================================
  // ADIVINÁ LA PALABRA (5 letras, 6 intentos)
  // =====================================================================
  const WORDS = (
    'arbol perro libro playa campo fuego nieve lunes marzo abril junio julio suelo techo silla plato cielo nubes verde negro ' +
    'mundo mujer padre madre hijos primo tieso ancho largo corto bajos altos limon fresa mango melon pasas queso leche huevo ' +
    'carne pollo arroz pasta salsa sopas tarta dulce torta miel cafes jugos agua vinos yerba termo mates hielo ' +
    'barco avion moto autos tren bicis ruta calle plaza barra banco cajas papel lapiz goma regla carta sobre mapas reloj ' +
    'radio cable perla oro plata cobre hierro acero piedra arena barro pasto flores rosas tallo hojas ramas palma pinos ' +
    'tigre leona zorro mono osos lobos ratas raton conejo patos ganso cisne aguila buhos garza pulpo ballena delfin tiburon ' +
    'cebra jirafa camello burro vacas toros cerdo oveja cabra gallo pajaro loros sapos ranas grillo abeja avispa hormiga ' +
    'feliz triste calma susto miedo amor odio risas llanto suerte broma juego truco pista golpe salto carrera dados ' +
    'cerca lejos arriba abajo nunca siempre ahora tarde noche temprano manana viaje visita fiesta regalo sorpresa ' +
    'nadar correr saltar cantar bailar comer beber dormir jugar leer mirar pensar soñar volar abrir cerrar subir bajar ' +
    'calor frio viento rayos trueno brisa ' +
    'dedos manos brazo pecho codos cuello cara boca nariz ojos orejas labio pelo barba ' +
    'clave lista nota canto tango rock disco banda votos ley grupo equipo club pelota arco gol cancha tribuna hincha ' +
    'pizza fideo ñoqui asado chori locro humita tamal flan budin helado ' +
    'campana timbre puerta ventana pared piso patio jardin balcon cocina baños pieza living garage ' +
    'fruta granos trigo maiz soja papas batata cebolla tomate lechuga zanahoria ' +
    'nieto abuelo tios amigo vecino novio novia jefe socio ' +
    'poema verso tinta letra texto frase idea plan meta logro exito fallo error dudas ' +
    'mesa sofa cama lampara espejo cuadro alfombra cortina ' +
    'rubio moreno pelado ' +
    'barato caro rico pobre nuevo viejo joven grande chico bueno malo lindo feo ' +
    'brujo hada magia hechizo duende ogro dragon castillo reina principe ' +
    'nieve playa monte cerro valle lago rio mar isla costa bosque selva desierto ' +
    'tarea clase curso aula recreo examen nota boletin ' +
    'monte nacer vivir morir crecer ganar perder ' +
    'ruido sonar tocar sonido musica piano bombo flauta violin ' +
    'pared lazos nudos hilos aguja tela lana seda ropa saco camisa remera falda medias zapato botas ' +
    'robot pixel teclado mouse pantalla ' +
    'oveja yegua potro pumas ' +
    'mente alma vida muerte tiempo ' +
    'plaza pueblo ciudad barrio ' +
    'golfo bahia canal puente torre faro ' +
    'tenis rugby futbol boxeo surf ' +
    'santo virgen iglesia ' +
    'nacion patria bandera himno ' +
    'perla ambar coral rubi ' +
    'lente gafas anteojos ' +
    'pinta tinte color ' +
    'marca serie letra hojas nubes cajon ' +
    'fosil craneo huesos ' +
    'trigo harina pan masa horno ' +
    'cuero lienzo ' +
    'salud fuerza poder valor honor ' +
    'cinta disco video audio ' +
    'brasa llama humo chispa ceniza ' +
    'carro carta cosas causa chiste corte credo cruce cuota curva ' +
    'dicha disco ' +
    'fondo forma fruta ' +
    'gesto gorra grano grito guapo ' +
    'hielo hogar huevo ' +
    'jarra joven juego junta ' +
    'labor lente letra listo lomas lucha lugar ' +
    'mente metal miedo mitad modos monja mosca motor mueble ' +
    'nadie nariz norte novia nudos ' +
    'ola obra olivo orden ' +
    'pacto padre pausa perla pieza pinta plano polvo punto ' +
    'queja quema ' +
    'radar ramas rasgo reloj resto ritmo robot rueda ' +
    'sabor salir santo selva siglo signo sitio sobra solar sueño ' +
    'tabla talla tarde techo tecla temas tenor tiara tigre tinta tomar total trapo tribu trozo tumba ' +
    'unico untar usado ' +
    'vapor vasco vejez vela venta verbo viaje video vigor visor vocal volar ' +
    'yogur zorro zurdo').split(/\s+/);
  const norm = (w) => w.toLowerCase().normalize('NFD').replace(/[̀-̂̄-ͯ]/g, '').normalize('NFC');
  const LIST = [...new Set(WORDS.map(norm).filter(w => /^[a-zñ]{5}$/.test(w)))];
  const KB = ['qwertyuiop', 'asdfghjklñ', '↵zxcvbnm⌫'];
  function palabra(H) {
    let mode = H.get().mode || 'dia';
    let target, rows, cur, over;
    const root = h('div', { class: 'mg-word' });
    const grid = h('div', { class: 'wd-grid' });
    const kb = h('div', { class: 'wd-kb' });
    const note = h('div', { class: 'wd-note' });
    root.append(grid, note, kb);
    const st = () => { const s = H.get(); s.racha = s.racha || 0; s.wins = s.wins || 0; s.games = s.games || 0; return s; };
    const status = () => { const s = st(); H.status([`Ganadas ${s.wins}/${s.games}`, `Racha ${s.racha}`, mode === 'dia' ? 'Palabra del día' : 'Partida libre']); };
    const todayKey = () => { const d = new Date(); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };
    function pickDaily() { const k = todayKey(); let x = k * 2654435761 % 4294967296; return LIST[x % LIST.length]; }
    function newGame(force) {
      closeOver(root);
      const s = st();
      target = mode === 'dia' ? pickDaily() : LIST[rnd(LIST.length)];
      rows = []; cur = ''; over = false;
      if (mode === 'dia' && s.day === todayKey() && s.dayRows && !force) { rows = s.dayRows.slice(); over = !!s.dayDone; }
      render();
      if (over) note.textContent = rows.length && rows[rows.length - 1] === target ? '¡Ya la adivinaste hoy! Mañana hay otra (o probá una partida libre).' : `Hoy era “${target.toUpperCase()}”. Mañana hay otra.`;
    }
    function score(guess) {
      const res = new Array(5).fill('no'), left = {};
      for (let i = 0; i < 5; i++) { if (guess[i] === target[i]) res[i] = 'ok'; else left[target[i]] = (left[target[i]] || 0) + 1; }
      for (let i = 0; i < 5; i++) if (res[i] !== 'ok' && left[guess[i]]) { res[i] = 'hay'; left[guess[i]]--; }
      return res;
    }
    function render() {
      grid.replaceChildren();
      for (let r = 0; r < 6; r++) {
        const word = r < rows.length ? rows[r] : r === rows.length ? cur : '';
        const sc = r < rows.length ? score(rows[r]) : null;
        const row = h('div', { class: 'wd-row' + (r === rows.length && !over ? ' cur' : '') });
        for (let i = 0; i < 5; i++) row.append(h('span', { class: 'wd-l' + (sc ? ' ' + sc[i] : word[i] ? ' full' : ''), text: (word[i] || '').toUpperCase() }));
        grid.append(row);
      }
      const best = {};
      for (const w of rows) score(w).forEach((v, i) => { const l = w[i]; const rank = { ok: 3, hay: 2, no: 1 }; if (!best[l] || rank[v] > rank[best[l]]) best[l] = v; });
      kb.replaceChildren(...KB.map(line => h('div', { class: 'wd-kr' }, ...[...line].map(ch => {
        const k = h('button', { type: 'button', class: 'wd-k' + (best[ch] ? ' ' + best[ch] : '') + (ch === '↵' || ch === '⌫' ? ' wide' : ''), text: ch === '↵' ? 'Enviar' : ch === '⌫' ? '⌫' : ch.toUpperCase() });
        k.onclick = () => press(ch === '↵' ? 'Enter' : ch === '⌫' ? 'Backspace' : ch);
        return k;
      }))));
      if (!over) note.textContent = '';
      status();
    }
    function shake(msg) { note.textContent = msg; const r = grid.children[rows.length]; if (r) { r.classList.remove('shake'); void r.offsetWidth; r.classList.add('shake'); } }
    function press(k) {
      if (over) return;
      if (k === 'Enter') {
        if (cur.length < 5) { SFX('bad'); return shake('Faltan letras'); }
        SFX('select');
        rows.push(cur); const g = cur; cur = '';
        const won = g === target, lost = !won && rows.length === 6;
        const s = st();
        if (won || lost) {
          over = true; s.games++;
          if (won) { s.wins++; s.racha++; } else s.racha = 0;
        }
        if (mode === 'dia') { s.day = todayKey(); s.dayRows = rows.slice(); s.dayDone = over; }
        H.set(s); render();
        if (won) { confetti(root); setTimeout(() => overlay(root, ['¡Genio!', '¡Excelente!', '¡Muy bien!', '¡Bien!', '¡Justo!', '¡Por poco!'][rows.length - 1], `Era “${target.toUpperCase()}”`, [btn('Partida libre', () => { mode = 'libre'; syncSeg(); newGame(); }, 'primary'), btn('Cerrar', () => closeOver(root))]), 600); }
        else if (lost) setTimeout(() => overlay(root, 'Se terminaron los intentos', `Era “${target.toUpperCase()}”`, [btn('Otra', () => { if (mode === 'dia') { mode = 'libre'; syncSeg(); } newGame(); }, 'primary')]), 500);
        return;
      }
      if (k === 'Backspace') { if (cur) SFX('erase'); cur = cur.slice(0, -1); return render(); }
      const ch = norm(k);
      if (/^[a-zñ]$/.test(ch) && cur.length < 5) { cur += ch; SFX('type'); render(); }
    }
    let segEl;
    const syncSeg = () => { for (const x of segEl.children) x.classList.toggle('on', x.textContent === (mode === 'dia' ? 'Palabra del día' : 'Libre')); };
    segEl = seg([['dia', 'Palabra del día'], ['libre', 'Libre']], mode, (v) => { mode = v; const s = H.get(); s.mode = v; H.set(s); newGame(); });
    const key = (e) => { if (e.ctrlKey || e.altKey || e.metaKey) return false; if (e.key === 'Enter' || e.key === 'Backspace' || /^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ]$/.test(e.key)) { press(e.key); return true; } return false; };
    const tools = [segEl, btn('Nueva libre', () => { mode = 'libre'; syncSeg(); newGame(true); })];
    requestAnimationFrame(() => newGame());
    return { el: root, tools, key, help: 'Adiviná la palabra de 5 letras en 6 intentos. Verde: letra en su lugar. Amarillo: está, pero en otro lugar. Sin tildes.' };
  }

  // =====================================================================
  // BLOQUES (piezas que caen)
  // =====================================================================
  const PIECES = {
    I: { c: '#3fc5f0', m: [[0, 1], [1, 1], [2, 1], [3, 1]] }, O: { c: '#f7d038', m: [[1, 0], [2, 0], [1, 1], [2, 1]] },
    T: { c: '#a55eea', m: [[1, 0], [0, 1], [1, 1], [2, 1]] }, S: { c: '#4cd964', m: [[1, 0], [2, 0], [0, 1], [1, 1]] },
    Z: { c: '#ff5e57', m: [[0, 0], [1, 0], [1, 1], [2, 1]] }, J: { c: '#3d7bf7', m: [[0, 0], [0, 1], [1, 1], [2, 1]] },
    L: { c: '#ff9f43', m: [[2, 0], [0, 1], [1, 1], [2, 1]] }
  };
  function bloques(H) {
    const COLS = 10, ROWS = 20;
    let grid, piece, next, bag, score, lines, level, loop, over, paused, started, cell = 28;
    const root = h('div', { class: 'mg-blocks' });
    const cv = h('canvas', { class: 'bl-cv' });
    const side = h('div', { class: 'bl-side' });
    const nextCv = h('canvas', { class: 'bl-next' });
    const msg = h('div', { class: 'sn-msg', text: 'Tocá una flecha para empezar' });
    side.append(h('span', { class: 'bl-lab', text: 'Sigue' }), nextCv, h('div', { class: 'bl-keys', html: '← → mover<br>↑ girar<br>↓ bajar<br>espacio: tirar<br>P: pausa' }));
    const wrap = h('div', { class: 'bl-wrap' }, cv, msg);
    root.append(wrap, side);
    const ctx = cv.getContext('2d'), nctx = nextCv.getContext('2d');
    const status = () => H.status([`Puntos ${score || 0}`, `Líneas ${lines || 0}`, `Nivel ${level || 1}`, `Mejor ${Math.max(H.get().best || 0, score || 0)}`]);
    function fit() {
      const Hh = root.clientHeight - 30 || 560;
      cell = Math.max(14, Math.floor(Hh / ROWS));
      const dpr = window.devicePixelRatio || 1;
      cv.width = COLS * cell * dpr; cv.height = ROWS * cell * dpr; cv.style.width = COLS * cell + 'px'; cv.style.height = ROWS * cell + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const nc = Math.round(cell * 0.8);
      nextCv.width = 4 * nc * dpr; nextCv.height = 3 * nc * dpr; nextCv.style.width = 4 * nc + 'px'; nextCv.style.height = 3 * nc + 'px';
      nctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw();
    }
    function fromBag() { if (!bag || !bag.length) bag = shuffle(Object.keys(PIECES)); return bag.pop(); }
    function make(k) { return { k, c: PIECES[k].c, cells: PIECES[k].m.map(([x, y]) => [x, y]), x: 3, y: k === 'I' ? -1 : 0 }; }
    function newGame() {
      closeOver(root); clearInterval(loop);
      grid = Array.from({ length: ROWS }, () => new Array(COLS).fill(null));
      bag = null; next = fromBag(); piece = make(fromBag());
      score = 0; lines = 0; level = 1; over = false; paused = false; started = false;
      msg.hidden = false; msg.textContent = 'Tocá una flecha para empezar';
      draw(); status();
    }
    const speed = () => Math.max(90, 650 - (level - 1) * 55);
    function start() { if (started || over) return; started = true; msg.hidden = true; restartLoop(); }
    function restartLoop() { clearInterval(loop); loop = setInterval(() => { if (!paused && !over) drop(); }, speed()); }
    function fits(cells, px, py) { return cells.every(([x, y]) => { const X = px + x, Y = py + y; return X >= 0 && X < COLS && Y < ROWS && (Y < 0 || !grid[Y][X]); }); }
    function rotate() {
      if (piece.k === 'O') return;
      const size = piece.k === 'I' ? 4 : 3;
      const rc = piece.cells.map(([x, y]) => [size - 1 - y, x]);
      for (const dx of [0, -1, 1, -2, 2]) if (fits(rc, piece.x + dx, piece.y)) { piece.cells = rc; piece.x += dx; SFX('click'); return draw(); }
    }
    function moveX(d) { if (fits(piece.cells, piece.x + d, piece.y)) { piece.x += d; SFX('move'); draw(); } }
    function drop() {
      if (fits(piece.cells, piece.x, piece.y + 1)) { piece.y++; draw(); return true; }
      lock(); return false;
    }
    function hardDrop() { SFX('whoosh'); let n = 0; while (fits(piece.cells, piece.x, piece.y + 1)) { piece.y++; n++; } score += n * 2; lock(); }
    function lock() {
      for (const [x, y] of piece.cells) { const Y = piece.y + y; if (Y < 0) return gameOver(); grid[Y][piece.x + x] = piece.c; }
      let cleared = 0;
      for (let y = ROWS - 1; y >= 0; y--) if (grid[y].every(Boolean)) { grid.splice(y, 1); grid.unshift(new Array(COLS).fill(null)); cleared++; y++; }
      if (cleared) SFX('line', { n: cleared }); else SFX('place');
      if (cleared) {
        score += [0, 100, 300, 500, 800][cleared] * level; lines += cleared;
        const nl = 1 + Math.floor(lines / 10); if (nl !== level) { level = nl; restartLoop(); }
      }
      piece = make(next); next = fromBag();
      if (!fits(piece.cells, piece.x, piece.y)) return gameOver();
      draw(); status();
    }
    function gameOver() {
      over = true; clearInterval(loop); draw();
      const s = H.get(); const rec = score > (s.best || 0); if (rec) s.best = score; s.games = (s.games || 0) + 1; H.set(s); status();
      if (rec && score) confetti(root);
      overlay(root, rec && score ? '¡Nuevo récord!' : 'Se llenó', `${score} puntos · ${lines} líneas`, [btn('Otra vez', newGame, 'primary')]);
    }
    const PAL = { pastel: { '#3fc5f0': '#a8e6f5', '#f7d038': '#fbe9a0', '#a55eea': '#d6b8f5', '#4cd964': '#b5efc0', '#ff5e57': '#ffb8b4', '#3d7bf7': '#b0c9fb', '#ff9f43': '#ffd3a8' },
      neon: { '#3fc5f0': '#00f0ff', '#f7d038': '#fff200', '#a55eea': '#d000ff', '#4cd964': '#39ff14', '#ff5e57': '#ff1744', '#3d7bf7': '#2979ff', '#ff9f43': '#ff9100' },
      gris: { '#3fc5f0': '#c7ccd4', '#f7d038': '#e6e8eb', '#a55eea': '#8b919b', '#4cd964': '#a9afb8', '#ff5e57': '#6e747e', '#3d7bf7': '#9aa1ab', '#ff9f43': '#d3d7dd' } };
    function block(c, x, y, sz, cx2) {
      const g = cx2 || ctx;
      const pal = PAL[H.get().skin]; if (pal && pal[c]) c = pal[c];
      g.fillStyle = c; g.fillRect(x * sz + 1, y * sz + 1, sz - 2, sz - 2);
      g.fillStyle = 'rgba(255,255,255,.28)'; g.fillRect(x * sz + 1, y * sz + 1, sz - 2, Math.max(2, sz * 0.18));
      g.fillStyle = 'rgba(0,0,0,.18)'; g.fillRect(x * sz + 1, y * sz + sz - 1 - Math.max(2, sz * 0.14), sz - 2, Math.max(2, sz * 0.14));
    }
    function draw() {
      if (!grid) return;
      ctx.fillStyle = '#121826'; ctx.fillRect(0, 0, COLS * cell, ROWS * cell);
      ctx.strokeStyle = 'rgba(255,255,255,.04)'; ctx.lineWidth = 1;
      for (let x = 1; x < COLS; x++) { ctx.beginPath(); ctx.moveTo(x * cell + .5, 0); ctx.lineTo(x * cell + .5, ROWS * cell); ctx.stroke(); }
      for (let y = 1; y < ROWS; y++) { ctx.beginPath(); ctx.moveTo(0, y * cell + .5); ctx.lineTo(COLS * cell, y * cell + .5); ctx.stroke(); }
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) if (grid[y][x]) block(grid[y][x], x, y, cell);
      if (piece && !over) {
        // sombra de dónde cae
        let gy = piece.y; while (fits(piece.cells, piece.x, gy + 1)) gy++;
        ctx.fillStyle = 'rgba(255,255,255,.08)';
        for (const [x, y] of piece.cells) if (gy + y >= 0) ctx.fillRect((piece.x + x) * cell + 1, (gy + y) * cell + 1, cell - 2, cell - 2);
        for (const [x, y] of piece.cells) if (piece.y + y >= 0) block(piece.c, piece.x + x, piece.y + y, cell);
      }
      const nc = Math.round(cell * 0.8);
      nctx.clearRect(0, 0, 4 * nc, 3 * nc);
      if (next) { const p = PIECES[next]; const ox = next === 'I' || next === 'O' ? 0 : 0.5, oy = next === 'I' ? 0 : 0.5; for (const [x, y] of p.m) block(p.c, x + ox, y + oy, nc, nctx); }
    }
    const key = (e) => {
      if (over) return false;
      if (e.key === 'p' || e.key === 'P') { if (started) { paused = !paused; msg.hidden = !paused; msg.textContent = 'En pausa · P para seguir'; } return true; }
      if (paused) return false;
      switch (e.key) {
        case 'ArrowLeft': start(); moveX(-1); return true;
        case 'ArrowRight': start(); moveX(1); return true;
        case 'ArrowUp': case 'x': case 'X': start(); rotate(); return true;
        case 'ArrowDown': start(); if (drop()) { score += 1; status(); } return true;
        case ' ': if (!started) { start(); return true; } hardDrop(); return true;
      }
      return false;
    };
    let lastSz = '', rf = 0;
    const ro = new ResizeObserver(() => { const k = root.clientWidth + 'x' + root.clientHeight; if (k === lastSz) return; lastSz = k; cancelAnimationFrame(rf); rf = requestAnimationFrame(fit); }); ro.observe(root);
    requestAnimationFrame(() => { newGame(); fit(); });
    return { el: root, tools: [btn('Nueva', newGame)], key, setSkin: () => draw(), help: 'Completá líneas para borrarlas. Flechas para mover y girar, espacio para tirar la pieza de golpe.', hide: () => { if (started && !over) { paused = true; msg.hidden = false; msg.textContent = 'En pausa · P para seguir'; } } };
  }

  // ---------- catálogo ----------
  window.BaseMini.GAMES.push(
    { id: 'memotest', n: 'Memotest', d: 'Encontrá los pares dando vuelta las cartas.', c: '#d35400', create: memotest, skinLabel: 'Cartas',
      skins: [['frutas', 'Frutas', '#ff8a3d'], ['animales', 'Animales', '#2fb5a8'], ['deportes', 'Deportes', '#3d7bf7'], ['comida', 'Comida', '#e64980'], ['viajes', 'Viajes', '#7bc96f']],
      art: '<svg viewBox="0 0 64 64"><rect x="8" y="14" width="22" height="30" rx="4" fill="#ff8a3d"/><rect x="12" y="18" width="14" height="22" rx="2" fill="none" stroke="#fff" stroke-width="1.6" stroke-dasharray="3 2"/><rect x="34" y="20" width="22" height="30" rx="4" fill="#fff"/><text x="45" y="41" font-size="15" text-anchor="middle">🍓</text></svg>',
      best: (s) => s.wins ? `${s.wins} ganadas${s.best_facil ? ` · fácil ${fmtTime(s.best_facil)}` : ''}` : 'Nunca jugaste' },
    { id: 'viborita', n: 'Viborita', d: 'Comé manzanas, crecé y no choques.', c: '#1e8449', create: viborita, skinLabel: 'Víbora',
      skins: [['verde', 'Verde', '#3ecf6a'], ['azul', 'Azul', '#3d9bff'], ['fuego', 'Fuego', '#ff8a1f'], ['arcoiris', 'Arcoíris', '#c86bff'], ['cebra', 'Cebra', '#888']],
      art: '<svg viewBox="0 0 64 64"><rect x="8" y="8" width="48" height="48" rx="8" fill="#203024"/><path d="M16 44h12V28h16v-8" fill="none" stroke="#3ecf6a" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/><circle cx="42" cy="20" r="1.6" fill="#fff"/><circle cx="46" cy="20" r="1.6" fill="#fff"/><circle cx="44" cy="44" r="5" fill="#ff4d5e"/></svg>',
      best: (s) => s.best_normal || s.best_lenta || s.best_rapida ? `Mejor: ${Math.max(s.best_normal || 0, s.best_lenta || 0, s.best_rapida || 0)} puntos` : 'Nunca jugaste' },
    { id: 'tateti', n: 'Ta-te-ti', d: 'Contra la compu (tres niveles) o de a dos.', c: '#2e86de', create: tateti, skinLabel: 'Fichas',
      skins: [['clasico', 'X y O', '#4dabf7'], ['frutas', 'Frutilla y limón', '#ff6b6b'], ['animales', 'Perro y gato', '#f5b52e'], ['corazones', 'Corazones', '#e64980'], ['futbol', 'Pelotas', '#7bc96f']],
      art: '<svg viewBox="0 0 64 64"><path d="M26 10v44M38 10v44M10 26h44M10 38h44" stroke="#fff" stroke-width="3" stroke-linecap="round"/><path d="M13 13l9 9M22 13l-9 9" stroke="#ff6b6b" stroke-width="3.4" stroke-linecap="round"/><circle cx="32" cy="32" r="4.6" fill="none" stroke="#4dabf7" stroke-width="3.2"/><path d="M41 41l9 9M50 41l-9 9" stroke="#ff6b6b" stroke-width="3.4" stroke-linecap="round"/></svg>',
      best: (s) => { const r = s.sc && s.sc.imposible; return r && (r.yo + r.otro + r.emp) ? `Imposible: ${r.emp} empates, ${r.otro} perdidas` : (s.sc ? 'Jugaste' : 'Nunca jugaste'); } },
    { id: 'palabra', n: 'Adiviná la palabra', d: 'Una palabra de 5 letras por día, en 6 intentos.', c: '#6aaa64', create: palabra, skinLabel: 'Colores',
      skins: [['clasico', 'Clásico', '#6aaa64'], ['contraste', 'Alto contraste', '#f5793a']],
      art: '<svg viewBox="0 0 64 64"><g font-size="11" font-weight="800" text-anchor="middle" fill="#fff"><rect x="6" y="22" width="10" height="12" rx="2" fill="#6aaa64"/><text x="11" y="32">M</text><rect x="17.5" y="22" width="10" height="12" rx="2" fill="#c9b458"/><text x="22.5" y="32">A</text><rect x="29" y="22" width="10" height="12" rx="2" fill="#787c7e"/><text x="34" y="32">T</text><rect x="40.5" y="22" width="10" height="12" rx="2" fill="#6aaa64"/><text x="45.5" y="32">E</text><rect x="52" y="22" width="10" height="12" rx="2" fill="#787c7e"/><text x="57" y="32">S</text></g></svg>',
      best: (s) => s.games ? `${s.wins}/${s.games} ganadas · racha ${s.racha || 0}` : 'Nunca jugaste' },
    { id: 'bloques', n: 'Bloques', d: 'Encajá las piezas que caen y completá líneas.', c: '#8854d0', create: bloques, skinLabel: 'Colores',
      skins: [['clasico', 'Clásico', '#a55eea'], ['pastel', 'Pastel', '#d6b8f5'], ['neon', 'Neón', '#39ff14'], ['gris', 'Grises', '#9aa1ab']],
      art: '<svg viewBox="0 0 64 64"><g><rect x="10" y="40" width="10" height="10" rx="1.5" fill="#3d7bf7"/><rect x="20" y="40" width="10" height="10" rx="1.5" fill="#3d7bf7"/><rect x="30" y="40" width="10" height="10" rx="1.5" fill="#4cd964"/><rect x="40" y="40" width="10" height="10" rx="1.5" fill="#f7d038"/><rect x="40" y="30" width="10" height="10" rx="1.5" fill="#f7d038"/><rect x="10" y="30" width="10" height="10" rx="1.5" fill="#3d7bf7"/><rect x="22" y="10" width="10" height="10" rx="1.5" fill="#a55eea"/><rect x="32" y="10" width="10" height="10" rx="1.5" fill="#a55eea"/><rect x="42" y="10" width="10" height="10" rx="1.5" fill="#a55eea"/><rect x="32" y="20" width="10" height="10" rx="1.5" fill="#a55eea"/></g></svg>',
      best: (s) => s.best ? `Mejor: ${s.best} puntos` : 'Nunca jugaste' }
  );
})();
