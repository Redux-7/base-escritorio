// Panel para la tablet: un servidor chiquito en la red de casa. La tablet abre una página
// y desde ahí maneja Base (accesos, música, volumen, luces, súper, apagar la compu…).
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const STATIC = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/tablet.js': ['tablet.js', 'text/javascript; charset=utf-8'],
  '/tablet.css': ['tablet.css', 'text/css; charset=utf-8'],
  '/manifest.webmanifest': ['manifest.webmanifest', 'application/manifest+json'],
  '/icono.png': ['icono.png', 'image/png']
};

let D = null; // dependencias que pasa main.js
const P = { srv: null, port: 0, token: '', clients: new Map(), media: null, mediaAt: 0, vol: null, volAt: 0, thumbs: new Map() };

function tokenFile() { return path.join(D.userDir(), 'tablet.json'); }
function loadToken() {
  try { const j = JSON.parse(fs.readFileSync(tokenFile(), 'utf8')); if (j && /^[0-9a-f]{32}$/.test(j.token)) return j.token; } catch {}
  return resetToken();
}
function resetToken() {
  const t = crypto.randomBytes(16).toString('hex');
  try { fs.mkdirSync(D.userDir(), { recursive: true }); fs.writeFileSync(tokenFile(), JSON.stringify({ token: t }), 'utf8'); } catch {}
  P.token = t; P.clients.clear();
  return t;
}
function lanIps() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal) continue;
      const ip = a.address;
      const priv = /^192\.168\./.test(ip) || /^10\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip);
      if (!priv) continue;
      const virt = /vEthernet|VirtualBox|VMware|Hyper-V|WSL|Loopback|Bluetooth|ZeroTier|Tailscale|Hamachi/i.test(name);
      out.push({ ip, name, score: (virt ? 0 : 10) + (/^192\.168\./.test(ip) ? 3 : 0) + (/wi-?fi|wlan|ethernet/i.test(name) ? 2 : 0) });
    }
  }
  return out.sort((a, b) => b.score - a.score);
}
function url() { const ip = (lanIps()[0] || {}).ip || '127.0.0.1'; return `http://${ip}:${P.port}/?k=${P.token}`; }
function qr(text) {
  const QRCode = require('./vendor/QRCode');
  const L = require('./vendor/QRCode/QRErrorCorrectLevel');
  const q = new QRCode(-1, L.M); q.addData(text); q.make();
  const n = q.getModuleCount(), rows = [];
  for (let r = 0; r < n; r++) { let s = ''; for (let c = 0; c < n; c++) s += q.isDark(r, c) ? '1' : '0'; rows.push(s); }
  return rows;
}

function send(res, code, body, type) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
  res.writeHead(code, { 'Content-Type': type || 'application/json; charset=utf-8', 'Content-Length': buf.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(buf);
}
function authed(req, u) {
  const k = String(req.headers['x-base-key'] || u.searchParams.get('k') || '');
  if (k.length !== P.token.length) return false;
  return crypto.timingSafeEqual(Buffer.from(k), Buffer.from(P.token));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const parts = [];
    req.on('data', (c) => { size += c.length; if (size > 256 * 1024) { reject(new Error('Muy grande')); req.destroy(); } else parts.push(c); });
    req.on('end', () => { try { resolve(parts.length ? JSON.parse(Buffer.concat(parts).toString('utf8')) : {}); } catch { reject(new Error('JSON inválido')); } });
    req.on('error', reject);
  });
}
async function media() {
  if (Date.now() - P.mediaAt < 700 && P.media) return P.media;
  P.mediaAt = Date.now();
  const r = await D.helper.send('smtc');
  P.media = r.ok && Array.isArray(r.data) ? r.data : (r.ok && r.data ? [r.data] : []);
  return P.media;
}
async function vol() {
  if (Date.now() - P.volAt < 700 && P.vol) return P.vol;
  P.volAt = Date.now();
  const r = await D.helper.send('vol');
  P.vol = r.ok && r.data ? r.data : null;
  return P.vol;
}
const okApp = (a) => typeof a === 'string' && a.length < 300 && !/[|\r\n]/.test(a);

async function act(b) {
  const a = String(b.a || '');
  switch (a) {
    case 'show': D.show(); return { ok: true };
    case 'media': {
      if (!okApp(b.app) || !['toggle', 'next', 'prev', 'seek'].includes(b.act)) return { ok: false };
      const v = b.act === 'seek' ? Math.max(0, Math.min(86400, Number(b.v) || 0)).toFixed(1) : '';
      const r = await D.helper.send('smtcdo', `${b.app}|${b.act}|${v}`); P.mediaAt = 0;
      return { ok: !!(r.ok && r.data) };
    }
    case 'mediakey': if (!['play', 'next', 'prev'].includes(b.k)) return { ok: false }; return D.helper.send('media', b.k);
    case 'vol': { const r = await D.helper.send('volset', String(Math.max(0, Math.min(100, Math.round(Number(b.v) || 0))))); P.volAt = 0; return { ok: r.ok, vol: r.data }; }
    case 'mute': { const r = await D.helper.send('volmute', b.on ? '1' : '0'); P.volAt = 0; return { ok: r.ok, vol: r.data }; }
    case 'sys': {
      if (!['lock', 'sleep', 'shutdown', 'restart', 'minimizeAll', 'taskview', 'explorer', 'start'].includes(b.name)) return { ok: false };
      return D.sysAction(b.name);
    }
    case 'keys': {
      const allowed = { captura: 'win+shift+s', escritorio: 'win+d', emojis: 'win+.' };
      if (!allowed[b.k]) return { ok: false };
      return D.helper.send('keys', allowed[b.k]);
    }
    case 'wins': {
      const r = await D.helper.send('list', D.selfHandle());
      if (!r.ok) return { ok: false };
      const list = [];
      for (const w of r.data || []) list.push({ h: w.h, t: w.t, app: w.exe ? path.basename(w.exe).replace(/\.exe$/i, '') : '', min: !!w.min, icon: w.exe ? await D.iconOf(w.exe) : null });
      return { ok: true, list };
    }
    case 'win': {
      if (!/^\d{1,20}$/.test(String(b.h)) || !['focus', 'minimize', 'close'].includes(b.do)) return { ok: false };
      await D.helper.send(b.do, String(b.h)); return { ok: true };
    }
    case 'lamp': {
      const l = D.lamps().find(x => x.id === b.id);
      if (!l) return { ok: false, error: 'No encuentro esa luz' };
      try {
        const cfg = { id: l.id, key: l.key, ip: l.ip, ver: l.ver, schema: l.schema };
        const st = b.status ? await D.tuya.lampStatus(cfg) : await D.tuya.lampAction(cfg, b.do || {});
        D.toRenderer({ a: 'lampState', id: l.id, st });
        return { ok: true, st };
      } catch (e) { return { ok: false, error: e.message }; }
    }
    // lo que vive en la pantalla de Base (tableros, accesos, súper, diseño del panel…)
    case 'open': case 'board': case 'dnd': case 'theme': case 'super': case 'layout':
      return D.askRenderer(Object.assign({}, b, { a }));
    default: return { ok: false, error: 'Acción desconocida' };
  }
}

async function handle(req, res) {
  let u; try { u = new URL(req.url, 'http://x'); } catch { return send(res, 400, { ok: false }); }
  const st = STATIC[u.pathname];
  if (st && req.method === 'GET') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'tablet', st[0])), st[1]); } catch { return send(res, 404, 'No encontrado', 'text/plain'); }
  }
  if (!u.pathname.startsWith('/api/')) return send(res, 404, 'No encontrado', 'text/plain; charset=utf-8');
  if (!authed(req, u)) return send(res, 401, { ok: false, error: 'Esta tablet no está vinculada. Escaneá de nuevo el código de Base.' });
  const ip = req.socket.remoteAddress || '';
  P.clients.set(ip.replace(/^::ffff:/, ''), { at: Date.now(), ua: String(req.headers['user-agent'] || '').slice(0, 160) });
  try {
    if (u.pathname === '/api/state' && req.method === 'GET') {
      const [m, v] = await Promise.all([media(), vol()]);
      return send(res, 200, { ok: true, snap: D.snap() || null, media: m, vol: v, now: Date.now() });
    }
    if (u.pathname === '/api/thumb' && req.method === 'GET') {
      const app = u.searchParams.get('app') || '';
      if (!okApp(app)) return send(res, 400, { ok: false });
      const key = app + '|' + (u.searchParams.get('v') || '');
      let img = P.thumbs.get(key);
      if (img === null) return send(res, 404, { ok: false });
      if (!img) {
        const r = await D.helper.send('smtcthumb', app);
        if (!r.ok || !r.data || !r.data.data) { P.thumbs.set(key, null); return send(res, 404, { ok: false }); }
        img = { type: /^image\/[\w.+-]+$/.test(r.data.type) ? r.data.type : 'image/png', buf: Buffer.from(r.data.data, 'base64') };
        P.thumbs.set(key, img); if (P.thumbs.size > 20) P.thumbs.delete(P.thumbs.keys().next().value);
      }
      res.writeHead(200, { 'Content-Type': img.type, 'Content-Length': img.buf.length, 'Cache-Control': 'private, max-age=3600' });
      return res.end(img.buf);
    }
    if (u.pathname === '/api/do' && req.method === 'POST') {
      const b = await readBody(req);
      return send(res, 200, (await act(b)) || { ok: true });
    }
  } catch (e) {
    D.log('Panel tablet: ' + e.message);
    return send(res, 500, { ok: false, error: e.message });
  }
  return send(res, 404, { ok: false });
}

function start(port) {
  port = Number(port) || 8766;
  if (P.srv && P.port === port) return Promise.resolve(true);
  stop();
  if (!P.token) P.token = loadToken();
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => { handle(req, res).catch(() => { try { send(res, 500, { ok: false }); } catch {} }); });
    srv.on('error', (e) => { D.log('Panel tablet: no pude abrir el puerto ' + port + ' (' + e.code + ')'); P.srv = null; P.err = e.code === 'EADDRINUSE' ? 'El puerto ' + port + ' lo está usando otro programa' : e.message; resolve(false); });
    srv.listen(port, '0.0.0.0', () => { P.srv = srv; P.port = port; P.err = ''; D.log('Panel tablet escuchando en ' + url().replace(/k=.*/, 'k=…')); resolve(true); });
  });
}
function stop() { if (P.srv) { try { P.srv.close(); } catch {} P.srv = null; } }
function info() {
  if (!P.token && D) P.token = loadToken();
  const on = !!P.srv;
  const u = on ? url() : '';
  const clients = [...P.clients.entries()].map(([ip, c]) => ({ ip, at: c.at, ua: c.ua })).sort((a, b) => b.at - a.at);
  return { on, url: u, qr: on ? qr(u) : null, ips: lanIps().map(x => x.ip), port: P.port, error: P.err || '', clients };
}
function init(deps) { D = deps; }

module.exports = { init, start, stop, info, resetToken: () => { resetToken(); return info(); } };
