// Panel de Base para la tablet
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const ICO = {
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  windows: '<rect x="3" y="7" width="13" height="12" rx="2"/><path d="M8 7V5h13v12h-5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  power: '<path d="M12 3v9M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  prev: '<path d="M7 5v14M19 5L9 12l10 7z"/>', next: '<path d="M17 5v14M5 5l10 7-10 7z"/>',
  play: '<path d="M7 4.5v15l13-7.5z"/>', pause: '<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/>',
  mute: '<path d="M4 9h4l5-4v14l-5-4H4zM17 9l5 5M22 9l-5 5"/>', vol: '<path d="M4 9h4l5-4v14l-5-4H4zM16.5 8.5a5 5 0 0 1 0 7M19.5 5.5a9 9 0 0 1 0 13"/>',
  shot: '<rect x="3" y="6" width="18" height="13" rx="2"/><circle cx="12" cy="12.5" r="3.2"/><path d="M8 6l1.5-2h5L16 6"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15zM10 20a2 2 0 0 0 4 0"/><path d="M3 3l18 18"/>',
  grid4: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>', drag: '<circle cx="9" cy="6" r="1.3"/><circle cx="15" cy="6" r="1.3"/><circle cx="9" cy="12" r="1.3"/><circle cx="15" cy="12" r="1.3"/><circle cx="9" cy="18" r="1.3"/><circle cx="15" cy="18" r="1.3"/>',
  wide: '<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>', tall: '<path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4"/>',
  cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/><path d="M3 4h2l2.5 11h11l2-8H7"/>',
  bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', restart: '<path d="M4 12a8 8 0 1 0 2.5-5.8M4 4v5h5"/>', full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  desk: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M7 21h10"/>', music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.3-1.3M17.7 6.3l1.4-1.4"/>'
};
const svg = (k, cls) => `<svg viewBox="0 0 24 24" class="${cls || ''}" aria-hidden="true">${ICO[k] || ''}</svg>`;
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const h = (tag, attrs, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'html') e.innerHTML = v; else if (k === 'text') e.textContent = v; else if (k.startsWith('on')) e[k] = v; else e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) e.append(k);
  return e;
};

// ---------- clave de vinculación ----------
let KEY = '';
try { KEY = localStorage.getItem('base-k') || ''; } catch {}
const qk = new URLSearchParams(location.search).get('k');
if (qk && /^[0-9a-f]{32}$/.test(qk)) { KEY = qk; try { localStorage.setItem('base-k', qk); } catch {} history.replaceState(null, '', location.pathname); }

async function api(path, body) {
  const r = await fetch('/api/' + path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Base-Key': KEY }, body: JSON.stringify(body) } : { headers: { 'X-Base-Key': KEY }, cache: 'no-store' });
  if (r.status === 401) { showPair(); throw new Error('sin vincular'); }
  return r.json();
}
const doIt = (b) => api('do', b).catch(e => ({ ok: false, error: e.message }));

// ---------- estado ----------
const T = { snap: null, media: [], vol: null, edit: false, layout: null, structKey: '', upd: [], dragging: 0, failed: 0, now: 0, skew: 0 };
const DEFAULT = () => ({ v: 2, blocks: [
  { id: 'b1', t: 'accesos', w: 2, h: 4 }, { id: 'b2', t: 'musica', w: 2, h: 3 },
  { id: 'b3', t: 'luz', w: 2, h: 3 }, { id: 'b4', t: 'atajos', w: 2, h: 2 }
], accent: '', scale: 'm' });
const layout = () => T.layout || (T.snap && T.snap.panel && Array.isArray(T.snap.panel.blocks) && T.snap.panel.v === 2 ? T.snap.panel : DEFAULT());
let saveT = null;
function saveLayout() {
  clearTimeout(saveT);
  saveT = setTimeout(() => { doIt({ a: 'layout', panel: T.layout }); }, 400);
}
function editLayout(fn) {
  T.layout = JSON.parse(JSON.stringify(layout()));
  fn(T.layout);
  saveLayout();
  render(true);
}

function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 2600); }
function showPair() { $('#pair').hidden = false; $('#app').hidden = true; }

async function poll() {
  if (!KEY) return showPair();
  if (document.hidden) return;
  try {
    const r = await api('state');
    if (!r || !r.ok) throw new Error('mal');
    T.failed = 0; $('#offline').hidden = true;
    T.skew = r.now - Date.now();
    T.snap = r.snap; T.media = r.media || []; T.vol = r.vol;
    if (T.snap && T.snap.panel && !T.edit && !saveT) T.layout = null;
    render(false);
  } catch (e) {
    if (e.message === 'sin vincular') return;
    if (++T.failed >= 2) $('#offline').hidden = false;
  }
}

// ---------- dibujo ----------
function structKey() {
  const s = T.snap || {};
  return JSON.stringify([layout(), s.items, s.boards, s.board, (s.lamps || []).map(l => l.id + l.n), s.super, s.scenes, s.wx, s.name, s.dnd, s.dark, T.edit, innerWidth > innerHeight]);
}
function render(force) {
  const s = T.snap;
  $('#app').hidden = false; $('#pair').hidden = true;
  const L = layout();
  document.documentElement.style.setProperty('--ac', L.accent || (s && s.accent) || '#8b5cf6');
  document.documentElement.dataset.scale = L.scale || 'm';
  document.body.classList.toggle('editing', T.edit);
  const k = structKey();
  if (force || k !== T.structKey) {
    T.structKey = k;
    T.upd = [];
    renderTop(); renderGrid(); renderTray(); renderBar();
  }
  for (const f of T.upd) { try { f(); } catch (e) { console.error(e); } }
}
const DOW = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MON = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
function tickClock() {
  const d = new Date();
  $('#hh').textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  const ds = DOW[d.getDay()]; $('#date').textContent = ds[0].toUpperCase() + ds.slice(1) + ' ' + d.getDate() + ' de ' + MON[d.getMonth()];
  const hr = d.getHours(), n = T.snap && T.snap.name;
  $('#greet').textContent = (hr < 6 ? 'Buenas noches' : hr < 13 ? 'Buen día' : hr < 20 ? 'Buenas tardes' : 'Buenas noches') + (n ? ', ' + n : '');
}
function renderTop() {
  const s = T.snap || {};
  tickClock();
  const nav = $('#boards'); nav.replaceChildren();
  for (const b of s.boards || []) {
    nav.append(h('button', { class: 'chip' + (b.id === s.board ? ' on' : ''), text: b.n, onclick: async () => { s.board = b.id; render(true); await doIt({ a: 'board', id: b.id }); setTimeout(poll, 300); } }));
  }
  const wx = s.wx;
  $('#wx').innerHTML = wx ? `<svg viewBox="0 0 24 24" aria-hidden="true">${wx.ic}</svg><b>${wx.t}°</b><span>${esc(wx.d)}<br>${wx.min}° / ${wx.max}°</span>` : '';
  const eb = $('#edit-btn');
  eb.innerHTML = svg(T.edit ? 'check' : 'edit') + `<span>${T.edit ? 'Listo' : 'Personalizar'}</span>`;
  eb.classList.toggle('on', T.edit);
}
$('#edit-btn').onclick = () => { T.edit = !T.edit; if (T.edit) T.layout = JSON.parse(JSON.stringify(layout())); render(true); };

function blockShell(b, title, body, extraCls) {
  const L = layout();
  const portrait = innerWidth < innerHeight;
  const w = Math.min(b.w || 2, portrait ? 2 : 4), hh = Math.max(1, Math.min(6, b.h || 2));
  const el = h('section', { class: 'blk t-' + b.t + (extraCls ? ' ' + extraCls : ''), 'data-id': b.id, style: `grid-column: span ${w}; grid-row: span ${hh}` });
  if (title) el.append(h('div', { class: 'blk-h', text: title }));
  el.append(body);
  if (T.edit) {
    const tools = h('div', { class: 'blk-tools' },
      h('button', { class: 'tl drag', html: svg('drag'), 'aria-label': 'Arrastrar', onpointerdown: (e) => startDrag(e, b.id) }),
      h('button', { class: 'tl', html: svg('wide'), title: 'Ancho', onclick: () => editLayout(l => { const x = l.blocks.find(y => y.id === b.id); x.w = (x.w || 2) % 4 + 1; }) }),
      h('button', { class: 'tl', html: svg('tall'), title: 'Alto', onclick: () => editLayout(l => { const x = l.blocks.find(y => y.id === b.id); const HS = [2, 3, 4, 6]; x.h = HS[(HS.indexOf(x.h) + 1) % HS.length]; }) }),
      h('button', { class: 'tl del', html: svg('x'), title: 'Quitar', onclick: () => editLayout(l => { l.blocks = l.blocks.filter(y => y.id !== b.id); }) }));
    el.append(tools);
  }
  return el;
}
function renderGrid() {
  const g = $('#grid'); g.replaceChildren();
  const L = layout();
  for (const b of L.blocks) {
    const f = BLOCKS[b.t];
    if (!f) continue;
    try { g.append(f(b)); } catch (e) { console.error(e); }
  }
  if (!L.blocks.length) g.append(h('div', { class: 'empty', text: T.edit ? 'Sumá bloques desde abajo' : 'Tocá Personalizar para armar tu panel' }));
}

// ----- bloques -----
function iconEl(it) {
  const box = h('span', { class: 'aic' });
  const letter = () => { box.replaceChildren(h('span', { class: 'let', text: it.l || '?' })); };
  if (it.ic) { const img = h('img', { src: it.ic, alt: '', draggable: 'false' }); img.onerror = letter; img.onload = () => { if (img.naturalWidth < 8) letter(); }; box.append(img); } else letter();
  return box;
}
const BLOCKS = {
  accesos(b) {
    const s = T.snap || {}; const hide = new Set(b.hide || []);
    const grid = h('div', { class: 'apps' });
    const add = (it, inGroup) => {
      if (hide.has(it.id)) return;
      const btn = h('button', { class: 'app', onclick: () => { if (T.edit) return; if (it.g) return openGroup(it); tap(btn); doIt({ a: 'open', id: it.id }).then(r => { if (r && r.ok === false) toast(r.error || 'No se pudo abrir'); else toast('Abriendo ' + it.n); }); } },
        it.g ? h('span', { class: 'aic grp' }, ...it.g.slice(0, 4).map(x => iconEl(x))) : iconEl(it), h('span', { class: 'an', text: it.n }));
      if (T.edit) btn.append(h('i', { class: 'rm', html: svg('x'), onclick: (e) => { e.stopPropagation(); editLayout(l => { const x = l.blocks.find(y => y.id === b.id); x.hide = [...(x.hide || []), it.id]; }); } }));
      grid.append(btn);
    };
    for (const it of s.items || []) add(it);
    if (!grid.children.length) grid.append(h('p', { class: 'muted', text: 'Este tablero no tiene accesos.' }));
    if (T.edit && hide.size) grid.append(h('button', { class: 'app ghost', onclick: () => editLayout(l => { delete l.blocks.find(y => y.id === b.id).hide; }) }, h('span', { class: 'aic', html: svg('restart') }), h('span', { class: 'an', text: 'Mostrar todos' })));
    return blockShell(b, 'Accesos', grid);
  },
  atajos(b) {
    const s = T.snap || {};
    const list = [
      ['shot', 'Captura', () => doIt({ a: 'keys', k: 'captura' })],
      ['bell', s.dnd ? 'Avisos: no' : 'No molestar', async () => { const r = await doIt({ a: 'dnd' }); toast(r && r.on ? 'No molestar activado' : 'Avisos activados'); poll(); }, s.dnd],
      ['moon', s.dark ? 'Modo claro' : 'Modo oscuro', async () => { await doIt({ a: 'theme' }); setTimeout(poll, 300); }],
      ['grid4', 'Minimizar todo', () => doIt({ a: 'sys', name: 'minimizeAll' })]
    ];
    return blockShell(b, 'Atajos rápidos', h('div', { class: 'quick' }, ...list.map(([ic, n, fn, on]) => { const x = h('button', { class: 'qb' + (on ? ' on' : ''), html: svg(ic) + `<span>${esc(n)}</span>`, onclick: () => { if (!T.edit) { tap(x); fn(); } } }); return x; })));
  },
  musica(b) {
    const artImg = h('img', { alt: '' }); artImg.onerror = () => { artImg.hidden = true; }; artImg.onload = () => { artImg.hidden = false; };
    const art = h('div', { class: 'art', html: svg('music') }); art.append(artImg);
    const src = h('div', { class: 'msrc' }), tt = h('div', { class: 'mtt' }), ar = h('div', { class: 'mar' });
    const prog = h('div', { class: 'prog' }, h('i')), t1 = h('span'), t2 = h('span');
    const bPrev = h('button', { class: 'mb', html: svg('prev') }), bPlay = h('button', { class: 'mb big' }), bNext = h('button', { class: 'mb', html: svg('next') });
    const cur = () => { const m = T.media || []; return m.find(x => x.cur) || m.find(x => x.status === 'Playing') || m[0] || null; };
    const go = (act) => { const c = cur(); if (c) doIt({ a: 'media', app: c.app, act }).then(() => setTimeout(poll, 250)); else doIt({ a: 'mediakey', k: act === 'toggle' ? 'play' : act }); };
    bPrev.onclick = () => go('prev'); bNext.onclick = () => go('next'); bPlay.onclick = () => { const c = cur(); if (c) c.status = c.status === 'Playing' ? 'Paused' : 'Playing'; upd(); go('toggle'); };
    const vol = volume();
    let lastArt = '';
    const upd = () => {
      const c = cur();
      const name = c ? (/spotify/i.test(c.app) ? 'Spotify' : /chrome/i.test(c.app) ? 'Chrome' : /opera/i.test(c.app) ? 'Opera' : /edge/i.test(c.app) ? 'Edge' : /firefox/i.test(c.app) ? 'Firefox' : (c.app.split(/[!.\\]/).filter(Boolean).pop() || '')) : '';
      src.textContent = c ? name : 'Nada sonando';
      tt.textContent = c ? (c.title || 'Sin título') : 'Poné música en la compu';
      ar.textContent = c ? [c.artist, c.album].filter(Boolean).join(' · ') : '';
      bPlay.innerHTML = svg(c && c.status === 'Playing' ? 'pause' : 'play');
      const key = c ? c.app + '|' + c.title : '';
      if (key !== lastArt) { lastArt = key; artImg.hidden = true; if (c && c.title) artImg.src = `/api/thumb?app=${encodeURIComponent(c.app)}&v=${encodeURIComponent(c.title)}&k=${KEY}`; }
      if (c && c.end > 0) {
        let pos = c.pos; if (c.status === 'Playing' && c.upd) pos += (Date.now() + T.skew - c.upd) / 1000;
        pos = Math.max(0, Math.min(c.end, pos));
        prog.firstChild.style.width = (pos / c.end * 100).toFixed(1) + '%';
        t1.textContent = fmtT(pos); t2.textContent = fmtT(c.end); prog.hidden = false;
      } else { prog.hidden = true; t1.textContent = ''; t2.textContent = ''; }
    };
    T.upd.push(upd);
    return blockShell(b, 'Sonando en la compu', h('div', { class: 'music' },
      h('div', { class: 'mtop' }, art, h('div', { class: 'minfo' }, src, tt, ar, prog, h('div', { class: 'times' }, t1, t2))),
      h('div', { class: 'mctl' }, bPrev, bPlay, bNext), vol));
  },
  volumen(b) { return blockShell(b, 'Volumen', volume()); },
  luz(b) {
    const s = T.snap || {};
    const lamps = s.lamps || [];
    const l = lamps.find(x => x.id === b.lamp) || lamps[0];
    if (!l) return blockShell(b, 'Luces', h('p', { class: 'muted', text: 'Sumá tus lamparitas desde Base en la compu (tarjeta Luces).' }));
    const orb = h('button', { class: 'orb' }), nm = h('b'), sw = h('button', { class: 'tog' });
    const br = range(1, (v, fin) => lampDo(l, { bright: v }, fin));
    const cols = h('div', { class: 'cols' });
    const COLS = [['#ffffff', { temp: 50 }], ['#ffd29a', { temp: 0 }], ['#ff4d4d'], ['#ff9a2e'], ['#4fd36b'], ['#3d9bff'], ['#a77bff'], ['#ff5fc1']];
    for (const [c, ex] of COLS) cols.append(h('button', { class: 'col', style: `--c:${c}`, 'data-c': c, onclick: () => lampDo(l, ex || { color: c }, true) }));
    const pick = h('input', { type: 'color', value: '#a77bff' }); pick.onchange = () => lampDo(l, { color: pick.value }, true);
    cols.append(h('label', { class: 'col rainbow' }, pick));
    const scenes = h('div', { class: 'scenes' }, ...(s.scenes || []).slice(0, 4).map(sc => h('button', { class: 'scn', style: `--c:${sc.color}`, html: `<i></i>${esc(sc.n)}`, onclick: () => lampDo(l, { scene: sc.id }, true) })));
    orb.onclick = () => lampDo(l, { toggle: true }, true); sw.onclick = orb.onclick;
    const upd = () => {
      const st = (T.snap.lamps.find(x => x.id === l.id) || {}).st;
      const on = st && st.on;
      orb.classList.toggle('off', !on); sw.classList.toggle('on', !!on);
      orb.style.setProperty('--c', lampColor(st));
      nm.textContent = st ? (on ? colorName(st) + ' · ' + st.bright + '%' : 'Apagada') : 'Conectando…';
      if (st && !br.busy) br.set(st.bright);
      br.input.style.setProperty('--c', st && st.mode === 'colour' ? st.color : '#ffd9a0');
      for (const c of cols.querySelectorAll('.col[data-c]')) c.classList.toggle('on', !!(on && st.mode === 'colour' && c.dataset.c === nearest(st.color)));
    };
    if (!l.st) doIt({ a: 'lamp', id: l.id, status: true }).then(r => { if (r && r.ok) { l.st = r.st; upd(); } });
    T.upd.push(upd);
    const title = lamps.length > 1 ? 'Luz: ' + l.n : 'Luz del ' + l.n.toLowerCase();
    const head = h('div', { class: 'lhead' }, orb, h('div', { class: 'lmain' }, nm, br.wrap), sw);
    return blockShell(b, lamps.length > 1 || !/^[a-záéíóú]/i.test(l.n) ? l.n : title, h('div', { class: 'lamp' }, head, cols, scenes));
  },
  super(b) {
    const s = T.snap || {};
    const inp = h('input', { placeholder: 'Agregar… (ej. 2 leche)', enterkeyhint: 'done' });
    const addIt = async () => { const v = inp.value.trim(); if (!v) return; inp.value = ''; await doIt({ a: 'super', add: v }); poll(); };
    inp.onkeydown = (e) => { if (e.key === 'Enter') addIt(); };
    const list = h('div', { class: 'slist' }, ...(s.super || []).map(it => h('button', { class: 'sit', onclick: async (e) => { e.currentTarget.classList.add('done'); await doIt({ a: 'super', done: it.id }); setTimeout(poll, 300); } }, h('i'), h('span', { text: (it.q ? it.q + ' ' : '') + it.t }))));
    if (!(s.super || []).length) list.append(h('p', { class: 'muted', text: 'Nada para comprar' }));
    return blockShell(b, 'Supermercado', h('div', { class: 'super' }, h('div', { class: 'sadd' }, inp, h('button', { class: 'sbtn', html: svg('plus'), onclick: addIt })), list));
  },
  clima(b) {
    const w = (T.snap || {}).wx;
    return blockShell(b, w ? 'Clima en ' + w.city : 'Clima', w ? h('div', { class: 'clima', html: `<svg viewBox="0 0 24 24">${w.ic}</svg><div><b>${w.t}°</b><span>${esc(w.d)}</span><small>Mín ${w.min}° · Máx ${w.max}°</small></div>` }) : h('p', { class: 'muted', text: 'Sin datos' }));
  },
  boton(b) {
    const r = refInfo(b.ref);
    const btn = h('button', { class: 'bigbtn', onclick: () => { if (T.edit) return; tap(btn); r.run(); } }, r.icon, h('span', { text: r.n }));
    return blockShell(b, null, btn, 'solo');
  }
};
function refInfo(ref) {
  ref = String(ref || '');
  if (ref.startsWith('sc:')) {
    const id = ref.slice(3); let it = null;
    for (const x of (T.snap && T.snap.items) || []) { if (x.id === id) it = x; for (const y of x.g || []) if (y.id === id) it = y; }
    return { n: it ? it.n : 'Acceso', icon: it ? iconEl(it) : h('span', { class: 'aic', html: svg('folder') }), run: () => doIt({ a: 'open', id }).then(r2 => r2 && r2.ok === false && toast(r2.error || 'No se pudo abrir')) };
  }
  const A = ACTIONS.find(a => a.id === ref.slice(4)) || ACTIONS[0];
  return { n: A.n, icon: h('span', { class: 'aic sys', html: svg(A.ic) }), run: A.run };
}
const ACTIONS = [
  { id: 'show', n: 'Mostrar Base', ic: 'monitor', run: () => doIt({ a: 'show' }) },
  { id: 'files', n: 'Archivos', ic: 'folder', run: () => doIt({ a: 'sys', name: 'explorer' }) },
  { id: 'lock', n: 'Bloquear', ic: 'lock', run: () => doIt({ a: 'sys', name: 'lock' }) },
  { id: 'shot', n: 'Captura', ic: 'shot', run: () => doIt({ a: 'keys', k: 'captura' }) },
  { id: 'min', n: 'Minimizar todo', ic: 'grid4', run: () => doIt({ a: 'sys', name: 'minimizeAll' }) },
  { id: 'desk', n: 'Ver el escritorio', ic: 'desk', run: () => doIt({ a: 'keys', k: 'escritorio' }) },
  { id: 'play', n: 'Pausa / seguir', ic: 'play', run: () => doIt({ a: 'mediakey', k: 'play' }) }
];
function fmtT(s) { s = Math.floor(s); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function tap(el) { el.classList.add('tap'); setTimeout(() => el.classList.remove('tap'), 180); if (navigator.vibrate) try { navigator.vibrate(12); } catch {} }

// barra de volumen grande
function volume() {
  const muteB = h('button', { class: 'vb' }), upB = h('span', { class: 'vb ico', html: svg('vol') }), pct = h('b', { class: 'vpct' });
  const r = range(0, async (v, fin) => {
    T.vol = Object.assign({}, T.vol || {}, { level: v, muted: false }); pct.textContent = v + '%';
    if (fin || !r.lastSent || Date.now() - r.lastSent > 120) { r.lastSent = Date.now(); const x = await doIt({ a: 'vol', v }); if (x && x.vol && !r.busy) T.vol = x.vol; }
  });
  muteB.onclick = async () => { const m = !(T.vol && T.vol.muted); T.vol = Object.assign({}, T.vol || {}, { muted: m }); upd(); const x = await doIt({ a: 'mute', on: m }); if (x && x.vol) T.vol = x.vol; upd(); };
  const upd = () => {
    const v = T.vol; const lv = v ? Math.round(v.level != null ? v.level : v.vol != null ? v.vol : 0) : 0;
    muteB.innerHTML = svg(v && v.muted ? 'mute' : 'vol');
    muteB.classList.toggle('on', !!(v && v.muted));
    if (!r.busy) { r.set(lv); pct.textContent = (v ? lv : '--') + '%'; }
  };
  T.upd.push(upd);
  return h('div', { class: 'volume' }, muteB, r.wrap, pct);
}
// deslizador táctil grande (no usa el input nativo para que el dedo no "salte")
function range(min, onSet) {
  const fill = h('i'), knob = h('b');
  const input = h('div', { class: 'rng' }, fill, knob);
  const wrap = h('div', { class: 'rngw' }, input);
  const o = { wrap, input, busy: false, val: 0 };
  o.set = (v) => { o.val = Math.max(min, Math.min(100, Math.round(v))); const p = (o.val - min) / (100 - min) * 100; fill.style.width = p + '%'; knob.style.left = p + '%'; };
  const at = (e) => { const rc = input.getBoundingClientRect(); return min + Math.max(0, Math.min(1, (e.clientX - rc.left) / rc.width)) * (100 - min); };
  input.onpointerdown = (e) => {
    if (T.edit) return;
    o.busy = true; input.setPointerCapture(e.pointerId); input.classList.add('drag');
    o.set(at(e)); onSet(o.val, false);
    input.onpointermove = (ev) => { o.set(at(ev)); onSet(o.val, false); };
    input.onpointerup = input.onpointercancel = () => { input.onpointermove = null; input.classList.remove('drag'); onSet(o.val, true); setTimeout(() => { o.busy = false; }, 900); };
  };
  return o;
}
// luces
let lampT = null;
async function lampDo(l, a, fin) {
  const st = (T.snap.lamps.find(x => x.id === l.id) || {}).st;
  if (st) { if (a.toggle) st.on = !st.on; if (a.bright != null) st.bright = a.bright; if (a.color) { st.color = a.color; st.mode = 'colour'; st.on = true; } if (a.temp != null) { st.temp = a.temp; st.mode = 'white'; st.on = true; } }
  for (const f of T.upd) f();
  clearTimeout(lampT);
  const run = async () => { const r = await doIt({ a: 'lamp', id: l.id, do: a }); if (r && r.ok) { const x = T.snap.lamps.find(y => y.id === l.id); if (x) x.st = r.st; for (const f of T.upd) f(); } else toast((r && r.error) || 'La luz no respondió'); };
  if (fin) run(); else lampT = setTimeout(run, 200);
}
function lampColor(st) {
  if (!st || !st.on) return '#7d8590';
  if (st.mode === 'colour') return st.color;
  const t = st.temp / 100, m = (a, b) => Math.round(a + (b - a) * t);
  return `rgb(${m(255, 220)},${m(196, 236)},${m(120, 255)})`;
}
const NAMES = { '#ff4d4d': 'Rojo', '#ff9a2e': 'Naranja', '#4fd36b': 'Verde', '#3d9bff': 'Azul', '#a77bff': 'Violeta', '#ff5fc1': 'Rosa' };
function nearest(hex) {
  const n = parseInt(String(hex || '#ffffff').slice(1), 16), r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
  let best = '', bd = 1e9;
  for (const c of Object.keys(NAMES)) { const m = parseInt(c.slice(1), 16); const d = (r - (m >> 16 & 255)) ** 2 + (g - (m >> 8 & 255)) ** 2 + (b - (m & 255)) ** 2; if (d < bd) { bd = d; best = c; } }
  return best;
}
function colorName(st) { if (st.mode !== 'colour') return st.temp < 25 ? 'Blanco cálido' : st.temp > 70 ? 'Blanco frío' : 'Blanco'; return NAMES[nearest(st.color)] || 'Color'; }

// ----- hojas (ventanas, confirmar, elegir) -----
function sheet(title, ...kids) {
  const sh = $('#sheet'); sh.replaceChildren(h('h2', { text: title }), ...kids);
  $('#sheet-bg').hidden = false;
}
function closeSheet() { $('#sheet-bg').hidden = true; }
$('#sheet-bg').onclick = (e) => { if (e.target.id === 'sheet-bg') closeSheet(); };
function openGroup(g) {
  sheet(g.n, h('div', { class: 'apps sheet-apps' }, ...g.g.map(it => { const b = h('button', { class: 'app', onclick: () => { doIt({ a: 'open', id: it.id }).then(r => r && r.ok === false ? toast(r.error || 'No se pudo abrir') : toast('Abriendo ' + it.n)); closeSheet(); } }, iconEl(it), h('span', { class: 'an', text: it.n })); return b; })));
}
async function openWindows() {
  sheet('Ventanas abiertas', h('p', { class: 'muted', text: 'Cargando…' }));
  const r = await doIt({ a: 'wins' });
  if (!r || !r.ok) return sheet('Ventanas abiertas', h('p', { class: 'muted', text: 'No pude ver las ventanas.' }));
  const list = h('div', { class: 'wins' }, ...r.list.map(w => h('div', { class: 'win' },
    h('button', { class: 'wgo', onclick: () => { doIt({ a: 'win', h: w.h, do: 'focus' }); closeSheet(); toast('Listo, ' + (w.app || 'la ventana') + ' quedó adelante'); } }, w.icon ? h('img', { src: w.icon, alt: '' }) : h('span', { class: 'aic', html: svg('windows') }), h('span', {}, h('b', { text: w.t }), h('small', { text: w.app + (w.min ? ' · minimizada' : '') }))),
    h('button', { class: 'wx2', html: svg('x'), 'aria-label': 'Cerrar', onclick: async (e) => { e.currentTarget.closest('.win').remove(); await doIt({ a: 'win', h: w.h, do: 'close' }); } }))));
  sheet('Ventanas abiertas', r.list.length ? list : h('p', { class: 'muted', text: 'No hay ventanas abiertas.' }));
}
function confirmPower() {
  const b = (ic, n, cls, fn) => h('button', { class: 'pw ' + (cls || ''), html: svg(ic) + `<span>${n}</span>`, onclick: () => { closeSheet(); fn(); } });
  sheet('¿Qué hacemos con la compu?', h('div', { class: 'pws' },
    b('power', 'Apagar', 'danger', () => { doIt({ a: 'sys', name: 'shutdown' }); toast('Apagando la compu…'); }),
    b('restart', 'Reiniciar', '', () => { doIt({ a: 'sys', name: 'restart' }); toast('Reiniciando…'); }),
    b('moon', 'Suspender', '', () => { doIt({ a: 'sys', name: 'sleep' }); toast('Suspendiendo…'); }),
    b('x', 'Cancelar', 'ghost', () => {})));
}
function renderBar() {
  const items = [
    ['monitor', 'Mostrar Base', () => doIt({ a: 'show' }).then(() => toast('Base quedó adelante en la compu'))],
    ['windows', 'Ventanas', openWindows],
    ['folder', 'Archivos', () => doIt({ a: 'sys', name: 'explorer' }).then(() => toast('Abrí el Explorador en la compu'))],
    ['lock', 'Bloquear', () => doIt({ a: 'sys', name: 'lock' }).then(() => toast('Compu bloqueada'))],
    ['moon', 'Suspender', () => sheet('¿Suspender la compu?', h('div', { class: 'pws' }, h('button', { class: 'pw', html: svg('moon') + '<span>Suspender</span>', onclick: () => { closeSheet(); doIt({ a: 'sys', name: 'sleep' }); toast('Suspendiendo…'); } }), h('button', { class: 'pw ghost', html: svg('x') + '<span>Cancelar</span>', onclick: closeSheet })))],
    ['power', 'Apagar', confirmPower, 'danger']
  ];
  const bar = $('#bar'); bar.replaceChildren(...items.map(([ic, n, fn, cls]) => { const b = h('button', { class: 'bb ' + (cls || ''), html: svg(ic) + `<span>${n}</span>`, onclick: () => { if (!T.edit) { tap(b); fn(); } } }); return b; }));
  if (document.fullscreenEnabled && !document.fullscreenElement) bar.append(h('button', { class: 'bb mini', html: svg('full'), 'aria-label': 'Pantalla completa', onclick: () => document.documentElement.requestFullscreen().catch(() => {}) }));
}

// ----- modo Personalizar -----
const ADDS = [
  ['accesos', 'Accesos', 'grid4', { w: 2, h: 4 }], ['musica', 'Música y volumen', 'music', { w: 2, h: 3 }], ['volumen', 'Solo volumen', 'vol', { w: 2, h: 2 }],
  ['luz', 'Luz', 'bulb', { w: 2, h: 3 }], ['super', 'Supermercado', 'cart', { w: 1, h: 4 }], ['clima', 'Clima', 'sun', { w: 1, h: 2 }], ['atajos', 'Atajos rápidos', 'shot', { w: 2, h: 2 }]
];
const ACCENTS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6', '#64748b'];
function renderTray() {
  const tray = $('#tray');
  tray.hidden = !T.edit;
  if (!T.edit) return tray.replaceChildren();
  const L = layout();
  const lamps = (T.snap && T.snap.lamps) || [];
  const add = (t, extra) => editLayout(l => { l.blocks.push(Object.assign({ id: 'b' + Date.now().toString(36), t }, extra)); setTimeout(() => { const g = $('#grid'); g.scrollTop = g.scrollHeight; }, 50); });
  const chips = [];
  for (const [t, n, ic, sz] of ADDS) {
    if (t === 'luz' && lamps.length > 1) { for (const lp of lamps) chips.push(h('button', { class: 'tc', html: svg(ic) + `<span>+ ${esc(lp.n)}</span>`, onclick: () => add('luz', Object.assign({ lamp: lp.id }, sz)) })); continue; }
    chips.push(h('button', { class: 'tc', html: svg(ic) + `<span>+ ${n}</span>`, onclick: () => add(t, Object.assign({}, sz)) }));
  }
  chips.push(h('button', { class: 'tc', html: svg('plus') + '<span>+ Botón</span>', onclick: () => pickButton(add) }));
  const acc = h('div', { class: 'accs' }, ...ACCENTS.map(c => h('button', { class: 'acc' + ((L.accent || '') === c ? ' on' : ''), style: `--c:${c}`, onclick: () => editLayout(l => { l.accent = c; }) })),
    h('button', { class: 'acc auto' + (!L.accent ? ' on' : ''), text: 'Base', onclick: () => editLayout(l => { l.accent = ''; }) }));
  const sizes = h('div', { class: 'szs' }, ...[['s', 'Chicos'], ['m', 'Normales'], ['l', 'Grandes']].map(([k, n]) => h('button', { class: 'sz' + ((L.scale || 'm') === k ? ' on' : ''), text: n, onclick: () => editLayout(l => { l.scale = k; }) })));
  tray.replaceChildren(
    h('div', { class: 'trow' }, h('span', { class: 'tl2', text: 'Sumar' }), ...chips),
    h('div', { class: 'trow' }, h('span', { class: 'tl2', text: 'Color' }), acc, h('span', { class: 'tl2', text: 'Botones' }), sizes,
      h('button', { class: 'tc ghost', text: 'Volver al diseño original', onclick: () => editLayout(l => { Object.assign(l, DEFAULT()); }) })));
}
function pickButton(add) {
  const items = [];
  for (const x of (T.snap && T.snap.items) || []) { if (x.g) x.g.forEach(y => items.push(y)); else items.push(x); }
  sheet('¿Qué hace el botón?',
    h('div', { class: 'apps sheet-apps' }, ...ACTIONS.map(a => h('button', { class: 'app', onclick: () => { closeSheet(); add('boton', { ref: 'act:' + a.id, w: 1, h: 2 }); } }, h('span', { class: 'aic sys', html: svg(a.ic) }), h('span', { class: 'an', text: a.n }))),
      ...items.map(it => h('button', { class: 'app', onclick: () => { closeSheet(); add('boton', { ref: 'sc:' + it.id, w: 1, h: 2 }); } }, iconEl(it), h('span', { class: 'an', text: it.n })))));
}
// arrastrar bloques para ordenarlos
function startDrag(e, id) {
  e.preventDefault();
  const g = $('#grid'); const blk = g.querySelector(`.blk[data-id="${id}"]`);
  if (!blk) return;
  blk.classList.add('dragging');
  const ghost = blk.cloneNode(true); ghost.classList.add('ghost'); const rc = blk.getBoundingClientRect();
  Object.assign(ghost.style, { position: 'fixed', left: rc.left + 'px', top: rc.top + 'px', width: rc.width + 'px', height: rc.height + 'px', pointerEvents: 'none', zIndex: 50 });
  document.body.append(ghost);
  const ox = e.clientX - rc.left, oy = e.clientY - rc.top;
  let target = null;
  const move = (ev) => {
    ghost.style.left = (ev.clientX - ox) + 'px'; ghost.style.top = (ev.clientY - oy) + 'px';
    const over = document.elementsFromPoint(ev.clientX, ev.clientY).find(x => x.classList && x.classList.contains('blk') && !x.classList.contains('ghost') && x !== blk);
    for (const x of g.querySelectorAll('.blk.over')) x.classList.remove('over');
    target = over ? over.dataset.id : null;
    if (over) over.classList.add('over');
  };
  const up = () => {
    removeEventListener('pointermove', move); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
    ghost.remove(); blk.classList.remove('dragging');
    if (target) editLayout(l => { const a = l.blocks.findIndex(x => x.id === id), b = l.blocks.findIndex(x => x.id === target); const [it] = l.blocks.splice(a, 1); l.blocks.splice(b, 0, it); });
    else render(true);
  };
  addEventListener('pointermove', move); addEventListener('pointerup', up); addEventListener('pointercancel', up);
}

// ---------- arranque ----------
if (!KEY) showPair();
else { $('#app').hidden = false; poll(); }
setInterval(poll, 1500);
setInterval(() => { tickClock(); for (const f of T.upd) { try { f(); } catch {} } }, 1000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
addEventListener('resize', () => render(false));
// la pantalla queda prendida mientras se usa el panel (si el navegador lo permite)
async function wake() { try { if (navigator.wakeLock) T.wl = await navigator.wakeLock.request('screen'); } catch {} }
document.addEventListener('visibilitychange', () => { if (!document.hidden) wake(); });
wake();
})();
