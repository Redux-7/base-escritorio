const { contextBridge, ipcRenderer, webUtils } = require('electron');
let edition = { edicion: 'completa' };
try { edition = Object.assign(edition, JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'edicion.json'), 'utf8'))); } catch {}

contextBridge.exposeInMainWorld('baseApi', {
  load: () => ipcRenderer.invoke('data:load'),
  save: (data) => ipcRenderer.send('data:save', data),

  minimize: () => ipcRenderer.send('win:minimize'),
  hide: () => ipcRenderer.send('win:hide'),
  quit: () => ipcRenderer.send('app:quit'),

  pickTarget: (kind) => ipcRenderer.invoke('shortcut:pick', kind),
  iconFor: (target) => ipcRenderer.invoke('shortcut:icon', target),
  open: (item) => ipcRenderer.invoke('shortcut:open', item),
  pathForFile: (file) => {
    try { return webUtils.getPathForFile(file); } catch { return ''; }
  },

  pickBackground: () => ipcRenderer.invoke('bg:pick'),
  applySettings: (s) => ipcRenderer.invoke('settings:apply', s),
  panel: {
    info: () => ipcRenderer.invoke('panel:info'),
    reset: () => ipcRenderer.invoke('panel:reset'),
    push: (snap) => ipcRenderer.send('panel:snap', snap),
    reply: (id, r) => ipcRenderer.send('panel:reply', id, r),
    onDo: (cb) => ipcRenderer.on('panel:do', (_e, m) => cb(m))
  },
  luces: {
    scan: () => ipcRenderer.invoke('luces:scan'),
    cloud: (cid, secret, region) => ipcRenderer.invoke('luces:cloud', cid, secret, region),
    detect: (l) => ipcRenderer.invoke('luces:detect', l),
    status: (l) => ipcRenderer.invoke('luces:status', l),
    act: (l, a) => ipcRenderer.invoke('luces:do', l, a),
    scenes: () => ipcRenderer.invoke('luces:scenes')
  },
  update: {
    check: () => ipcRenderer.invoke('update:check'),
    install: () => ipcRenderer.invoke('update:install'),
    info: () => ipcRenderer.invoke('update:info'),
    onAvailable: (cb) => ipcRenderer.on('update:available', (_e, d) => cb(d)),
    onProgress: (cb) => ipcRenderer.on('update:progress', (_e, d) => cb(d))
  },
  displays: () => ipcRenderer.invoke('displays:list'),
  setDisplay: (id) => ipcRenderer.invoke('displays:set', id),
  notify: (title, body) => ipcRenderer.send('notify', { title, body }),
  floatNotify: (n) => ipcRenderer.send('fnotif:show', n),
  floatPlayer: (site, pref) => ipcRenderer.invoke('player:float', site, pref),
  browsers: () => ipcRenderer.invoke('browsers:list'),
  waBounds: (r) => ipcRenderer.invoke('wa:bounds', r),
  waReload: () => ipcRenderer.invoke('wa:reload'),
  dealsEpic: () => ipcRenderer.invoke('deals:epic'),
  onFloatOpen: (cb) => ipcRenderer.on('fnotif:open', (_e, id) => cb(id)),
  get: (url) => ipcRenderer.invoke('net:get', url),
  openUrl: (url) => ipcRenderer.invoke('shortcut:open', { type: 'web', target: url }),

  onModeSet: (cb) => ipcRenderer.on('mode:set', (_e, m) => cb(m)),
  onSearch: (cb) => ipcRenderer.on('search:open', () => cb()),
  recentFiles: () => ipcRenderer.invoke('files:recent'),
  article: (url) => ipcRenderer.invoke('news:article', url),
  smallIcon: (p) => ipcRenderer.invoke('icon:for', p),
  google: {
    status: () => ipcRenderer.invoke('google:status'),
    setConfig: (id, secret) => ipcRenderer.invoke('google:setConfig', id, secret),
    link: (mode) => ipcRenderer.invoke('google:link', mode),
    unlink: (mode) => ipcRenderer.invoke('google:unlink', mode),
    events: (mode, from, to) => ipcRenderer.invoke('google:events', mode, from, to),
    createEvent: (mode, ev) => ipcRenderer.invoke('google:createEvent', mode, ev),
    deleteEvent: (mode, id) => ipcRenderer.invoke('google:deleteEvent', mode, id),
    mail: (mode) => ipcRenderer.invoke('google:mail', mode),
    message: (mode, id) => ipcRenderer.invoke('google:message', mode, id),
    markRead: (mode, ids) => ipcRenderer.invoke('google:markRead', mode, ids),
    cardMails: (mode, q, skip, days) => ipcRenderer.invoke('google:cardMails', mode, q, skip, days),
    openMail: (email, thread) => ipcRenderer.invoke('open:mail', email, thread),
    open: (url) => ipcRenderer.invoke('open:google', url)
  },
  taskbar: () => ipcRenderer.invoke('taskbar:list'),
  systemShortcuts: () => ipcRenderer.invoke('system:shortcuts'),
  games: () => ipcRenderer.invoke('games:list'),
  startApps: (force) => ipcRenderer.invoke('apps:start', force),
  launchSpecial: (kind, id) => ipcRenderer.invoke('launch:special', kind, id),
  media: {
    state: () => ipcRenderer.invoke('media:state'),
    key: (k) => ipcRenderer.invoke('media:key', k),
    vol: () => ipcRenderer.invoke('vol:get'),
    volSet: (v) => ipcRenderer.invoke('vol:set', v),
    volMute: (on) => ipcRenderer.invoke('vol:mute', on),
    sessions: () => ipcRenderer.invoke('media:sessions'),
    thumb: (app) => ipcRenderer.invoke('media:thumb', app),
    act: (app, act, val) => ipcRenderer.invoke('media:do', app, act, val)
  },
  windows: {
    list: () => ipcRenderer.invoke('win:list'),
    act: (action, h) => ipcRenderer.invoke('win:do', action, h),
    system: (name) => ipcRenderer.invoke('sys:action', name)
  },
  edition,
  stats: (detail) => ipcRenderer.invoke('sys:stats', !!detail),
  openDrive: (name) => ipcRenderer.invoke('sys:openDrive', name),
  luma: (src) => ipcRenderer.invoke('img:luma', src),
  dock: { find: (n) => ipcRenderer.invoke('dock:find', n), pick: () => ipcRenderer.invoke('dock:pick'), bounds: (b) => ipcRenderer.invoke('dock:bounds', b), release: () => ipcRenderer.invoke('dock:release'), state: () => ipcRenderer.invoke('dock:state'), windows: () => ipcRenderer.invoke('dock:windows'), adopt: (h) => ipcRenderer.invoke('dock:adopt', h) },
  fx: {
    places: () => ipcRenderer.invoke('fx:places'), list: (d, h) => ipcRenderer.invoke('fx:list', d, h), peek: (p) => ipcRenderer.invoke('fx:peek', p), thumb: (p) => ipcRenderer.invoke('fx:thumb', p),
    icon: (p) => ipcRenderer.invoke('fx:icon', p), open: (p) => ipcRenderer.invoke('fx:open', p), reveal: (p) => ipcRenderer.invoke('fx:reveal', p),
    winExplorer: (p) => ipcRenderer.invoke('fx:winexplorer', p), trash: (l) => ipcRenderer.invoke('fx:trash', l), rename: (p, n) => ipcRenderer.invoke('fx:rename', p, n),
    mkdir: (d, n) => ipcRenderer.invoke('fx:mkdir', d, n), paste: (l, d, mv) => ipcRenderer.invoke('fx:paste', l, d, mv), copyPath: (p) => ipcRenderer.invoke('fx:copypath', p)
  },
  sm: { apps: (f) => ipcRenderer.invoke('sm:apps', f), icon: (p) => ipcRenderer.invoke('sm:icon', p), open: (it) => ipcRenderer.invoke('sm:open', it), recent: () => ipcRenderer.invoke('sm:recent') },
  photos: { pick: () => ipcRenderer.invoke('photos:pick'), list: (dir) => ipcRenderer.invoke('photos:list', dir), show: (url) => ipcRenderer.invoke('photos:show', url) },
  backup: {
    export: (data, opts) => ipcRenderer.invoke('backup:export', data, opts),
    pick: () => ipcRenderer.invoke('backup:pick'),
    pending: () => ipcRenderer.invoke('backup:pending'),
    dismiss: () => ipcRenderer.invoke('backup:dismiss'),
    apply: (which, current) => ipcRenderer.invoke('backup:apply', which, current)
  },
  clearSocial: () => ipcRenderer.invoke('redes:clear'),
  locate: () => ipcRenderer.invoke('geo:locate'),
  ready: () => ipcRenderer.send('app:ready'),
  reportError: (msg) => ipcRenderer.send('app:error', String(msg)),
  platform: process.platform
});
